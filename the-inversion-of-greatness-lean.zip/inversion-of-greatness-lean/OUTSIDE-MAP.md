# Outside-half map: Chapters 7–12

Which results in Chapters 7–12 have a deductive skeleton checked in Lean, what each rests on, and what stays in the manuscript.

`Outside/Modal` and `Outside/NoBeyond` check the 15 spine results at the scope listed below, and `Capstone` combines Appendix B line 14 with selected outside results using one Reality–Nature identity and coverage package. The fork itself covers *No unconditioned ground*, the *Grounding-Contact Trilemma* and *No Way Possible*. *Isolation is not separation*, *The Missing Clause* and *No Concrete Emergence from Non-Time* are included in `Outside/NoBeyond`; the first and third carry a countermodel for the premise each adds. Tier B is organized by chapter in `Outside/Attributes` (Chapter 11), `Outside/ClassicalGrounds` (Chapter 10) and `Outside/Rivals` (Chapters 7–9). Results left in the manuscript are listed per batch below, with the reason.

## The finding

The outside half is one argument applied many times. Nearly every closure in Chapters 7–11 runs the same three-way fork on a proposed rival to Nature:

1. **Concrete, or doing concrete work.** Then it is T, S and Φ in operation, so it is inside Nature.
2. **Determinate but abstract or atemporal.** Then it is Nature's own structure or modal standing, or it depends on what it was meant to ground.
3. **No determinate content.** Then it has no determinate way to be, so it is not possible.

The inside half already holds the pieces as Lean inputs: `univocalExistence`, `concreteNonAddition` and `abstractaFork` (Identity), `possibleMeansThereIsAWay` (NullState) and `realityIsNature` (Identity). So the outside half is **one generic theorem, proved once, with each rival as a short instance**. Each instance then adds only its own premise: why this rival falls on the branch it does.

Reusing the Chapter 2 coverage package ties references to Reality, Nature and real content to the same definitions and inputs. Item-level conditions and candidate modality have their own parameters. The [premise ledger](PREMISES.md) records their scope.

## Tier A: the spine

Module `Outside/NoBeyond`: one generic theorem, then these as instances.

| Result | Section | Branches used | Inside results it rests on |
| --- | --- | --- | --- |
| *Concrete work incurs the conditions* | §2.4 | 1, 2, 3 | The manuscript draws on line 10 and separate criteria for the roles at concrete operations (§2.4.7). Lean supplies the change-token statement as an item-level premise. |
| *No unconditioned ground* | §2.9 | 2 | Abstracta Fork, Concreteness Fork, Univocity of Existence |
| *No Unconditioned Essence* (coverage clauses) | §7.2.1 | 2, 3 | Lean locates real items in Nature under the supplied fork. The bearer and explanatory-priority claims remain in the manuscript. |
| *Isolation is not separation* | §7.2.3 | 2 | *What tells things apart is structure*, *Reality is Nature* |
| *The Missing Clause* | §7.2.5 | 2, 3 | *Grounding requires differentiated terms*, No-Individuating-Surplus Criterion |
| *No Concrete Emergence from Non-Time* | §8.1.2 | 1, plus a formal-or-concrete fork | Transition Closure, Real Transformation Closure, Framework-Invariance, *Concrete work incurs the conditions* |
| *Grounding-Contact Trilemma* | §10.4 | 1, 2, 3 | All three spine inputs |
| *No Outside Selector* (coverage clauses) | §10.4 | 1, 2, 3 | Lean checks the work, coverage, and possibility clauses. The distinction between selecting a subconfiguration and explaining total actuality remains in the manuscript. |
| *Aseity Forfeiture* | §11.1 | 1 | *To exist is to occupy time, space, and substance*, *Nature is time, space, and substance* |
| *No Divine Addition* | §11.10 | 1, 2, 3 | Actuality, *Necessity entails Possibility*, *Possible means there is a way*, *Reality is Nature*, *No Unconditioned Essence*, *What tells things apart is structure* |
| *No Supernature* | §11.10 | 1, 2, 3 | *No Divine Addition*, *No Outside Selector*, *Nothing never was and never could be* |
| *No Way Possible* | §11.10 | 3 | *Possible means there is a way* |
| *The contentless God has no referent* (concrete-work case) | §11.10 | 1, 3 | Lean assumes modeled agency is concrete work and rules out a withdrawn agent among the supplied ways. |
| *The Modal Ontological Reductio* (concrete-work case) | §10.1.1 | 1, 3 | Lean assumes the modeled personal powers are concrete work. Each definition inherits the same withdrawal predicate. |
| *No Creator of Nature* (scoped cases) | §11.10 | 1, 2 | Lean takes withdrawal at the onset as a premise and uses asymmetric strict ground for the sustaining cases. The separate question of passing from an absent source to an onset remains in the manuscript. |

## Tier A: modal logic (a second module, with real countermodels)

Module `Outside/Modal`: a small possible-worlds semantics. Most of the inside half's theorems are short chains of inference. These results carry real logical content, and several of them are claims that something does **not** follow, which only a countermodel can confirm.

| Result | Section | What Lean checks |
| --- | --- | --- |
| *Possibility-Premise Burden* | §10.1.1 | In S5, ◇□G gives □G, and S5 alone settles neither ◇□G nor ◇□¬G: two models, one each way. |
| *Necessary abstracta need a possibility premise* (S5 Parity) | §8.1.5 | ◇□A and ◇□¬A cannot both hold in S5, and S5 does not choose between them. Shares its proof with the row above. |
| *No Rescue by Changing the Modal Logic* | §10.1.1 | Without axiom 5, ◇□G does not give □G: a countermodel. |
| *Constitutive Grounding Non-Propagation* | §8.2.5 | □P and □(P → Q) give □Q, but □(T ∧ S ∧ Φ) together with □(full ground → change) does not give □(change): a countermodel. This checks the book's own scope claim that no particular change follows. |
| *Whatever makes possibility vary is necessary* | §7.2.1 | Over a frame where every world sees every world, possibility cannot vary between evaluations; variation needs a restricted frame. Links to the inside half's `oneRange`. |
| *Restriction adds nothing* | §7.3.1 | A modal base that selects a subset of genuine alternatives introduces no alternative outside the domain. |
| *The Modal Trilemma* | §7.2.1 | Exhaustive three-way modal classification, from *Every claim is possible or not*. |

## Tier B: chapter instances

These follow the same fork. Each adds only its own per-branch premises: why each branch lands where the chapter says.

- **Chapter 11 attributes (24 disjunctions):** *Unboundedness requires a dimension* (Infinity), *Maximizing leaves no bearer* (Perfection), *Timeless or Everlasting* (Eternity), *The Creation Trilemma* and *The Eternal-Truths Dilemma* (Omnipotence), *The Creator-Relation Trilemma* (Causality), *The Decree Trilemma* (Sovereignty), *The Present Trilemma* (Presence), *The Immanence Dilemma* (Relatability), *Omniscience is reflexive*, *The Discriminating-Content Burden* (Simplicity), *The Predicate-Content Dilemma*.
- **Chapter 10 classical grounds:** *Three concessions for active power*, *No Third Option Between Contrastive and Empty*, *Subsistence is Nature's too*, *One unchanging act discriminates nothing*, *A beginning needs what it would begin*, *The Sustenance Fork*, *The Divine Causation Trilemma*, *The Creation Fork*, *The Three Grounds Trilemma*, *No corner is empty of structure*.
- **Chapter 7–9 rivals:** *The Bearer Problem* and *No Exit for the Powers Base* (dispositionalism), *Concrete Relata, Non-Concrete Seam*, *Being, Not Concreteness*, *Abstraction lands on its base*, *The form runs downstream*, *Resumption requires a bearer*, *Conditions on There Being a Mind* (the Idealist Inversion), *The substrate must differentiate too*.

## Tier B, Chapter 11: what went in and what stayed out (2026-11-21)

In `Outside/Attributes`: *Unboundedness requires a dimension*, *The Discriminating-Content Burden*, *The Predicate-Content Dilemma*, *The Creation Trilemma*, *The Creator-Relation Trilemma*, *Omniscience is reflexive* and *The Present Trilemma*. Each branch lands on the fork, or (Creation) on the box's own named exit, modal collapse; Omniscience is a short chain, and Presence lands its middle branch on spatiality.

Left in the manuscript: *Timeless or Everlasting*, *Maximizing leaves no bearer*, *The Eternal-Truths Dilemma*, *The Decree Trilemma* and *The Immanence Dilemma*. Each shows that no branch keeps the doctrine's full set of commitments (coherence and scope, decree and freedom, transcendence and mutuality). In Lean that is only "each branch drops one commitment, so not all hold": the premises carry the whole result and the proof checks nothing beyond the case split.

## Tier B, Chapter 10: what went in and what stayed out (2026-11-21)

In `Outside/ClassicalGrounds`: *No Third Option Between Contrastive and Empty*, *Subsistence is Nature's too*, *The Creation Fork*, *The Three Grounds Trilemma* and *No corner is empty of structure*. None needs any axiom.

Covered elsewhere: *A beginning needs what it would begin* is the first conclusion of `noCreatorOfNature`. *Three concessions for active power* and *One unchanging act discriminates nothing* are the input to the pure-act branch of *Subsistence is Nature's too* (`threeConcessions`); on their own they split commitments and conclude nothing Lean could check.

Left in the manuscript: *The Sustenance Fork* (necessary sustaining gives up this order's contingency; contingent sustaining hands the question to the three concessions) and *The Divine Causation Trilemma*, which classifies God's causal share and states that it establishes no divine role.

## Tier B, Chapters 7–9: what went in and what stayed out (2026-11-21)

In `Outside/Rivals`: *No Exit for the Powers Base*, *The form runs downstream*, *Conditions on There Being a Mind* and *The substrate must differentiate too*. None needs any axiom. In the substrate result Lean shows the substrate is temporal in both modes of producing, matching the box: only the temporality of the constituting relation itself stays open.

Left in the manuscript: *The Bearer Problem* (deny □◇C, or rest the deepest modal fact on an absence) and *Being, Not Concreteness* (the residue survives unless modal collapse) end in a choice of commitments; *Concrete Relata, Non-Concrete Seam* calls itself diagnostic; *Resumption requires a bearer* is one premise and its consequence; *Abstraction lands on its base* would restate its premises as its conclusion.

## Out of Lean: argument from evidence or judgment

These are real arguments, but their force lies in weighing evidence, probability or moral judgment rather than in a deductive step. Formalizing them would put the whole argument into one hypothesis and check nothing.

- **Chapter 9's mind and science results** (hard problem, illusionism, effectiveness of mathematics, structural realism), apart from the Tier B instances above.
- **Chapter 10's evidential arguments:** fine-tuning, design, moral, beauty, religious experience and miracles, Pascal's Wager, degrees of perfection, simplicity as parsimony. *Probability rides on modality* (§10.1.9) could later connect to the modal module, but the probabilistic part stays out.
- **Chapter 12, nearly all:** its 46 disjunctions test doctrines against moral and evidential standards. *Every reply must be carried through* is a discipline for the ledger rather than a theorem to formalize. A few forks are inconsistent triads (*No branch keeps all three*, §12.1.6). Lean can confirm the inconsistency, but the moral premises carry everything, so the gain is small.

Every premise introduced by the modules above is recorded in [PREMISES.md](PREMISES.md).
