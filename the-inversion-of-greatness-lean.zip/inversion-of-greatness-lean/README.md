# Inversion of Greatness Lean

One Lean project for selected deductive arguments from the book. Lean is a proof checker: it confirms that each conclusion follows from the premises stated for it, with no step skipped. It does not show that the premises are true. That question stays with the manuscript, and [PREMISES.md](PREMISES.md) records each premise, its source and its status.

## Shape

The book closes Nature off from the inside (Chapters 1–4) and closes it against anything outside (Chapters 7–12). The capstone combines Appendix B line 14 with selected conclusions about what lies within Nature.

| Module | Book | State |
| --- | --- | --- |
| `Basic` | Shared vocabulary: necessity and the three conditions | Done |
| `Inside/Necessity` | Appendix B lines 1–11, and §2.4.6 *From Movement* | Done |
| `Inside/Identity` | Appendix B line 13, §2.8.3. Line 12’s naming equality is a stated input. | Done |
| `Inside/WholeLine` | Appendix B line 14 | Done |
| `Inside/NullState` | §3.2.6, No-World Reductio | Done |
| `Inside/Cycle/PhaseClosure` | §4.6.5, Finite Reversible Phase Closure | Done |
| `Inside/Cycle/DominanceCrossing` | §4.6.5, Integrated Dominance Crossing | Done |
| `Inside/Cycle/Bridge` | §4.6.5: the crossing gives the expansion → contraction edge of the phase order | Done |
| `Outside/Modal` | Chapters 7, 8 and 10: S5 transfer and parity, no rescue without symmetry, Non-Propagation, invariance, restriction | Done |
| `Outside/NoBeyond` | Chapters 2, 7, 10 and 11: the three-way fork, then *No Divine Addition*, *No Supernature*, concrete-work versions of the contentless-God and modal ontological arguments, *Aseity Forfeiture*, and scoped cases of *No Creator of Nature* | Done |
| `Outside/Attributes` | Chapter 11: seven attribute closures (Infinity, Simplicity, predicate content, Creation, the Creator relation, Omniscience, Presence) | Done |
| `Outside/ClassicalGrounds` | Chapter 10: eminent content, subsistence, the Creation Fork, grounds of logic, the catuṣkoṭi | Done |
| `Outside/Rivals` | Chapters 7–9: the powers base, Platonic Forms, a grounding mind, a cosmic substrate | Done |
| `Formal/CrossingAmbiguity` | Appendix F, *Exponential Crossing Ambiguity*: the family count (2^m − 2 registrations, shared shadows, 2^(m−1) − 1 classes) for every m; the maximality clause is not formalized | Done |
| `Capstone` | Appendix B line 14 and selected outside results, with shared Reality–Nature premises | Done |

The capstone uses one Reality–Nature identity and coverage package across both halves. The predicates for time, space, and substance at an evaluation and at a concrete operation are separate inputs. `theInversionOfGreatnessJoined` relates them through `Realization` (§§2.4.7, 2.6.8, 2.6.10): the actual witness and every concrete work realize the evaluation-level conditions where they occur. Its conclusion about the contentless-God description uses a separately supplied `isWay` predicate. The premise ledger records these modeling limits.

Only results with a deductive skeleton belong here. The ethics and politics chapters, and argument that rests on judgment, stay in the manuscript.

## Working rules

- Philosophical premises enter as named hypotheses or structure fields, never as `axiom` and never as `sorry`.
- Each new hypothesis gets a ledger row in the same change: Defined, Argued for or Open, with its manuscript link.
- A countermodel showing that a premise is needed is as valuable as a proof. Keep them as `example`s beside the theorem.
- Each file ends with `#print axioms` for its main theorems. Only Lean's standard `propext`, `Classical.choice` and `Quot.sound` should appear.

## Check the proofs

Install Elan, Lean's toolchain manager ([official instructions](https://lean-lang.org/install/)). On Windows, unpack this folder to a short path such as `C:\lean`: Mathlib’s file paths are long, and inside a deeply nested folder the first download can fail with a git error. Then, from this folder:

```text
lake exe cache get
lake build
```

`lean-toolchain` pins Lean 4.8.0, and `lakefile.lean` pins Mathlib v4.8.0 to match. The first command downloads Mathlib's prebuilt files, so the build doesn't compile Mathlib from source. A clean build ends without errors and prints the axiom lists.

## Toy scalar-field cycle

[Run the interval calculation and its generated Lean check](experiments/toy-cycle/README.md). This experiment uses its own physical model inputs.

## License

Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0), matching the book and archival deposit.
