# Toy scalar-field cycle

This check follows a whole range of outgoing states through a gradual shift to overall contraction dominance, the later bounce at maximal compression, and reheating. It proves that every returned state is inside the outgoing range for the specified homogeneous model. The global sign change describes which regime dominates overall. The homogeneous calculation has no variables for individual structures or local gravitational contraction.

The calculation adapts the quadratic kinetic model in [An et al., equations 34–37](https://arxiv.org/pdf/2010.13287). The positive plateau and effective reheating law are choices for this experiment. A physical application would require evidence that the actual dynamics restore such a range.

## Reproduce the check

From the root of the Lean project, run:

```text
node experiments/toy-cycle/check.cjs
node experiments/toy-cycle/check.cjs --check-lean
```

The first command runs the interval calculation and prints its bounds as JSON. The second runs the same calculation, passes its bounds to `lake env lean --stdin` as exact rational numbers, and exits with an error if either check fails. Use the [project setup](../../README.md#check-the-proofs) for Lean and Mathlib. This was tested with Node 24.15.0, Lean 4.8.0, and Mathlib v4.8.0. The JavaScript has no package dependencies. To inspect the generated Lean source on its own, run:

```text
node experiments/toy-cycle/check.cjs --lean
```

## Pinned model

Time is scaled by `1/10000` and densities by `10^8`. Let `v` be the field velocity and `X = v²/2`. The coefficients, potential, and Friedmann constraint are:

```text
Q = (1 + phi²/2)^(-2)
K = 1 - 2Q
V = 10^-7 - 0.01 sech(sqrt(20) phi)
3H² = K X + 3Q X² + V + radiation
```

The plateau is `10^-15` in unscaled reduced Planck density units. The evolution equations are:

```text
d(phi)/dt = v
d(v)/dt = [-3Hv(K + 2QX) - K_phi X - 3Q_phi X² - V_phi - Gamma v] / (K + 6QX)
d(H)/dt = -X(K + 2QX) - 2 radiation/3
d(radiation)/dt = -4H radiation + Gamma v²
```

During overall expansion with `phi*v > 0`, let `u = abs(phi) - 3`. For `0 < u < 1`, set `Gamma = 0.16 u²(1-u)²`. Everywhere else set `Gamma = 0`. The starting section is `phi = 4.2` with positive velocity and the positive Friedmann root. The input speed and radiation density vary independently by ±3% around `0.0031284101` and `0.00001382131568`. Reflection of both `phi` and `v` preserves the equations and identifies the opposite outgoing section with the starting section.

## How the check works

- On the first uphill leg to `phi = 4.7` and the final leg through reheating, the code uses outward-rounded Picard enclosures and second-order Taylor bounds for the two evolving quantities. The mean-value form keeps the correlation between the state and its first derivative. Each square-root bound is checked by squaring. Exponentials use a bounded Taylor remainder and repeated squaring.
- On the outward excursion beyond `4.7`, `K` and `V` increase and `Q` decreases. The signs in the field equation give at least `2.5 H` damping. The field therefore stays in a finite interval while climbing. The positive potential slope has a positive lower bound there and forces the field velocity through zero. The same slope makes the field descend. The checked speed barrier on the descent provides a minimum travel time and a radiation dilution bound before `phi = 4.6`. A lower acceleration bound on the final part of that descent gives the lower speed bound needed at `4.6`.
- The next two sections use the decreasing field coordinate and scalar comparison. For a fixed radiation history, scalar flows preserve order, so enclosing the two endpoint flows covers all intervening data. The radiation bounds hold through expansion and are checked by a growth bound through the onset of overall contraction. On the negative part of the potential the positive kinetic root of the Friedmann constraint lets the calculation evolve `H` continuously across zero.
- At the high-density bounce, the interval calculation encloses every possible zero of `H` where its time derivative is positive. The outgoing calculation then uses the reflected field coordinate through reheating to `phi = -4.2`. The checked speed and radiation bounds are strictly inside the input range. Each cycle includes an uphill leg of at least 150 scaled time units, which rules out accumulation of cycles at a finite future time.
- The JavaScript checks the ODE enclosures and the numerical inequalities supporting the analytic steps. The generated Lean proof takes the return enclosures as inputs and checks their containment and iteration. It uses the exact binary endpoint values as rational numbers, so decimal rendering cannot change the bounds.

