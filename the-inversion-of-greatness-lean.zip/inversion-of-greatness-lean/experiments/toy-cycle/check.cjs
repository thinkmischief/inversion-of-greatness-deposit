"use strict";

const { spawnSync } = require("node:child_process");
const { existsSync, mkdtempSync, rmdirSync, unlinkSync, writeFileSync } = require("node:fs");
const { tmpdir } = require("node:os");
const { join, resolve } = require("node:path");

// See README.md for the model, proof obligations, and commands.
const bits=new DataView(new ArrayBuffer(8));
// Round an IEEE-754 result outwards by stepping to its adjacent bit pattern.
function up(x) {
  if(!Number.isFinite(x)) throw Error("nonfinite interval bound");
  if(x===0) return Number.MIN_VALUE;
  bits.setFloat64(0,x);
  bits.setBigUint64(0,bits.getBigUint64(0)+(x>0?1n:-1n));
  return bits.getFloat64(0);
}
const down=x=>-up(-x);
const exact=x=>[x,x];
const dec=x=>[down(x),up(x)];
const add=([a,b],[c,d])=>[down(a+c),up(b+d)];
const sub=([a,b],[c,d])=>[down(a-d),up(b-c)];
const mul=([a,b],[c,d])=>{const p=[a*c,a*d,b*c,b*d];return [down(Math.min(...p)),up(Math.max(...p))]};
const div=(x,[c,d])=>{if(c<=0&&d>=0)throw Error("division interval crosses zero");return mul(x,[down(1/d),up(1/c)])};
const sq=([a,b])=>[a<=0&&b>=0?0:Math.max(0,down(Math.min(a*a,b*b))),up(Math.max(a*a,b*b))];
const sqrt=([a,b])=>{
  if(a<=0)throw Error("nonpositive radicand");
  let low=down(Math.sqrt(a)),high=up(Math.sqrt(b));
  while(up(low*low)>a)low=down(low);
  while(down(high*high)<b)high=up(high);
  return [low,high];
};
const hull=(x,y)=>[Math.min(x[0],y[0]),Math.max(x[1],y[1])];
const subset=(x,y)=>y[0]<x[0]&&x[1]<y[1];
const inflate=([a,b])=>{
  const guard=up(Math.max(1e-30,up(b-a)/8));
  return [down(a-guard),up(b+guard)];
};
function expPos(x){
  if (x[0] < 0 || x[1] > 32) throw Error("exponential argument outside validated Taylor range");
  const u=div(x,exact(32));
  u[0]=Math.max(0,u[0]);
  let term=exact(1), sum=exact(1);
  for(let n=1;n<=20;n++){
    term=div(mul(term,u),exact(n));
    sum=add(sum,term);
  }
  const next=div(mul(term,u),exact(21));
  // For 0 <= u <= 1 and terms after the 21st, each term is at most 1/22 of the preceding one.
  sum=add(sum,[0,up(2*next[1])]);
  for(let n=0;n<5;n++)sum=sq(sum);
  return sum;
}
const one=exact(1), two=exact(2), three=exact(3), four=exact(4), six=exact(6);
const scaleV=dec(.01), plateau=dec(1e-7), lambda=sqrt(exact(20));
function onFieldRange(phi){
  const f=add(one,div(sq(phi),two));
  const Q=div(one,sq(f));
  const Qp=div(mul(exact(-2),phi),mul(sq(f),f));
  const K=sub(one,mul(two,Q));
  const Kp=mul(exact(-2),Qp);
  const arg=mul(lambda,phi);
  const expAny = x => x[0]>=0 ? expPos(x) :
    x[1]<=0 ? div(one,expPos([-x[1],-x[0]])) :
    hull(div(one,expPos([0,-x[0]])),expPos([0,x[1]]));
  const ef=expAny(arg), eb=div(one,ef), esum=add(ef,eb);
  const well=div(mul(two,scaleV),esum);
  const V=sub(plateau,well);
  const Vp=div(mul(mul(lambda,well),sub(ef,eb)),esum);
  return {K,Kp,Q,Qp,V,Vp};
}

const zero=exact(0);
function radiationGamma(phi){
  const lo=Math.max(0,sub(phi,three)[0]), hi=Math.min(1,sub(phi,three)[1]);
  if (hi<=lo)return zero;
  const u=[lo,hi];
  const gamma=mul(dec(.16),sq(mul(u,sub(one,u))));
  return [phi[0]<3||phi[1]>4?0:gamma[0],gamma[1]];
}
function outgoingRates(c, gamma, [X,R]) {
  R=[Math.max(0,R[0]),R[1]];
  const {K,Kp,Q,Qp,V,Vp}=c;
  const v=sqrt(mul(two,X));
  const H=sqrt(div(add(add(add(mul(K,X),mul(mul(three,Q),sq(X))),V),R),three));
  const pureKinetic=add(K,mul(mul(two,Q),X));
  const force=add(add(Vp,mul(Kp,X)),mul(mul(three,Qp),sq(X)));
  const loss=mul(add(mul(mul(three,H),pureKinetic),gamma),v);
  return [
    div(sub(zero,add(force,loss)),add(K,mul(mul(six,Q),X))),
    sub(mul(gamma,v),div(mul(mul(four,H),R),v))
  ];
}

// A scalar ODE preserves order for a fixed history of the other inputs.
// Enclose the two endpoint flows using Picard tubes, including all values
// of those other inputs in the differential inclusion used for the tubes.
function lowerUpperPointStep(bracket, h, calc) {
  let startBounds, endBounds;
  const output=[], acceptedTubes=[];
  for(const x of bracket) {
    const point=exact(x);
    let tube=inflate(hull(point,add(point,mul([0,h],calc(point)))));
    let closed=false;
    for(let j=0;j<18;j++){
      const slope=calc(tube);
      const image=add(point,mul([0,h],slope));
      if(subset(image,tube)){
        const end=add(point,mul(exact(h),slope));
        output.push(end); acceptedTubes.push(tube); closed=true; break;
      }
      tube=inflate(hull(tube,image));
    }
    if(!closed)throw Error("no Picard enclosure");
  }
  calc(hull(acceptedTubes[0],acceptedTubes[1]));
  return [output[0][0],output[1][1]];
}
const rad=[0,up(1e-100)];
function downhillExpanded(den) {
  const h=1/den;
  let phi=dec(4.6);
  let X=div(sq([down(4e-8),up(3e-7)]),two), minX=X[0], minH=Infinity;
  for(let i=0;i<17*den/8;i++){
    const next=sub(phi,exact(h)), c=onFieldRange(hull(phi,next));
    const {K,Kp,Q,Qp,V,Vp}=c;
    try {
      const f = x=>{
        const y=sqrt(mul(two,x));
        const H=sqrt(div(add(add(add(mul(K,x),mul(mul(three,Q),sq(x))),V),rad),three));
        minH=Math.min(minH,H[0]);
        const force=add(add(Vp,mul(Kp,x)),mul(mul(three,Qp),sq(x)));
        const damping=mul(mul(mul(three,H),y),add(K,mul(mul(two,Q),x)));
        return div(sub(force,damping),add(K,mul(mul(six,Q),x)));
      };
      X=lowerUpperPointStep(X,h,f);
      minX=Math.min(minX,X[0]);
      phi=next;
    }catch(e){return {i,den,phi,X,minX,minH,reason:e.message}};
  }
  const {K,Q,V}=onFieldRange(phi);
  const H=sqrt(div(add(add(add(mul(K,X),mul(mul(three,Q),sq(X))),V),rad),three));
  return {den,phi,X,H,minX,minH};
}

function downhillThroughCrossover(enter,den) {
  let {phi,H}=enter;
  const h=1/den, radiation=[0,up(1e-90)];
  let minX=Infinity, attenuationWorst=0;
  for(let i=0;i<11*den/8;i++){
    const next=sub(phi,exact(h)), c=onFieldRange(hull(phi,next));
    const {K,Q,V}=c;
    try {
      const f = rate=>{
        const D=sub(sub(mul(three,sq(rate)),V),radiation);
        if(D[0]<=0)throw Error("could not isolate X");
        const P=sqrt(add(sq(K),mul(mul(exact(12),Q),D)));
        const X=div(mul(two,D),add(P,K));
        const y=sqrt(mul(two,X));
        minX=Math.min(minX,X[0]);
        attenuationWorst=Math.max(attenuationWorst,div(mul(exact(-4),rate),y)[1]);
        const derivative=sub(sub(exact(0),mul(X,add(K,mul(mul(two,Q),X)))),
          mul(div(two,three),radiation));
        return div(derivative,y);
      };
      H=lowerUpperPointStep(H,h,f);
      phi=next;
    }catch(e){return {i,den,phi,H,minX,attenuationWorst,reason:e.message}};
  }
  return {den,phi,H,minX,attenuationWorst};
}

const p2_3=div(two,three), twelve=exact(12);
// In this range V is negative. The Friedmann constraint determines a
// unique positive kinetic energy, even at H = 0.
function descendingRates(c,[H,rho]){
  rho=[Math.max(0,rho[0]),rho[1]];
  const {K,Q,V}=c;
  const D=sub(sub(mul(three,sq(H)),V),rho);
  if(D[0]<=0)throw Error("could not isolate a positive scalar kinetic root");
  const P=sqrt(add(sq(K),mul(mul(twelve,Q),D)));
  const X=K[0]>=0 ? div(mul(two,D),add(P,K)) : div(sub(P,K),mul(six,Q));
  const inwardSpeed=sqrt(mul(two,X));
  const physicalHdot=sub(sub(zero,mul(X,add(K,mul(mul(two,Q),X)))),mul(p2_3,rho));
  return {rhs:[div(physicalHdot,inwardSpeed),
              div(mul(exact(-4),mul(H,rho)),inwardSpeed)],X,physicalHdot,P};
}
function throughBounce(denominator,t0,rmax) {
  let H=t0.map((v,i)=>i===0?down(v):up(v)), r=[0,up(rmax)];
  let phi=dec(1.1);
  const h=1/denominator, steps=9*denominator/4;
  let hits=0, phiAtZero=null, lowestSlope=Infinity, minX=Infinity, minP=Infinity;
  for(let i=0;i<steps;i++){
    const right=sub(phi,exact(h)), across=hull(phi,right), c=onFieldRange(across), state=[H,r];
    let tube=state.map((s,j)=>inflate(hull(s,add(s,mul([0,h],descendingRates(c,state).rhs[j])))));
    let accepted=false;
    try{
      for(let j=0;j<12;j++){
        const rates=descendingRates(c,tube);
        const image=state.map((x,k)=>add(x,mul([0,h],rates.rhs[k])));
        if(image.every((x,k)=>subset(x,tube[k]))){
          const end=state.map((x,k)=>add(x,mul(exact(h),rates.rhs[k])));
          if(tube[0][0]<=0&&tube[0][1]>=0){
            hits++;
            phiAtZero=phiAtZero?hull(phiAtZero,across):across;
            lowestSlope=Math.min(lowestSlope,rates.physicalHdot[0]);
          }
          minX=Math.min(minX,rates.X[0]); minP=Math.min(minP,rates.P[0]);
          H=end[0];r=[Math.max(0,end[1][0]),end[1][1]];
          accepted=true; break;
        }
        tube=tube.map((x,k)=>inflate(hull(x,image[k])));
      }
      if(!accepted)throw Error("Picard inclusion failed");
    } catch(e){return {at:i,phi,H,r,hits,phiAtZero,lowestSlope,minP,minX,reason:e.message};}
    phi=right;
  }
  const end=descendingRates(onFieldRange(phi),[H,r]);
  return {at:steps,phi,H,r,hits,phiAtZero,lowestSlope,minP,minX,exitSpeed:sqrt(mul(two,end.X))};
}

function kineticToReheating(n, hin, R){
  let phi=dec(1.15);
  const c0=onFieldRange(phi);
  const D=sub(sub(mul(three,sq(hin)),c0.V),R);
  const P=sqrt(add(sq(c0.K),mul(mul(exact(12),c0.Q),D)));
  let X=div(mul(two,D),add(P,c0.K));
  const h=div(dec(1.85),exact(n));
  for(let i=0;i<n;i++){
    const next=add(phi,h), c=onFieldRange(hull(phi,next));
    try{
      // The stepper accepts an exact dyadic step. For a non-dyadic interval,
      // scale the derivative to a unit step with duration in h.
      X=lowerUpperPointStep(X,1,x=>mul(h,outgoingRates(c,zero,[x,R])[0]));
      phi=next;
    }catch(e){return {i,phi,X,reason:e.message}}
  }
  return {phi,X,R,v:sqrt(mul(two,X))};
}

const dC=x=>[x,zero];
const dAdd=(x,y)=>[add(x[0],y[0]),add(x[1],y[1])];
const dSub=(x,y)=>[sub(x[0],y[0]),sub(x[1],y[1])];
const dMul=(x,y)=>[mul(x[0],y[0]),add(mul(x[1],y[0]),mul(x[0],y[1]))];
const dDiv=(x,y)=>{const value=div(x[0],y[0]);return [value,div(sub(x[1],mul(value,y[1])),y[0])]};
const dSq=x=>[sq(x[0]),mul(mul(two,x[0]),x[1])];
const dSqrt=x=>{const value=sqrt(x[0]);return [value,div(x[1],mul(two,value))]};
function directionInExit(phi,state,dr){
  const [X,R]=state;
  const [dPhi, dX, dRho] = dr;
  const x=[X,dX],r=[[Math.max(0,R[0]),R[1]],dRho];
  const {K,Q,Kp,Qp,V,Vp}=onFieldRange(phi);
  const f=add(one,div(sq(phi),two));
  const Qpp=add(div(exact(-2),mul(sq(f),f)),div(mul(exact(6),sq(phi)),sq(sq(f))));
  const Kpp=mul(exact(-2),Qpp);
  const W=sub(plateau,V);
  const Vpp=sub(mul(sq(lambda),W),div(mul(two,sq(Vp)),W));
  const k=[K,mul(Kp,dPhi)], q=[Q,mul(Qp,dPhi)], potential=[V,mul(Vp,dPhi)];
  const kp=[Kp,mul(Kpp,dPhi)],qp=[Qp,mul(Qpp,dPhi)],vp=[Vp,mul(Vpp,dPhi)];
  const u=sub(phi,three);
  let gp=zero;
  if(u[0]<1&&u[1]>0) {
    const inBand=[Math.max(0,u[0]),Math.min(1,u[1])];
    gp=mul(dec(.32),mul(mul(inBand,sub(one,inBand)),sub(one,mul(two,inBand))));
    if(u[0]<0||u[1]>1)gp=hull(gp,zero);
  }
  const g=[radiationGamma(phi),mul(gp,dPhi)];
  const speed=dSqrt(dMul(dC(two),x));
  const energy=dAdd(dAdd(dAdd(dMul(k,x),dMul(dMul(dC(three),q),dSq(x))),potential),r);
  const H=dSqrt(dDiv(energy,dC(three)));
  const kinetic=dAdd(k,dMul(dMul(dC(two),q),x));
  const force=dAdd(dAdd(vp,dMul(kp,x)),dMul(dMul(dC(three),qp),dSq(x)));
  const friction=dMul(dAdd(dMul(dMul(dC(three),H),kinetic),g),speed);
  const Dx=dDiv(dSub(dC(zero),dAdd(force,friction)),dAdd(k,dMul(dMul(dC(six),q),x)));
  const Dr=dSub(dMul(g,speed),dDiv(dMul(dMul(dC(four),H),r),speed));
  return [Dx[1],Dr[1]];
}
// Enclose a coupled (X, radiation) segment with a second-order Taylor
// endpoint and a Picard tube for its remainder. The branch has H > 0 and v > 0.
function transportOutgoing(steps, enter, span){
  let phi=enter.phi, state=[enter.X,enter.R];
  const h=div(dec(span),exact(steps));
  let minX=Infinity;
  for(let i=0;i<steps;i++){
    const next=add(phi,h), across=hull(phi,next), c=onFieldRange(across);
    const calc=point=>outgoingRates(c,radiationGamma(across),point);
    try {
      let tube=state.map((x,j)=>inflate(hull(x,add(x,mul([0,h[1]],calc(state)[j])))));
      let rates;
      let proved=false;
      for(let n=0;n<16;n++){
        rates=calc(tube);
        const b=state.map((x,j)=>add(x,mul([0,h[1]],rates[j])));
        if(b.every((x,j)=>subset(x,tube[j]))){proved=true;break;}
        tube=tube.map((x,j)=>inflate(hull(x,b[j])));
      }
      if(!proved)throw Error("Picard tube not accepted");
      // Mean-value form preserves the correlation between the state and its own derivative.
      const center=state.map(([lo,hi])=>exact(lo+(hi-lo)/2));
      const dev=state.map((x,j)=>sub(x,center[j]));
      const f=outgoingRates(onFieldRange(phi),radiationGamma(phi),center);
      const jx=directionInExit(phi,state,[zero,one,zero]);
      const jr=directionInExit(phi,state,[zero,zero,one]);
      const accel=directionInExit(across,tube,[one,...rates]);
      const h2=div(sq(h),two);
      state=state.map((x,i)=>{
        const mx=add(i===0?one:zero,mul(h,jx[i]));
        const mr=add(i===1?one:zero,mul(h,jr[i]));
        return add(add(add(center[i],mul(h,f[i])),add(mul(mx,dev[0]),mul(mr,dev[1]))),mul(h2,accel[i]));
      });
      state[1][0]=Math.max(0,state[1][0]);
      minX=Math.min(minX,tube[0][0]);
      phi=next;
    }catch(e){return {steps,i,phi,state,minX,reason:e.message};}
  }
  return {steps,phi,state,v:sqrt(mul(two,state[0])),minX};
}

const centerSpeed = "0.0031284101";
const centerRadiation = "0.00001382131568";
const lowerFactor = "0.97";
const upperFactor = "1.03";

function requireBound(condition, message) {
  if (!condition) throw new Error(message);
}

function requireFinished(stage, description) {
  requireBound(!stage.reason, description + ": " + stage.reason);
  return stage;
}

function checkReversalAndDescentEntry(outward) {
  const c = onFieldRange(dec(4.7));
  const outwardSpeedLimit = dec(0.000892);
  const outwardRadiationLimit = dec(2.721e-6);
  const outwardKineticLimit = div(sq(outwardSpeedLimit), two);
  requireBound(outward.v[1] < outwardSpeedLimit[0], "uphill speed ceiling");
  requireBound(outward.state[1][1] < outwardRadiationLimit[0], "uphill radiation ceiling");

  // Beyond 4.7, K and V increase, Q decreases, and V' stays positive.
  // This inequality gives at least 2.5 H damping of the outward velocity.
  requireBound(c.K[0] > mul(exact(18), mul(c.Q, outwardKineticLimit))[1], "uphill damping");
  requireBound(outwardKineticLimit[1] < p2_3[0], "uphill geometric force sign");
  const minimumH = sqrt(div(c.V, three));
  const reversalCeiling = add(dec(4.7), div(outwardSpeedLimit, mul(dec(2.5), minimumH)));
  requireBound(reversalCeiling[1] < dec(6.9)[0], "finite outward excursion");

  // On the descent to 4.6, the speed barrier limits the distance traveled
  // while radiation is diluted. At the barrier, inward acceleration is negative.
  const downhill = onFieldRange([dec(4.6)[0], dec(6.9)[1]]);
  const c46 = onFieldRange(dec(4.6));
  const barrier = dec(3e-7);
  const barrierX = div(sq(barrier), two);
  const Hfloor = dec(0.00018);
  requireBound(sqrt(div(c46.V, three))[0] > Hfloor[1], "positive H above 4.6");
  requireBound(downhill.Vp[0] > 0, "downhill slope has a positive lower bound");
  const largestSlope = mul(lambda, sub(plateau, c46.V));
  const geometricForce = add(mul(downhill.Kp, barrierX), mul(mul(three, downhill.Qp), sq(barrierX)));
  const minimumFriction = mul(mul(mul(three, Hfloor), barrier), downhill.K);
  requireBound(add(largestSlope, geometricForce)[1] < minimumFriction[0], "inward speed barrier");

  // exp(2.31) > 10 converts the redshift bound to powers of ten without libm exp.
  requireBound(expPos(dec(2.31))[0] > 10, "radiation redshift conversion");
  const exponent = distance => mul(four, mul(Hfloor, div(dec(distance), barrier)));
  requireBound(exponent(0.05)[0] > 119 && exponent(0.1)[0] > 239, "minimum redshift time");
  requireBound(mul(outwardRadiationLimit, dec(1e-51))[1] < dec(1e-55)[0], "radiation at 4.65");
  requireBound(mul(outwardRadiationLimit, dec(1e-103))[1] < rad[1], "radiation at 4.6");

  const cShort = onFieldRange([dec(4.6)[0], dec(4.65)[1]]);
  const smallX = [0, barrierX[1]];
  const Hupper = sqrt(div(add(add(add(mul(cShort.K, smallX),
    mul(mul(three, cShort.Q), sq(smallX))), cShort.V), [0, dec(1e-55)[1]]), three));
  const slowSpeed = dec(4e-8);
  const greatestFriction = mul(mul(mul(three, Hupper), [0, slowSpeed[1]]),
    add(cShort.K, mul(mul(two, cShort.Q), smallX)));
  const acceleration = div(sub(cShort.Vp, greatestFriction),
    add(cShort.K, mul(mul(six, cShort.Q), smallX)));
  requireBound(acceleration[0] > dec(4e-11)[1], "inward acceleration below the lower speed");
  requireBound(div(slowSpeed, dec(4e-11))[1] < div(dec(0.05), barrier)[0],
    "minimum inward speed reached before 4.6");
  return { maximumReversalPosition: reversalCeiling[1], speedAtDescentEntry: [slowSpeed[0], barrier[1]] };
}

function checkCycle() {
  const fractionalRange = [dec(Number(lowerFactor))[0], dec(Number(upperFactor))[1]];
  const speed = dec(Number(centerSpeed));
  const radiation = dec(Number(centerRadiation));
  const initialSpeed = mul(speed, fractionalRange);
  const initialRadiation = mul(radiation, fractionalRange);
  const initial = { phi: dec(4.2), X: div(sq(initialSpeed), two), R: initialRadiation };

  const outward = requireFinished(transportOutgoing(16384, initial, 0.5), "first uphill leg");
  const descentEntry = checkReversalAndDescentEntry(outward);
  const expandingDescent = requireFinished(downhillExpanded(65536), "expanding descent to 2.475");
  const contractingEntry = requireFinished(
    downhillThroughCrossover(expandingDescent, 16384), "descent through the dominance crossover"
  );
  const negativeEntry = [-0.002595, -0.002592];
  requireBound(subset(contractingEntry.H, [dec(negativeEntry[0])[1], dec(negativeEntry[1])[0]]),
    "contracting state fits the bounce entry");
  requireBound(mul(dec(1.375), [0, contractingEntry.attenuationWorst])[1] < 1,
    "radiation growth integral before the bounce entry");
  requireBound(mul(rad, expPos(exact(1)))[1] < dec(1e-90)[0], "radiation bootstrap before bounce");

  const bounced = requireFinished(throughBounce(16384, negativeEntry, 1e-90), "bounce");
  requireBound(bounced.H[0] > 0 && bounced.hits > 0 && bounced.lowestSlope > 0,
    "bounce must cross H = 0 with positive slope");

  // H and radiation suffice to reconstruct the kinetic energy at the next section.
  // Reflection of the field and its velocity preserves the equations.
  const reheatingEntry = requireFinished(kineticToReheating(32768, bounced.H, bounced.r),
    "outgoing transport to the reheating band");
  const returned = requireFinished(transportOutgoing(16384, reheatingEntry, 1.2),
    "reheating and return");

  const speedEdges = [mul(dec(Number(lowerFactor)), speed)[1], mul(dec(Number(upperFactor)), speed)[0]];
  const radiationEdges = [mul(dec(Number(lowerFactor)), radiation)[1],
    mul(dec(Number(upperFactor)), radiation)[0]];
  requireBound(subset(returned.v, speedEdges), "returned speed lies strictly inside input range");
  requireBound(subset(returned.state[1], radiationEdges), "returned radiation lies strictly inside input range");
  // For phi >= 4.2, K and V increase and Q decreases. The geometric force
  // and the friction are then nonnegative as long as X < 2/3, so the
  // uphill speed cannot exceed its starting value along the first leg.
  requireBound(onFieldRange(initial.phi).K[0] > 0 && initial.X[1] < p2_3[0],
    "initial uphill speed is nonincreasing");
  requireBound(div(dec(0.5), initialSpeed)[0] > 150, "positive minimum duration");

  return {
    initial: { fieldPosition: 4.2, speedCenter: centerSpeed, radiationCenter: centerRadiation,
      lowerFactor, upperFactor },
    outward,
    descentEntry,
    expandingDescent,
    contractingEntry,
    bounce: bounced,
    return: { fieldPosition: -4.2, speed: returned.v, radiation: returned.state[1] },
    minimumCycleDuration: 150,
  };
}

// Print the exact dyadic rational represented by the floating-point endpoint.
// Formatting a bound to ordinary decimal digits can silently round it inward.
function leanRational(x) {
  requireBound(x > 0 && Number.isFinite(x), "positive finite endpoint for Lean");
  bits.setFloat64(0, x);
  const raw = bits.getBigUint64(0);
  const exponent = Number((raw >> 52n) & 2047n);
  let numerator = raw & ((1n << 52n) - 1n);
  if (exponent !== 0) numerator += 1n << 52n;
  let scale = (exponent || 1) - 1075;
  if (scale >= 0) return "(" + (numerator << BigInt(scale)) + " : ℝ)";
  while (scale < 0 && numerator % 2n === 0n) {
    numerator /= 2n;
    scale++;
  }
  return "(" + numerator + " / " + (1n << BigInt(-scale)) + " : ℝ)";
}

function leanSource(result) {
  const [vLower, vUpper] = result.return.speed.map(leanRational);
  const [rLower, rUpper] = result.return.radiation.map(leanRational);
  return [
    "/- Generated from check.cjs --lean.",
    "The ODE enclosure is computed externally. Lean checks containment and iteration. -/",
    "import Mathlib.Tactic.Linarith",
    "import Mathlib.Data.Real.Basic",
    "",
    "def InOutgoingRange (s : ℝ × ℝ) : Prop :=",
    "  " + lowerFactor + " * " + centerSpeed + " ≤ s.1 ∧ s.1 ≤ " + upperFactor + " * " + centerSpeed + " ∧",
    "  " + lowerFactor + " * " + centerRadiation + " ≤ s.2 ∧ s.2 ≤ " + upperFactor + " * " + centerRadiation,
    "",
    "def InComputedReturn (s : ℝ × ℝ) : Prop :=",
    "  " + vLower + " ≤ s.1 ∧ s.1 ≤ " + vUpper + " ∧",
    "  " + rLower + " ≤ s.2 ∧ s.2 ≤ " + rUpper,
    "",
    "theorem return_enclosure_is_inside (s : ℝ × ℝ) (bounds : InComputedReturn s) :",
    "    InOutgoingRange s := by",
    "  obtain ⟨vLower, vUpper, rLower, rUpper⟩ := bounds",
    "  refine ⟨le_trans ?_ vLower, le_trans vUpper ?_, le_trans ?_ rLower, le_trans rUpper ?_⟩ <;> norm_num",
    "",
    "theorem iterate_returns_to_outgoing_range",
    "    (F : ℝ × ℝ → ℝ × ℝ)",
    "    (enclosure : ∀ s, InOutgoingRange s → InComputedReturn (F s))",
    "    (s : ℝ × ℝ) (inside : InOutgoingRange s) :",
    "    ∀ n : Nat, InOutgoingRange (F^[n] s) := by",
    "  intro n",
    "  induction n with",
    "  | zero => exact inside",
    "  | succ n ih =>",
    "    rw [Function.iterate_succ_apply']",
    "    exact return_enclosure_is_inside _ (enclosure _ ih)",
    "",
    "#print axioms return_enclosure_is_inside",
    "#print axioms iterate_returns_to_outgoing_range",
    "",
  ].join("\n");
}

const mode = process.argv[2];
if (process.argv.length > 3 || (mode !== undefined && mode !== "--lean" && mode !== "--check-lean")) {
  throw new Error("Usage: node check.cjs [--lean | --check-lean]");
}

const result = checkCycle();
if (mode === "--lean") {
  process.stdout.write(leanSource(result));
} else if (mode === "--check-lean") {
  const directory = mkdtempSync(join(tmpdir(), "iog-toy-cycle-"));
  const certificate = join(directory, "ReturnCertificate.lean");
  try {
    writeFileSync(certificate, leanSource(result), "utf8");
    const lean = spawnSync("lake", ["env", "lean", certificate], {
      cwd: resolve(__dirname, "..", ".."),
      stdio: ["ignore", "inherit", "inherit"],
    });
    if (lean.error) throw lean.error;
    if (lean.status !== 0) {
      throw new Error("Lean failed: " + (lean.signal ?? lean.status));
    }
  } finally {
    if (existsSync(certificate)) unlinkSync(certificate);
    rmdirSync(directory);
  }
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
} else {
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
}
