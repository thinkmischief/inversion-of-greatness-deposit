# Premise ledger

This ledger maps every module of the [Inversion of Greatness Lean](README.md) project to the book. Repeated inputs share a row. Each row states what Lean receives and whether the book defines it, argues for it, or leaves it open. **Argued for** records the book’s support at the stated scope. Lean may still take that result as a hypothesis. **Defined** includes explicit modeling definitions, with their relationship to the book stated in the row. **Open** marks a claim left unestablished at the scope of the Lean input.

## No free-standing residue and the Chapter 3 reductio

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `noFreeStandingResidue` | **Open** | If all three conditions are absent in a candidate, that candidate supports no internal fact. The joint-absence theorem takes this implication as an input. The existing countermodel gives a fact and its ground in the same candidate while all three conditions are absent. | [§2.7.4, conditional diagnostic and form][null] · [§3.2.6, “What it corroborates”][convergence] |
| `possibleMeansThereIsAWay` | **Argued for** | Real possibility of a content is equivalent to its holding in a represented determinate way Reality could be. Both directions enter as one input. | [§3.2.5, Possible means there is a way][convergence] |
| `determinateWaysSupportFacts` | **Argued for** | Each genuine candidate must support at least one fact about how things are in that candidate. Truths about a description belong to the representation side of the distinction. | [§3.2.1, Something Is the Case, and §3.2.6, No-World Reductio][convergence] · [§2.7.2, Incoherence of ∅, step 2][null] |
| `HasDeterminateWitness`, `AbsoluteAbsence` | **Defined** | The witness is a determinate candidate in which the stated content holds. The reductio uses the factless aspect of absolute absence, encoded by the failure of every internal fact. | [§§3.2.5–3.2.6, Possible means there is a way and No-World Reductio][convergence] |
| `JointAbsence` | **Defined** | Each of T, S, and Φ is absent. This is the joint-absence reading of ∅. Equating it with the factless reading requires `noFreeStandingResidue`. | [§§2.7.1–2.7.2, both readings of ∅][null] · [§3.2.6, “Why this is not a semantic exclusion”][convergence] |
| `abstractFactHasGround` | **Argued for** | The formal input grants a genuine structural ground for an obtaining abstract fact. The facthood line supplies bearing, and the Abstracta Fork identifies the proposed basis as an articulation or modal standing. A particular uninstantiated case still needs its basis identified as constitutive, especially if the only evidence offered is a possible realization. | [§3.2.1, Something Is the Case and the Platonist reply][convergence] · [§2.8.1, The Abstracta Fork, instantiated and uninstantiated branches][identity] |
| `factCannotObtainWithoutItsGround` | **Defined** | The candidate-indexed implication models the necessary-dependence part of the book’s definition of grounding. If the basis is a genuine constitutive ground, the obtaining fact requires it in that candidate. The implication leaves the type of ground open. | [§1.5.5, Ground and Dependence][being] |
| `isAbstract`, `obtains` | **Defined** | Local hypotheses select an abstract fact and a candidate in which it obtains. The theorem is conditional on these two hypotheses. | [§1.5.1, Existence and Instantiation][being] · [§3.2.1, the Platonist reply][convergence] |

## Appendix B lines 1–11

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `realityRole` | **Defined** | An item is real exactly when it belongs to Reality. Lean derives No Beyond from this role. | [§1.1, Reality, definition and no-beyond paragraph][reality] |
| `Necessary` | **Defined** | The file represents necessity by truth at every real evaluation. The book also expresses necessity as Reality’s incapacity for the contrary. | [§1.2.3, Necessity][modal] · [§2.1, Modal Notation][s5] |
| `ThreeConditions` | **Defined** | A pointwise conjunction of the three structural conditions. Its necessity is a theorem. | [§§1.4.1–1.4.4, the conditions and their joint structure][conditions] · [§2.5, Triconditional Necessity][necessity] |
| `oneRange` | **Argued for** | Every real evaluation assesses the same complete range. Lean represents this by equality of the ranges assessed. | [§1.1, no beyond Reality][reality] · [§1.2.1, modal maximum][modal] · [§2.1.4, Fixed Capacity][s5] |
| `evaluationInvariance` | **Argued for** | At each real evaluation, real possibility of fixed content is equivalent to Reality’s standing capacity for that content. The parameterized theorems accept the equivalence. The one-range version derives it given `oneRange` and the common `permits` interpretation. | [§2.1.4, Fixed Capacity, and §2.1.6, pipeline line 3][s5] · [Appendix B, lines 3–7][appendix] |
| `actualChange`, `witness` | **Argued for** | The proposition and its proof supply an actual instance of the kind of change fixed in §1.3. The reflective witness uses Predecessor. The file accepts the witness as a proof argument, rather than formalizing the predecessor episode. | [§1.3, Change][change] · [§2.2.1, Change Is Actual and the Predecessor premise][witness] |
| `actualityImpliesPossibility` | **Argued for** | The actual instance witnesses real possibility of that kind of change. The one-range theorem expresses the same input with `permits (rangeAssessed actualEvaluation) change`. | [§1.2.5, Actuality and the actuality-to-possibility passage][modal] · [§2.2.1, Change is really possible][witness] |
| `ReflectiveRoute.capacityProvidesCriteria` | **Argued for** | Packages Capacity Constitution applied to the reflective witness with the move to criteria for ordered succession, co-present differentiated poles, and persistent bearing across real evaluations. The Lean parameter summarizes that part of the bilateral argument. The Lean reflective route uses an actual-change witness to derive line 10, while Appendix B states line 10 as a necessary conditional without that antecedent. | [§2.4, Capacity Constitution, and §§2.4.1–2.4.3, the three limbs][requirements] · [§2.4.5, What the bilateral line establishes][requirements] |
| `ReflectiveRoute.orderedSuccessionGivesTemporality` | **Argued for** | The criterion of genuine asymmetric, transitive succession identifies T at the proof’s resolution. | [§1.4.1, Temporality][conditions] · [§2.4.1, Ordered Succession][requirements] |
| `ReflectiveRoute.attentionCrossesRealSeparation` | **Argued for** | On the reflective route, the differentiated, separately selectable poles satisfy the criterion of crossable separation. The manuscript presents this as a disputed constitutive premise. | [§2.4.2, Attention Crosses a Real Separation and its scope][requirements] |
| `ReflectiveRoute.relationalDistinctness` | **Argued for** | Crossable positional separation meets S. The criterion includes a crossable interval and occupiable origin and terminus. | [§1.4.2, Spatiality][conditions] · [§2.4.2, Relational Distinctness][requirements] |
| `ReflectiveRoute.crossIntervalPersistence` | **Argued for** | Continuity bearing a transition across its interval meets Φ under the book’s criterion. This is the premise for persistent bearing in the reflective route. | [§1.4.3, Substantiality][conditions] · [§2.4.3, Cross-Interval Persistence][requirements] |
| `constitutiveRequirement` | **Argued for** | Line 10, necessarily if change is really possible then T, S, and Φ obtain. The generic line 11 theorem accepts it. The reflective version supplies it using the five fields above; `movementRequiresThreeConditions` supplies the movement form, □(◇M → T ∧ S ∧ Φ), without Attention Crosses a Real Separation. `threeConditionsNecessaryByEitherRoute` takes either route. | [§2.4.5, Change requires time, space, and substance][requirements] · [§2.9.1, lines 9–11][whole] |
| `actualMovement`, `witness` (movement route), `movementActualityImpliesPossibility` | **Argued for** | Displacement occurs, and what is actual is possible: ◇M. The witness is empirical, independent of the reflective episode. | [§2.4.2, Movement is really possible][requirements] · [§1.2.5, Actuality][modal] |
| `MovementRoute.containment` | **Argued for** | Step 4 of *From Movement*: a displacement occupies a before and an after, crosses an interval, and is undergone by what persists across it; by Capacity Constitution the capacity for movement consists in structure providing that order, interval and persistence, at every real evaluation. The crossable separation comes from the displacement itself, so the route has no Attention Crosses a Real Separation field. | [§2.4.6, From Movement][requirements] |
| `MovementRoute.orderedSuccessionGivesTemporality`, `relationalDistinctness`, `crossIntervalPersistence` | **Argued for** | The same three limb criteria as the reflective route. | [§§2.4.1–2.4.3][requirements] |

Modal bivalence is a stated premise of the book’s presentation. The two implications in `modalStatusInvariant` follow separately from the fixed-capacity equivalence. The Lean theorem has no bivalence hypothesis. [§2.1.1, Modal Bivalence, and §2.1.6, lines 2 and 6][s5]

## Appendix B line 12

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `natureNamesJointComplex` | **Defined** | Nature names the joint T/S/Φ complex on the structure-wide reading. In Lean the supplied Nature and joint complex are related by this explicit naming equality. | [§1.4.4, Nature][conditions] · [§2.6.10, Triconditional Identity][three] |
| `operativeWorkPrinciple`, `formalDescriptionsDependOnOperativeWork` | **Argued for** | The proposition and its proof supply the premise that formal descriptions depend on operative work for the same-realizer argument. The operative predicates range over concrete change-realizers. This stronger line 12 reading supplies no premise to the line 13 Lean proof. | [§2.6.1, Formal descriptions depend on operative work][three] · [Appendix B, lines 12–13][appendix] |
| `successionPivot` | **Argued for** | Operative succession requires relational extension and persistent bearing in that same realizer, given the operative-work premise. | [§2.6.2, Succession’s Realizers][three] |
| `extensionPivot` | **Argued for** | Operative extension requires ordered succession and persistent bearing in that same realizer, given the operative-work premise. | [§2.6.3, Extension’s Realizers][three] |
| `persistencePivot` | **Argued for** | Operative persistence requires ordered succession and relational extension in that same realizer, given the operative-work premise. | [§2.6.4, Persistence’s Realizers][three] |

## Appendix B lines 13–14

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `NatureContents`, `natureTotality` | **Defined** | At totality resolution, Nature’s contents comprise the modal field, its determinate articulations, and their abstractions. `natureTotality` links that definition to the supplied belonging predicate. | [§2.8.3, premise 6a, first clause][identity] |
| `realityIsWhole` | **Defined** | A content belongs to Reality exactly when it is real. This is the two-way role definition for Reality. | [§1.1, Reality and No Beyond][reality] · [§2.8.3, step 1][identity] |
| `natureContentsAreReal` | **Argued for** | Each of the field, its determinate articulations, and their abstractions counts as real in the totality argument. This is the direction from Nature’s profile to Reality’s. The quantification is over the relevant structural contents. | [§2.8.3, steps 2–4, 6a and 7][identity] |
| `univocalExistence` | **Argued for** | Real content falls under the field itself, a concrete occupant, or an abstractum. The code packages the explicit field exception and the Concreteness Fork’s exhaustive classification. | [§2.8.2, Univocal Existence, and §2.8.3, step 4a][identity] |
| `concreteNonAddition` | **Argued for** | A concrete occupant is a determinate articulation of Nature rather than a further constituent alongside the conditions. | [§2.6.8, Ontological Identity][three] · [§2.8.3, steps 3 and 4a][identity] |
| `abstractaFork` | **Argued for** | Every real abstractum covered by the fork belongs as an abstraction of Nature’s articulations or modal standing. This is a totality-level placement premise in Lean. | [§2.8.1, The Abstracta Fork, and §2.8.3, step 4][identity] |
| `positiveDifferenceNeedsStructuralContent` | **Argued for** | A positive difference between the two wholes must appear in their complete structural content on one side or the other. The encoding requires the profile to capture relations, constraints, grounding, and other relevant articulations along with occupants. | [§2.6.1, Structure][three] · [§2.8.3, steps 5–6a][identity] |
| `natureIsMaximal` | **Argued for** | The original individuation route takes Nature’s maximality as an input. The separate profile-inclusion result derives it from coverage when the contents of a proposed larger whole are real. | [§2.8.3, steps 2–6a and conclusion][identity] |
| `realityIsMaximal` | **Argued for** | Reality is maximal in the sense of encompassing real content. The original individuation route takes this as an input. | [§1.1, no beyond Reality][reality] · [§3.4.1, No Outside][convergenceIdentity] |
| `leftIsMaximal`, `rightIsMaximal` | **Defined** | These are scope conditions on the generic no-surplus lemma. At its book application the two proofs come from `natureIsMaximal` and `realityIsMaximal`. | [§2.8.3, premise 6a][identity] |
| `distinctMaximalWholesHavePositiveDifference`, `distinctWholesHavePositiveDifference` | **Argued for** | Distinct totalities require a positive structural differentiator. The scope of §2.4.8 is concrete individuation. §2.4.13 expressly applies it to totalities, and §2.8.3 invokes it in 6a. The named field supplies that application to Lean. | [§§2.4.8 and 2.4.13, individuation and the discussion of two totalities][requirements] · [§2.8.3, premise 6a][identity] |
| `noPositiveDifference` | **Argued for** | The generic no-surplus lemma accepts this input. At line 13 the proof derives it from mutual profile inclusion and `positiveDifferenceNeedsStructuralContent`. | [§2.8.3, steps 5–7][identity] · [§2.6.6, no-surplus clause of Necessary co-extension is uninformative][three] |
| `StructuralProfileIncluded` | **Defined** | Inclusion means that every content of the first complete structural profile belongs to the second. The relation is a Lean definition informed by the book’s account of structure and the totality reading. | [§2.6.1, Structure][three] · [§2.8.3, premise 6a][identity] |
| `natureInReality`, `realityInNature` | **Argued for** | Mutual profile inclusion is a hypothesis of the intermediate identity lemma. The line 13 theorem supplies both directions by proving the same contents from coverage. | [§2.8.3, steps 1–7, especially 4a and 6a][identity] |
| `identity`, `premises`, `coverage`, `route` | **Defined** | Bundle parameters refer to the fields in `RealityNaturePremises`, `RealityNatureCoverage`, and `ReflectiveRoute` listed here. Line 14 conjoins the conclusions from the identity and necessity arguments. | [§2.9.1, line 14 and the paragraph separating the two conclusions][whole] |

## Inputs of the alternative inclusion and role formulations

| Lean premise | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `uniqueRealityRole` | **Argued for** | §3.4.2 describes the role as uniquely filled. This alternative Lean theorem takes uniqueness explicitly and proves Nature fills the role from coverage. Uniqueness for arbitrary carriers with the same contents would need individuation. | [§1.1, the structural role and the second-reality paragraph][reality] · [§3.4.2, Role Is Not Yet Identity][convergenceIdentity] |
| `allRealWholesIncluded` | **Argued for** | Every real whole is structurally included in Reality. This is the whole-level formalization of the second-reality argument. | [§1.1, the second-reality paragraph][reality] |
| `candidateIsReal`, `candidateIsMaximal` | **Defined** | Local scope hypotheses for the arbitrary candidate. Maximality says any containing whole is also included in the candidate. For Nature, the separate coverage proof supplies maximality under profile inclusion with the real-contents condition below. | [§1.1, no beyond Reality][reality] · [§2.8.3, premise 6a][identity] |
| `contentInclusionSuffices` | **Open** | The generic lemma accepts the bridge for a separately given inclusion relation. For the complete-profile definition above, Lean supplies it directly by definition. | [§2.6.1, Structure][three] · [§2.8.3, premise 6a][identity] |
| `inclusionAntisymmetric` | **Open** | The generic order lemmas accept antisymmetry for the supplied relation. The book’s specific identity argument concerns the two maximal wholes and uses positive individuation instead of a general order axiom. | [§2.8.3, premise 6a, and step 7][identity] · [§2.4.13, individuation of totalities][requirements] |
| `superwholeContentsAreReal` | **Defined** | Domain restriction for the maximality result. Any proposed enlargement of Nature in the comparison has real contents. The Lean quantifier ranges over a generic whole type, so the restriction is explicit. | [§1.1, membership and reality][reality] · [§2.8.3, premise 6a and step 7][identity] |

## Integrated Dominance Crossing (§4.6.5)

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `expansionAtStart`, `startBeforeStop` | **Defined** | Local hypotheses fixing an interval and a positive totality-scale expansion rate at its start. | [§4.6.5, Integrated Dominance Crossing][cycle] |
| `rateDerivative`, `continuousReduction` | **Open** | `H` has derivative `-A` on the closed interval and `A` is continuous there. This is the continuity clause of Finite Expansion Dominance. | [§4.6.5, Finite Expansion Dominance][cycle] |
| `accumulatedEnough` | **Open** | The cumulative reduction over the interval exceeds the starting rate. The Gradient Exhaustion Fork presses toward it without proving it, and the book records two physical identifications still owed. | [§4.6.5, Finite Expansion Dominance and the Gradient Exhaustion Fork paragraph][cycle] |
| `reductionAtZero` | **Open** | `A > 0` at every zero of `H` in the interval. Used only for the unique crossing and the strict signs on either side. | [§4.6.5, Finite Expansion Dominance][cycle] |
| `localContraction`, `LocalContractionDuringExpansion` | **Defined** | An uninterpreted label for local contraction. The example stipulates it everywhere, so it shows only that the label can co-occur with positive `H`. The example's substance is that positive net reduction with too small an integral leaves `H` positive. | [§4.6.5, convergence during expansion][cycle] |

## Finite Reversible Phase Closure (§4.6.5)

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `cover`, `covers`, `next` | **Argued for** | A finite list covers the phase-types, and one time-independent successor function gives each type's successor. This is Finite Autonomous Phase Dynamics. Fixed laws alone establish neither finitude nor successor-completeness; the book earns both where the whole arrives at the bound, since every arrival is one bounce type, so expansion, contraction and the bounce are three classes, each fixing its successor (One Bound, One Type with §2.9.4). Lean takes them as inputs. | [§4.6.5, Phase-Configuration Identity and Finite Autonomous Phase Dynamics][cycle] |
| `oneToOne` | **Open** | Distinct phase-types never share a successor. The book notes that microscopic reversibility supplies this only when the phase equivalence is preserved backward as well as forward. | [§4.6.5, the injectivity paragraph before Finite Reversible Phase Closure][cycle] |
| `contractionDominanceToBounce`, `bounceToExpansionDominance` | **Argued for** | The successor edges contraction → bounce and bounce → expansion. Compression ends at a definite state of maximal compression (§4.6, where compression ends), and at that bound the history can’t go further in, reach zero extension and last, rest, or stop, so its only change is outward (§4.6, what happens at the bounce). Whether contents keep their own sizes under the strongest gravity, and so where the law-fixed bound lies, stays physical. Lean takes both edges as inputs. | [§4.6.5, Single-Boundary Restoration and the forward dynamical route][cycle] |
| `expansionDominanceToContractionDominance` | **Argued for** | The edge expansion → contraction, a hypothesis of `periodicDominanceOrder`. `Inside/Cycle/Bridge` derives it from Integrated Dominance Crossing (`periodicDominanceOrderFromCrossing`), using the premise below. | [§4.6.5, the forward dynamical route][cycle] |
| `classificationReadsSignChange` | **Argued for** | When the global rate passes strictly from positive to negative, with no interval at zero, the classified successor of expansion dominance is contraction dominance. The book states this in Integrated Dominance Crossing: compression dominance is the next regime, with no interval of zero expansion between. | [§4.6.5, Integrated Dominance Crossing][cycle] |
| `contractionDominanceNeBounce`, `contractionDominanceNeExpansion`, `expansionDominanceNeContraction`, `expansionDominanceNeBounce` | **Defined** | The three phase-types are distinct, as the theorem box states. | [§4.6.5, Finite Reversible Phase Closure][cycle] |
| `classifiedSuccessor` | **Defined** | Scope hypothesis: expansion dominance's successor is one of the three named types. The four-phase example shows the conclusion fails without it. | [§4.6.5, Finite Reversible Phase Closure][cycle] |
| `past`, `pastSteps` | **Open** | The occupied phase has an indefinitely deep chain of classified predecessors under the same successor map. With a finite successor-complete classification, `finitePhaseReturnFromInfinitePast` proves a positive period for the present type without assuming injectivity. | [§4.6.5, Bi-Infinite Autonomous Phase Recurrence][cycle] |
| `sameTurnaroundConditions` | **Argued for** | The earlier and present expanding phases have the same successor-sufficient type. Equality at this resolution allows differences that do not affect the successor. The book earns restoration in part: every arrival of the whole at the bound is alike in arrangement, make-up and direction (One Bound, One Type). Where a clumped contraction’s entropy goes stays physical. | [§4.6.5, Phase-Configuration Identity and the earlier-turnaround route][cycle] |
| `earlierTurnaround` | **Argued for** | Local convergence was already occurring during expansion dominance. The earlier history shifted continuously into overall contraction dominance. The zero of the global rate is a point within that crossover. With `sameTurnaroundConditions`, Lean derives the same order of regimes for the present expansion and, given the two restoration edges above, the periodic order. | [§4.6.5, The present expansion ends as earlier ones did][cycle] |

## Outside: modal results (Chapters 7, 8 and 10)

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `Box`, `Dia`, `sees` | **Defined** | Possible-worlds truth conditions for necessity and possibility. Over the frame where every world sees every world, `Box` is the inside half's `Necessary` (`boxOverOneRangeIsNecessary`). | [§2.1, Modal Notation][s5] · [§1.2.1, Possibility][modal] |
| `IsS5`, `reflexive` | **Argued for** | Accessibility is an equivalence relation, or at least reflexive. The book reaches S5 through the one-range premise; the transfer results use it, and `noTransferWithoutSymmetry` shows what fails without symmetry. | [§2.1.6, Possibility and impossibility never vary][s5] · [§10.1.1, No Rescue by Changing the Modal Logic][ontological] |
| `oneFact` | **Argued for** | At every world the conditions hold exactly when change is possible. This is the modal identity. It gives □◇C from □(T ∧ S ∧ Φ) and nothing more: `noParticularChangeIsNecessary` satisfies it with a world where no change occurs. | [§2.6.6, Modal Identity][three] · [§8.2.5, Constitutive Grounding Non-Propagation][collapse] |
| `frozenWorldHasNoHistory` | **Argued for** | Wherever the conditions hold, some change occurs. With □(T ∧ S ∧ Φ) this gives □C. It is the premise that does this work, not the modal identity. | [§2.4.10, The Frozen-World Test][requirements] · [§2.9.1, Some change is necessary][whole] |
| `groundNecessary`, `sufficiency` | **Argued for** | A full ground and its sufficiency conditional. Distribution needs both necessary; the countermodel has the sufficiency necessary and the ground contingent, so no particular change follows. | [§2.9.4, the sufficiency theorems][whole] · [§8.2.5][collapse] |
| `baseIsGenuine`, `genuineHaveConditions` | **Argued for** | A modal base drawn from genuine alternatives, and every genuine alternative answering to the conditions. | [§7.3.1, Restriction adds nothing][relative] |

**§8.2.5 wording, resolved 2026-11-21.** Three sentences credited □C, "that some change occurs", to "the identity" (lines 20, 30 and 63); they now cite the frozen-world step. The book's derivation in §2.9.1 instead takes it from *The frozen world has no history*, and `noParticularChangeIsNecessary` shows the modal identity cannot supply it. Line 63 also said □(T ∧ S ∧ Φ) "alone" gives □◇C, while the same box says that step holds by the identity. Both read as citation slips rather than gaps in the argument.

## Outside: nothing beyond Nature and the capstone (Chapters 2, 7, 10 and 11)

The fork itself adds no premise: `realIsWithinNature` is the coverage argument recorded above under Appendix B lines 13–14.

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `WithinNature` | **Defined** | Nature itself, Nature in a determinate operation, or an abstraction of such an articulation: membership in Nature together with Nature's contents. | [§2.8.3, premise 6a][identity] · [§11.10, No Divine Addition][god] |
| `CandidateModality.possibleMeansAWay` | **Argued for** | A candidate is possible exactly when it has a determinate way to be. The item-level form of the null-state input above. | [§3.2.5, Possible means there is a way][convergence] |
| `CandidateModality.waysAreReal` | **Argued for** | Every determinate way belongs to Reality's one modal structure. | [§11.10, No Divine Addition][god] · [§1.1][reality] |
| `ConditionsAtItems.workIsChange`, `changeIncursConditions` | **Argued for** | Concrete work is change, and each change token incurs T, S and Φ at its operation. Lean takes this local result as an item-level input. | [§2.4.7, Concrete work incurs the conditions][requirements] |
| `actualityOrNecessityEntailsPossibility` | **Argued for** | A God claimed actual or necessary must be possible. | [§1.2.5, Actuality][modal] · [§11.10][god] |
| `threeReadings` (essence) | **Argued for** | *Essence* names a constitutive truth of a real bearer, a distinct real ground with a real relation, or nothing specified. Lean checks coverage of the named items in the first two readings. Bearer independence and explanatory priority are outside the lemma’s statement. | [§7.2.1, No Unconditioned Essence][source] |
| `agencyIsConcreteWork` | **Argued for at concrete-work scope** | The Lean hypothesis uniformly makes modeled agency imply concrete work. Its CG₀ version combines that agency with withdrawal from the three item predicates. The book’s full CG₀ description also refuses every determinate replacement truth-condition. | [§11.10, The contentless God has no referent][god] |
| `greatnessIncludesPersonalPowers`, `personalPowersAreConcreteWork` | **Argued for at concrete-work scope** | Maximal greatness includes knowing, willing and power to act. Lean takes the modeled powers to imply concrete work. The book’s MGB₀ also excludes determinate analogues that perform the three roles. | [§10.1.1, The Modal Ontological Reductio][ontological] |
| `embeddedDoesConcreteWork`, `independenceExcludesDependence` | **Defined** | Scope of *Aseity Forfeiture*: the deity is embedded in temporal, relational and active roles, and an independent ground does not depend on what it grounds. | [§11.1, Aseity Forfeiture][greatness] |
| `incurringIsDependence` | **Argued for** | Incurring the conditions is constitutive dependence on them. | [§11.1, Aseity Forfeiture][greatness] · [§1.5, To exist is to occupy time, space, and substance][being] |
| `strictGroundAsymmetric` | **Argued for** | Strict ground is asymmetric, so irreflexive as well. §11.10 states irreflexivity in step 4; step 5 uses the asymmetry of priority, since a creator within Nature would be both prior and posterior to the conditions' obtaining. Lean takes the stronger asymmetric form, which covers both steps. | [§11.10, No Creator of Nature, steps 4–5][god] |
| `existenceWithinNatureRestsOnConditions` | **Argued for** | The conditions' obtaining is part of what makes anything within Nature exist. | [§11.10, No Creator of Nature, step 5][god] |
| `beginningRequiresWithdrawnOnset` | **Open as a bridge from source to onset** | The hypothesis makes the onset itself a change token and withdrawn at that same token. This gives the contradiction. The manuscript describes a categorial onset from an absent source. Absence at the source and withdrawal at the transition are separate claims, and this lemma takes the latter as an input. | [§10.1.5, A beginning needs what it would begin][cosmological] · [§11.10, step 3][god] |
| `Individuation.whatTellsApartIsStructure` | **Argued for** | Two distinct concrete items are told apart by some real differentiating structure. The proof needs it only for the no-brute-count conclusion; the countermodel beside the theorem shows two real worlds forming a brute count without it. | [§2.4.8, What tells things apart is structure][requirements] · [§7.2.3, Isolation is not separation][modalRealism] |
| `worldsAreReal`, `worldsAreConcrete` | **Defined** | The modal realist's own claim: the worlds are real and concrete. Isolation enters no premise, which is the theorem's point. | [§7.2.3][modalRealism] |
| `threeReadings` (admissibility), `groundedInRealElementsIsTheirStructure`, `determinateWorkIsReal` | **Argued for** | An admissibility condition is grounded in the natures of real elements, or is a primitive with determinate constraining work, or makes no further difference. A condition grounded in real elements belongs to their structure; one with determinate work is a real differentiated item (*Grounding requires differentiated terms*). | [§7.2.5, The Missing Clause][combinatorialism] · [§3.1, Grounding requires differentiated terms][transition] |
| `noIndividuatingSurplus`, `constraintIsReal` | **Argued for** | A condition that makes no further difference from the structural constraint already identified is that constraint under another description, and the constraint is real. | [§3.4.3, No-Individuating-Surplus Criterion][convergenceIdentity] · [§7.2.5][combinatorialism] |
| `RecoveryOfTime.formalOrConcrete`, `formalGeneratesNoWorld` | **Argued for** | A recovery of time is formal or concrete, and a merely formal correlation represents temporal relations without generating a concrete temporal world. | [§8.1.2, No Concrete Emergence from Non-Time][emergentTime] |
| `RecoveryOfTime.realTransformationClosure` | **Argued for** | A concrete recovery is a real transformation, so a change token. With `changeIncursConditions` it incurs T, S and Φ at the recovery itself. Framework-Invariance enters through `changeIncursConditions`: the requirement holds whichever theory describes the recovery. | [§3.5, Real Transformation Closure][realization] · [§2.4.5, Framework-Invariance][requirements] |
| `RecoveryOfTime.generatedTimeHasCapacity`, `nonTimeLacksCapacity` | **Defined** | A concrete temporal world has local transition-capacity; complete non-time, lacking order, has none. | [§3.1.2][transition] · [§8.1.2][emergentTime] |
| `RecoveryOfTime.transitionClosure` | **Argued for** | Local transition-capacity cannot switch on from a state that lacks it. The countermodel beside the theorem shows emergence from non-time is consistent without it. | [§3.1.2, Transition Closure][transition] |

`theInversionOfGreatness` combines the inside conclusion with selected outside results. Both halves use one `identity` package and its coverage fields. Line 11 can use either witness. The movement route requires actual displacement, the shared modal lift, Containment, and the three limb criteria. Attention Crosses a Real Separation is specific to the reflective route.

| Capstone modeling question | Status | Scope and source |
| --- | --- | --- |
| Relating operation-level T, S and Φ to evaluation-level T, S and Φ | **Open in Lean** | The manuscript argues that the roles operate at each concrete change token (§2.4.7) and treats their joint structure at the level of Reality separately (§2.6.10). A shared model needs to specify which item realizes the witnessed transition and how the roles it performs relate to the standing structure under evaluation. The present capstone has no realization relation. [§2.4.5, Forward Conditional Necessity, and §2.4.7][requirements] · [§§2.6.8 and 2.6.10, operative realizer and joint structure][three] · [§2.9.2, concrete occupancy][whole] |
| `isWay` in `PossibleDescription` | **Defined** | A supplied predicate identifying ways eligible to answer a description. In the capstone it is independent of the relation `CandidateModality.wayOf`; the theorem draws its two conclusions under those separate interpretations. [§3.2.5, Shape of Possibility][convergence] |

## Outside: the divine attributes (Chapter 11)

Each instance adds only its per-branch premises; the outcome `Closed` (incurs T, S and Φ, lies within Nature, or is not possible) is defined from `Outside/NoBeyond`. *The Predicate-Content Dilemma* adds none.

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `Closed` | **Defined** | The three places the fork leaves a candidate: incurring the conditions, within Nature, or not possible. | [§2.9.2][whole] · [§11.10][god] |
| `twoReadings`, `negativeIsContrastOrEmpty`, `contrastReinstatesDifferentiation`, `degreeConcedesStructure` | **Argued for** | Infinity read negatively has contrastive content or none; read positively it sits in an ordering of degree. Contrastive content and degree are real structure. | [§11.2.3, Unboundedness requires a dimension][infinity] |
| `contentConcedesStructure`, `noAlternativeTruthConditions`, `retainsCommitments`, `noContentNoWay` | **Argued for at the stated scope** | Specifying content concedes determinate structure. The no-way branch assumes a lack of specifying content, an absence of alternative truth conditions, and retention of the identities and distinct inferential profiles. Lean takes the no-way consequence under those three inputs as a premise. Lack of specifying content alone leaves the identities uninformative. | [§11.2.1, The Discriminating-Content Burden][simplicity] |
| `threeHorns` (creation), `differentiationIsStructure`, `bruteWorksOrIsStructure`, `modalCollapse` | **Argued for** | Different termini admit differentiation; a brute selection does concrete work or is structure; with no alternatives, contingent effects collapse. The conclusion keeps collapse as a separate exit, as the box does. | [§11.7.1, The Creation Trilemma][omnipotence] |
| `threeHorns` (creator relation), `outwardRelationIsReal`, `inwardDifferentiationIsReal`, `creatureSideAnswersOrIsEmpty` | **Argued for** | An external creation makes creatorhood a real relation; a creation within God is a differentiation in divine reality; a creature-side-only relation answers with content or withdraws it. | [§11.7.2, The Creator-Relation Trilemma][causality] |
| `whatItSays`, `omniscienceKnowsAll` | **Defined** | The truth that God knows every truth says exactly that; omniscience is knowing every truth. Step 2 of the box is derived from these, not assumed. | [§11.4.2, Omniscience is reflexive][omniscience] |
| `reflexiveKnowingNeedsArticulation` | **Argued for** | Knowing that one knows takes the knowing and its fit as determinate content, which requires articulation. | [§11.4.1][awareness] · [§11.4.2][omniscience] |
| `threeHorns` (presence), `somewhereIsNotEverywhere`, `everywhereIsAtPositions`, `nowhereIsNotPresence` | **Argued for** | Somewhere only is not everywhere; everywhere is at positions, which is spatiality (Relational Distinctness); nowhere is no longer presence. | [§11.8.1, The Present Trilemma][presence] · [§2.4.2][requirements] |

## Outside: the classical grounds (Chapter 10)

Each instance adds only its per-branch premises and reuses `Closed` from the Chapter 11 module.

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `differencePrinciple`, `contrastReinstatesStructure`, `excludingNothingIsEmpty` | **Argued for** | Positive eminent content is contrastive or excludes nothing; contrastive content is order, difference and bearing; content that excludes nothing is ∅. | [§10.2.1, No Third Option Between Contrastive and Empty][simplicityTen] · [§2.8, the Difference Principle][identity] |
| `threeMarks`, `twinIsReal`, `inItselfNoDifference`, `unreceivedNoDifference` | **Argued for** | Subsisting means existing in itself, unreceived, or as pure act; the first two name no difference from Nature's own structure grounding its configurations, which is real. | [§10.2.2, Subsistence is Nature's too, steps 1–3][negativa] |
| `threeConcessions`, `differentiatedContentIsStructure`, `bruteSelectionDiffersInNothing`, `collapseDiffersInNothing` | **Argued for** | As pure act, a ground grounding contingent configurations incurs one of *Three concessions for active power* (via *One unchanging act discriminates nothing*). Differentiated content is structure; a brute selection or a collapsed creation differs from the twin in nothing (Univocity of Existence, step 5). | [§10.2.2, step 4][negativa] · [§10.2.1][simplicityTen] |
| `groundingNeedsCapacity`, `groundingRequiresDifferentiatedTerms` | **Argued for** | Grounding creaturely possibility needs a capacity for something distinct; that capacity admits distinct relata in a real grounding relation, not two labels. | [§10.1.2, The Creation Fork][modalGrounding] · [§3.1, Grounding requires differentiated terms][transition] |
| `threeHorns` (logic), `independenceLeavesNoConclusion`, `necessaryDependenceIsStructure`, `contingentActPresupposesStructure` | **Argued for** | Logic is independent of God, necessarily dependent, or contingently dependent. The first surrenders the argument; the second is determinate structure; the third needs an act that is concrete thinking or Nature's structure. | [§10.1.3, The Three Grounds Trilemma][transcendental] |
| `fourCorners`, `affirmingIsWork`, `denyingIsWork`, `bothIsWork`, `withholdingIsWork` | **Argued for** | The catuṣkoṭi's four stances exhaust the positions, and each, the refusal included, is an activity. | [§10.3.4, No corner is empty of structure][madhyamaka] · [§3.3.1, Denial is a change][convergenceDenial] |

## Outside: rivals in modality, metaphysics and mind (Chapters 7–9)

Each instance adds only its per-branch premises.

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `threeBranches` (powers), `equivalenceIsTheTriad`, `manifestationIsWork`, `withoutWorkIsStructureOrEmpty` | **Argued for** | A powers base is equivalent to the conditions, grounds by concrete work, or grounds without it. Equivalence is the triad renamed; manifestation is a becoming; without work the base is structure or modal standing, or (unmanifested and contentless) nothing. | [§7.2.2, No Exit for the Powers Base][powers] · [§2.9.2][whole] |
| `determinacyIsFixed`, `concreteMeansDownstream`, `abstractMeansStructured`, `instantiationIsReal` | **Argued for** | A Form's determinacy is fixed on the concrete side (leaving it downstream) or the abstract side (already structured); explaining an instance needs a real instantiation relation. | [§8.1.5, The form runs downstream][platonism] |
| `threeRoles`, `stateRealizerInstantiation`, `encodingIsProcessing`, `sustainingIsWork` | **Argued for** | A grounding mind has the experience as its state, encodes it, or keeps it in being; the Encoding Dilemma places T, S and Φ at the first two, and sustaining is concrete work. | [§9.5, Conditions on There Being a Mind][idealism] · [§2.6.7, The Encoding Dilemma][three] |
| `producingDifferentiates`, `twoModes`, `transitionClosure` (substrate), `encodingDilemma` | **Argued for** | A substrate producing an alter differentiates it; producing is a happening (temporal by Transition Closure) or timeless constitution (T, S and Φ at the host by the Encoding Dilemma). | [§9.5, The substrate must differentiate too][idealism] · [§3.1.2][transition] |

## Appendix F: Exponential Crossing Ambiguity, the family count

No philosophical premise. The module checks the combinatorics of the appendix’s finite model.

| Lean premise or definition | Status | What the proof uses | Manuscript source |
| --- | --- | --- | --- |
| `Trajectory`, `complement`, `complementary` | **Defined** | Two bearers, two positions, m times; a complementary registration is fixed by bearer 1’s trajectory, bearer 2 taking the opposite position at every time; each visits both positions exactly when the trajectory is not constant. | [Appendix F, the model and *Exponential Crossing Ambiguity*][appendixF] |
| `representatives` | **Defined** | One member per class: bearer 1 at the first position at the first time. Exchange of bearers and exchange of positions both act as complement, which has no fixed point. | [Appendix F, proof of *Exponential Crossing Ambiguity*][appendixF] |

## Vocabulary carried as parameters

| Lean names | Status | Interpretation | Manuscript source |
| --- | --- | --- | --- |
| `Evaluation`, `actualEvaluation`, `reference`, `Range`, `realityRange`, `rangeAssessed`, `capacity`, `possibleAt`, `permits` | **Defined** | Real evaluations, a reference or actual evaluation, the complete range each assesses, and permission by Reality’s capacity. These parameters name the pieces of the modal interpretation. The substantive equivalence is recorded above. | [§§1.2.1, 1.2.3, and 1.2.5][modal] · [§2.1.4][s5] |
| `Content`, `content`, `change`, `temporality`, `spatiality`, `substantiality` | **Defined** | Fixed content, the witnessed kind of change, and the three structural conditions at the relevant evaluation. | [§1.2.1, Possibility][modal] · [§1.3, Change][change] · [§§1.4.1–1.4.4][conditions] |
| `ReflectiveRoute.orderedSuccession`, `differentiatedPoles`, `crossableSeparation`, `persistentBearing` | **Defined** | Predicate fields name the reflective criteria. The separate premises above say how the criteria are supplied and what they entail. | [§§2.4.1–2.4.3, the three limbs and Attention Crosses a Real Separation][requirements] |
| `Realizer`, `temporalWork`, `spatialWork`, `substantialWork` | **Defined** | Concrete change-realizers and the three conditions when operating in a realizer. | [§§2.6.1–2.6.5 and §2.6.7][three] |
| `Whole`, `Field`, `Item`, `nature`, `reality`, `jointComplex`, `belongs`, `belongsToReality`, `fieldOf`, `real` | **Defined** | Names for independently supplied wholes, their modal field, and structural membership of real content. The equalities and coverage claims are recorded above. | [§1.1, Reality][reality] · [§1.4.4, Nature][conditions] · [§2.8.3, the field and maximal totality][identity] |
| `fieldContent`, `concreteOccupant`, `abstractum`, `articulation`, `abstraction` | **Defined** | Predicates in the classification of real contents. The classification and placement implications enter separately. | [§2.8.1, The Abstracta Fork, and §2.8.3, steps 3–4a and 6a][identity] |
| `maximal`, `positiveDifference`, `realWhole`, `includedIn` | **Defined** | The generic types carry predicates for maximality, real wholes, positive differentiation, and inclusion. Their substantive connections are the hypotheses listed above. | [§1.1, No Beyond][reality] · [§2.8.3, steps 5–6a][identity] |
| `Candidate`, `Fact`, `possible`, `isDeterminateWay`, `holdsAt` | **Defined** | Candidate ways, fact contents, real possibility, and facts supported internally by a candidate. | [§§3.2.5–3.2.6][convergence] |
| `Basis`, `isAbstractFact`, `structuralGroundOf`, `basisPresentAt` | **Defined** | Abstract fact and basis types, with predicates for constitutive grounding and presence within a candidate. The proof takes the rules connecting these predicates as the explicit premises above. | [§1.5.5, Ground and Dependence][being] · [§3.2.1, facthood and bearing][convergence] |

The identity proof uses classical reasoning to pass from a contradiction under nonidentity to equality. The book’s modal bivalence premise belongs to its classical framework, and the file’s `#print axioms` output records Lean’s foundational dependencies separately from the philosophical hypotheses above. The example models test implications between these premises. Their stipulated contents are example data. [§2.1.1, Modal Bivalence][s5]

[reality]: https://inversionofgreatness.org/groundwork#sec-1-1
[modal]: https://inversionofgreatness.org/groundwork#sec-1-2
[change]: https://inversionofgreatness.org/groundwork#sec-1-3
[conditions]: https://inversionofgreatness.org/groundwork#sec-1-4
[being]: https://inversionofgreatness.org/groundwork#sec-1-5
[s5]: https://inversionofgreatness.org/the-argument#sec-2-1
[witness]: https://inversionofgreatness.org/the-argument#sec-2-2
[requirements]: https://inversionofgreatness.org/the-argument#sec-2-4
[necessity]: https://inversionofgreatness.org/the-argument#sec-2-5
[three]: https://inversionofgreatness.org/the-argument#sec-2-6
[null]: https://inversionofgreatness.org/the-argument#sec-2-7
[identity]: https://inversionofgreatness.org/the-argument#sec-2-8
[whole]: https://inversionofgreatness.org/the-argument#sec-2-9
[convergence]: https://inversionofgreatness.org/convergence#sec-3-2
[convergenceIdentity]: https://inversionofgreatness.org/convergence#sec-3-4
[cycle]: https://inversionofgreatness.org/nature-alone#sec-4-6
[source]: https://inversionofgreatness.org/modality#sec-7-2-1
[relative]: https://inversionofgreatness.org/modality#sec-7-3-1
[collapse]: https://inversionofgreatness.org/metaphysics#sec-8-2-5
[ontological]: https://inversionofgreatness.org/rival-ultimates#sec-10-1-1
[god]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-10
[modalRealism]: https://inversionofgreatness.org/modality#sec-7-2-3
[combinatorialism]: https://inversionofgreatness.org/modality#sec-7-2-5
[emergentTime]: https://inversionofgreatness.org/metaphysics#sec-8-1-2
[transition]: https://inversionofgreatness.org/convergence#sec-3-1
[realization]: https://inversionofgreatness.org/convergence#sec-3-5
[greatness]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-1
[infinity]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-2-3
[simplicity]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-2-1
[omnipotence]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-7-1
[causality]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-7-2
[awareness]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-4-1
[omniscience]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-4-2
[presence]: https://inversionofgreatness.org/reclaiming-greatness#sec-11-8-1
[simplicityTen]: https://inversionofgreatness.org/rival-ultimates#sec-10-2-1
[negativa]: https://inversionofgreatness.org/rival-ultimates#sec-10-2-2
[modalGrounding]: https://inversionofgreatness.org/rival-ultimates#sec-10-1-2
[transcendental]: https://inversionofgreatness.org/rival-ultimates#sec-10-1-3
[madhyamaka]: https://inversionofgreatness.org/rival-ultimates#sec-10-3-4
[powers]: https://inversionofgreatness.org/modality#sec-7-2-2
[platonism]: https://inversionofgreatness.org/metaphysics#sec-8-1-5
[idealism]: https://inversionofgreatness.org/physics-and-mind#sec-9-5
[convergenceDenial]: https://inversionofgreatness.org/convergence#sec-3-3
[cosmological]: https://inversionofgreatness.org/rival-ultimates#sec-10-1-5
[appendix]: https://inversionofgreatness.org/formal-proof-summary
[appendixF]: https://inversionofgreatness.org/formal-results
