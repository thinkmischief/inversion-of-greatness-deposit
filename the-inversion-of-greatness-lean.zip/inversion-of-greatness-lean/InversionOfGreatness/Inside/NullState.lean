/-!
# The null-state reductio (§3.2.6)

Independent of Appendix B. Distinguishes absolute absence from the
joint absence of the three conditions. The extension to joint absence
takes the no-free-standing-residue thesis (§2.7.4) as an explicit input.
-/

namespace InversionOfGreatness

universe u v w

section NullStateReductio

variable {Candidate : Type u} {Fact : Type v}

/-- A modal witness is a represented determinate way in which the
content holds (§3.2.5). The existence of a description is no witness
unless a determinate way answers to the description. -/
def HasDeterminateWitness
    (isDeterminateWay : Candidate → Prop) (content : Candidate → Prop) : Prop :=
  ∃ candidate, isDeterminateWay candidate ∧ content candidate

/-- The aspect of absolute absence used by §3.2.6: no fact holds
in the represented candidate. `holdsAt` records facts supported by
that candidate itself, and excludes facts about the representation. -/
def AbsoluteAbsence (holdsAt : Candidate → Fact → Prop) (candidate : Candidate) : Prop :=
  ¬ ∃ fact, holdsAt candidate fact

/-- The No-World Reductio (§3.2.6). A possible absolute absence would
have a determinate witness. That same witness would both support an
internal fact and support none. -/
theorem absoluteAbsenceImpossible
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact) :
    ¬ possible (AbsoluteAbsence holdsAt) := by
  intro possibleAbsence
  obtain ⟨candidate, isWay, absence⟩ :=
    (possibleMeansThereIsAWay (AbsoluteAbsence holdsAt)).mp possibleAbsence
  exact absence (determinateWaysSupportFacts candidate isWay)

/-- Facthood requires a bearer (§3.2.1). If an obtaining abstract fact
has a genuine constitutive ground, §1.5.5's account of dependence
requires that ground in the same candidate. The two hypotheses distinguish
identifying such a ground from requiring its presence wherever the fact
obtains. A representation or merely possible realization does not by
itself supply either hypothesis. Nothing here types the ground as T, S
or Φ. -/
theorem abstractFactHasBasisInSameCandidate
    {Basis : Type w}
    (holdsAt : Candidate → Fact → Prop)
    (isAbstractFact : Fact → Prop)
    (structuralGroundOf : Basis → Fact → Prop)
    (basisPresentAt : Candidate → Basis → Prop)
    (abstractFactHasGround :
      ∀ candidate fact, isAbstractFact fact → holdsAt candidate fact →
        ∃ basis, structuralGroundOf basis fact)
    (factCannotObtainWithoutItsGround :
      ∀ basis fact, structuralGroundOf basis fact →
        ∀ candidate, holdsAt candidate fact → basisPresentAt candidate basis)
    (candidate : Candidate) (fact : Fact)
    (isAbstract : isAbstractFact fact) (obtains : holdsAt candidate fact) :
    ∃ basis, structuralGroundOf basis fact ∧ basisPresentAt candidate basis := by
  obtain ⟨basis, grounds⟩ := abstractFactHasGround candidate fact isAbstract obtains
  exact ⟨basis, grounds, factCannotObtainWithoutItsGround basis fact grounds candidate obtains⟩

/-- Each condition is absent. This is stronger than the negation of
their conjunction, which requires only a failure of at least one. -/
def JointAbsence
    (temporality spatiality substantiality : Candidate → Prop) (candidate : Candidate) : Prop :=
  ¬ temporality candidate ∧ ¬ spatiality candidate ∧ ¬ substantiality candidate

/-- The independent extension of §3.2.6 to joint absence takes the
no-free-standing-residue thesis from §2.7.4 as an explicit input. -/
theorem jointAbsenceImpossibleWithNoResidue
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (temporality spatiality substantiality : Candidate → Prop)
    (noFreeStandingResidue :
      ∀ candidate, JointAbsence temporality spatiality substantiality candidate →
        AbsoluteAbsence holdsAt candidate) :
    ¬ possible (JointAbsence temporality spatiality substantiality) := by
  intro possibleJointAbsence
  obtain ⟨candidate, isWay, jointAbsence⟩ :=
    (possibleMeansThereIsAWay (JointAbsence temporality spatiality substantiality)).mp
      possibleJointAbsence
  exact noFreeStandingResidue candidate jointAbsence
    (determinateWaysSupportFacts candidate isWay)

/-! ## Bearer-route theorems: conditional, not the book's (review 2026-11-27)

The theorems below were written on 2026-11-27 as a proposed second route
to the residue thesis, □C, □◇C and □(T ∧ S ∧ Φ). Each is valid from its
stated inputs. An independent review (REVIEW-FINDINGS-null-route-sonnet.md)
found that two inputs are not the book's own: `presentBearersStandInTime`
/ `presentBearersOccupy` (the book separates being borne from standing in
time: §3.2.4, "doesn't secure T merely because it obtains"; §2.4.10, "A
static pattern of difference survives"), and `determinateWaysSupportFacts`
read as *internal* facts with a present bearer (the book leaves the
objectless world open, §3.2.6, and lets an empty world support "nothing
exists", §2.7.2, borne by the modal structure, which is no occupant,
§2.8.3). They are kept as conditional theorems: they show exactly what
those inputs would buy. They are not results of the book. Nor are they independent of the S5 pipeline:
`possibleMeansThereIsAWay` is its one-range line, as §3.2.6 admits. -/

/-- *No free-standing residue*, conditional on the bearer inputs below (see the section note).
Facthood requires a bearer present in the candidate (§3.2.1; §1.5.5,
dependence). To be present in a candidate is to be real there, and to be
anything real is to stand in time, space and substance (§1.5, the
definition of existence; defended in §2.8.2). A candidate in which all
three conditions are absent therefore has no bearer, so it supports no
fact. `holdsAt` records facts about how things are in the candidate:
facts about the representation, and facts about Reality's modal range
such as what pluralities could have, are not internal facts of the
candidate. Only the temporal limb is used. -/
theorem noFreeStandingResidueFromExistence {Basis : Type w}
    (holdsAt : Candidate → Fact → Prop)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality spatiality substantiality : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersStandInTime :
      ∀ candidate basis, basisPresentAt candidate basis → temporality candidate) :
    ∀ candidate, JointAbsence temporality spatiality substantiality candidate →
      AbsoluteAbsence holdsAt candidate := by
  intro candidate jointAbsence ⟨fact, holds⟩
  obtain ⟨basis, present⟩ := factsHaveBearers candidate fact holds
  exact jointAbsence.1 (presentBearersStandInTime candidate basis present)

/-- Conditional (see the section note). The Null-State Reductio for joint absence with the residue thesis
from the bearer inputs (see the section note). -/
theorem jointAbsenceImpossibleFromExistence {Basis : Type w}
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality spatiality substantiality : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersStandInTime :
      ∀ candidate basis, basisPresentAt candidate basis → temporality candidate) :
    ¬ possible (JointAbsence temporality spatiality substantiality) :=
  jointAbsenceImpossibleWithNoResidue possible isDeterminateWay holdsAt
    possibleMeansThereIsAWay determinateWaysSupportFacts
    temporality spatiality substantiality
    (noFreeStandingResidueFromExistence holdsAt basisPresentAt
      temporality spatiality substantiality factsHaveBearers presentBearersStandInTime)

/-- Conditional (see the section note). Every possible way contains change.
A possible content has a determinate way as witness (§3.2.5); a way
supports a fact (§2.4.16); the fact's bearer is present and real there,
so it stands in time (§1.5). Time is the standing of states one before
another, and moments differ only by what fills them (§1.4.1, §2.4.9), so
a candidate with time has states that give way to one another: change.
A world where change is not even possible lacks actual change, so it is
no possible way, given the bearer inputs. -/
theorem determinateWaysContainChange {Basis : Type w}
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality change : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersStandInTime :
      ∀ candidate basis, basisPresentAt candidate basis → temporality candidate)
    (timeIsSuccessionOfDifferingStates : ∀ candidate, temporality candidate → change candidate) :
    ∀ candidate, isDeterminateWay candidate → change candidate := by
  intro candidate isWay
  obtain ⟨fact, holds⟩ := determinateWaysSupportFacts candidate isWay
  obtain ⟨basis, present⟩ := factsHaveBearers candidate fact holds
  exact timeIsSuccessionOfDifferingStates candidate
    (presentBearersStandInTime candidate basis present)

/-- Conditional (see the section note). *Some change is necessary* (□C, §2.9.1) from the bearer inputs: no possible
way is changeless. §2.9.1 reaches □C from *Nature is necessary* and the
Frozen-World Test; this route replaces those with the bearer inputs. -/
theorem someChangeIsNecessary {Basis : Type w}
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality change : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersStandInTime :
      ∀ candidate basis, basisPresentAt candidate basis → temporality candidate)
    (timeIsSuccessionOfDifferingStates : ∀ candidate, temporality candidate → change candidate) :
    ¬ possible (fun candidate => ¬ change candidate) := by
  intro possibleChangeless
  obtain ⟨candidate, isWay, changeless⟩ :=
    (possibleMeansThereIsAWay (fun candidate => ¬ change candidate)).mp possibleChangeless
  exact changeless (determinateWaysContainChange isDeterminateWay holdsAt
    determinateWaysSupportFacts basisPresentAt temporality change factsHaveBearers
    presentBearersStandInTime timeIsSuccessionOfDifferingStates candidate isWay)

/-- Conditional (see the section note). Every possible way has time, space and substance, by the same route
run on all three limbs. A way supports a fact (§2.4.16); the fact's
bearer is real where it holds; to be real is to occupy, and occupying
takes a *when*, a *where* and a *what* (§1.5). At the resolution of
§1.4, a *when* is a position among states one before another (§1.4.1),
a *where* is one end of a crossable interval between occupiable places
(§1.4.2), and a *what* occupies the carrier-role across a transition
(§1.4.3). The route rests on §1.5's account of existence, defended in
§2.8.2 by the Difference Principle and *Concrete work incurs the
conditions*. The review found that defense does not carry these inputs (see the section note). -/
theorem determinateWaysHaveTheConditions {Basis : Type w}
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality spatiality substantiality : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersOccupy :
      ∀ candidate basis, basisPresentAt candidate basis →
        temporality candidate ∧ spatiality candidate ∧ substantiality candidate) :
    ∀ candidate, isDeterminateWay candidate →
      temporality candidate ∧ spatiality candidate ∧ substantiality candidate := by
  intro candidate isWay
  obtain ⟨fact, holds⟩ := determinateWaysSupportFacts candidate isWay
  obtain ⟨basis, present⟩ := factsHaveBearers candidate fact holds
  exact presentBearersOccupy candidate basis present

/-- Conditional (see the section note). No possible way lacks any of the three conditions: □(T ∧ S ∧ Φ) in
the way semantics of §3.2.5, given the bearer inputs, without the
witnesses of change and movement. -/
theorem noPossibleWayLacksTheConditions {Basis : Type w}
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality spatiality substantiality : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersOccupy :
      ∀ candidate basis, basisPresentAt candidate basis →
        temporality candidate ∧ spatiality candidate ∧ substantiality candidate) :
    ¬ possible (fun candidate =>
      ¬ (temporality candidate ∧ spatiality candidate ∧ substantiality candidate)) := by
  intro possibleLack
  obtain ⟨candidate, isWay, lacks⟩ := (possibleMeansThereIsAWay _).mp possibleLack
  exact lacks (determinateWaysHaveTheConditions isDeterminateWay holdsAt
    determinateWaysSupportFacts basisPresentAt temporality spatiality substantiality
    factsHaveBearers presentBearersOccupy candidate isWay)

/-- Conditional (see the section note); the Reverse Lift is not met on the book's premises. The diagnostic grants that fully
typed conditions make change possible, (T ∧ S ∧ Φ) → ◇C (§2.4.9), and
holds that Chapter 3 cannot deliver T, S and Φ under every evaluation
without importing Chapter 2's identification. The route above delivers
them from facthood and occupancy (§§2.4.16, 1.5, 1.4) instead, so □◇C
would follow by universal modus ponens, given the bearer inputs. -/
theorem reverseLift {Basis : Type w}
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality spatiality substantiality changePossibleAt : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersOccupy :
      ∀ candidate basis, basisPresentAt candidate basis →
        temporality candidate ∧ spatiality candidate ∧ substantiality candidate)
    (conditionsSufficeForPossibleChange : ∀ candidate,
      temporality candidate ∧ spatiality candidate ∧ substantiality candidate →
        changePossibleAt candidate) :
    ¬ possible (fun candidate => ¬ changePossibleAt candidate) := by
  intro possibleNoChange
  obtain ⟨candidate, isWay, noChange⟩ := (possibleMeansThereIsAWay _).mp possibleNoChange
  exact noChange (conditionsSufficeForPossibleChange candidate
    (determinateWaysHaveTheConditions isDeterminateWay holdsAt determinateWaysSupportFacts
      basisPresentAt temporality spatiality substantiality factsHaveBearers
      presentBearersOccupy candidate isWay))

/-- Conditional (see the section note). No possible way is changeless. With actuality implying possibility at
each way, a way where change is not possible is changeless, so the
necessary possibility of change follows, given the bearer inputs. -/
theorem noPossibleChangelessWay {Basis : Type w}
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (basisPresentAt : Candidate → Basis → Prop)
    (temporality change changePossibleAt : Candidate → Prop)
    (factsHaveBearers :
      ∀ candidate fact, holdsAt candidate fact → ∃ basis, basisPresentAt candidate basis)
    (presentBearersStandInTime :
      ∀ candidate basis, basisPresentAt candidate basis → temporality candidate)
    (timeIsSuccessionOfDifferingStates : ∀ candidate, temporality candidate → change candidate)
    (actualityImpliesPossibility : ∀ candidate, change candidate → changePossibleAt candidate) :
    ¬ possible (fun candidate => ¬ changePossibleAt candidate) := by
  intro possibleNoChange
  obtain ⟨candidate, isWay, noPossibleChange⟩ :=
    (possibleMeansThereIsAWay (fun candidate => ¬ changePossibleAt candidate)).mp possibleNoChange
  exact noPossibleChange (actualityImpliesPossibility candidate
    (determinateWaysContainChange isDeterminateWay holdsAt determinateWaysSupportFacts
      basisPresentAt temporality change factsHaveBearers presentBearersStandInTime
      timeIsSuccessionOfDifferingStates candidate isWay))

-- A toy countermodel to the stronger inference without no-free-standing
-- residue. The fact has a basis in its candidate despite the joint
-- absence of the three conditions. The basis is not given any of the
-- three conditions' roles as the proof needs them.
example :
    let isWay : Unit → Prop := fun _ => True
    let holdsAt : Unit → Unit → Prop := fun _ _ => True
    let structuralGroundOf : Unit → Unit → Prop := fun _ _ => True
    let basisPresentAt : Unit → Unit → Prop := fun _ _ => True
    let absent : Unit → Prop := fun _ => False
    HasDeterminateWitness isWay (JointAbsence absent absent absent) ∧
      (∃ basis, structuralGroundOf basis () ∧ basisPresentAt () basis) ∧
      ¬ HasDeterminateWitness isWay (AbsoluteAbsence holdsAt) := by
  intro isWay holdsAt structuralGroundOf basisPresentAt absent
  refine ⟨⟨(), True.intro, id, id, id⟩, ?_, ?_⟩
  · exact abstractFactHasBasisInSameCandidate holdsAt (fun _ => True)
      structuralGroundOf basisPresentAt (fun _ _ _ _ => ⟨(), True.intro⟩)
      (fun _ _ _ _ _ => True.intro) () () True.intro True.intro
  · exact absoluteAbsenceImpossible (HasDeterminateWitness isWay) isWay holdsAt
      (fun _ => Iff.rfl) (fun _ _ => ⟨(), True.intro⟩)

#print axioms absoluteAbsenceImpossible
#print axioms abstractFactHasBasisInSameCandidate
#print axioms jointAbsenceImpossibleWithNoResidue
#print axioms noFreeStandingResidueFromExistence
#print axioms jointAbsenceImpossibleFromExistence
#print axioms determinateWaysContainChange
#print axioms noPossibleChangelessWay
#print axioms someChangeIsNecessary
#print axioms determinateWaysHaveTheConditions
#print axioms noPossibleWayLacksTheConditions
#print axioms reverseLift

end NullStateReductio

end InversionOfGreatness
