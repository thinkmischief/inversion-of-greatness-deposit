/-!
# The null-state reductio (§3.2.6)

Independent of Appendix B. Distinguishes absolute absence from the
joint absence of the three conditions. The extension to joint absence
takes the no-free-standing-residue thesis (§2.7.4) as an explicit input.
-/

namespace InversionOfGreatness

universe u v w

section NullStateReductio

variable {Candidate : Type u} {Fact : Type v}

/-- A modal witness is a represented determinate way in which the
content holds (§3.2.5). The existence of a description is no witness
unless a determinate way answers to the description. -/
def HasDeterminateWitness
    (isDeterminateWay : Candidate → Prop) (content : Candidate → Prop) : Prop :=
  ∃ candidate, isDeterminateWay candidate ∧ content candidate

/-- The aspect of absolute absence used by §3.2.6: no fact holds
in the represented candidate. `holdsAt` records facts supported by
that candidate itself, and excludes facts about the representation. -/
def AbsoluteAbsence (holdsAt : Candidate → Fact → Prop) (candidate : Candidate) : Prop :=
  ¬ ∃ fact, holdsAt candidate fact

/-- The No-World Reductio (§3.2.6). A possible absolute absence would
have a determinate witness. That same witness would both support an
internal fact and support none. -/
theorem absoluteAbsenceImpossible
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact) :
    ¬ possible (AbsoluteAbsence holdsAt) := by
  intro possibleAbsence
  obtain ⟨candidate, isWay, absence⟩ :=
    (possibleMeansThereIsAWay (AbsoluteAbsence holdsAt)).mp possibleAbsence
  exact absence (determinateWaysSupportFacts candidate isWay)

/-- Facthood requires a bearer (§3.2.1). If an obtaining abstract fact
has a genuine constitutive ground, §1.5.5's account of dependence
requires that ground in the same candidate. The two hypotheses distinguish
identifying such a ground from requiring its presence wherever the fact
obtains. A representation or merely possible realization does not by
itself supply either hypothesis. Nothing here types the ground as T, S
or Φ. -/
theorem abstractFactHasBasisInSameCandidate
    {Basis : Type w}
    (holdsAt : Candidate → Fact → Prop)
    (isAbstractFact : Fact → Prop)
    (structuralGroundOf : Basis → Fact → Prop)
    (basisPresentAt : Candidate → Basis → Prop)
    (abstractFactHasGround :
      ∀ candidate fact, isAbstractFact fact → holdsAt candidate fact →
        ∃ basis, structuralGroundOf basis fact)
    (factCannotObtainWithoutItsGround :
      ∀ basis fact, structuralGroundOf basis fact →
        ∀ candidate, holdsAt candidate fact → basisPresentAt candidate basis)
    (candidate : Candidate) (fact : Fact)
    (isAbstract : isAbstractFact fact) (obtains : holdsAt candidate fact) :
    ∃ basis, structuralGroundOf basis fact ∧ basisPresentAt candidate basis := by
  obtain ⟨basis, grounds⟩ := abstractFactHasGround candidate fact isAbstract obtains
  exact ⟨basis, grounds, factCannotObtainWithoutItsGround basis fact grounds candidate obtains⟩

/-- Each condition is absent. This is stronger than the negation of
their conjunction, which requires only a failure of at least one. -/
def JointAbsence
    (temporality spatiality substantiality : Candidate → Prop) (candidate : Candidate) : Prop :=
  ¬ temporality candidate ∧ ¬ spatiality candidate ∧ ¬ substantiality candidate

/-- The independent extension of §3.2.6 to joint absence takes the
no-free-standing-residue thesis from §2.7.4 as an explicit input. -/
theorem jointAbsenceImpossibleWithNoResidue
    (possible : (Candidate → Prop) → Prop)
    (isDeterminateWay : Candidate → Prop)
    (holdsAt : Candidate → Fact → Prop)
    (possibleMeansThereIsAWay :
      ∀ content, possible content ↔ HasDeterminateWitness isDeterminateWay content)
    (determinateWaysSupportFacts :
      ∀ candidate, isDeterminateWay candidate → ∃ fact, holdsAt candidate fact)
    (temporality spatiality substantiality : Candidate → Prop)
    (noFreeStandingResidue :
      ∀ candidate, JointAbsence temporality spatiality substantiality candidate →
        AbsoluteAbsence holdsAt candidate) :
    ¬ possible (JointAbsence temporality spatiality substantiality) := by
  intro possibleJointAbsence
  obtain ⟨candidate, isWay, jointAbsence⟩ :=
    (possibleMeansThereIsAWay (JointAbsence temporality spatiality substantiality)).mp
      possibleJointAbsence
  exact noFreeStandingResidue candidate jointAbsence
    (determinateWaysSupportFacts candidate isWay)

-- A toy countermodel to the stronger inference without no-free-standing
-- residue. The fact has a basis in its candidate despite the joint
-- absence of the three conditions. The basis is not given any of the
-- three conditions' roles as the proof needs them.
example :
    let isWay : Unit → Prop := fun _ => True
    let holdsAt : Unit → Unit → Prop := fun _ _ => True
    let structuralGroundOf : Unit → Unit → Prop := fun _ _ => True
    let basisPresentAt : Unit → Unit → Prop := fun _ _ => True
    let absent : Unit → Prop := fun _ => False
    HasDeterminateWitness isWay (JointAbsence absent absent absent) ∧
      (∃ basis, structuralGroundOf basis () ∧ basisPresentAt () basis) ∧
      ¬ HasDeterminateWitness isWay (AbsoluteAbsence holdsAt) := by
  intro isWay holdsAt structuralGroundOf basisPresentAt absent
  refine ⟨⟨(), True.intro, id, id, id⟩, ?_, ?_⟩
  · exact abstractFactHasBasisInSameCandidate holdsAt (fun _ => True)
      structuralGroundOf basisPresentAt (fun _ _ _ _ => ⟨(), True.intro⟩)
      (fun _ _ _ _ _ => True.intro) () () True.intro True.intro
  · exact absoluteAbsenceImpossible (HasDeterminateWitness isWay) isWay holdsAt
      (fun _ => Iff.rfl) (fun _ _ => ⟨(), True.intro⟩)

#print axioms absoluteAbsenceImpossible
#print axioms abstractFactHasBasisInSameCandidate
#print axioms jointAbsenceImpossibleWithNoResidue

end NullStateReductio

end InversionOfGreatness
