import InversionOfGreatness.Basic

/-!
# Necessity of the three conditions (Appendix B lines 1–11)

From No Beyond and the one assessed range to the necessity of
T, S and Φ (§§1.1–1.2, §2.1, §2.2, §§2.4.1–2.4.5). The actual change
witness and actuality-to-possibility are explicit hypotheses. The
reflective route derives line 10 from its separately stated premises.
The movement route (§2.4.6) reaches the same conclusion from actual
displacement, without Attention Crosses a Real Separation, and either route
suffices.
Locally instantiated objects and particular histories are outside the
statement.
-/

namespace InversionOfGreatness

universe u v w x

variable {Evaluation : Type u} {Content : Type v}

/-- Line 1 (§1.1). Structural belonging to Reality is the criterion
for being real. This excludes real content exterior to Reality. -/
theorem noRealContentOutsideReality
    {Item : Type w} (real belongsToReality : Item → Prop)
    (realityRole : ∀ item, belongsToReality item ↔ real item) :
    ¬ ∃ item, real item ∧ ¬ belongsToReality item := by
  intro exterior
  obtain ⟨item, realItem, outside⟩ := exterior
  exact outside ((realityRole item).mpr realItem)

/-- Lines 1, 3 and 4 (§§1.1–1.2, §2.1.4). Real possibility is
defined by the complete range being assessed. Each real evaluation
assesses that same range. Local reachability is outside this predicate.
The same-range premise represents the book's substantive application
of No Beyond to real modal evaluation. -/
theorem evaluationInvarianceFromOneRange
    {Range : Type x} (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop) :
    ∀ evaluation content,
      permits (rangeAssessed evaluation) content ↔ permits realityRange content := by
  intro evaluation content
  rw [oneRange evaluation]

/-- Lines 5–7. A fixed content keeps either verdict across real evaluations,
given the equivalence in line 3. Modal bivalence (line 2) is unnecessary
for these two implications. -/
theorem modalStatusInvariant
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (reference : Evaluation) (content : Content) :
    (possibleAt reference content →
      Necessary (fun evaluation => possibleAt evaluation content)) ∧
    (¬ possibleAt reference content →
      Necessary (fun evaluation => ¬ possibleAt evaluation content)) := by
  constructor
  · intro possibleAtReference evaluation
    have permitted := (evaluationInvariance reference content).mp possibleAtReference
    exact (evaluationInvariance evaluation content).mpr permitted
  · intro impossibleAtReference evaluation possibleAtEvaluation
    have permitted := (evaluationInvariance evaluation content).mp possibleAtEvaluation
    exact impossibleAtReference ((evaluationInvariance reference content).mpr permitted)

/-- Lines 8–9. An actual change supplies the initial possibility judgment. -/
theorem changeNecessarilyPossible
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (change : Content)
    (actualChange : Prop)
    (witness : actualChange)
    (actualityImpliesPossibility : actualChange → possibleAt actualEvaluation change) :
    Necessary (fun evaluation => possibleAt evaluation change) :=
  (modalStatusInvariant capacity possibleAt evaluationInvariance actualEvaluation change).1
    (actualityImpliesPossibility witness)

/-- Line 11. Apply the constitutive requirement (line 10) pointwise to the
necessary possibility of change (line 9). -/
theorem threeConditionsNecessary
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (change : Content)
    (actualChange : Prop)
    (witness : actualChange)
    (actualityImpliesPossibility : actualChange → possibleAt actualEvaluation change)
    (temporality spatiality substantiality : Evaluation → Prop)
    (constitutiveRequirement :
      Necessary (fun evaluation => possibleAt evaluation change →
        ThreeConditions temporality spatiality substantiality evaluation)) :
    Necessary (ThreeConditions temporality spatiality substantiality) := by
  have possibleThroughout :=
    changeNecessarilyPossible capacity possibleAt evaluationInvariance
      actualEvaluation change actualChange witness actualityImpliesPossibility
  intro evaluation
  exact constitutiveRequirement evaluation (possibleThroughout evaluation)

/-- The reflective route's premises (§§2.4.1–2.4.5). The predicates
describe what Reality's standing capacity provides at an evaluation.
The first bridge packages Capacity Constitution together with the
application of the limb criteria to the reflective witness. The
bilateral defense of that bridge remains in the manuscript.
-/
structure ReflectiveRoute (Evaluation : Type u) (actualChange canChange : Prop)
    (temporality spatiality substantiality : Evaluation → Prop) where
  orderedSuccession : Evaluation → Prop
  differentiatedPoles : Evaluation → Prop
  crossableSeparation : Evaluation → Prop
  persistentBearing : Evaluation → Prop

  capacityProvidesCriteria : actualChange → canChange →
    Necessary (fun evaluation =>
      orderedSuccession evaluation ∧ differentiatedPoles evaluation ∧ persistentBearing evaluation)
  orderedSuccessionGivesTemporality :
    ∀ evaluation, orderedSuccession evaluation → temporality evaluation
  attentionCrossesRealSeparation :
    ∀ evaluation, differentiatedPoles evaluation → crossableSeparation evaluation
  relationalDistinctness :
    ∀ evaluation, crossableSeparation evaluation → spatiality evaluation
  crossIntervalPersistence :
    ∀ evaluation, persistentBearing evaluation → substantiality evaluation

/-- Line 10. Under every evaluation, really possible change requires
all three conditions. The spatial limb passes through Attention Crosses a
Real Separation before applying Relational Distinctness. -/
theorem changeRequiresThreeConditionsFromReflection
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (change : Content) (actualChange : Prop) (witness : actualChange)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : ReflectiveRoute Evaluation actualChange (capacity change)
      temporality spatiality substantiality) :
    Necessary (fun evaluation => possibleAt evaluation change →
      ThreeConditions temporality spatiality substantiality evaluation) := by
  intro evaluation possibleChange
  have permitted := (evaluationInvariance evaluation change).mp possibleChange
  obtain ⟨order, poles, bearing⟩ := route.capacityProvidesCriteria witness permitted evaluation
  have separation := route.attentionCrossesRealSeparation evaluation poles
  exact ⟨route.orderedSuccessionGivesTemporality evaluation order,
    route.relationalDistinctness evaluation separation,
    route.crossIntervalPersistence evaluation bearing⟩

/-- Line 11 with line 10 supplied by the reflective route. -/
theorem threeConditionsNecessaryFromReflection
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (change : Content)
    (actualChange : Prop) (witness : actualChange)
    (actualityImpliesPossibility : actualChange → possibleAt actualEvaluation change)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : ReflectiveRoute Evaluation actualChange (capacity change)
      temporality spatiality substantiality) :
    Necessary (ThreeConditions temporality spatiality substantiality) :=
  threeConditionsNecessary capacity possibleAt evaluationInvariance actualEvaluation change
    actualChange witness actualityImpliesPossibility temporality spatiality substantiality
    (changeRequiresThreeConditionsFromReflection capacity possibleAt evaluationInvariance
      change actualChange witness temporality spatiality substantiality route)

/-- The movement route's premises (§2.4.6, *From Movement*). The witness
is actual displacement. A displacement occupies a before and an after,
crosses an interval between positions, and is undergone by what persists
across it; by Capacity Constitution the capacity for movement consists in
structure that provides that order, interval and persistence
(*Containment*). The crossable separation comes from the displacement
itself, so this route needs neither Attention Crosses a Real Separation nor the
reflective witness. -/
structure MovementRoute (Evaluation : Type u) (actualMovement canMove : Prop)
    (temporality spatiality substantiality : Evaluation → Prop) where
  orderedSuccession : Evaluation → Prop
  crossableSeparation : Evaluation → Prop
  persistentBearing : Evaluation → Prop

  containment : actualMovement → canMove →
    Necessary (fun evaluation =>
      orderedSuccession evaluation ∧ crossableSeparation evaluation ∧ persistentBearing evaluation)
  orderedSuccessionGivesTemporality :
    ∀ evaluation, orderedSuccession evaluation → temporality evaluation
  relationalDistinctness :
    ∀ evaluation, crossableSeparation evaluation → spatiality evaluation
  crossIntervalPersistence :
    ∀ evaluation, persistentBearing evaluation → substantiality evaluation

/-- Step 4 of *From Movement*: under every evaluation, really possible
movement requires all three conditions. □(◇M → T ∧ S ∧ Φ). -/
theorem movementRequiresThreeConditions
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (movement : Content) (actualMovement : Prop) (witness : actualMovement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : MovementRoute Evaluation actualMovement (capacity movement)
      temporality spatiality substantiality) :
    Necessary (fun evaluation => possibleAt evaluation movement →
      ThreeConditions temporality spatiality substantiality evaluation) := by
  intro evaluation possibleMovement
  have permitted := (evaluationInvariance evaluation movement).mp possibleMovement
  obtain ⟨order, separation, bearing⟩ := route.containment witness permitted evaluation
  exact ⟨route.orderedSuccessionGivesTemporality evaluation order,
    route.relationalDistinctness evaluation separation,
    route.crossIntervalPersistence evaluation bearing⟩

/-- *Time, space, and substance are necessary*, from movement (§2.4.6).
The same modal lift as line 11, applied to movement. -/
theorem threeConditionsNecessaryFromMovement
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (movement : Content)
    (actualMovement : Prop) (witness : actualMovement)
    (actualityImpliesPossibility : actualMovement → possibleAt actualEvaluation movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : MovementRoute Evaluation actualMovement (capacity movement)
      temporality spatiality substantiality) :
    Necessary (ThreeConditions temporality spatiality substantiality) :=
  threeConditionsNecessary capacity possibleAt evaluationInvariance actualEvaluation movement
    actualMovement witness actualityImpliesPossibility temporality spatiality substantiality
    (movementRequiresThreeConditions capacity possibleAt evaluationInvariance
      movement actualMovement witness temporality spatiality substantiality route)

/-- The two routes are independent at their vulnerable witness (§2.4.6).
Either one suffices: a reader who declines Attention Crosses a Real Separation but
grants actual displacement keeps □(T ∧ S ∧ Φ), and a reader who denies
displacement keeps it by granting the reflective route's bridges. -/
theorem threeConditionsNecessaryByEitherRoute
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (change movement : Content)
    (actualChange actualMovement : Prop)
    (changeActualityImpliesPossibility : actualChange → possibleAt actualEvaluation change)
    (movementActualityImpliesPossibility :
      actualMovement → possibleAt actualEvaluation movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (routes :
      (actualChange ∧ Nonempty (ReflectiveRoute Evaluation actualChange (capacity change)
        temporality spatiality substantiality)) ∨
      (actualMovement ∧ Nonempty (MovementRoute Evaluation actualMovement (capacity movement)
        temporality spatiality substantiality))) :
    Necessary (ThreeConditions temporality spatiality substantiality) := by
  rcases routes with ⟨witness, ⟨route⟩⟩ | ⟨witness, ⟨route⟩⟩
  · exact threeConditionsNecessaryFromReflection capacity possibleAt evaluationInvariance
      actualEvaluation change actualChange witness changeActualityImpliesPossibility
      temporality spatiality substantiality route
  · exact threeConditionsNecessaryFromMovement capacity possibleAt evaluationInvariance
      actualEvaluation movement actualMovement witness movementActualityImpliesPossibility
      temporality spatiality substantiality route

#print axioms changeRequiresThreeConditionsFromReflection
#print axioms threeConditionsNecessaryFromReflection
#print axioms movementRequiresThreeConditions
#print axioms threeConditionsNecessaryFromMovement
#print axioms threeConditionsNecessaryByEitherRoute

-- A bivalent evaluation-indexed verdict can flip with the evaluation.
-- The verdict in this model is local; it lacks the one-range premise.
example :
    let localPossibility : Bool → Prop := fun evaluation => evaluation = true
    (∀ evaluation, localPossibility evaluation ∨ ¬ localPossibility evaluation) ∧
      localPossibility true ∧ ¬ Necessary localPossibility := by
  exact ⟨fun evaluation => Classical.em (evaluation = true),
    rfl, fun everywhere => Bool.noConfusion (everywhere false)⟩

#print axioms evaluationInvarianceFromOneRange

end InversionOfGreatness
