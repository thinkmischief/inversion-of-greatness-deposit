import InversionOfGreatness.Basic

/-!
# Reality–Nature identity (Appendix B lines 12–13)

Line 12's realizer reading (§2.6.10) and the coverage, individuation
and no-surplus steps of §2.8.3. The two wholes are independently
supplied, and the manuscript's defenses of the coverage inputs stay
outside the proof.
-/

namespace InversionOfGreatness

universe u v w

/-- Line 12's stronger reading (§2.6.10). The domain is concrete
change-realizers and the predicates track the three conditions at work
in the same realizer. The operative-work principle and the three pivots
are supplied as hypotheses. This reading is separate from line 13. -/
theorem conditionsMutuallyImplicateInRealizers
    {Realizer : Type u}
    (temporalWork spatialWork substantialWork : Realizer → Prop)
    (operativeWorkPrinciple : Prop)
    (formalDescriptionsDependOnOperativeWork : operativeWorkPrinciple)
    (successionPivot : operativeWorkPrinciple →
      ∀ r, temporalWork r → spatialWork r ∧ substantialWork r)
    (extensionPivot : operativeWorkPrinciple →
      ∀ r, spatialWork r → temporalWork r ∧ substantialWork r)
    (persistencePivot : operativeWorkPrinciple →
      ∀ r, substantialWork r → temporalWork r ∧ spatialWork r) :
    ∀ r, (temporalWork r ↔ spatialWork r ∧ substantialWork r) ∧
      (spatialWork r ↔ temporalWork r ∧ substantialWork r) ∧
      (substantialWork r ↔ temporalWork r ∧ spatialWork r) := by
  intro r
  have succession := successionPivot formalDescriptionsDependOnOperativeWork r
  have extension := extensionPivot formalDescriptionsDependOnOperativeWork r
  have persistence := persistencePivot formalDescriptionsDependOnOperativeWork r
  exact ⟨⟨succession, fun h => (extension h.1).1⟩,
    ⟨extension, fun h => (succession h.1).1⟩,
    ⟨persistence, fun h => (succession h.1).2⟩⟩

/-- The totality reading of Nature in §2.8.3, premise 6a. -/
def NatureContents {Item : Type w}
    (fieldContent articulation abstraction : Item → Prop) (item : Item) : Prop :=
  fieldContent item ∨ articulation item ∨ abstraction item

/-- The coverage inputs to line 13 (§2.8.3). The two wholes are independently
supplied. `jointComplex` designates the joint T/S/Φ structure from the
structure-wide reading of line 12. The three profile predicates below
refer to that complex, its determinate articulations and abstractions.
The manuscript's defenses of these inputs remain outside this proof. -/
structure RealityNatureCoverage (Whole : Type u) (Field : Type v) (Item : Type w)
    (nature reality : Whole) (jointComplex : Field) where
  belongs : Whole → Item → Prop
  fieldOf : Whole → Field
  real : Item → Prop
  fieldContent : Item → Prop
  concreteOccupant : Item → Prop
  abstractum : Item → Prop
  articulation : Item → Prop
  abstraction : Item → Prop
  -- Line 12's structure-wide reading (§1.4.4, §2.6.10).
  natureNamesJointComplex : fieldOf nature = jointComplex
  -- Premise 6a's totality reading.
  natureTotality :
    ∀ item, belongs nature item ↔ NatureContents fieldContent articulation abstraction item
  -- No Beyond (§1.1) and the placement of real content (§2.8.3).
  realityIsWhole : ∀ item, belongs reality item ↔ real item
  natureContentsAreReal :
    ∀ item, NatureContents fieldContent articulation abstraction item → real item
  -- Univocal Existence (4a), concrete non-addition (3) and the Abstracta Fork (4).
  univocalExistence :
    ∀ item, real item → fieldContent item ∨ concreteOccupant item ∨ abstractum item
  concreteNonAddition : ∀ item, concreteOccupant item → articulation item
  abstractaFork : ∀ item, abstractum item → abstraction item

/-- Coverage plus the individuation inputs to line 13. -/
structure RealityNaturePremises (Whole : Type u) (Field : Type v) (Item : Type w)
    (nature reality : Whole) (jointComplex : Field)
    extends RealityNatureCoverage Whole Field Item nature reality jointComplex where
  maximal : Whole → Prop
  positiveDifference : Whole → Whole → Prop
  -- A positive difference between the two wholes must appear in the
  -- complete structural content (premise 5).
  positiveDifferenceNeedsStructuralContent :
    positiveDifference nature reality →
      ∃ item, (belongs nature item ∧ ¬ belongs reality item) ∨
        (belongs reality item ∧ ¬ belongs nature item)
  natureIsMaximal : maximal nature
  realityIsMaximal : maximal reality
  -- The application in premise 6a: if these maximal wholes are
  -- numerically distinct, that requires a positive differentiator.
  -- §2.4.13 expressly applies §2.4.8's concrete individuation
  -- argument to totalities. The formal proof takes that application
  -- as input; being exhaustive alone does not entail it.
  distinctMaximalWholesHavePositiveDifference :
    maximal nature → maximal reality → nature ≠ reality → positiveDifference nature reality

/-- The no-surplus step is the classical contrapositive of positive
individuation for the two maximal wholes. -/
theorem maximalWholesWithNoSurplusAreOne
    {Whole : Type u} {left right : Whole}
    (maximal : Whole → Prop) (positiveDifference : Whole → Whole → Prop)
    (leftIsMaximal : maximal left) (rightIsMaximal : maximal right)
    (distinctWholesHavePositiveDifference :
      maximal left → maximal right → left ≠ right → positiveDifference left right)
    (noPositiveDifference : ¬ positiveDifference left right) :
    left = right := by
  apply Classical.byContradiction
  intro distinct
  exact noPositiveDifference (distinctWholesHavePositiveDifference
    leftIsMaximal rightIsMaximal distinct)

/-- Line 13's exhaustion step. Both directions are checked. -/
theorem realityAndNatureHaveSameContents
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (premises : RealityNatureCoverage Whole Field Item nature reality jointComplex) :
    ∀ item, premises.belongs nature item ↔ premises.belongs reality item := by
  intro item
  constructor
  · intro inNature
    exact (premises.realityIsWhole item).mpr
      (premises.natureContentsAreReal item ((premises.natureTotality item).mp inNature))
  · intro inReality
    have realItem := (premises.realityIsWhole item).mp inReality
    apply (premises.natureTotality item).mpr
    rcases premises.univocalExistence item realItem with field | occupant | abstractItem
    · exact Or.inl field
    · exact Or.inr (Or.inl (premises.concreteNonAddition item occupant))
    · exact Or.inr (Or.inr (premises.abstractaFork item abstractItem))

/-- §3.4.2 describes Reality's role as uniquely filled. If that
uniqueness is granted, the coverage argument establishes that Nature
fills the role, so the names co-refer. This conditional does not derive
uniqueness from No Beyond or bivalence. The canonical identity
proof below takes the structural individuation route. -/
theorem realityIsNatureFromUniqueRole
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (uniqueRealityRole : ∀ whole,
      (∀ item, coverage.belongs whole item ↔ coverage.real item) → whole = reality) :
    nature = reality :=
  uniqueRealityRole nature (fun item =>
    (realityAndNatureHaveSameContents coverage item).trans (coverage.realityIsWhole item))

/-- §1.1 read in terms of structural inclusion of wholes. Every real
whole is included in Reality. A maximal whole admits no proper
enlargement: any containing whole is also included in it. Mutual
structural inclusion identifies the wholes. Here inclusion compares
wholes and is distinct from the belonging of an item to Reality.

For Nature, the remaining application is to show that it is real and
maximal under this same inclusion relation. -/
theorem realMaximalWholeIsReality
    {Whole : Type u} {candidate reality : Whole}
    (realWhole : Whole → Prop) (includedIn : Whole → Whole → Prop)
    (allRealWholesIncluded : ∀ whole, realWhole whole → includedIn whole reality)
    (inclusionAntisymmetric :
      ∀ left right, includedIn left right → includedIn right left → left = right)
    (candidateIsReal : realWhole candidate)
    (candidateIsMaximal : ∀ larger, includedIn candidate larger → includedIn larger candidate) :
    candidate = reality := by
  have candidateInReality := allRealWholesIncluded candidate candidateIsReal
  exact inclusionAntisymmetric candidate reality candidateInReality
    (candidateIsMaximal reality candidateInReality)

/-- §2.8.3 gives Nature all real content. A proposed containing
whole whose contents are real therefore has every one of its contents
in Nature. Turning this into inclusion of wholes requires the explicit
bridge from complete structural content to structural inclusion:
the contents must capture any relevant relations and articulations. -/
theorem natureIsMaximalFromCoverage
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (includedIn : Whole → Whole → Prop)
    (contentInclusionSuffices :
      ∀ left right, (∀ item, coverage.belongs left item → coverage.belongs right item) →
        includedIn left right)
    (superwholeContentsAreReal :
      ∀ larger, includedIn nature larger → ∀ item, coverage.belongs larger item →
        coverage.real item) :
    ∀ larger, includedIn nature larger → includedIn larger nature := by
  intro larger natureInLarger
  apply contentInclusionSuffices larger nature
  intro item inLarger
  have realItem := superwholeContentsAreReal larger natureInLarger item inLarger
  have inReality := (coverage.realityIsWhole item).mpr realItem
  exact (realityAndNatureHaveSameContents coverage item).mpr inReality

/-- Line 13 via the same structural inclusion relation. Coverage gives
both directions of content inclusion specifically for Nature and Reality,
so their identity needs only the inclusion bridge and antisymmetry in
addition to coverage. Maximality of either whole is not a hypothesis. -/
theorem realityIsNatureFromStructuralCoverage
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (includedIn : Whole → Whole → Prop)
    (contentInclusionSuffices :
      ∀ left right, (∀ item, coverage.belongs left item → coverage.belongs right item) →
        includedIn left right)
    (inclusionAntisymmetric :
      ∀ left right, includedIn left right → includedIn right left → left = right) :
    nature = reality := by
  have sameContents := realityAndNatureHaveSameContents coverage
  exact inclusionAntisymmetric nature reality
    (contentInclusionSuffices nature reality (fun item => (sameContents item).mp))
    (contentInclusionSuffices reality nature (fun item => (sameContents item).mpr))

/-- Inclusion of complete structural profiles. The content type includes
the field, its articulations and abstractions (§2.8.3, 6a), including real
relations, constraints and roles (§§1.5, 2.6.1). With this reading,
pointwise content inclusion is the definition of profile inclusion. -/
def StructuralProfileIncluded {Whole : Type u} {Item : Type w}
    (belongs : Whole → Item → Prop) (left right : Whole) : Prop :=
  ∀ item, belongs left item → belongs right item

/-- The coverage proof establishes maximality under profile inclusion.
Any candidate enlargement being compared has only real contents. -/
theorem natureIsMaximalUnderProfileInclusion
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (superwholeContentsAreReal :
      ∀ larger, StructuralProfileIncluded coverage.belongs nature larger →
        ∀ item, coverage.belongs larger item → coverage.real item) :
    ∀ larger, StructuralProfileIncluded coverage.belongs nature larger →
      StructuralProfileIncluded coverage.belongs larger nature :=
  natureIsMaximalFromCoverage coverage (StructuralProfileIncluded coverage.belongs)
    (fun _ _ inclusion => inclusion) superwholeContentsAreReal

/-- Antisymmetry for the pair of maximal wholes in §2.8.3, 6a.
Mutual profile inclusion rules out a positive difference appearing in
either profile. The individuation argument (§§2.4.8, 2.4.13) supplies
the premise that distinct totalities must have such a difference.
The carriers of the profiles are still independently supplied wholes. -/
theorem mutualProfileInclusionIdentifiesRealityAndNature
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (premises : RealityNaturePremises Whole Field Item nature reality jointComplex)
    (natureInReality : StructuralProfileIncluded premises.belongs nature reality)
    (realityInNature : StructuralProfileIncluded premises.belongs reality nature) :
    nature = reality := by
  have noPositiveDifference : ¬ premises.positiveDifference nature reality := by
    intro positiveDifference
    obtain ⟨item, difference⟩ :=
      premises.positiveDifferenceNeedsStructuralContent positiveDifference
    rcases difference with ⟨inNature, outsideReality⟩ | ⟨inReality, outsideNature⟩
    · exact outsideReality (natureInReality item inNature)
    · exact outsideNature (realityInNature item inReality)
  exact maximalWholesWithNoSurplusAreOne premises.maximal premises.positiveDifference
    premises.natureIsMaximal premises.realityIsMaximal
    premises.distinctMaximalWholesHavePositiveDifference noPositiveDifference

/-- Line 13. Coverage supplies mutual profile inclusion. The book's
individuation premises give equality of the maximal wholes. -/
theorem realityIsNature
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (premises : RealityNaturePremises Whole Field Item nature reality jointComplex) :
    nature = reality := by
  have sameContents := realityAndNatureHaveSameContents premises.toRealityNatureCoverage
  exact mutualProfileInclusionIdentifiesRealityAndNature premises
    (fun item => (sameContents item).mp)
    (fun item => (sameContents item).mpr)

/-- The identified whole has the joint T/S/Φ complex as its modal field. -/
theorem realityHasJointModalField
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (premises : RealityNaturePremises Whole Field Item nature reality jointComplex) :
    premises.fieldOf reality = jointComplex :=
  (congrArg premises.fieldOf (realityIsNature premises)).symm.trans
    premises.natureNamesJointComplex

-- Independence check: two stipulated maximal wholes can agree on every
-- content and have no positive differentiator. In this model, positive
-- difference implies a difference in content, but distinctness does
-- not imply positive difference.
example : ∃ (real : Unit → Prop) (belongs : Bool → Unit → Prop) (maximal : Bool → Prop)
    (positiveDifference : Bool → Bool → Prop),
    Necessary (ThreeConditions (fun (_ : Unit) => True) (fun _ => True) (fun _ => True)) ∧
      maximal true ∧ maximal false ∧
      (∀ item, real item ∨ ¬ real item) ∧
      (∀ item, belongs true item ↔ real item) ∧
      (∀ item, belongs false item ↔ real item) ∧
      (positiveDifference true false →
        ∃ item, (belongs true item ∧ ¬ belongs false item) ∨
          (belongs false item ∧ ¬ belongs true item)) ∧
      ¬ positiveDifference true false ∧ true ≠ false :=
  ⟨fun _ => True, fun _ _ => True, fun _ => True, fun _ _ => False,
    fun _ => ⟨True.intro, True.intro, True.intro⟩,
    True.intro, True.intro, fun _ => Or.inl True.intro, fun _ => Iff.rfl,
    fun _ => Iff.rfl, False.elim, id, by decide⟩

#print axioms conditionsMutuallyImplicateInRealizers
#print axioms maximalWholesWithNoSurplusAreOne
#print axioms realityIsNatureFromUniqueRole
#print axioms realMaximalWholeIsReality
#print axioms natureIsMaximalFromCoverage
#print axioms realityIsNatureFromStructuralCoverage
#print axioms natureIsMaximalUnderProfileInclusion
#print axioms mutualProfileInclusionIdentifiesRealityAndNature
#print axioms realityIsNature
#print axioms realityHasJointModalField

end InversionOfGreatness
