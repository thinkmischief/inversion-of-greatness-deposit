import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.MeasureTheory.Integral.FundThmCalculus
import Mathlib.Tactic.Linarith
import Mathlib.Topology.Algebra.Order.Compact
import Mathlib.Topology.Order.IntermediateValue

/-!
# Integrated Dominance Crossing

Source: Chapter 4, §4.6.5 (Finite Expansion Dominance and Integrated Dominance Crossing).
Uses Mathlib v4.8.0 (Lean 4.8.0). Build with `lake build` from the project folder.

`H` is the totality-scale expansion rate. `A = -H'` measures the net reduction
of that rate. Local contraction is represented by a separate predicate and can
occur during positive `H`. The zero of `H` describes a change of global
dominance. The calculus assumes the indicated rate and interval are available,
sufficient cumulative reduction occurs, and, for uniqueness and strict signs,
each zero has a strictly negative derivative.
-/

namespace InversionOfGreatness.IntegratedDominanceCrossing

open Filter MeasureTheory Set
open scoped Topology

/-- A local contraction witness at a time of overall expansion dominance. -/
def LocalContractionDuringExpansion
    (localContraction : ℝ → Prop) (H : ℝ → ℝ) (t : ℝ) : Prop :=
  localContraction t ∧ 0 < H t

/-- The cumulative reduction forces a negative endpoint and an interior zero. -/
theorem crossing_of_integrated_reduction
    {H A : ℝ → ℝ} {start stop : ℝ} (startBeforeStop : start < stop)
    (expansionAtStart : 0 < H start)
    (rateDerivative : ∀ t ∈ Icc start stop, HasDerivAt H (- A t) t)
    (continuousReduction : ContinuousOn A (Icc start stop))
    (accumulatedEnough : H start < ∫ t in start..stop, A t) :
    H stop < 0 ∧ ∃ crossing ∈ Ioo start stop, H crossing = 0 := by
  have balance : (∫ t in start..stop, A t) = - H stop - - H start := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt (f := fun t => - H t)
    · intro t ht
      rw [uIcc_of_le startBeforeStop.le] at ht
      simpa only [neg_neg] using (rateDerivative t ht).neg
    · exact ContinuousOn.intervalIntegrable_of_Icc startBeforeStop.le continuousReduction
  have contractionAtStop : H stop < 0 := by linarith
  obtain ⟨crossing, inInterval, zero⟩ :=
    intermediate_value_Icc' startBeforeStop.le (HasDerivAt.continuousOn rateDerivative)
      (show (0 : ℝ) ∈ Icc (H stop) (H start) from ⟨contractionAtStop.le, expansionAtStart.le⟩)
  have afterStart : start < crossing := by
    refine lt_of_le_of_ne inInterval.1 ?_
    intro same
    rw [same] at expansionAtStart
    linarith
  have beforeStop : crossing < stop := by
    refine lt_of_le_of_ne inInterval.2 ?_
    intro same
    rw [same] at zero
    linarith
  exact ⟨contractionAtStop, crossing, ⟨afterStart, beforeStop⟩, zero⟩

private theorem positive_before_zero {H : ℝ → ℝ} {left z speed : ℝ}
    (leftBefore : left < z) (zero : H z = 0)
    (derivative : HasDerivAt H speed z) (speedNegative : speed < 0) :
    ∃ t ∈ Ioo left z, 0 < H t := by
  have slopeNegative : ∀ᶠ t in 𝓝[≠] z, slope H z t < 0 :=
    (hasDerivAt_iff_tendsto_slope.mp derivative).eventually
      (eventually_lt_nhds speedNegative)
  have slopeLeft : ∀ᶠ t in 𝓝[<] z, slope H z t < 0 :=
    slopeNegative.filter_mono (nhds_left'_le_nhds_ne z)
  have nearby : ∀ᶠ t in 𝓝[<] z, t ∈ Ioo left z :=
    Ioo_mem_nhdsWithin_Iio' leftBefore
  obtain ⟨t, slopeNeg, ht⟩ := (slopeLeft.and nearby).exists
  rw [slope_def_field, zero, sub_zero] at slopeNeg
  refine ⟨t, ht, lt_of_not_ge ?_⟩
  intro nonpositive
  exact (not_lt_of_ge
    (div_nonneg_of_nonpos nonpositive (sub_nonpos.mpr ht.2.le))) slopeNeg

private theorem negative_after_zero {H : ℝ → ℝ} {z right speed : ℝ}
    (beforeRight : z < right) (zero : H z = 0)
    (derivative : HasDerivAt H speed z) (speedNegative : speed < 0) :
    ∃ t ∈ Ioo z right, H t < 0 := by
  have slopeNegative : ∀ᶠ t in 𝓝[≠] z, slope H z t < 0 :=
    (hasDerivAt_iff_tendsto_slope.mp derivative).eventually
      (eventually_lt_nhds speedNegative)
  have slopeRight : ∀ᶠ t in 𝓝[>] z, slope H z t < 0 :=
    slopeNegative.filter_mono (nhds_right'_le_nhds_ne z)
  have nearby : ∀ᶠ t in 𝓝[>] z, t ∈ Ioo z right :=
    Ioo_mem_nhdsWithin_Ioi' beforeRight
  obtain ⟨t, slopeNeg, ht⟩ := (slopeRight.and nearby).exists
  rw [slope_def_field, zero, sub_zero] at slopeNeg
  refine ⟨t, ht, lt_of_not_ge ?_⟩
  intro nonnegative
  exact (not_lt_of_ge (div_nonneg nonnegative (sub_nonneg.mpr ht.1.le))) slopeNeg

/-- If a negative rate returns to zero, its first subsequent zero cannot have a negative derivative. -/
private theorem negative_stays_negative {H : ℝ → ℝ} {a b : ℝ}
    (aBeforeB : a < b) (negativeAtA : H a < 0)
    (continuousRate : ContinuousOn H (Icc a b))
    (downwardAtZero :
      ∀ t ∈ Icc a b, H t = 0 → ∃ speed < 0, HasDerivAt H speed t) :
    H b < 0 := by
  by_contra! nonnegativeAtB
  let zeros := Icc a b ∩ H ⁻¹' ({0} : Set ℝ)
  have compactZeros : IsCompact zeros :=
    isCompact_Icc.of_isClosed_subset
      (continuousRate.preimage_isClosed_of_isClosed isClosed_Icc isClosed_singleton)
      (by exact fun _ ht => ht.1)
  obtain ⟨firstCandidate, inInterval, isZero⟩ :=
    intermediate_value_Icc aBeforeB.le continuousRate
      (show (0 : ℝ) ∈ Icc (H a) (H b) from ⟨negativeAtA.le, nonnegativeAtB⟩)
  have nonemptyZeros : zeros.Nonempty := ⟨firstCandidate, inInterval, mem_singleton_iff.mpr isZero⟩
  obtain ⟨firstZero, isLeast⟩ := compactZeros.exists_isLeast nonemptyZeros
  have firstInInterval : firstZero ∈ Icc a b := isLeast.1.1
  have firstIsZero : H firstZero = 0 := isLeast.1.2
  have aBeforeFirst : a < firstZero := by
    refine lt_of_le_of_ne firstInInterval.1 ?_
    intro same
    rw [same] at negativeAtA
    linarith
  obtain ⟨speed, speedNegative, derivative⟩ :=
    downwardAtZero firstZero firstInInterval firstIsZero
  obtain ⟨positiveTime, between, positiveRate⟩ :=
    positive_before_zero aBeforeFirst firstIsZero derivative speedNegative
  have beforeB : positiveTime ≤ b := between.2.le.trans firstInInterval.2
  have continuousEarlier : ContinuousOn H (Icc a positiveTime) :=
    continuousRate.mono (Icc_subset_Icc le_rfl beforeB)
  obtain ⟨earlierZero, earlierInInterval, earlierIsZero⟩ :=
    intermediate_value_Icc between.1.le continuousEarlier
      (show (0 : ℝ) ∈ Icc (H a) (H positiveTime) from ⟨negativeAtA.le, positiveRate.le⟩)
  have earlierInZeros : earlierZero ∈ zeros :=
    ⟨⟨earlierInInterval.1, earlierInInterval.2.trans beforeB⟩, mem_singleton_iff.mpr earlierIsZero⟩
  exact (not_lt_of_ge (isLeast.2 earlierInZeros)) (earlierInInterval.2.trans_lt between.2)

/-- A strictly downward slope at every zero gives one crossing and strict signs on either side. -/
theorem unique_crossing_of_integrated_reduction
    {H A : ℝ → ℝ} {start stop : ℝ} (startBeforeStop : start < stop)
    (expansionAtStart : 0 < H start)
    (rateDerivative : ∀ t ∈ Icc start stop, HasDerivAt H (- A t) t)
    (continuousReduction : ContinuousOn A (Icc start stop))
    (accumulatedEnough : H start < ∫ t in start..stop, A t)
    (reductionAtZero : ∀ t ∈ Icc start stop, H t = 0 → 0 < A t) :
    H stop < 0 ∧ ∃ crossing ∈ Ioo start stop, H crossing = 0 ∧
      (∀ t ∈ Icc start stop, H t = 0 → t = crossing) ∧
      (∀ t ∈ Icc start stop, t < crossing → 0 < H t) ∧
      (∀ t ∈ Icc start stop, crossing < t → H t < 0) := by
  obtain ⟨negativeAtStop, crossing, crossingIn, crossingIsZero⟩ :=
    crossing_of_integrated_reduction startBeforeStop expansionAtStart rateDerivative
      continuousReduction accumulatedEnough
  have continuousRate := HasDerivAt.continuousOn rateDerivative
  have negativeAfter :
      ∀ z ∈ Icc start stop, H z = 0 → ∀ t ∈ Icc start stop, z < t → H t < 0 := by
    intro z zIn zero t tIn zBeforeT
    obtain ⟨nearby, between, nearbyNegative⟩ :=
      negative_after_zero zBeforeT zero (rateDerivative z zIn)
        (neg_lt_zero.mpr (reductionAtZero z zIn zero))
    have smallerInterval := Icc_subset_Icc (zIn.1.trans between.1.le) tIn.2
    apply negative_stays_negative between.2 nearbyNegative (continuousRate.mono smallerInterval)
    intro u uIn uZero
    exact ⟨- A u, neg_lt_zero.mpr (reductionAtZero u (smallerInterval uIn) uZero),
      rateDerivative u (smallerInterval uIn)⟩
  have crossingClosed : crossing ∈ Icc start stop := ⟨crossingIn.1.le, crossingIn.2.le⟩
  have uniqueZero : ∀ t ∈ Icc start stop, H t = 0 → t = crossing := by
    intro t tIn tZero
    rcases lt_trichotomy t crossing with earlier | same | later
    · have := negativeAfter t tIn tZero crossing crossingClosed earlier
      linarith
    · exact same
    · have := negativeAfter crossing crossingClosed crossingIsZero t tIn later
      linarith
  refine ⟨negativeAtStop, crossing, crossingIn, crossingIsZero, uniqueZero, ?_,
    negativeAfter crossing crossingClosed crossingIsZero⟩
  intro t tIn tBefore
  by_contra! nonpositiveAtT
  obtain ⟨earlierZero, earlierIn, earlierIsZero⟩ :=
    intermediate_value_Icc' tIn.1 (continuousRate.mono (Icc_subset_Icc le_rfl tIn.2))
      (show (0 : ℝ) ∈ Icc (H t) (H start) from ⟨nonpositiveAtT, expansionAtStart.le⟩)
  have earlierClosed : earlierZero ∈ Icc start stop :=
    ⟨earlierIn.1, earlierIn.2.trans tIn.2⟩
  have same := uniqueZero earlierZero earlierClosed earlierIsZero
  exact (not_lt_of_ge (same ▸ earlierIn.2)) tBefore

/-- A rate model can have local contraction, and even positive net reduction,
    throughout a finite interval while the global rate stays positive. -/
theorem local_contraction_with_insufficient_reduction :
    ∃ (localContraction : ℝ → Prop) (H A : ℝ → ℝ),
      (∀ t ∈ Icc (0 : ℝ) 1, LocalContractionDuringExpansion localContraction H t) ∧
      (∀ t ∈ Icc (0 : ℝ) 1, HasDerivAt H (- A t) t ∧ 0 < A t) ∧
      ContinuousOn A (Icc (0 : ℝ) 1) ∧
      (∫ t in (0 : ℝ)..1, A t) < H 0 := by
  refine ⟨fun _ => True, fun t => 2 - t, fun _ => 1, ?_, ?_, continuousOn_const, ?_⟩
  · intro t ht
    refine ⟨trivial, ?_⟩
    change 0 < 2 - t
    linarith [ht.2]
  · intro t _
    exact ⟨by simpa only [zero_sub] using (hasDerivAt_const t (2 : ℝ)).sub (hasDerivAt_id t),
      zero_lt_one⟩
  · simp [intervalIntegral.integral_const]

#print axioms crossing_of_integrated_reduction
#print axioms unique_crossing_of_integrated_reduction
#print axioms local_contraction_with_insufficient_reduction

end InversionOfGreatness.IntegratedDominanceCrossing
