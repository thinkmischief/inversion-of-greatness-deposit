/-!
# Finite Reversible Phase Closure

Lean 4.8.0 formalization of the finite reversible branch in §4.6.5
of The Inversion of Greatness. `Phase` denotes successor-complete
totality-level phase types. A finite list covers the types, and a
single time-independent function gives their successors. Injectivity
is a hypothesis on that phase map.

The local convergence described in §4.6.5 can occur throughout
expansion dominance. The named regimes track dominance at the
scale of the whole universe. Expansion dominance can give way to
contraction dominance through a continuous crossover. The bounce
is a maximal-compression boundary type.

Here `next` is the next type in the chosen phase classification,
counting regimes and the bounce boundary. Its successor edges
specify phase order. They leave open the duration and continuous
evolution within and between those types, including local collapse.
The general recurrence theorem allows any finite number of types.
The order result for the two regimes and the bounce boundary uses
additional successor premises.
-/

namespace InversionOfGreatness.FiniteReversiblePhaseClosure

universe u
variable {Phase : Type u}

/-- Iterate the classified phase successor for a given number of steps. -/
def phaseAfter (next : Phase → Phase) (initial : Phase) : Nat → Phase
  | 0 => initial
  | n + 1 => next (phaseAfter next initial n)

private theorem phaseAfterAdd (next : Phase → Phase) (initial : Phase)
    (earlier later : Nat) :
    phaseAfter next initial (earlier + later) =
      phaseAfter next (phaseAfter next initial earlier) later := by
  induction later with
  | zero => rfl
  | succ later ih =>
    change next (phaseAfter next initial (earlier + later)) =
      next (phaseAfter next (phaseAfter next initial earlier) later)
    exact congrArg next ih

private theorem phaseAfterInjective (next : Phase → Phase)
    (oneToOne : ∀ {left right}, next left = next right → left = right) (steps : Nat) :
    ∀ {left right}, phaseAfter next left steps = phaseAfter next right steps → left = right := by
  induction steps with
  | zero =>
    intro left right same
    exact same
  | succ steps ih =>
    intro left right same
    exact ih (oneToOne same)

/-- Pigeonhole for an infinite sequence covered by a finite list.
A hit at the head either repeats later or lets us discard the head
from the cover of the sequence's tail. -/
private theorem repeatInFiniteCover (cover : List Phase) (sequence : Nat → Phase)
    (covers : ∀ n, sequence n ∈ cover) :
    ∃ start gap, sequence (start + (gap + 1)) = sequence start := by
  induction cover generalizing sequence with
  | nil => exact False.elim (by simpa using covers 0)
  | cons head rest ih =>
    rcases Classical.em (∃ index, sequence index = head) with hit | noHit
    · obtain ⟨index, atHead⟩ := hit
      let offset := index + 1
      let shifted := fun n => sequence (offset + n)
      rcases Classical.em (∃ n, shifted n = head) with later | noLater
      · obtain ⟨n, laterAtHead⟩ := later
        refine ⟨index, n, ?_⟩
        have reindex : index + (n + 1) = offset + n := by
          dsimp [offset]
          rw [Nat.add_comm n 1, ← Nat.add_assoc]
        rw [reindex]
        exact laterAtHead.trans atHead.symm
      · have coversShifted : ∀ n, shifted n ∈ rest := by
          intro n
          have member : shifted n ∈ head :: rest := covers (offset + n)
          rcases List.mem_cons.mp member with atHeadAgain | inRest
          · exact False.elim (noLater ⟨n, atHeadAgain⟩)
          · exact inRest
        obtain ⟨start, gap, repeated⟩ := ih shifted coversShifted
        refine ⟨offset + start, gap, ?_⟩
        rw [Nat.add_assoc]
        exact repeated
    · apply ih sequence
      intro n
      rcases List.mem_cons.mp (covers n) with atHead | inRest
      · exact False.elim (noHit ⟨n, atHead⟩)
      · exact inRest

/-- Every starting phase has a positive period. Repetition starts
at that phase, because injectivity cancels the prefix to the first
repeat. The offset is arbitrary, so the whole future orbit repeats. -/
theorem finiteReversiblePhaseClosure (cover : List Phase)
    (covers : ∀ phase, phase ∈ cover) (next : Phase → Phase)
    (oneToOne : ∀ {left right}, next left = next right → left = right)
    (initial : Phase) :
    ∃ period, 0 < period ∧ ∀ offset,
      phaseAfter next initial (period + offset) = phaseAfter next initial offset := by
  obtain ⟨start, gap, repeated⟩ :=
    repeatInFiniteCover cover (phaseAfter next initial) (fun n => covers _)
  have returns : phaseAfter next initial (gap + 1) = initial := by
    apply phaseAfterInjective next oneToOne start
    rw [← phaseAfterAdd next initial (gap + 1) start, Nat.add_comm (gap + 1) start]
    exact repeated
  refine ⟨gap + 1, Nat.succ_pos gap, ?_⟩
  intro offset
  rw [phaseAfterAdd, returns]

/-- Together with injectivity, surjectivity makes the phase map a permutation. -/
theorem finiteInjectivePhaseMapSurjective (cover : List Phase)
    (covers : ∀ phase, phase ∈ cover) (next : Phase → Phase)
    (oneToOne : ∀ {left right}, next left = next right → left = right) :
    ∀ target, ∃ previous, next previous = target := by
  intro target
  obtain ⟨period, positive, repeats⟩ :=
    finiteReversiblePhaseClosure cover covers next oneToOne target
  cases period with
  | zero => exact False.elim ((Nat.lt_irrefl 0) positive)
  | succ previousSteps => exact ⟨phaseAfter next target previousSteps, repeats 0⟩

/-- A supplied contraction-dominant regime, bounce boundary, and
outgoing expansion-dominant regime lie on an orbit that returns
after at least three successor steps. The classification can
include further types before contraction dominance returns. -/
theorem dominanceHalfCycleReturns (cover : List Phase)
    (covers : ∀ phase, phase ∈ cover) (next : Phase → Phase)
    (oneToOne : ∀ {left right}, next left = next right → left = right)
    (contractionDominant bounceBoundary expansionDominant : Phase)
    (contractionDominanceToBounce : next contractionDominant = bounceBoundary)
    (bounceToExpansionDominance : next bounceBoundary = expansionDominant)
    (contractionDominanceNeBounce : contractionDominant ≠ bounceBoundary)
    (contractionDominanceNeExpansion : contractionDominant ≠ expansionDominant) :
    ∃ extra : Nat, phaseAfter next contractionDominant (extra + 3) = contractionDominant ∧
      phaseAfter next expansionDominant (extra + 1) = contractionDominant := by
  obtain ⟨period, positive, repeats⟩ :=
    finiteReversiblePhaseClosure cover covers next oneToOne contractionDominant
  have returns : phaseAfter next contractionDominant period = contractionDominant := repeats 0
  have afterTwo : phaseAfter next contractionDominant 2 = expansionDominant := by
    change next (next contractionDominant) = expansionDominant
    rw [contractionDominanceToBounce, bounceToExpansionDominance]
  cases period with
  | zero => exact False.elim ((Nat.lt_irrefl 0) positive)
  | succ rest =>
    cases rest with
    | zero => exact False.elim (contractionDominanceNeBounce (returns.symm.trans contractionDominanceToBounce))
    | succ rest =>
      cases rest with
      | zero => exact False.elim (contractionDominanceNeExpansion (returns.symm.trans afterTwo))
      | succ extra =>
        have count : 2 + (extra + 1) = extra + 3 := by
          calc
            2 + (extra + 1) = (2 + extra) + 1 := (Nat.add_assoc 2 extra 1).symm
            _ = (extra + 2) + 1 := congrArg (fun n => n + 1) (Nat.add_comm 2 extra)
            _ = extra + 3 := rfl
        have later := phaseAfterAdd next contractionDominant 2 (extra + 1)
        rw [count, afterTwo] at later
        exact ⟨extra, returns, later.symm.trans returns⟩

/-- If expansion dominance's next classified type is among these
three types, injectivity forces it to be contraction dominance.
This is conditional on that classification and says nothing about
the continuity of the crossover or the onset of local collapse. -/
theorem contractionDominanceIsNextUnderThreeTypeClassification
    (next : Phase → Phase)
    (oneToOne : ∀ {left right}, next left = next right → left = right)
    (contractionDominant bounceBoundary expansionDominant : Phase)
    (contractionDominanceToBounce : next contractionDominant = bounceBoundary)
    (bounceToExpansionDominance : next bounceBoundary = expansionDominant)
    (expansionDominanceNeContraction : expansionDominant ≠ contractionDominant)
    (expansionDominanceNeBounce : expansionDominant ≠ bounceBoundary)
    (classifiedSuccessor : next expansionDominant = contractionDominant ∨
      next expansionDominant = bounceBoundary ∨ next expansionDominant = expansionDominant) :
    next expansionDominant = contractionDominant := by
  rcases classifiedSuccessor with turns | returnsToBounce | staysExpansion
  · exact turns
  · exact False.elim (expansionDominanceNeContraction
      (oneToOne (returnsToBounce.trans contractionDominanceToBounce.symm)))
  · exact False.elim (expansionDominanceNeBounce
      (oneToOne (staysExpansion.trans bounceToExpansionDominance.symm)))

/-- Given the three successor edges, the order of the two dominance
regimes and the bounce boundary repeats. The phase-map result
uses the edges and autonomy alone. -/
theorem periodicDominanceOrder (next : Phase → Phase)
    (contractionDominant bounceBoundary expansionDominant : Phase)
    (contractionDominanceToBounce : next contractionDominant = bounceBoundary)
    (bounceToExpansionDominance : next bounceBoundary = expansionDominant)
    (expansionDominanceToContractionDominance : next expansionDominant = contractionDominant) :
    ∀ rounds, phaseAfter next bounceBoundary (3 * rounds) = bounceBoundary ∧
      phaseAfter next bounceBoundary (3 * rounds + 1) = expansionDominant ∧
      phaseAfter next bounceBoundary (3 * rounds + 2) = contractionDominant := by
  have bounceReturns : ∀ rounds, phaseAfter next bounceBoundary (3 * rounds) = bounceBoundary := by
    intro rounds
    induction rounds with
    | zero => rfl
    | succ rounds ih =>
      rw [Nat.mul_succ, phaseAfterAdd, ih]
      change next (next (next bounceBoundary)) = bounceBoundary
      rw [bounceToExpansionDominance, expansionDominanceToContractionDominance, contractionDominanceToBounce]
  intro rounds
  have atBounce := bounceReturns rounds
  refine ⟨atBounce, ?_, ?_⟩
  · change next (phaseAfter next bounceBoundary (3 * rounds)) = expansionDominant
    rw [atBounce, bounceToExpansionDominance]
  · change next (next (phaseAfter next bounceBoundary (3 * rounds))) = contractionDominant
    rw [atBounce, bounceToExpansionDominance, expansionDominanceToContractionDominance]

private inductive FourPhase where
  | contractionDominant | bounceBoundary | expansionDominant | intermediateType

private def fourPhaseNext : FourPhase → FourPhase
  | .contractionDominant => .bounceBoundary
  | .bounceBoundary => .expansionDominant
  | .expansionDominant => .intermediateType
  | .intermediateType => .contractionDominant

-- A finite injective map can include a further classified type
-- before contraction dominance returns. This is a counterexample
-- about what the phase-map premises imply, using abstract labels.
example :
    (∀ phase : FourPhase, phase ∈
      [FourPhase.contractionDominant, .bounceBoundary, .expansionDominant, .intermediateType]) ∧
    (∀ left right, fourPhaseNext left = fourPhaseNext right → left = right) ∧
    fourPhaseNext .contractionDominant = .bounceBoundary ∧
    fourPhaseNext .bounceBoundary = .expansionDominant ∧
    phaseAfter fourPhaseNext .expansionDominant 2 = .contractionDominant ∧
    fourPhaseNext .expansionDominant ≠ .contractionDominant := by
  refine ⟨?_, ?_, rfl, rfl, rfl, ?_⟩
  · intro phase
    cases phase <;> simp
  · intro left right equal
    cases left <;> cases right <;> first | rfl | cases equal
  · intro equal
    cases equal

/-- An indefinitely deep predecessor history over a finite set of phase types
puts its present type on a periodic orbit. The successor map can be noninjective. -/
theorem finitePhaseReturnFromInfinitePast
    (cover : List Phase) (covers : ∀ phase, phase ∈ cover) (next : Phase → Phase)
    (past : Nat → Phase) (pastSteps : ∀ n, next (past (n + 1)) = past n) :
    ∃ period, 0 < period ∧ ∀ offset,
      phaseAfter next (past 0) (period + offset) = phaseAfter next (past 0) offset := by
  have advance (earlier steps : Nat) :
      phaseAfter next (past (earlier + steps)) steps = past earlier := by
    induction steps generalizing earlier with
    | zero => rfl
    | succ steps ih =>
      change next (phaseAfter next (past (earlier + (steps + 1))) steps) = past earlier
      rw [show earlier + (steps + 1) = (earlier + 1) + steps by
        rw [Nat.add_assoc earlier 1 steps, Nat.add_comm 1 steps]]
      rw [ih, pastSteps]
  obtain ⟨index, gap, seenAgain⟩ := repeatInFiniteCover cover past (fun n => covers (past n))
  have atRepeat : phaseAfter next (past index) (gap + 1) = past index := by
    calc
      phaseAfter next (past index) (gap + 1) =
          phaseAfter next (past (index + (gap + 1))) (gap + 1) :=
        congrArg (fun phase => phaseAfter next phase (gap + 1)) seenAgain.symm
      _ = past index := advance index (gap + 1)
  have atPresent : phaseAfter next (past index) index = past 0 := by
    simpa only [Nat.zero_add] using advance 0 index
  have returns : phaseAfter next (past 0) (gap + 1) = past 0 := by
    calc
      phaseAfter next (past 0) (gap + 1) =
          phaseAfter next (phaseAfter next (past index) index) (gap + 1) := by rw [atPresent]
      _ = phaseAfter next (past index) (index + (gap + 1)) := (phaseAfterAdd ..).symm
      _ = phaseAfter next (past index) ((gap + 1) + index) := by rw [Nat.add_comm index]
      _ = past 0 := by rw [phaseAfterAdd, atRepeat, atPresent]
  exact ⟨gap + 1, Nat.succ_pos gap, fun offset => by rw [phaseAfterAdd, returns]⟩

/-- The earlier expansion's gradual shift to overall contraction dominance
recurs if the earlier and present expansion have the same successor-sufficient
type. Local convergence already occurs during expansion dominance. The successor
edge records which regime comes next in the continuous evolution. -/
theorem contractionDominanceFromEarlierTurnaround
    (next : Phase → Phase) (earlierExpansion presentExpansion contractionDominant : Phase)
    (sameTurnaroundConditions : earlierExpansion = presentExpansion)
    (earlierTurnaround : next earlierExpansion = contractionDominant) :
    next presentExpansion = contractionDominant :=
  (congrArg next sameTurnaroundConditions).symm.trans earlierTurnaround

/-- The continuous crossover and the two restoration edges reproduce the order
of expansion dominance, contraction dominance, and the bounce. The bounce is the
boundary at maximal compression. -/
theorem periodicDominanceOrderFromEarlierTurnaround
    (next : Phase → Phase)
    (earlierExpansion expansionDominant contractionDominant bounceBoundary : Phase)
    (sameTurnaroundConditions : earlierExpansion = expansionDominant)
    (earlierTurnaround : next earlierExpansion = contractionDominant)
    (contractionDominanceToBounce : next contractionDominant = bounceBoundary)
    (bounceToExpansionDominance : next bounceBoundary = expansionDominant) :
    ∀ rounds, phaseAfter next bounceBoundary (3 * rounds) = bounceBoundary ∧
      phaseAfter next bounceBoundary (3 * rounds + 1) = expansionDominant ∧
      phaseAfter next bounceBoundary (3 * rounds + 2) = contractionDominant :=
  periodicDominanceOrder next contractionDominant bounceBoundary expansionDominant
    contractionDominanceToBounce bounceToExpansionDominance
    (contractionDominanceFromEarlierTurnaround next earlierExpansion expansionDominant
      contractionDominant sameTurnaroundConditions earlierTurnaround)

#print axioms finitePhaseReturnFromInfinitePast
#print axioms contractionDominanceFromEarlierTurnaround
#print axioms periodicDominanceOrderFromEarlierTurnaround
#print axioms finiteReversiblePhaseClosure
#print axioms finiteInjectivePhaseMapSurjective
#print axioms dominanceHalfCycleReturns
#print axioms contractionDominanceIsNextUnderThreeTypeClassification
#print axioms periodicDominanceOrder

end InversionOfGreatness.FiniteReversiblePhaseClosure
