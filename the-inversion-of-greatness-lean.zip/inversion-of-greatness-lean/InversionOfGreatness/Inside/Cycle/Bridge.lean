import InversionOfGreatness.Inside.Cycle.DominanceCrossing
import InversionOfGreatness.Inside.Cycle.PhaseClosure

/-!
# From the crossing to the phase order (§4.6.5)

`periodicDominanceOrder` takes the edge from expansion dominance to
contraction dominance as a hypothesis. The book derives that edge from
Integrated Dominance Crossing: the global rate passes strictly from
positive to negative, with no interval at zero, so "compression dominance
is the next regime, with no interval of zero expansion between".

The bridge premise says how the phase classification reads regimes: when
the rate changes sign strictly, from expansion dominance with no
intermediate stretch, the classified successor of expansion dominance is
contraction dominance.
-/

namespace InversionOfGreatness.CycleBridge

open Set
open InversionOfGreatness.IntegratedDominanceCrossing
open InversionOfGreatness.FiniteReversiblePhaseClosure

universe u

variable {Phase : Type u}

/-- A strict sign change of the global rate on the interval: positive
before one interior instant, negative after it. -/
def StrictSignChange (H : ℝ → ℝ) (start stop : ℝ) : Prop :=
  ∃ crossing ∈ Ioo start stop,
    (∀ t ∈ Icc start stop, t < crossing → 0 < H t) ∧
    (∀ t ∈ Icc start stop, crossing < t → H t < 0)

/-- Integrated Dominance Crossing, with net reduction positive at every
zero, gives a strict sign change. -/
theorem crossingGivesStrictSignChange
    {H A : ℝ → ℝ} {start stop : ℝ} (startBeforeStop : start < stop)
    (expansionAtStart : 0 < H start)
    (rateDerivative : ∀ t ∈ Icc start stop, HasDerivAt H (- A t) t)
    (continuousReduction : ContinuousOn A (Icc start stop))
    (accumulatedEnough : H start < ∫ t in start..stop, A t)
    (reductionAtZero : ∀ t ∈ Icc start stop, H t = 0 → 0 < A t) :
    StrictSignChange H start stop := by
  obtain ⟨_, crossing, inside, _, _, before, after⟩ :=
    unique_crossing_of_integrated_reduction startBeforeStop expansionAtStart rateDerivative
      continuousReduction accumulatedEnough reductionAtZero
  exact ⟨crossing, inside, before, after⟩

/-- The edge from expansion dominance to contraction dominance, derived
from the crossing and the classification's reading of a strict sign change. -/
theorem expansionDominanceToContractionDominanceFromCrossing
    (next : Phase → Phase) (expansionDominant contractionDominant : Phase)
    {H A : ℝ → ℝ} {start stop : ℝ} (startBeforeStop : start < stop)
    (expansionAtStart : 0 < H start)
    (rateDerivative : ∀ t ∈ Icc start stop, HasDerivAt H (- A t) t)
    (continuousReduction : ContinuousOn A (Icc start stop))
    (accumulatedEnough : H start < ∫ t in start..stop, A t)
    (reductionAtZero : ∀ t ∈ Icc start stop, H t = 0 → 0 < A t)
    (classificationReadsSignChange :
      StrictSignChange H start stop → next expansionDominant = contractionDominant) :
    next expansionDominant = contractionDominant :=
  classificationReadsSignChange
    (crossingGivesStrictSignChange startBeforeStop expansionAtStart rateDerivative
      continuousReduction accumulatedEnough reductionAtZero)

/-- The periodic order of the two dominance regimes and the bounce, with
the expansion-to-contraction edge derived rather than assumed. The other
two edges remain inputs: Single-Boundary Restoration and conditional
re-expansion. -/
theorem periodicDominanceOrderFromCrossing
    (next : Phase → Phase)
    (contractionDominant bounceBoundary expansionDominant : Phase)
    (contractionDominanceToBounce : next contractionDominant = bounceBoundary)
    (bounceToExpansionDominance : next bounceBoundary = expansionDominant)
    {H A : ℝ → ℝ} {start stop : ℝ} (startBeforeStop : start < stop)
    (expansionAtStart : 0 < H start)
    (rateDerivative : ∀ t ∈ Icc start stop, HasDerivAt H (- A t) t)
    (continuousReduction : ContinuousOn A (Icc start stop))
    (accumulatedEnough : H start < ∫ t in start..stop, A t)
    (reductionAtZero : ∀ t ∈ Icc start stop, H t = 0 → 0 < A t)
    (classificationReadsSignChange :
      StrictSignChange H start stop → next expansionDominant = contractionDominant) :
    ∀ rounds, phaseAfter next bounceBoundary (3 * rounds) = bounceBoundary ∧
      phaseAfter next bounceBoundary (3 * rounds + 1) = expansionDominant ∧
      phaseAfter next bounceBoundary (3 * rounds + 2) = contractionDominant :=
  periodicDominanceOrder next contractionDominant bounceBoundary expansionDominant
    contractionDominanceToBounce bounceToExpansionDominance
    (expansionDominanceToContractionDominanceFromCrossing next expansionDominant
      contractionDominant startBeforeStop expansionAtStart rateDerivative
      continuousReduction accumulatedEnough reductionAtZero classificationReadsSignChange)

#print axioms crossingGivesStrictSignChange
#print axioms expansionDominanceToContractionDominanceFromCrossing
#print axioms periodicDominanceOrderFromCrossing

end InversionOfGreatness.CycleBridge
