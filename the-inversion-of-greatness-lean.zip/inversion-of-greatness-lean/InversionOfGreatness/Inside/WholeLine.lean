import InversionOfGreatness.Inside.Necessity
import InversionOfGreatness.Inside.Identity

/-!
# The whole line (Appendix B line 14)

Conjoins the identity (line 13) with the necessity of the three
conditions (line 11). This is the inside half's conclusion and the
first input to the book's capstone theorem.
-/

namespace InversionOfGreatness

universe u v w x

variable {Evaluation : Type u} {Content : Type v}

/-- Line 14 combines line 13 and the checked reflective proof of line 11. -/
theorem natureIsNecessaryFromReflection
    {Whole : Type u} {Field : Type v} {Item : Type w}
    {nature reality : Whole} {jointComplex : Field}
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    (capacity : Content → Prop)
    (possibleAt : Evaluation → Content → Prop)
    (evaluationInvariance :
      ∀ evaluation content, possibleAt evaluation content ↔ capacity content)
    (actualEvaluation : Evaluation) (change : Content)
    (actualChange : Prop) (witness : actualChange)
    (actualityImpliesPossibility : actualChange → possibleAt actualEvaluation change)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : ReflectiveRoute Evaluation actualChange (capacity change)
      temporality spatiality substantiality) :
    nature = reality ∧ Necessary (ThreeConditions temporality spatiality substantiality) :=
  ⟨realityIsNature identity,
    threeConditionsNecessaryFromReflection capacity possibleAt evaluationInvariance
      actualEvaluation change actualChange witness actualityImpliesPossibility
      temporality spatiality substantiality route⟩

/-- Line 14 with evaluation-invariance derived from the single
complete range rather than supplied as a separate hypothesis. -/
theorem natureIsNecessaryFromOneRange
    {Whole : Type u} {Field : Type v} {Item : Type w} {Range : Type x}
    {nature reality : Whole} {jointComplex : Field}
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop)
    (actualEvaluation : Evaluation) (change : Content)
    (actualChange : Prop) (witness : actualChange)
    (actualityImpliesPossibility :
      actualChange → permits (rangeAssessed actualEvaluation) change)
    (temporality spatiality substantiality : Evaluation → Prop)
    (route : ReflectiveRoute Evaluation actualChange (permits realityRange change)
      temporality spatiality substantiality) :
    nature = reality ∧ Necessary (ThreeConditions temporality spatiality substantiality) :=
  natureIsNecessaryFromReflection identity (permits realityRange)
    (fun evaluation => permits (rangeAssessed evaluation))
    (evaluationInvarianceFromOneRange realityRange rangeAssessed oneRange permits)
    actualEvaluation change actualChange witness actualityImpliesPossibility
    temporality spatiality substantiality route

/-- Line 14 from one range, with line 11 supplied by either route: the
reflective route or *From Movement* (§2.4.6). -/
theorem natureIsNecessaryByEitherRoute
    {Whole : Type u} {Field : Type v} {Item : Type w} {Range : Type x}
    {nature reality : Whole} {jointComplex : Field}
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop)
    (actualEvaluation : Evaluation) (change movement : Content)
    (actualChange actualMovement : Prop)
    (changeActualityImpliesPossibility :
      actualChange → permits (rangeAssessed actualEvaluation) change)
    (movementActualityImpliesPossibility :
      actualMovement → permits (rangeAssessed actualEvaluation) movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (routes :
      (actualChange ∧ Nonempty (ReflectiveRoute Evaluation actualChange
        (permits realityRange change) temporality spatiality substantiality)) ∨
      (actualMovement ∧ Nonempty (MovementRoute Evaluation actualMovement
        (permits realityRange movement) temporality spatiality substantiality))) :
    nature = reality ∧ Necessary (ThreeConditions temporality spatiality substantiality) :=
  ⟨realityIsNature identity,
    threeConditionsNecessaryByEitherRoute (permits realityRange)
      (fun evaluation => permits (rangeAssessed evaluation))
      (evaluationInvarianceFromOneRange realityRange rangeAssessed oneRange permits)
      actualEvaluation change movement actualChange actualMovement
      changeActualityImpliesPossibility movementActualityImpliesPossibility
      temporality spatiality substantiality routes⟩

#print axioms natureIsNecessaryFromReflection
#print axioms natureIsNecessaryFromOneRange
#print axioms natureIsNecessaryByEitherRoute

end InversionOfGreatness
