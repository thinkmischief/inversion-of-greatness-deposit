import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.Data.Fintype.BigOperators

/-!
# Exponential Crossing Ambiguity: the family count (Appendix F)

Two bearers over `m` times between two positions, `false` and `true`.
A complementary registration puts the bearers at opposite positions at every
time, so it is fixed by bearer 1's trajectory `w`; bearer 2 follows its
complement. Each bearer visits both positions exactly when `w` is not constant.

Checked here, for every `m ≥ 1`:
* the complementary registrations number `2^m - 2`;
* they all cast the same three pairwise shadows (both positions occupied at
  every time, both bearers present, each bearer visiting both positions);
* exchanging the bearers and exchanging the two positions act the same way,
  as complement, with no fixed point, and each class has exactly one member
  with bearer 1 at `false` at the first time, so the classes number
  `2^(m-1) - 1`.

Not checked here: the theorem's maximality clause (no pairwise-shadow class
contains more, at any number of positions). Appendix F proves it by a case
argument that is not yet formalized.
-/

namespace InversionOfGreatness.CrossingAmbiguity

/-- Bearer 1's trajectory over `m` times between the two positions. -/
abbrev Trajectory (m : ℕ) := Fin m → Bool

/-- Bearer 2's trajectory in a complementary registration. -/
def complement {m : ℕ} (w : Trajectory m) : Trajectory m := fun t => !w t

/-- A trajectory that visits both positions. -/
def Nonconstant {m : ℕ} (w : Trajectory m) : Prop := ∃ s t, w s ≠ w t

instance {m : ℕ} (w : Trajectory m) : Decidable (Nonconstant w) := by
  unfold Nonconstant; infer_instance

/-- The complementary registrations, each given by bearer 1's trajectory. -/
def complementary (m : ℕ) : Finset (Trajectory m) := Finset.univ.filter Nonconstant

/-- Bearer 2 visits both positions exactly when bearer 1 does. -/
theorem nonconstant_complement_iff {m : ℕ} (w : Trajectory m) :
    Nonconstant (complement w) ↔ Nonconstant w := by
  unfold Nonconstant complement
  constructor
  · rintro ⟨s, t, h⟩; exact ⟨s, t, fun e => h (by rw [e])⟩
  · rintro ⟨s, t, h⟩
    refine ⟨s, t, fun e => h ?_⟩
    cases hs : w s <;> cases ht : w t <;> simp_all

/-- Over at least one time, a trajectory visits both positions exactly when it
is neither of the two constant trajectories. -/
theorem nonconstant_iff (n : ℕ) (w : Trajectory (n + 1)) :
    Nonconstant w ↔ (w ≠ fun _ => false) ∧ (w ≠ fun _ => true) := by
  constructor
  · rintro ⟨s, t, h⟩
    refine ⟨fun e => h ?_, fun e => h ?_⟩ <;> rw [e]
  · rintro ⟨hf, ht⟩
    by_contra hc
    have same : ∀ s, w s = w 0 := fun s => by
      by_contra hs; exact hc ⟨s, 0, hs⟩
    cases h0 : w 0
    · exact hf (funext fun s => (same s).trans h0)
    · exact ht (funext fun s => (same s).trans h0)

/-- The complementary registrations number `2^m - 2`. -/
theorem card_complementary (n : ℕ) : (complementary (n + 1)).card = 2 ^ (n + 1) - 2 := by
  have split : complementary (n + 1) =
      Finset.univ \ {(fun _ => false : Trajectory (n + 1)), fun _ => true} := by
    ext w
    simp only [complementary, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_sdiff,
      Finset.mem_insert, Finset.mem_singleton, not_or]
    exact nonconstant_iff n w
  have distinct : (fun _ => false : Trajectory (n + 1)) ≠ fun _ => true := fun e =>
    Bool.false_ne_true (congrFun e 0)
  rw [split, Finset.card_sdiff (Finset.subset_univ _), Finset.card_univ, Fintype.card_fun,
    Fintype.card_bool, Fintype.card_fin, Finset.card_pair distinct]

/-- Every complementary registration casts the same pairwise shadows: both
positions occupied at every time, and each bearer visiting both positions. -/
theorem shared_shadows {m : ℕ} {w : Trajectory m} (hw : w ∈ complementary m) :
    (∀ t, ({w t, complement w t} : Finset Bool) = Finset.univ) ∧
      Finset.univ.image w = Finset.univ ∧
      Finset.univ.image (complement w) = Finset.univ := by
  have hn : Nonconstant w := (Finset.mem_filter.mp hw).2
  have both : ∀ v : Trajectory m, Nonconstant v → Finset.univ.image v = Finset.univ := by
    rintro v ⟨s, t, h⟩
    ext b
    simp only [Finset.mem_image, Finset.mem_univ, true_and, iff_true]
    cases hs : v s <;> cases ht : v t <;> cases b <;> simp_all <;>
      first | exact ⟨s, hs⟩ | exact ⟨t, ht⟩
  refine ⟨fun t => ?_, both w hn, both _ ((nonconstant_complement_iff w).mpr hn)⟩
  ext b
  simp only [complement, Finset.mem_insert, Finset.mem_singleton, Finset.mem_univ, iff_true]
  cases w t <;> cases b <;> simp

/-- Exchanging the bearers and exchanging the two positions both send a
registration to its complement; complement is an involution with no fixed point. -/
theorem complement_involutive_no_fixed_point (n : ℕ) (w : Trajectory (n + 1)) :
    complement (complement w) = w ∧ complement w ≠ w := by
  refine ⟨funext fun t => by simp [complement], fun e => ?_⟩
  have := congrFun e 0
  cases h : w 0 <;> simp_all [complement]

/-- One representative per class: bearer 1 starts at `false`. -/
def representatives (n : ℕ) : Finset (Trajectory (n + 1)) :=
  (complementary (n + 1)).filter fun w => w 0 = false

/-- Every complementary registration has exactly one of itself and its
complement among the representatives. -/
theorem one_representative_per_class (n : ℕ) {w : Trajectory (n + 1)}
    (hw : w ∈ complementary (n + 1)) :
    (w ∈ representatives n ↔ complement w ∉ representatives n) := by
  have hn : Nonconstant w := (Finset.mem_filter.mp hw).2
  have hc : complement w ∈ complementary (n + 1) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, (nonconstant_complement_iff w).mpr hn⟩
  simp only [representatives, Finset.mem_filter, hw, hc, true_and, complement]
  cases w 0 <;> simp

/-- The classes number `2^(m-1) - 1`. -/
theorem card_representatives (n : ℕ) : (representatives n).card = 2 ^ n - 1 := by
  -- Trajectories starting at `false` correspond to free tails.
  let e : (Fin n → Bool) ↪ Trajectory (n + 1) :=
    ⟨fun v => Fin.cons false v, fun a b h => by
      have := congrArg Fin.tail h; simpa using this⟩
  have image : (Finset.univ.map e).filter (fun w => w ≠ fun _ => false) = representatives n := by
    ext w
    simp only [representatives, complementary, Finset.mem_filter, Finset.mem_map,
      Finset.mem_univ, true_and, nonconstant_iff]
    constructor
    · rintro ⟨⟨v, rfl⟩, hne⟩
      refine ⟨⟨hne, fun h => ?_⟩, rfl⟩
      have := congrFun h 0; simp [e] at this
    · rintro ⟨⟨hne, _⟩, h0⟩
      refine ⟨⟨Fin.tail w, ?_⟩, hne⟩
      simp only [e, Function.Embedding.coeFn_mk]
      rw [← h0, Fin.cons_self_tail]
  have constIn : (fun _ => false : Trajectory (n + 1)) ∈ Finset.univ.map e :=
    Finset.mem_map.mpr ⟨fun _ => false, Finset.mem_univ _, by
      funext i; refine Fin.cases rfl (fun j => rfl) i⟩
  rw [← image, Finset.filter_ne' , Finset.card_erase_of_mem constIn, Finset.card_map,
    Finset.card_univ, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]

#print axioms card_complementary
#print axioms shared_shadows
#print axioms complement_involutive_no_fixed_point
#print axioms one_representative_per_class
#print axioms card_representatives

end InversionOfGreatness.CrossingAmbiguity
