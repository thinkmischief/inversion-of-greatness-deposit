import InversionOfGreatness.Inside.WholeLine
import InversionOfGreatness.Outside.NoBeyond

/-!
# The capstone

This theorem combines Appendix B line 14 with selected outside results
from §§10.4 and 11.10. Both halves use the same `identity` premises for
Reality, Nature and real content.

The inside half takes T, S and Φ as predicates on evaluations. The
outside half takes them as predicates on items, with the local premise
that each change token incurs all three (§2.4.7). Both families are
supplied separately. The theorem contains no relation between an item
and an evaluation, or between `isWay` and `CandidateModality.wayOf`.
The Chapter 3 reductio and Chapter 4 cycle results are checked separately.
-/

namespace InversionOfGreatness

open NoBeyond

universe u v w x

/-- From the stated inputs, Nature is Reality and the evaluation-level
conditions hold necessarily. At item level, concrete work incurs the
conditions, all real items and candidate ways lie within Nature, and
no item satisfying `isWay` meets the modeled contentless-God description. -/
theorem theInversionOfGreatness
    {Evaluation : Type u} {Content : Type v}
    {Whole : Type u} {Field : Type v} {Item : Type w} {Range : Type x}
    {nature reality : Whole} {jointComplex : Field}
    -- The identity premises, shared by both halves.
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    -- The inside half: one range, then either route to line 11: the
    -- reflective witness with its route, or actual displacement with
    -- *From Movement* (§2.4.6), which needs no Attention Crosses a Real Separation.
    (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop)
    (actualEvaluation : Evaluation) (change movement : Content)
    (actualChange actualMovement : Prop)
    (changeActualityImpliesPossibility :
      actualChange → permits (rangeAssessed actualEvaluation) change)
    (movementActualityImpliesPossibility :
      actualMovement → permits (rangeAssessed actualEvaluation) movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (routes :
      (actualChange ∧ Nonempty (ReflectiveRoute Evaluation actualChange
        (permits realityRange change) temporality spatiality substantiality)) ∨
      (actualMovement ∧ Nonempty (MovementRoute Evaluation actualMovement
        (permits realityRange movement) temporality spatiality substantiality)))
    -- The outside half: candidate modality, the conditions at items, agency.
    (modality : CandidateModality Item identity.toRealityNatureCoverage.real)
    (conditions : ConditionsAtItems Item)
    (agency isWay : Item → Prop)
    (agencyIsConcreteWork : ∀ item, agency item → conditions.concreteWork item) :
    nature = reality ∧
    Necessary (ThreeConditions temporality spatiality substantiality) ∧
    (¬ ∃ item, conditions.concreteWork item ∧ Exempt conditions item) ∧
    (¬ ∃ item, identity.toRealityNatureCoverage.real item ∧
      ¬ WithinNature identity.toRealityNatureCoverage item) ∧
    (∀ candidate, modality.possible candidate →
      ∀ way, modality.wayOf candidate way → WithinNature identity.toRealityNatureCoverage way) ∧
    ¬ PossibleDescription isWay (ContentlessGod conditions agency) := by
  have inside := natureIsNecessaryByEitherRoute identity realityRange rangeAssessed oneRange
    permits actualEvaluation change movement actualChange actualMovement
    changeActualityImpliesPossibility movementActualityImpliesPossibility
    temporality spatiality substantiality routes
  have outside := noSupernature identity.toRealityNatureCoverage modality conditions
  exact ⟨inside.1, inside.2, outside.1, outside.2.1, outside.2.2,
    (contentlessGodHasNoReferent conditions agency isWay agencyIsConcreteWork).1⟩

#print axioms theInversionOfGreatness

end InversionOfGreatness
