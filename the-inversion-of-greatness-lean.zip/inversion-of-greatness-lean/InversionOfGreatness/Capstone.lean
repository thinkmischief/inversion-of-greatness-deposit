import InversionOfGreatness.Inside.WholeLine
import InversionOfGreatness.Outside.NoBeyond

/-!
# The capstone

This theorem combines Appendix B line 14 with selected outside results
from §§10.4 and 11.10. Both halves use the same `identity` premises for
Reality, Nature and real content.

The inside half takes T, S and Φ as predicates on evaluations. The
outside half takes them as predicates on items, with the local premise
that each change token incurs all three (§2.4.7). Both families are
supplied separately. `theInversionOfGreatness` contains no relation
between an item and an evaluation; `theInversionOfGreatnessJoined`
(below) adds one, `Realization`, so the actual witness and every concrete
work realize the evaluation-level conditions where they occur. Neither
relates `isWay` to `CandidateModality.wayOf`.
The Chapter 3 reductio and Chapter 4 cycle results are checked separately.
-/

namespace InversionOfGreatness

open NoBeyond

universe u v w x

/-- From the stated inputs, Nature is Reality and the evaluation-level
conditions hold necessarily. At item level, concrete work incurs the
conditions, all real items and candidate ways lie within Nature, and
no item satisfying `isWay` meets the modeled contentless-God description. -/
theorem theInversionOfGreatness
    {Evaluation : Type u} {Content : Type v}
    {Whole : Type u} {Field : Type v} {Item : Type w} {Range : Type x}
    {nature reality : Whole} {jointComplex : Field}
    -- The identity premises, shared by both halves.
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    -- The inside half: one range, then either route to line 11: the
    -- reflective witness with its route, or actual displacement with
    -- *From Movement* (§2.4.6), which needs no Attention Crosses a Real Separation.
    (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop)
    (actualEvaluation : Evaluation) (change movement : Content)
    (actualChange actualMovement : Prop)
    (changeActualityImpliesPossibility :
      actualChange → permits (rangeAssessed actualEvaluation) change)
    (movementActualityImpliesPossibility :
      actualMovement → permits (rangeAssessed actualEvaluation) movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (routes :
      (actualChange ∧ Nonempty (ReflectiveRoute Evaluation actualChange
        (permits realityRange change) temporality spatiality substantiality)) ∨
      (actualMovement ∧ Nonempty (MovementRoute Evaluation actualMovement
        (permits realityRange movement) temporality spatiality substantiality)))
    -- The outside half: candidate modality, the conditions at items, agency.
    (modality : CandidateModality Item identity.toRealityNatureCoverage.real)
    (conditions : ConditionsAtItems Item)
    (agency isWay : Item → Prop)
    (agencyIsConcreteWork : ∀ item, agency item → conditions.concreteWork item) :
    nature = reality ∧
    Necessary (ThreeConditions temporality spatiality substantiality) ∧
    (¬ ∃ item, conditions.concreteWork item ∧ Exempt conditions item) ∧
    (¬ ∃ item, identity.toRealityNatureCoverage.real item ∧
      ¬ WithinNature identity.toRealityNatureCoverage item) ∧
    (∀ candidate, modality.possible candidate →
      ∀ way, modality.wayOf candidate way → WithinNature identity.toRealityNatureCoverage way) ∧
    ¬ PossibleDescription isWay (ContentlessGod conditions agency) := by
  have inside := natureIsNecessaryByEitherRoute identity realityRange rangeAssessed oneRange
    permits actualEvaluation change movement actualChange actualMovement
    changeActualityImpliesPossibility movementActualityImpliesPossibility
    temporality spatiality substantiality routes
  have outside := noSupernature identity.toRealityNatureCoverage modality conditions
  exact ⟨inside.1, inside.2, outside.1, outside.2.1, outside.2.2,
    (contentlessGodHasNoReferent conditions agency isWay agencyIsConcreteWork).1⟩

#print axioms theInversionOfGreatness

/-! ## Joining the two halves: realization

The book joins the item-level and evaluation-level conditions. The
roles operate at each concrete change token (§2.4.7); the token is an
operative realizer of the structure (§2.6.8); and the conditions it
bears are the standing structure, Nature, where it occurs (§2.6.10;
concrete occupancy, §2.9.2). `Realization` states that join: an item
occurs at an evaluation, and an item bearing all three conditions
realizes all three evaluation-level conditions there. -/

/-- Where an item occurs, the conditions it bears are the conditions of
that evaluation (§§2.4.7, 2.6.8, 2.6.10, 2.9.2). -/
structure Realization {Evaluation : Type u} {Item : Type w}
    (conditions : ConditionsAtItems Item)
    (temporality spatiality substantiality : Evaluation → Prop) where
  occursAt : Item → Evaluation → Prop
  rolesRealizeTheStructure : ∀ item evaluation, occursAt item evaluation →
    conditions.temporalAt item ∧ conditions.spatialAt item ∧ conditions.substantialAt item →
    ThreeConditions temporality spatiality substantiality evaluation

/-- Every change token realizes the three evaluation-level conditions
where it occurs. -/
theorem changeTokensRealizeTheConditions {Evaluation : Type u} {Item : Type w}
    {conditions : ConditionsAtItems Item}
    {temporality spatiality substantiality : Evaluation → Prop}
    (realization : Realization conditions temporality spatiality substantiality) :
    ∀ item evaluation, realization.occursAt item evaluation → conditions.changeToken item →
      ThreeConditions temporality spatiality substantiality evaluation :=
  fun item evaluation occurs isChange =>
    realization.rolesRealizeTheStructure item evaluation occurs
      (conditions.changeIncursConditions item isChange)

/-- Whatever does concrete work realizes the three evaluation-level
conditions where it works: the outside half's *Concrete work incurs the
conditions*, carried to the inside half's evaluations. -/
theorem concreteWorkRealizesTheConditions {Evaluation : Type u} {Item : Type w}
    {conditions : ConditionsAtItems Item}
    {temporality spatiality substantiality : Evaluation → Prop}
    (realization : Realization conditions temporality spatiality substantiality) :
    ∀ item evaluation, realization.occursAt item evaluation → conditions.concreteWork item →
      ThreeConditions temporality spatiality substantiality evaluation :=
  fun item evaluation occurs works =>
    changeTokensRealizeTheConditions realization item evaluation occurs
      (conditions.workIsChange item works)

/-- The capstone with the two halves joined. Everything
`theInversionOfGreatness` gives, and in addition: the actual witness is a
change token occurring at the actual evaluation, so the item-level
conditions it bears realize the evaluation-level conditions there, and
every concrete work realizes them wherever it occurs. The item-level
verdict and the necessity proved by the inside half agree. -/
theorem theInversionOfGreatnessJoined
    {Evaluation : Type u} {Content : Type v}
    {Whole : Type u} {Field : Type v} {Item : Type w} {Range : Type x}
    {nature reality : Whole} {jointComplex : Field}
    (identity : RealityNaturePremises Whole Field Item nature reality jointComplex)
    (realityRange : Range) (rangeAssessed : Evaluation → Range)
    (oneRange : ∀ evaluation, rangeAssessed evaluation = realityRange)
    (permits : Range → Content → Prop)
    (actualEvaluation : Evaluation) (change movement : Content)
    (actualChange actualMovement : Prop)
    (changeActualityImpliesPossibility :
      actualChange → permits (rangeAssessed actualEvaluation) change)
    (movementActualityImpliesPossibility :
      actualMovement → permits (rangeAssessed actualEvaluation) movement)
    (temporality spatiality substantiality : Evaluation → Prop)
    (routes :
      (actualChange ∧ Nonempty (ReflectiveRoute Evaluation actualChange
        (permits realityRange change) temporality spatiality substantiality)) ∨
      (actualMovement ∧ Nonempty (MovementRoute Evaluation actualMovement
        (permits realityRange movement) temporality spatiality substantiality)))
    (modality : CandidateModality Item identity.toRealityNatureCoverage.real)
    (conditions : ConditionsAtItems Item)
    (agency isWay : Item → Prop)
    (agencyIsConcreteWork : ∀ item, agency item → conditions.concreteWork item)
    -- The join.
    (realization : Realization conditions temporality spatiality substantiality)
    (witnessIsAToken : ∃ item, conditions.changeToken item ∧
      realization.occursAt item actualEvaluation) :
    nature = reality ∧
    Necessary (ThreeConditions temporality spatiality substantiality) ∧
    (¬ ∃ item, conditions.concreteWork item ∧ Exempt conditions item) ∧
    (¬ ∃ item, identity.toRealityNatureCoverage.real item ∧
      ¬ WithinNature identity.toRealityNatureCoverage item) ∧
    (∀ candidate, modality.possible candidate →
      ∀ way, modality.wayOf candidate way → WithinNature identity.toRealityNatureCoverage way) ∧
    ¬ PossibleDescription isWay (ContentlessGod conditions agency) ∧
    ThreeConditions temporality spatiality substantiality actualEvaluation ∧
    (∀ item evaluation, realization.occursAt item evaluation → conditions.concreteWork item →
      ThreeConditions temporality spatiality substantiality evaluation) := by
  have base := theInversionOfGreatness identity realityRange rangeAssessed oneRange permits
    actualEvaluation change movement actualChange actualMovement
    changeActualityImpliesPossibility movementActualityImpliesPossibility
    temporality spatiality substantiality routes modality conditions agency isWay
    agencyIsConcreteWork
  obtain ⟨token, isChange, occurs⟩ := witnessIsAToken
  exact ⟨base.1, base.2.1, base.2.2.1, base.2.2.2.1, base.2.2.2.2.1, base.2.2.2.2.2,
    changeTokensRealizeTheConditions realization token actualEvaluation occurs isChange,
    concreteWorkRealizesTheConditions realization⟩

#print axioms changeTokensRealizeTheConditions
#print axioms concreteWorkRealizesTheConditions
#print axioms theInversionOfGreatnessJoined

end InversionOfGreatness
