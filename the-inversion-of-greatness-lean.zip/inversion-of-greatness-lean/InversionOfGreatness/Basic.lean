/-!
# Shared vocabulary

Definitions for necessity and the conjunction of the three conditions at
an evaluation. Modules can import and reuse these definitions wherever
they use this evaluation-level vocabulary.
-/

namespace InversionOfGreatness

universe u

/-- Truth at every real evaluation (§1.2.3, §2.1). -/
def Necessary {Evaluation : Type u} (claim : Evaluation → Prop) : Prop :=
  ∀ evaluation, claim evaluation

/-- The pointwise conjunction of T, S and Φ (§§1.4.1–1.4.4). -/
def ThreeConditions {Evaluation : Type u}
    (temporality spatiality substantiality : Evaluation → Prop) : Evaluation → Prop :=
  fun evaluation => temporality evaluation ∧ spatiality evaluation ∧ substantiality evaluation

end InversionOfGreatness
