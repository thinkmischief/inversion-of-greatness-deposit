import InversionOfGreatness.Basic

/-!
# Modal results of the outside half

A possible-worlds semantics: worlds, an accessibility relation `sees`,
and `Box` and `Dia` defined over it. Reality's one range (§1.2.1, §2.1.4)
is the frame in which every world sees every world; there `Box` is the
inside half's `Necessary`.

Several results here are claims that something does not follow. Each
of those is confirmed by a countermodel: a frame where every stated
premise holds and the conclusion fails.
-/

namespace InversionOfGreatness.Modal

universe u

variable {World : Type u}

/-- True at every world `w` sees. -/
def Box (sees : World → World → Prop) (p : World → Prop) (w : World) : Prop :=
  ∀ v, sees w v → p v

/-- True at some world `w` sees. -/
def Dia (sees : World → World → Prop) (p : World → Prop) (w : World) : Prop :=
  ∃ v, sees w v ∧ p v

/-- S5: accessibility is reflexive, symmetric and transitive. -/
def IsS5 (sees : World → World → Prop) : Prop :=
  Equivalence sees

/-- Over the one range, where every world sees every world, `Box` is
the inside half's `Necessary`. -/
theorem boxOverOneRangeIsNecessary (p : World → Prop) (w : World) :
    Box (fun _ _ => True) p w ↔ Necessary p :=
  ⟨fun h v => h v trivial, fun h v _ => h v⟩

/-! ## The Modal Trilemma (§7.2.1) -/

/-- Every content is impossible, contingent or necessary at a world. -/
theorem modalStatusExhaustive (sees : World → World → Prop) (p : World → Prop) (w : World) :
    ¬ Dia sees p w ∨ (Dia sees p w ∧ ¬ Box sees p w) ∨ Box sees p w := by
  by_cases necessary : Box sees p w
  · exact Or.inr (Or.inr necessary)
  · by_cases possible : Dia sees p w
    · exact Or.inr (Or.inl ⟨possible, necessary⟩)
    · exact Or.inl possible

/-- The impossible and necessary cases exclude each other once every
world sees itself, as in the book's S5 frame. -/
theorem necessaryIsPossible {sees : World → World → Prop} (reflexive : ∀ w, sees w w)
    {p : World → Prop} {w : World} (necessary : Box sees p w) : Dia sees p w :=
  ⟨w, reflexive w, necessary w (reflexive w)⟩

/-! ## The possibility-premise burden and the S5 parity (§10.1.1, §8.1.5) -/

/-- S5 transfers a possibility premise: ◇□p gives □p. -/
theorem possiblyNecessaryIsNecessary {sees : World → World → Prop} (s5 : IsS5 sees)
    {p : World → Prop} {w : World} (premise : Dia sees (Box sees p) w) : Box sees p w := by
  obtain ⟨v, wSeesV, necessaryAtV⟩ := premise
  intro u wSeesU
  exact necessaryAtV u (s5.trans (s5.symm wSeesV) wSeesU)

/-- The premise ◇□p and its mirror ◇□¬p cannot both hold in S5. -/
theorem mirrorPremisesExclude {sees : World → World → Prop} (s5 : IsS5 sees)
    {p : World → Prop} {w : World}
    (forP : Dia sees (Box sees p) w)
    (againstP : Dia sees (Box sees (fun v => ¬ p v)) w) : False :=
  possiblyNecessaryIsNecessary s5 againstP w (s5.refl w)
    (possiblyNecessaryIsNecessary s5 forP w (s5.refl w))

/-- S5 supplies neither premise. Each fails in some S5 model, so
neither is a theorem of the logic. -/
theorem s5SuppliesNeitherPremise :
    (∃ (W : Type) (sees : W → W → Prop) (p : W → Prop) (w : W),
        IsS5 sees ∧ ¬ Dia sees (Box sees p) w) ∧
    (∃ (W : Type) (sees : W → W → Prop) (p : W → Prop) (w : W),
        IsS5 sees ∧ ¬ Dia sees (Box sees (fun v => ¬ p v)) w) := by
  have s5 : IsS5 (fun (_ _ : Unit) => True) := ⟨fun _ => trivial, fun _ => trivial, fun _ _ => trivial⟩
  refine ⟨⟨Unit, fun _ _ => True, fun _ => False, (), s5, ?_⟩,
    ⟨Unit, fun _ _ => True, fun _ => True, (), s5, ?_⟩⟩
  · intro ⟨v, _, necessary⟩
    exact necessary v trivial
  · intro ⟨v, _, necessary⟩
    exact necessary v trivial trivial

/-! ## No rescue by changing the modal logic (§10.1.1) -/

/-- Without symmetry the transfer fails. The frame is reflexive and
transitive (S4); at `false`, ◇□p holds and □p fails. -/
theorem noTransferWithoutSymmetry :
    ∃ (sees : Bool → Bool → Prop) (p : Bool → Prop),
      (∀ w, sees w w) ∧
      (∀ a b c, sees a b → sees b c → sees a c) ∧
      Dia sees (Box sees p) false ∧ ¬ Box sees p false := by
  refine ⟨fun a b => a = b ∨ (a = false ∧ b = true), fun w => w = true, ?_, ?_, ?_, ?_⟩
  · intro w
    exact Or.inl rfl
  · intro a b c ab bc
    cases a <;> cases b <;> cases c <;> simp_all
  · refine ⟨true, Or.inr ⟨rfl, rfl⟩, ?_⟩
    intro v trueSeesV
    cases v <;> simp_all
  · intro necessary
    exact absurd (necessary false (Or.inl rfl)) (by decide)

/-! ## Constitutive Grounding Non-Propagation (§8.2.5) -/

/-- Distribution: a necessary full ground with a necessary sufficiency
conditional gives a necessary result. -/
theorem necessaryGroundGivesNecessaryResult {sees : World → World → Prop}
    {fullGround result : World → Prop} {w : World}
    (groundNecessary : Box sees fullGround w)
    (sufficiency : Box sees (fun v => fullGround v → result v) w) :
    Box sees result w :=
  fun v wSeesV => sufficiency v wSeesV (groundNecessary v wSeesV)

/-- With the identity of the conditions and possible change, necessary
conditions are the necessary possibility of change. -/
theorem necessaryConditionsAreNecessaryPossibility {sees : World → World → Prop}
    {conditions change : World → Prop}
    (oneFact : ∀ v, conditions v ↔ Dia sees change v)
    {w : World} (conditionsNecessary : Box sees conditions w) :
    Box sees (Dia sees change) w :=
  fun v wSeesV => (oneFact v).mp (conditionsNecessary v wSeesV)

/-- No particular change follows. In an S5 model, the conditions hold
necessarily and are one fact with possible change, the full ground
necessarily suffices for the change, and the change actually occurs;
still the change is not necessary. -/
theorem noParticularChangeIsNecessary :
    ∃ (sees : Bool → Bool → Prop) (conditions fullGround change : Bool → Prop),
      IsS5 sees ∧
      (∀ v, conditions v ↔ Dia sees change v) ∧
      Box sees conditions true ∧
      Box sees (fun v => fullGround v → change v) true ∧
      change true ∧
      ¬ Box sees change true := by
  refine ⟨fun _ _ => True, fun _ => True, fun v => v = true, fun v => v = true,
    ⟨fun _ => trivial, fun _ => trivial, fun _ _ => trivial⟩, ?_,
    fun _ _ => trivial, fun _ _ grounded => grounded, rfl, ?_⟩
  · intro v
    exact ⟨fun _ => ⟨true, trivial, rfl⟩, fun _ => trivial⟩
  · intro necessary
    exact absurd (necessary false trivial) (by decide)

/-- Some change is necessary (§2.9.1) comes from the frozen-world
premise (§2.4.10): wherever the conditions hold, some change occurs.
The countermodel above shows that the identity of the conditions with
possible change does not supply this step. -/
theorem someChangeNecessaryFromFrozenWorld {sees : World → World → Prop}
    {conditions someChange : World → Prop} {w : World}
    (conditionsNecessary : Box sees conditions w)
    (frozenWorldHasNoHistory : Box sees (fun v => conditions v → someChange v) w) :
    Box sees someChange w :=
  necessaryGroundGivesNecessaryResult conditionsNecessary frozenWorldHasNoHistory

/-- Some change is necessary (§2.9.1) straight from the necessary
possibility of change (§2.3): without change there is no capacity for
change. Where no change ever occurs, the moments collapse into one and
the conditions are absent (§2.4.10); Reality's capacity for change
consists in the standing structure that permits it (*Capacity
Constitution*, §2.4); so a history with no change has no capacity for
change. The scope is a whole history: a local lull keeps its capacity,
since change goes on elsewhere and the structure stands. Step 2 rests on
Capacity Constitution applied at each evaluation: the capacity assessed
there consists in the structure there, which is the content of line 10.
The route is therefore line 11 unfolded (lines 9 and 10 with the frozen-
world step), not a shorter or independent route (GPT-6 review, 2026-11-27). -/
theorem someChangeNecessaryFromCapacity {sees : World → World → Prop}
    {capacityForChange someChange : World → Prop} {w : World}
    (changeNecessarilyPossible : Box sees capacityForChange w)
    (noChangeNoCapacity : Box sees (fun v => capacityForChange v → someChange v) w) :
    Box sees someChange w :=
  necessaryGroundGivesNecessaryResult changeNecessarilyPossible noChangeNoCapacity

/-! ## Whatever makes possibility vary is necessary (§7.2.1) -/

/-- Over the one range, a content's possibility is the same from every
evaluation. -/
theorem possibilityInvariantOverOneRange (p : World → Prop) (w v : World) :
    Dia (fun _ _ => True) p w ↔ Dia (fun _ _ => True) p v :=
  ⟨fun ⟨u, _, pu⟩ => ⟨u, trivial, pu⟩, fun ⟨u, _, pu⟩ => ⟨u, trivial, pu⟩⟩

/-- In S5, possibility is the same from any world a world sees. -/
theorem possibilityInvariantInS5 {sees : World → World → Prop} (s5 : IsS5 sees)
    (p : World → Prop) {w v : World} (wSeesV : sees w v) :
    Dia sees p w ↔ Dia sees p v :=
  ⟨fun ⟨u, wSeesU, pu⟩ => ⟨u, s5.trans (s5.symm wSeesV) wSeesU, pu⟩,
    fun ⟨u, vSeesU, pu⟩ => ⟨u, s5.trans wSeesV vSeesU, pu⟩⟩

/-- Variation needs a restricted frame: here each world sees only
itself, and `p` is possible from one world and not from the other. -/
theorem variationNeedsRestrictedFrame :
    ∃ (sees : Bool → Bool → Prop) (p : Bool → Prop),
      Dia sees p false ∧ ¬ Dia sees p true := by
  refine ⟨fun a b => a = b, fun w => w = false, ⟨false, rfl, rfl⟩, ?_⟩
  intro ⟨u, trueIsU, pu⟩
  cases trueIsU
  exact absurd pu (by decide)

/-! ## Restriction adds nothing (§7.3.1) -/

/-- Possibility restricted to a modal base. -/
def DiaIn (sees : World → World → Prop) (base : World → Prop) (p : World → Prop)
    (w : World) : Prop :=
  ∃ v, sees w v ∧ base v ∧ p v

/-- A base drawn from genuine alternatives selects no alternative
lacking the conditions, if every genuine alternative has them. -/
theorem restrictionAddsNothing {sees : World → World → Prop}
    {base genuine conditions : World → Prop} {w : World}
    (baseIsGenuine : ∀ v, base v → genuine v)
    (genuineHaveConditions : Box sees (fun v => genuine v → conditions v) w) :
    ¬ DiaIn sees base (fun v => ¬ conditions v) w :=
  fun ⟨v, wSeesV, inBase, lacks⟩ => lacks (genuineHaveConditions v wSeesV (baseIsGenuine v inBase))

#print axioms boxOverOneRangeIsNecessary
#print axioms modalStatusExhaustive
#print axioms necessaryIsPossible
#print axioms possiblyNecessaryIsNecessary
#print axioms mirrorPremisesExclude
#print axioms s5SuppliesNeitherPremise
#print axioms noTransferWithoutSymmetry
#print axioms necessaryGroundGivesNecessaryResult
#print axioms necessaryConditionsAreNecessaryPossibility
#print axioms noParticularChangeIsNecessary
#print axioms someChangeNecessaryFromFrozenWorld
#print axioms someChangeNecessaryFromCapacity
#print axioms possibilityInvariantOverOneRange
#print axioms possibilityInvariantInS5
#print axioms variationNeedsRestrictedFrame
#print axioms restrictionAddsNothing

end InversionOfGreatness.Modal
