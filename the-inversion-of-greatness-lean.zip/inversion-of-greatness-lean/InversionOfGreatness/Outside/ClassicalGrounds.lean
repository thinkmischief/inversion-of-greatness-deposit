import InversionOfGreatness.Outside.Attributes

/-!
# The classical grounds (Chapter 10)

Tier B instances of the fork for Chapter 10's proposed grounds of
Nature, logic and possibility. Each uses `Closed` from
`Outside/Attributes` and adds only its own per-branch premises.

Covered elsewhere or left in the manuscript (see `OUTSIDE-MAP.md`):
*A beginning needs what it would begin* is the first conclusion of
`noCreatorOfNature`. *Three concessions for active power* and *One
unchanging act discriminates nothing* enter *Subsistence is Nature's
too* as the premise for its pure-act branch. *The Sustenance Fork*
splits commitments, and *The Divine Causation Trilemma* classifies
without concluding, so Lean would check nothing beyond the case split.
-/

namespace InversionOfGreatness.ClassicalGrounds

open InversionOfGreatness NoBeyond Attributes

universe u v w x

variable {Whole : Type u} {Field : Type v} {Item : Type w}
  {nature reality : Whole} {jointComplex : Field}
  (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
  (modality : CandidateModality Item coverage.real) (conditions : ConditionsAtItems Item)

/-- *No Third Option Between Contrastive and Empty* (§10.2.1). Eminent
content is determinate and contrastive, which reinstates order,
difference and bearing, or excludes nothing, which is ∅. The Difference
Principle leaves no positive content that is neither. -/
theorem noThirdOptionBetweenContrastiveAndEmpty {content : Item}
    (contrastive excludesNothing : Prop)
    (differencePrinciple : contrastive ∨ excludesNothing)
    (contrastReinstatesStructure : contrastive → coverage.real content)
    (excludingNothingIsEmpty : excludesNothing → ¬ ∃ way, modality.wayOf content way) :
    Closed coverage modality conditions content := by
  rcases differencePrinciple with isContrastive | isEmpty
  · exact closedOfReal coverage modality conditions (contrastReinstatesStructure isContrastive)
  · exact closedOfNoWay coverage modality conditions (excludingNothingIsEmpty isEmpty)

/-- *Subsistence is Nature's too* (§10.2.2). A ground said to differ from
structure only by subsisting differs as existing in itself, as
unreceived, or as pure act. The first two name no difference from its
twin, Nature's own structure grounding Nature's configurations. As pure
act it incurs one of the *Three concessions for active power*:
differentiated content is structure, and a brute selection or a
collapsed creation leaves a ground that differs from the twin in
nothing. Every branch ends within Nature. -/
theorem subsistenceIsNaturesToo {ground twin : Item}
    (inItself unreceived pureAct differentiated brute collapse : Prop)
    (threeMarks : inItself ∨ unreceived ∨ pureAct)
    (twinIsReal : coverage.real twin)
    (inItselfNoDifference : inItself → ground = twin)
    (unreceivedNoDifference : unreceived → ground = twin)
    (threeConcessions : pureAct → differentiated ∨ brute ∨ collapse)
    (differentiatedContentIsStructure : differentiated → coverage.real ground)
    (bruteSelectionDiffersInNothing : brute → ground = twin)
    (collapseDiffersInNothing : collapse → ground = twin) :
    WithinNature coverage ground := by
  have atTwin : ground = twin → WithinNature coverage ground := fun same => by
    rw [same]; exact realIsWithinNature coverage twinIsReal
  rcases threeMarks with mark | mark | mark
  · exact atTwin (inItselfNoDifference mark)
  · exact atTwin (unreceivedNoDifference mark)
  · rcases threeConcessions mark with price | price | price
    · exact realIsWithinNature coverage (differentiatedContentIsStructure price)
    · exact atTwin (bruteSelectionDiffersInNothing price)
    · exact atTwin (collapseDiffersInNothing price)

/-- *The Creation Fork* (§10.1.2). A divine mind with no capacity for
anything distinct from itself grounds no creaturely possibility. With
that capacity it admits ground and creature as genuinely distinct
relata in a real grounding relation, which lies within Nature. -/
theorem creationFork {mind creature relation : Item}
    (groundsCreaturelyPossibility capacityForOther : Prop)
    (groundingNeedsCapacity : groundsCreaturelyPossibility → capacityForOther)
    (groundingRequiresDifferentiatedTerms :
      capacityForOther → mind ≠ creature ∧ coverage.real relation) :
    groundsCreaturelyPossibility → mind ≠ creature ∧ WithinNature coverage relation :=
  fun grounds =>
    let ⟨distinct, isReal⟩ := groundingRequiresDifferentiatedTerms (groundingNeedsCapacity grounds)
    ⟨distinct, realIsWithinNature coverage isReal⟩

/-- *The Three Grounds Trilemma* (§10.1.3). If logic does not depend on
God, the transcendental argument loses its conclusion. Necessary
dependence is already determinate structure. Contingent dependence
needs an act that presupposes that structure: concrete thinking, which
incurs the conditions, or Nature's own structure. -/
theorem threeGroundsTrilemma {ground : Item}
    (independent necessaryDependence contingentDependence argumentConcludes : Prop)
    (threeHorns : independent ∨ necessaryDependence ∨ contingentDependence)
    (independenceLeavesNoConclusion : independent → ¬ argumentConcludes)
    (necessaryDependenceIsStructure : necessaryDependence → coverage.real ground)
    (contingentActPresupposesStructure :
      contingentDependence → conditions.concreteWork ground ∨ coverage.real ground) :
    Closed coverage modality conditions ground ∨ ¬ argumentConcludes := by
  rcases threeHorns with horn | horn | horn
  · exact Or.inr (independenceLeavesNoConclusion horn)
  · exact Or.inl (closedOfReal coverage modality conditions (necessaryDependenceIsStructure horn))
  · rcases contingentActPresupposesStructure horn with works | isReal
    · exact Or.inl (closedOfWork coverage modality conditions works)
    · exact Or.inl (closedOfReal coverage modality conditions isReal)

/-- *No corner is empty of structure* (§10.3.4). Affirming, denying,
affirming-and-denying, and refusing all three are each an activity, the
fourth corner included, so every stance incurs the conditions at the
stance itself. -/
theorem noCornerIsEmptyOfStructure (stance affirming denying both withholding : Item → Prop)
    (fourCorners : ∀ taken, stance taken →
      affirming taken ∨ denying taken ∨ both taken ∨ withholding taken)
    (affirmingIsWork : ∀ taken, affirming taken → conditions.concreteWork taken)
    (denyingIsWork : ∀ taken, denying taken → conditions.concreteWork taken)
    (bothIsWork : ∀ taken, both taken → conditions.concreteWork taken)
    (withholdingIsWork : ∀ taken, withholding taken → conditions.concreteWork taken) :
    ∀ taken, stance taken →
      conditions.temporalAt taken ∧ conditions.spatialAt taken ∧ conditions.substantialAt taken := by
  intro taken isStance
  apply concreteWorkIncursConditions
  rcases fourCorners taken isStance with corner | corner | corner | corner
  · exact affirmingIsWork taken corner
  · exact denyingIsWork taken corner
  · exact bothIsWork taken corner
  · exact withholdingIsWork taken corner

#print axioms noThirdOptionBetweenContrastiveAndEmpty
#print axioms subsistenceIsNaturesToo
#print axioms creationFork
#print axioms threeGroundsTrilemma
#print axioms noCornerIsEmptyOfStructure

end InversionOfGreatness.ClassicalGrounds
