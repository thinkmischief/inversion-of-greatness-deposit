import InversionOfGreatness.Inside.Identity

/-!
# Nothing beyond Nature (Chapters 7–11)

Chapters 7–11 close every proposed rival to Nature with one fork. A
candidate that does concrete work is T, S and Φ in operation. A
determinate abstract or atemporal candidate is Nature's own structure.
A candidate with no determinate content is not possible.

The fork is not a new premise here. It is the inside half's coverage
argument (§2.8.3): every real item is field content, a concrete
occupant, which is an articulation of Nature, or an abstractum, which is
an abstraction of Nature. So every real item lies within Nature. The
results below reuse `RealityNatureCoverage` from `Inside/Identity`, so
they mean by Reality, Nature and real exactly what Chapters 1–3 mean.

Here the three conditions are predicates of particular acts, events or
bearers. `ConditionsAtItems` takes as a premise that each change token
incurs all three at the operation (§2.4.7, *Concrete work incurs the
conditions*). This premise concerns items. The inside half separately
uses predicates on evaluations.
-/

namespace InversionOfGreatness.NoBeyond

open InversionOfGreatness

universe u v w x

variable {Whole : Type u} {Field : Type v} {Item : Type w}
  {nature reality : Whole} {jointComplex : Field}

/-! ## Within Nature -/

/-- Nature itself, Nature in a determinate operation, or an abstraction of
such an articulation (§2.8.3, §11.10). -/
def WithinNature (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (item : Item) : Prop :=
  coverage.belongs nature item ∧
    NatureContents coverage.fieldContent coverage.articulation coverage.abstraction item

/-- The fork itself. Every real item lies within Nature: the field, a
concrete occupant as an articulation, or an abstractum as an
abstraction. -/
theorem realIsWithinNature
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    {item : Item} (isReal : coverage.real item) : WithinNature coverage item := by
  have inNature := (realityAndNatureHaveSameContents coverage item).mpr
    ((coverage.realityIsWhole item).mpr isReal)
  exact ⟨inNature, (coverage.natureTotality item).mp inNature⟩

/-- Nothing real lies beyond Nature or alongside it as an addition. -/
theorem nothingRealBeyondNature
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex) :
    ¬ ∃ item, coverage.real item ∧ ¬ WithinNature coverage item :=
  fun ⟨_, isReal, outside⟩ => outside (realIsWithinNature coverage isReal)

/-! ## Possible candidates and their ways -/

/-- The modal inputs for candidates. To be possible is to have a
determinate way to be (§3.2.5), and every determinate way belongs to
Reality's one modal structure (§1.1, §2.1). -/
structure CandidateModality (Item : Type w) (real : Item → Prop) where
  possible : Item → Prop
  wayOf : Item → Item → Prop
  possibleMeansAWay : ∀ candidate, possible candidate ↔ ∃ way, wayOf candidate way
  waysAreReal : ∀ candidate way, wayOf candidate way → real way

/-- Every way a possible candidate could be lies within Nature, and a
candidate with no determinate way is not possible. -/
theorem possibleCandidatesLieWithinNature
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (modality : CandidateModality Item coverage.real) (candidate : Item) :
    (modality.possible candidate →
      (∃ way, modality.wayOf candidate way) ∧
        ∀ way, modality.wayOf candidate way → WithinNature coverage way) ∧
    ((¬ ∃ way, modality.wayOf candidate way) → ¬ modality.possible candidate) :=
  ⟨fun isPossible => ⟨(modality.possibleMeansAWay candidate).mp isPossible,
      fun way isWay => realIsWithinNature coverage (modality.waysAreReal candidate way isWay)⟩,
    fun noWay isPossible => noWay ((modality.possibleMeansAWay candidate).mp isPossible)⟩

/-! ## Concrete work incurs the conditions (§2.4) -/

/-- The three conditions at particular items, with the premise that
concrete work is change and each change token incurs all three. -/
structure ConditionsAtItems (Item : Type w) where
  temporalAt : Item → Prop
  spatialAt : Item → Prop
  substantialAt : Item → Prop
  changeToken : Item → Prop
  concreteWork : Item → Prop
  workIsChange : ∀ item, concreteWork item → changeToken item
  changeIncursConditions :
    ∀ item, changeToken item → temporalAt item ∧ spatialAt item ∧ substantialAt item

variable {conditions : ConditionsAtItems Item}

/-- Exempt from at least one of the three conditions. -/
def Exempt (conditions : ConditionsAtItems Item) (item : Item) : Prop :=
  ¬ (conditions.temporalAt item ∧ conditions.spatialAt item ∧ conditions.substantialAt item)

/-- Withdrawn from all three: atemporal, aspatial, and with no bearer-role. -/
def Withdrawn (conditions : ConditionsAtItems Item) (item : Item) : Prop :=
  ¬ conditions.temporalAt item ∧ ¬ conditions.spatialAt item ∧ ¬ conditions.substantialAt item

theorem withdrawnIsExempt {item : Item} (withdrawn : Withdrawn conditions item) :
    Exempt conditions item :=
  fun ⟨temporal, _, _⟩ => withdrawn.1 temporal

/-- Whatever acts, changes, creates, sustains or intervenes supplies a
when, a where and a what at that work. -/
theorem concreteWorkIncursConditions {item : Item} (works : conditions.concreteWork item) :
    conditions.temporalAt item ∧ conditions.spatialAt item ∧ conditions.substantialAt item :=
  conditions.changeIncursConditions item (conditions.workIsChange item works)

/-- No concrete agent is exempt from the conditions. -/
theorem noExemptConcreteAgent (conditions : ConditionsAtItems Item) :
    ¬ ∃ item, conditions.concreteWork item ∧ Exempt conditions item :=
  fun ⟨_, works, exempt⟩ => exempt (concreteWorkIncursConditions works)

/-! ## Descriptions and their possibility -/

/-- A description is possible when some determinate way answers to it (§3.2.5). -/
def PossibleDescription (isWay : Item → Prop) (description : Item → Prop) : Prop :=
  ∃ item, isWay item ∧ description item

/-- A description that pairs withdrawal from all three conditions with
concrete work has no possible referent, and necessarily nothing answers
to it. -/
theorem withdrawnWorkerImpossible (conditions : ConditionsAtItems Item)
    (isWay description : Item → Prop)
    (describesWithdrawnWorker :
      ∀ item, description item → Withdrawn conditions item ∧ conditions.concreteWork item) :
    ¬ PossibleDescription isWay description ∧ ∀ item, isWay item → ¬ description item := by
  have nothingAnswers : ∀ item, ¬ description item := fun item described =>
    let ⟨withdrawn, works⟩ := describesWithdrawnWorker item described
    withdrawnIsExempt withdrawn (concreteWorkIncursConditions works)
  exact ⟨fun ⟨item, _, described⟩ => nothingAnswers item described,
    fun item _ => nothingAnswers item⟩

/-! ## The rivals -/

/-- *No Divine Addition* (§11.10). A God claimed to be actual or necessary
must be possible, so it has a determinate way to be, and every such way
lies within Nature. -/
theorem noDivineAddition
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (modality : CandidateModality Item coverage.real) (god : Item)
    (claimedActualOrNecessary : Prop) (claimed : claimedActualOrNecessary)
    (actualityOrNecessityEntailsPossibility : claimedActualOrNecessary → modality.possible god) :
    (∃ way, modality.wayOf god way) ∧ ∀ way, modality.wayOf god way → WithinNature coverage way :=
  (possibleCandidatesLieWithinNature coverage modality god).1
    (actualityOrNecessityEntailsPossibility claimed)

/-- Coverage clauses of *No Unconditioned Essence* (§7.2.1). The supplied
fork treats essence as a constitutive truth, a real ground and relation,
or an unspecified proposal. The result locates the named items in
Nature in the first two branches. Independence from a bearer and
explanatory priority require further relations. -/
theorem noUnconditionedEssence
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    {essence ground relation : Item} (specified : Prop)
    (threeReadings : coverage.real essence ∨ (coverage.real ground ∧ coverage.real relation) ∨
      ¬ specified) :
    WithinNature coverage essence ∨
      (WithinNature coverage ground ∧ WithinNature coverage relation) ∨ ¬ specified := by
  rcases threeReadings with constitutive | ⟨realGround, realRelation⟩ | unspecified
  · exact Or.inl (realIsWithinNature coverage constitutive)
  · exact Or.inr (Or.inl ⟨realIsWithinNature coverage realGround,
      realIsWithinNature coverage realRelation⟩)
  · exact Or.inr (Or.inr unspecified)

/-- Coverage clauses of *No Outside Selector* (§10.4). Concrete
selection incurs the conditions, real selectors are within Nature,
and possibility requires a determinate way. These clauses concern the
selector. The distinction between explaining a subconfiguration and
explaining total actuality requires an explanatory relation. -/
theorem noOutsideSelector
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (modality : CandidateModality Item coverage.real) (conditions : ConditionsAtItems Item)
    (selector : Item) :
    (conditions.concreteWork selector →
      conditions.temporalAt selector ∧ conditions.spatialAt selector ∧
        conditions.substantialAt selector) ∧
    (coverage.real selector → WithinNature coverage selector) ∧
    ((¬ ∃ way, modality.wayOf selector way) → ¬ modality.possible selector) :=
  ⟨concreteWorkIncursConditions, realIsWithinNature coverage,
    (possibleCandidatesLieWithinNature coverage modality selector).2⟩

/-- *No Supernature* (§11.10). No concrete agent is exempt from the
conditions, nothing real stands outside Nature or is added to it, and
every way a possible candidate could be lies within Nature. -/
theorem noSupernature
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (modality : CandidateModality Item coverage.real) (conditions : ConditionsAtItems Item) :
    (¬ ∃ item, conditions.concreteWork item ∧ Exempt conditions item) ∧
    (¬ ∃ item, coverage.real item ∧ ¬ WithinNature coverage item) ∧
    (∀ candidate, modality.possible candidate →
      ∀ way, modality.wayOf candidate way → WithinNature coverage way) :=
  ⟨noExemptConcreteAgent conditions, nothingRealBeyondNature coverage,
    fun candidate isPossible => ((possibleCandidatesLieWithinNature coverage modality candidate).1
      isPossible).2⟩

/-- Concrete-work version of CG₀ (§11.10): an item withdrawn from T, S
and Φ to which the supplied agency predicate applies. The manuscript's
exclusion of determinate replacement truth conditions is an additional
restriction on its own description. -/
def ContentlessGod (conditions : ConditionsAtItems Item) (agency : Item → Prop)
    (item : Item) : Prop :=
  Withdrawn conditions item ∧ agency item

/-- Concrete-work case of *The contentless God has no referent* (§11.10).
The premise makes agency imply concrete work throughout the model. The
conclusion excludes the modeled description among items satisfying `isWay`. -/
theorem contentlessGodHasNoReferent (conditions : ConditionsAtItems Item)
    (agency isWay : Item → Prop)
    (agencyIsConcreteWork : ∀ item, agency item → conditions.concreteWork item) :
    ¬ PossibleDescription isWay (ContentlessGod conditions agency) ∧
      ∀ item, isWay item → ¬ ContentlessGod conditions agency item :=
  withdrawnWorkerImpossible conditions isWay (ContentlessGod conditions agency)
    (fun item ⟨withdrawn, acts⟩ => ⟨withdrawn, agencyIsConcreteWork item acts⟩)

/-- Concrete-work version of MGB₀ (§10.1.1): maximal greatness and
withdrawal from T, S and Φ. The manuscript's further exclusion of
analogues that perform the roles is an additional restriction. -/
def WithdrawnMaximallyGreat (conditions : ConditionsAtItems Item)
    (maximallyGreat : Item → Prop) (item : Item) : Prop :=
  Withdrawn conditions item ∧ maximallyGreat item

/-- Concrete-work case of *The Modal Ontological Reductio* (§10.1.1).
The premises make maximal greatness imply personal powers and make
those powers imply concrete work. The conclusion excludes this modeled
description among items satisfying `isWay`. -/
theorem modalOntologicalReductio (conditions : ConditionsAtItems Item)
    (maximallyGreat personalPowers isWay : Item → Prop)
    (greatnessIncludesPersonalPowers : ∀ item, maximallyGreat item → personalPowers item)
    (personalPowersAreConcreteWork : ∀ item, personalPowers item → conditions.concreteWork item) :
    ¬ PossibleDescription isWay (WithdrawnMaximallyGreat conditions maximallyGreat) ∧
      ∀ item, isWay item → ¬ WithdrawnMaximallyGreat conditions maximallyGreat item :=
  withdrawnWorkerImpossible conditions isWay (WithdrawnMaximallyGreat conditions maximallyGreat)
    (fun item ⟨withdrawn, great⟩ =>
      ⟨withdrawn, personalPowersAreConcreteWork item (greatnessIncludesPersonalPowers item great)⟩)

/-- *Aseity Forfeiture* (§11.1). A deity embedded in temporal, relational
and active roles does concrete work, so it depends constitutively on the
conditions and is not their independent ground. -/
theorem aseityForfeiture (conditions : ConditionsAtItems Item)
    (embedded dependsOnConditions independentGround : Item → Prop)
    (embeddedDoesConcreteWork : ∀ item, embedded item → conditions.concreteWork item)
    (incurringIsDependence : ∀ item,
      conditions.temporalAt item ∧ conditions.spatialAt item ∧ conditions.substantialAt item →
        dependsOnConditions item)
    (independenceExcludesDependence :
      ∀ item, independentGround item → ¬ dependsOnConditions item)
    {deity : Item} (isEmbedded : embedded deity) :
    ¬ independentGround deity :=
  fun independent => independenceExcludesDependence deity independent
    (incurringIsDependence deity (concreteWorkIncursConditions (embeddedDoesConcreteWork deity isEmbedded)))

/-- Cases of *No Creator of Nature* (§11.10). The onset clause excludes
a beginning on the premise that its transition is both a change token
and itself withdrawn from the conditions. An absent source state is a
separate claim. The other clauses exclude strict self-grounding and
strict grounding by a member whose existence depends on the conditions. -/
theorem noCreatorOfNature
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (conditions : ConditionsAtItems Item)
    {Fact : Type x} (grounds : Fact → Fact → Prop)
    (strictGroundAsymmetric : ∀ a b, grounds a b → ¬ grounds b a)
    (conditionsObtain : Fact) (existenceOf : Item → Fact)
    (existenceWithinNatureRestsOnConditions :
      ∀ item, WithinNature coverage item → grounds conditionsObtain (existenceOf item))
    (beginsNature : Item → Prop) (onset : Item → Item)
    (beginningRequiresWithdrawnOnset : ∀ item, beginsNature item →
      conditions.changeToken (onset item) ∧ Withdrawn conditions (onset item)) :
    (∀ creator, ¬ beginsNature creator) ∧
    ¬ grounds conditionsObtain conditionsObtain ∧
    (∀ creator, WithinNature coverage creator → ¬ grounds (existenceOf creator) conditionsObtain) := by
  refine ⟨?_, fun selfGround => strictGroundAsymmetric _ _ selfGround selfGround, ?_⟩
  · intro creator begins
    obtain ⟨isChange, withdrawn⟩ := beginningRequiresWithdrawnOnset creator begins
    exact withdrawnIsExempt withdrawn (conditions.changeIncursConditions _ isChange)
  · intro creator within holds
    exact strictGroundAsymmetric _ _ holds (existenceWithinNatureRestsOnConditions creator within)

/-! ## Plurality and individuation (§7.2.3) -/

/-- The individuation input, *What tells things apart is structure*
(§2.4.8): two distinct concrete items are told apart by some real
differentiating structure. -/
structure Individuation (Item : Type w) (real : Item → Prop) where
  concrete : Item → Prop
  differentiates : Item → Item → Item → Prop
  whatTellsApartIsStructure : ∀ x y, concrete x → concrete y → x ≠ y →
    ∃ difference, differentiates difference x y ∧ real difference

/-- A brute count: two items with no real differentiator between them. -/
def BruteCount (real : Item → Prop) (differentiates : Item → Item → Item → Prop)
    (x y : Item) : Prop :=
  x ≠ y ∧ ∀ difference, differentiates difference x y → ¬ real difference

/-- *Isolation is not separation* (§7.2.3). Worlds the modal realist
counts as real and concrete lie within Nature. Any two of them are told
apart by a real difference, which lies within Nature too, and no two are
a brute count. Isolation appears in none of the premises: removing causal
and spatiotemporal connection changes nothing the proof uses. -/
theorem isolationIsNotSeparation
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    (individuation : Individuation Item coverage.real) (isWorld : Item → Prop)
    (worldsAreReal : ∀ world, isWorld world → coverage.real world)
    (worldsAreConcrete : ∀ world, isWorld world → individuation.concrete world) :
    (∀ world, isWorld world → WithinNature coverage world) ∧
    (∀ first second, isWorld first → isWorld second → first ≠ second →
      ∃ difference, individuation.differentiates difference first second ∧
        WithinNature coverage difference) ∧
    (∀ first second, isWorld first → isWorld second →
      ¬ BruteCount coverage.real individuation.differentiates first second) := by
  refine ⟨fun world isW => realIsWithinNature coverage (worldsAreReal world isW), ?_, ?_⟩
  · intro first second isFirst isSecond distinct
    obtain ⟨difference, differs, isReal⟩ := individuation.whatTellsApartIsStructure first second
      (worldsAreConcrete first isFirst) (worldsAreConcrete second isSecond) distinct
    exact ⟨difference, differs, realIsWithinNature coverage isReal⟩
  · intro first second isFirst isSecond ⟨distinct, noRealDifference⟩
    obtain ⟨difference, differs, isReal⟩ := individuation.whatTellsApartIsStructure first second
      (worldsAreConcrete first isFirst) (worldsAreConcrete second isSecond) distinct
    exact noRealDifference difference differs isReal

/-- Countermodel: without the individuation premise, two real worlds can
be a brute count. The third conclusion above needs it; the first does not. -/
example : ∃ (real : Bool → Prop) (differentiates : Bool → Bool → Bool → Prop),
    (∀ world, real world) ∧ BruteCount real differentiates true false := by
  refine ⟨fun _ => True, fun _ _ _ => False, fun _ => trivial, ?_, ?_⟩
  · exact fun same => Bool.noConfusion same
  · exact fun _ differs => False.elim differs

/-! ## Admissibility conditions (§7.2.5) -/

/-- *The Missing Clause* (§7.2.5). Recombination's admissibility
condition is grounded in the natures of real elements, or is a primitive
with determinate constraining work, or makes no further difference from
the structural constraint already identified. On every reading it lies
within Nature, so it supplies no modal source outside Reality or added to
it. -/
theorem missingClause
    (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
    {condition constraint : Item} (groundedIn : Item → Item → Prop)
    (determinateWork noFurtherDifference : Prop)
    (threeReadings : (∃ element, groundedIn condition element ∧ coverage.real element) ∨
      determinateWork ∨ noFurtherDifference)
    (groundedInRealElementsIsTheirStructure :
      ∀ element, groundedIn condition element → coverage.real element → coverage.real condition)
    (determinateWorkIsReal : determinateWork → coverage.real condition)
    (noIndividuatingSurplus : noFurtherDifference → condition = constraint)
    (constraintIsReal : coverage.real constraint) :
    WithinNature coverage condition := by
  rcases threeReadings with ⟨element, grounded, realElement⟩ | works | noDifference
  · exact realIsWithinNature coverage (groundedInRealElementsIsTheirStructure element grounded realElement)
  · exact realIsWithinNature coverage (determinateWorkIsReal works)
  · rw [noIndividuatingSurplus noDifference]
    exact realIsWithinNature coverage constraintIsReal

/-! ## Time does not emerge from non-time (§8.1.2) -/

/-- The inputs of *No Concrete Emergence from Non-Time* (§8.1.2). A
recovery of time is formal or concrete; a formal one generates no
concrete temporal world; a concrete one is a real transformation (Real
Transformation Closure, §3.5); and local transition-capacity cannot
switch on from a state that lacks it (Transition Closure, §3.1.2). -/
structure RecoveryOfTime (Item : Type w) (conditions : ConditionsAtItems Item) where
  formal : Item → Prop
  concrete : Item → Prop
  generatesConcreteTime : Item → Prop
  recoversFrom : Item → Item → Prop
  transitionCapacity : Item → Prop
  completeNonTime : Item → Prop
  formalOrConcrete : ∀ recovery, formal recovery ∨ concrete recovery
  formalGeneratesNoWorld : ∀ recovery, formal recovery → ¬ generatesConcreteTime recovery
  realTransformationClosure : ∀ recovery, concrete recovery → conditions.changeToken recovery
  generatedTimeHasCapacity :
    ∀ recovery, generatesConcreteTime recovery → transitionCapacity recovery
  transitionClosure : ∀ recovery base,
    recoversFrom recovery base → transitionCapacity recovery → transitionCapacity base
  nonTimeLacksCapacity : ∀ base, completeNonTime base → ¬ transitionCapacity base

/-- *No Concrete Emergence from Non-Time* (§8.1.2). Whatever generates a
concrete temporal world is a concrete recovery and incurs T, S and Φ at
the recovery itself; and no such recovery proceeds from the complete
absence of time. -/
theorem noConcreteEmergenceFromNonTime (conditions : ConditionsAtItems Item)
    (recoveries : RecoveryOfTime Item conditions) :
    (∀ recovery, recoveries.generatesConcreteTime recovery →
      recoveries.concrete recovery ∧ conditions.temporalAt recovery ∧
        conditions.spatialAt recovery ∧ conditions.substantialAt recovery) ∧
    ¬ ∃ recovery base, recoveries.recoversFrom recovery base ∧
      recoveries.completeNonTime base ∧ recoveries.generatesConcreteTime recovery := by
  refine ⟨fun recovery generates => ?_, fun ⟨recovery, base, recovers, nonTime, generates⟩ => ?_⟩
  · rcases recoveries.formalOrConcrete recovery with formal | concrete
    · exact absurd generates (recoveries.formalGeneratesNoWorld recovery formal)
    · exact ⟨concrete, conditions.changeIncursConditions recovery
        (recoveries.realTransformationClosure recovery concrete)⟩
  · exact recoveries.nonTimeLacksCapacity base nonTime
      (recoveries.transitionClosure recovery base recovers
        (recoveries.generatedTimeHasCapacity recovery generates))

/-- Countermodel: without Transition Closure, a state with no
transition-capacity can be followed by a recovery that has it. -/
example : ∃ (capacity nonTime : Bool → Prop) (recoversFrom : Bool → Bool → Prop),
    (∀ base, nonTime base → ¬ capacity base) ∧
      recoversFrom true false ∧ nonTime false ∧ capacity true := by
  refine ⟨fun state => state = true, fun state => state = false,
    fun recovery base => recovery = true ∧ base = false, ?_, ⟨rfl, rfl⟩, rfl, rfl⟩
  intro base isNonTime hasCapacity
  exact Bool.noConfusion (isNonTime.symm.trans hasCapacity)

#print axioms realIsWithinNature
#print axioms nothingRealBeyondNature
#print axioms possibleCandidatesLieWithinNature
#print axioms concreteWorkIncursConditions
#print axioms noExemptConcreteAgent
#print axioms withdrawnWorkerImpossible
#print axioms noDivineAddition
#print axioms noUnconditionedEssence
#print axioms noOutsideSelector
#print axioms noSupernature
#print axioms contentlessGodHasNoReferent
#print axioms modalOntologicalReductio
#print axioms aseityForfeiture
#print axioms noCreatorOfNature
#print axioms isolationIsNotSeparation
#print axioms missingClause
#print axioms noConcreteEmergenceFromNonTime

end InversionOfGreatness.NoBeyond
