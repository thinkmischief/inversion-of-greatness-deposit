import InversionOfGreatness.Outside.Attributes

/-!
# Rivals in modality, metaphysics and mind (Chapters 7–9)

Tier B instances of the fork for the rival grounds of Chapters 7–9:
the powers base, Platonic Forms, a grounding mind and a cosmic
substrate. Each uses `Closed` from `Outside/Attributes` or the
item-level conditions from `Outside/NoBeyond`, and adds only its own
per-branch premises.

Left in the manuscript (see `OUTSIDE-MAP.md`): *The Bearer Problem* and
*Being, Not Concreteness* end in a choice of commitments; *Concrete
Relata, Non-Concrete Seam* is diagnostic; *Resumption requires a bearer*
is one premise and its consequence; *Abstraction lands on its base*
would restate its premises as its conclusion.
-/

namespace InversionOfGreatness.Rivals

open InversionOfGreatness NoBeyond Attributes

universe u v w x

variable {Whole : Type u} {Field : Type v} {Item : Type w}
  {nature reality : Whole} {jointComplex : Field}
  (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
  (modality : CandidateModality Item coverage.real) (conditions : ConditionsAtItems Item)

/-- *No Exit for the Powers Base* (§7.2.2). A base offered to ground
change-realizers is functionally equivalent to the conditions, grounds
by concrete work, or grounds without it. Equivalence is the triad under
another description. A manifestation is a becoming, which is concrete
work. Without concrete work the base is structure or Reality's modal
standing, or, given no determinate content, nothing at all. -/
theorem noExitForThePowersBase {base : Item} (equivalent works withoutWork : Prop)
    (threeBranches : equivalent ∨ works ∨ withoutWork)
    (equivalenceIsTheTriad : equivalent → coverage.real base)
    (manifestationIsWork : works → conditions.concreteWork base)
    (withoutWorkIsStructureOrEmpty :
      withoutWork → coverage.real base ∨ ¬ ∃ way, modality.wayOf base way) :
    Closed coverage modality conditions base := by
  rcases threeBranches with branch | branch | branch
  · exact closedOfReal coverage modality conditions (equivalenceIsTheTriad branch)
  · exact closedOfWork coverage modality conditions (manifestationIsWork branch)
  · rcases withoutWorkIsStructureOrEmpty branch with isReal | empty
    · exact closedOfReal coverage modality conditions isReal
    · exact closedOfNoWay coverage modality conditions empty

/-- *The form runs downstream* (§8.1.5). A Form's determinacy is fixed
on the concrete side, which leaves it downstream of what it explains,
or on the abstract side, which is already structured; a mixed account
takes both. Explaining an instance needs a real instantiation relation,
which lies within Nature. So no Form is a structureless source wholly
prior to concrete configuration. -/
theorem formRunsDownstream {relation : Item}
    (concreteFixes abstractFixes whollyPrior structured explainsInstance : Prop)
    (determinacyIsFixed : concreteFixes ∨ abstractFixes)
    (concreteMeansDownstream : concreteFixes → ¬ whollyPrior)
    (abstractMeansStructured : abstractFixes → structured)
    (instantiationIsReal : explainsInstance → coverage.real relation) :
    ¬ (whollyPrior ∧ ¬ structured) ∧ (explainsInstance → WithinNature coverage relation) := by
  refine ⟨fun ⟨prior, unstructured⟩ => ?_,
    fun explains => realIsWithinNature coverage (instantiationIsReal explains)⟩
  rcases determinacyIsFixed with concrete | abstract
  · exact concreteMeansDownstream concrete prior
  · exact unstructured (abstractMeansStructured abstract)

/-- *Conditions on There Being a Mind* (§9.5). A mind that grounds an
experienced world has that experience as its state, encodes it, or keeps
it in being. By the Encoding Dilemma the first two instantiate T, S and
Φ; keeping a distinct experience in being is concrete work. -/
theorem conditionsOnThereBeingAMind {mind : Item} (grounds state encodes sustains : Prop)
    (threeRoles : grounds → state ∨ encodes ∨ sustains)
    (stateRealizerInstantiation : state →
      conditions.temporalAt mind ∧ conditions.spatialAt mind ∧ conditions.substantialAt mind)
    (encodingIsProcessing : encodes →
      conditions.temporalAt mind ∧ conditions.spatialAt mind ∧ conditions.substantialAt mind)
    (sustainingIsWork : sustains → conditions.concreteWork mind) :
    grounds →
      conditions.temporalAt mind ∧ conditions.spatialAt mind ∧ conditions.substantialAt mind := by
  intro isGround
  rcases threeRoles isGround with role | role | role
  · exact stateRealizerInstantiation role
  · exact encodingIsProcessing role
  · exact concreteWorkIncursConditions (sustainingIsWork role)

/-- *The substrate must differentiate too* (§9.5). A substrate that
produces a concrete alter differentiates it from others. If the
producing is a happening, Transition Closure makes the substrate
temporal; if it is timeless constitution, the Encoding Dilemma places
T, S and Φ at the substrate hosting the alter's live states. Either way
the substrate is differentiated and temporal; only the temporality of
the constituting relation itself stays open. -/
theorem substrateMustDifferentiate {substrate : Item}
    (produces happening timelessConstitution differentiates : Prop)
    (producingDifferentiates : produces → differentiates)
    (twoModes : produces → happening ∨ timelessConstitution)
    (transitionClosure : happening → conditions.temporalAt substrate)
    (encodingDilemma : timelessConstitution →
      conditions.temporalAt substrate ∧ conditions.spatialAt substrate ∧
        conditions.substantialAt substrate) :
    produces → differentiates ∧ conditions.temporalAt substrate ∧
      (timelessConstitution →
        conditions.spatialAt substrate ∧ conditions.substantialAt substrate) := by
  intro producing
  refine ⟨producingDifferentiates producing, ?_, fun constitution => (encodingDilemma constitution).2⟩
  rcases twoModes producing with mode | mode
  · exact transitionClosure mode
  · exact (encodingDilemma mode).1

#print axioms noExitForThePowersBase
#print axioms formRunsDownstream
#print axioms conditionsOnThereBeingAMind
#print axioms substrateMustDifferentiate

end InversionOfGreatness.Rivals
