import InversionOfGreatness.Outside.NoBeyond

/-!
# The divine attributes (Chapter 11)

Tier B instances of the fork in `Outside/NoBeyond`. Each Chapter 11
closure asks where a classical attribute could stand. Every branch it
names lands in one of three places: the candidate incurs T, S and Φ, or
it lies within Nature, or it has no determinate way to be and so is not
possible. `Closed` names that three-way outcome. Each instance adds only
its own premise: why each branch lands where the chapter says.

Five Chapter 11 disjunctions are not here: *Timeless or Everlasting*,
*Maximizing leaves no bearer*, *The Eternal-Truths Dilemma*, *The Decree
Trilemma* and *The Immanence Dilemma*. Each shows that no branch keeps
the doctrine's full set of commitments. Their premises carry the whole
result, so Lean would check nothing beyond the case split (see
`OUTSIDE-MAP.md`).
-/

namespace InversionOfGreatness.Attributes

open InversionOfGreatness NoBeyond

universe u v w x

variable {Whole : Type u} {Field : Type v} {Item : Type w}
  {nature reality : Whole} {jointComplex : Field}
  (coverage : RealityNatureCoverage Whole Field Item nature reality jointComplex)
  (modality : CandidateModality Item coverage.real) (conditions : ConditionsAtItems Item)

/-- Where the fork leaves a candidate: incurring T, S and Φ, within
Nature, or not possible. -/
def Closed (candidate : Item) : Prop :=
  (conditions.temporalAt candidate ∧ conditions.spatialAt candidate ∧
      conditions.substantialAt candidate) ∨
    WithinNature coverage candidate ∨ ¬ modality.possible candidate

theorem closedOfWork {candidate : Item} (works : conditions.concreteWork candidate) :
    Closed coverage modality conditions candidate :=
  Or.inl (concreteWorkIncursConditions works)

theorem closedOfReal {candidate : Item} (isReal : coverage.real candidate) :
    Closed coverage modality conditions candidate :=
  Or.inr (Or.inl (realIsWithinNature coverage isReal))

theorem closedOfNoWay {candidate : Item} (noWay : ¬ ∃ way, modality.wayOf candidate way) :
    Closed coverage modality conditions candidate :=
  Or.inr (Or.inr ((possibleCandidatesLieWithinNature coverage modality candidate).2 noWay))

/-- *Unboundedness requires a dimension* (§11.2.3). Read negatively, as
unreceived *esse*, infinity has determinate contrastive content, which
reinstates differentiation, or has no content. Read positively, as an
intrinsic mode, it is seated in an ordering of degree, which concedes
structure. -/
theorem unboundednessRequiresADimension {infinity : Item}
    (negative positive contrastive : Prop)
    (twoReadings : negative ∨ positive)
    (negativeIsContrastOrEmpty :
      negative → contrastive ∨ ¬ ∃ way, modality.wayOf infinity way)
    (contrastReinstatesDifferentiation : contrastive → coverage.real infinity)
    (degreeConcedesStructure : positive → coverage.real infinity) :
    Closed coverage modality conditions infinity := by
  rcases twoReadings with isNegative | isPositive
  · rcases negativeIsContrastOrEmpty isNegative with contrast | empty
    · exact closedOfReal coverage modality conditions (contrastReinstatesDifferentiation contrast)
    · exact closedOfNoWay coverage modality conditions empty
  · exact closedOfReal coverage modality conditions (degreeConcedesStructure isPositive)

/-- *The Discriminating-Content Burden* (§11.2.1), for a proposal that
retains the identities and distinct inferential profiles while supplying
no alternative truth conditions. The no-way consequence of lacking
specifying content in that case is an explicit premise. -/
theorem discriminatingContentBurden {distinction : Item}
    (suppliesContent suppliesAlternativeTruthConditions retainsIdentitiesAndProfiles : Prop)
    (noAlternativeTruthConditions : ¬ suppliesAlternativeTruthConditions)
    (retainsCommitments : retainsIdentitiesAndProfiles)
    (contentConcedesStructure : suppliesContent → coverage.real distinction)
    (noContentNoWay : ¬ suppliesContent → ¬ suppliesAlternativeTruthConditions →
      retainsIdentitiesAndProfiles → ¬ ∃ way, modality.wayOf distinction way) :
    Closed coverage modality conditions distinction := by
  by_cases supplies : suppliesContent
  · exact closedOfReal coverage modality conditions (contentConcedesStructure supplies)
  · exact closedOfNoWay coverage modality conditions
      (noContentNoWay supplies noAlternativeTruthConditions retainsCommitments)

/-- *The Predicate-Content Dilemma* (§11.10). If something answers to
the divine predicates, the subject has a determinate way to be, and every
such way lies within Nature. If nothing answers, the subject is not
possible. No premise beyond *No Divine Addition*'s is needed. -/
theorem predicateContentDilemma (subject : Item) :
    ((∃ way, modality.wayOf subject way) ∧
        ∀ way, modality.wayOf subject way → WithinNature coverage way) ∨
      ¬ modality.possible subject := by
  by_cases answers : ∃ way, modality.wayOf subject way
  · refine Or.inl ⟨answers, fun way isWay => ?_⟩
    exact realIsWithinNature coverage (modality.waysAreReal subject way isWay)
  · exact Or.inr ((possibleCandidatesLieWithinNature coverage modality subject).2 answers)

/-- *The Creation Trilemma* (§11.7.1). Different termini answering to
different divine content admit differentiation; a brute selection that
issues in a created order does concrete work, and one that does none is
structure; with no genuine alternatives, contingent effects collapse. -/
theorem creationTrilemma {selection : Item}
    (differentiated brute noAlternatives contingentEffects : Prop)
    (threeHorns : differentiated ∨ brute ∨ noAlternatives)
    (differentiationIsStructure : differentiated → coverage.real selection)
    (bruteWorksOrIsStructure :
      brute → conditions.concreteWork selection ∨ coverage.real selection)
    (modalCollapse : noAlternatives → ¬ contingentEffects) :
    Closed coverage modality conditions selection ∨ ¬ contingentEffects := by
  rcases threeHorns with isDifferentiated | isBrute | none
  · exact Or.inl (closedOfReal coverage modality conditions (differentiationIsStructure isDifferentiated))
  · rcases bruteWorksOrIsStructure isBrute with works | isReal
    · exact Or.inl (closedOfWork coverage modality conditions works)
    · exact Or.inl (closedOfReal coverage modality conditions isReal)
  · exact Or.inr (modalCollapse none)

/-- *The Creator-Relation Trilemma* (§11.7.2). An external creation makes
creatorhood a real outward relation; a creation within God is a
differentiation in divine reality; a relation real only on the creature's
side either answers with determinate content or withdraws it. -/
theorem creatorRelationTrilemma {relation : Item}
    (external withinGod creatureSideOnly : Prop)
    (threeHorns : external ∨ withinGod ∨ creatureSideOnly)
    (outwardRelationIsReal : external → coverage.real relation)
    (inwardDifferentiationIsReal : withinGod → coverage.real relation)
    (creatureSideAnswersOrIsEmpty :
      creatureSideOnly → coverage.real relation ∨ ¬ ∃ way, modality.wayOf relation way) :
    Closed coverage modality conditions relation := by
  rcases threeHorns with isExternal | isWithin | isCreatureSide
  · exact closedOfReal coverage modality conditions (outwardRelationIsReal isExternal)
  · exact closedOfReal coverage modality conditions (inwardDifferentiationIsReal isWithin)
  · rcases creatureSideAnswersOrIsEmpty isCreatureSide with isReal | empty
    · exact closedOfReal coverage modality conditions isReal
    · exact closedOfNoWay coverage modality conditions empty

/-- *Omniscience is reflexive* (§11.4.2). If God knows every truth, the
truth that God knows every truth is among them, so God knows it; knowing
that requires articulation among knower, known, knowing and fit. Step 2
is derived from what that truth says, not assumed. -/
theorem omniscienceIsReflexive {Truth : Type x} (isTrue knows : Truth → Prop)
    (omniscient articulated : Prop) (knowsEveryTruth : Truth)
    (whatItSays : isTrue knowsEveryTruth ↔ ∀ truth, isTrue truth → knows truth)
    (omniscienceKnowsAll : omniscient → ∀ truth, isTrue truth → knows truth)
    (reflexiveKnowingNeedsArticulation : knows knowsEveryTruth → articulated) :
    omniscient → articulated := fun isOmniscient =>
  have isTrueThatItKnows := whatItSays.mpr (omniscienceKnowsAll isOmniscient)
  reflexiveKnowingNeedsArticulation (omniscienceKnowsAll isOmniscient _ isTrueThatItKnows)

/-- *The Present Trilemma* (§11.8.1). Present in some places only is not
everywhere; present everywhere is present at positions, which is
spatiality at that presence (Relational Distinctness); present nowhere
is no longer presence. No branch yields a God everywhere and outside
space. -/
theorem presentTrilemma {god : Item}
    (somewhereOnly everywhere nowhere omnipresent : Prop)
    (threeHorns : somewhereOnly ∨ everywhere ∨ nowhere)
    (somewhereIsNotEverywhere : somewhereOnly → ¬ omnipresent)
    (everywhereIsAtPositions : everywhere → conditions.spatialAt god)
    (nowhereIsNotPresence : nowhere → ¬ omnipresent) :
    ¬ (omnipresent ∧ ¬ conditions.spatialAt god) := by
  rintro ⟨isOmnipresent, outsideSpace⟩
  rcases threeHorns with some | every | none
  · exact somewhereIsNotEverywhere some isOmnipresent
  · exact outsideSpace (everywhereIsAtPositions every)
  · exact nowhereIsNotPresence none isOmnipresent

#print axioms unboundednessRequiresADimension
#print axioms discriminatingContentBurden
#print axioms predicateContentDilemma
#print axioms creationTrilemma
#print axioms creatorRelationTrilemma
#print axioms omniscienceIsReflexive
#print axioms presentTrilemma

end InversionOfGreatness.Attributes
