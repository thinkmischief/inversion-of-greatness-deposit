import Lake
open Lake DSL

package «inversion-of-greatness» where

-- Pinned to match `lean-toolchain` (Lean 4.8.0).
require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.8.0"

@[default_target]
lean_lib InversionOfGreatness where
