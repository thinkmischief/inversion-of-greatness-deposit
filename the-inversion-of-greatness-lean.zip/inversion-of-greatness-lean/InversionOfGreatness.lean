import InversionOfGreatness.Basic
import InversionOfGreatness.Inside.Necessity
import InversionOfGreatness.Inside.Identity
import InversionOfGreatness.Inside.WholeLine
import InversionOfGreatness.Inside.NullState
import InversionOfGreatness.Inside.Cycle.PhaseClosure
import InversionOfGreatness.Inside.Cycle.DominanceCrossing
import InversionOfGreatness.Inside.Cycle.Bridge
import InversionOfGreatness.Outside.Modal
import InversionOfGreatness.Outside.NoBeyond
import InversionOfGreatness.Outside.Attributes
import InversionOfGreatness.Outside.ClassicalGrounds
import InversionOfGreatness.Outside.Rivals
import InversionOfGreatness.Capstone
import InversionOfGreatness.Formal.CrossingAmbiguity

/-!
# The Inversion of Greatness, in Lean

Root of the project. Building this file checks every module.

* `Basic`: the shared vocabulary.
* `Inside`: Chapters 1–4, Nature closed off from the inside.
* `Outside`: Chapters 7–12, Nature closed against anything outside it.
  `Modal` and `NoBeyond` cover the 15 spine results; `Attributes`,
  `ClassicalGrounds` and `Rivals` hold the Tier B instances for Chapters 7–11 (see `OUTSIDE-MAP.md`).
* `Capstone`: combines Appendix B line 14 with selected outside results
  using shared Reality–Nature identity and coverage premises.

The philosophical premises enter as named hypotheses. `PREMISES.md`
maps each one to its manuscript source and its status.
-/
