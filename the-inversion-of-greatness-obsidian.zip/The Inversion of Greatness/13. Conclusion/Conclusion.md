Something about reality makes reading this possible.

Each word arrives after another. Each keeps its place beside the rest. The words the book opened with still hold there, and in your mind.

No author outside the world has to supply those conditions. They belong to reality itself—not as three ornaments hung on an otherwise empty frame, but as what lets anything occur, differ, endure, or pass into anything else. The world after that recognition is the world before it. What changes is where its depth is located.

The creator-oriented traditions examined here were not foolish to reach upward. They began from things that are real. Effects depend on what sustains them. Some things can’t be otherwise. Obligation reaches beyond preference. A finite life can be harmed, can know it’s exposed, and can need more than it can provide alone. Meaning can exceed any one person’s grasp. None of those discoveries becomes empty when its answer is no longer placed above the world.

But they aren’t one discovery either. The cosmological search for what carries dependence, the ontological search for what can’t fail, the moral search for what binds vulnerable lives, and the mystical pressure against the limits of the self ask different questions. The lineages that carried them don’t secretly teach one doctrine. Their differences can’t be dissolved into a family resemblance broad enough to mean nothing. What they share is narrower: each encountered a real demand and placed its final answer in a personal source beyond Nature. The inversion keeps the demand and changes the address.

That change costs something. Giving old words new objects doesn’t preserve providence, final judgment, personal survival, or rescue by a power that can’t fail. Where their own reasons don’t establish them, they remain unestablished. It would be dishonest to call that no loss.

What has already been loved, understood, made, or given isn’t among those losses. Meaning realized here doesn’t wait for another mind to certify it. A life that alters another life has altered reality. Work that opens a possibility for someone else remains part of what they can do. A person can continue in memory, practice, relationship, and institutions without the same first-person life continuing after death. That is less than an afterlife. It is more than nothing.

There’s one thing left that a reader may fear losing, and it isn’t merely an explanation. A cause considered in abstraction rarely carries the grief. What can feel endangered is the sense that something is invested in them.

Wanting that is real. It isn’t foolishness smuggled into philosophy, and it isn’t weakness waiting to be corrected. A creature who can be hurt, who knows the hurt may come, and who sees the same exposure in others has reason to want what no isolated creature can provide: to be held by something larger than one life. The wanting doesn’t prove that a mind above Nature is doing the holding. It reveals why a world of vulnerable lives must learn to do it.

The older placement answered that need from above. Holding begins beside us: people can remember what another person has forgotten, grow food another person can’t grow, keep watch while another sleeps, carry knowledge across a death, and build protections no private kindness could maintain. These aren’t substitutes for being held. They are what being held looks like when those doing the holding are visible.

Nature alone.

The phrase removes the external maker; it doesn’t remove dependence. No one made the world for us, and no one lives in it alone. Every person arrives inside conditions they didn’t choose, sustained by work they didn’t perform and exposed to failures they can’t repair by themselves. The imagined author is gone. The need for one another is not.

Necessity by itself doesn’t decide how people should live together. The political turn needs further premises: vulnerable lives have equal standing, that standing must be exercisable rather than merely declared, and the public must carry the duties private action can’t. If those premises hold, care can’t remain a grace scattered among fortunate recipients. It has to take material form—in a roof, food, clean water, health care, safety, education, and a real say in the decisions that govern a life.

Reciprocity begins only after those conditions are present. Ask a person to carry others while no one maintains their roof, care, safety, or voice, and the demand isn’t mutuality. It is another extraction. Their claim comes first. No one can make what they are owed conditional on gratitude for an arrangement that isn’t carrying them.

For those already held by the shared order, the question turns. Other people keep the water safe, the food available, the roads passable, the knowledge alive, and the institutions answerable. They are already holding you. On what ground does anyone decline to help carry the people already carrying them? Self-interest reaches part of the way: a person has a stake in the conditions their own life needs. Recognition carries farther. A life beyond one’s immediate dependence is still a life that can be exposed or held.

Institutions matter because attention has limits. No person can know everyone who needs care or personally maintain every condition on which their neighbors depend. Institutions let strangers hold one another across distance and time. But an institution is an instrument, not an object of loyalty in its own right. It earns support by carrying people and loses that claim when it protects itself instead. The same is true of parties, nations, doctrines, and ideas—including this one.

People don’t need to settle every question about God before they can build those conditions together. Belief can remain, practice can remain, and communities can remain wherever their own reasons sustain them. Political life doesn’t need to govern conviction. It needs to notice who is held and who is left exposed. Roof, food, care, safety, and a say aren’t mysteries of interpretation. People provide them and withhold them, damage them and repair them, and share them with each other.

Maximum Possibility isn’t a promise that every desire will be met or every option kept open, and it isn’t a mechanism. It names a striving people already have—for more room to act—and says where that striving has to go: widening each person’s real room without buying that room by closing someone else’s. The rest is a hypothesis about which arrangements can carry it. No power above Nature will do that work for us.

Removing the maker changes the burden. No will above us is going to choose the next arrangement, correct the institution that has stopped carrying people, or open the possibility that neglect has closed. That can sound like abandonment only while agency is imagined as something handed down. Once the hand above is gone, unfinished possibility returns to the people already here.

No author stands beyond the page to write the next line for us. Someone still has to build the roof. Someone has to grow the food and share it. Someone has to treat the wound, keep the frightened person safe, and give the unheard person a say. Possibilities don’t become actual because they are available. People make them actual for one another.

The world isn’t newly ours. It’s ours anew.


---

← [12.8 No Exit](../12.%20Exodus/12.8%20No%20Exit.md) | [Acknowledgments](../15.%20Back%20Matter/Acknowledgments.md) →
