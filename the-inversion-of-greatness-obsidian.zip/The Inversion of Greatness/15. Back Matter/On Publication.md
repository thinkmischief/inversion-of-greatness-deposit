Why online? And why free? If the argument here succeeds, it doesn’t belong behind a paywall or institutional gate. This isn’t a stance against being paid for work. It’s a commitment to accessibility. No funding, grant, institution, or advance was received in the book’s making; all costs were my own.

The other reason comes down to personal freedom. Without a house style to negotiate with, the book could be written the way I think, and at my own pace.

A print edition will arrive in time, pending public review, interest, revisions, and finances. What’s here for free stays up.


---

← [ The Constraints](The%20Constraints.md) | [Symbols](Symbols.md) →
