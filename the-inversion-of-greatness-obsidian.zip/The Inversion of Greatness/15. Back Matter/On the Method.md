*A positive derivation, not a comparison of theories.* A great deal of metaphysics works by weighing rival views against each other—whether by parsimony or explanatory power—and is won on the balance of theoretical virtue. The deductive spine instead starts from something that cannot be coherently denied and follows what that requires. What follows is not all deduction. Each later identification or empirical extension goes only as far as its argument earns. Rival accounts are engaged as objections and tests, not as premises of the derivation.

*The S5 framework is grounded, not assumed.* Arguments that reach for a necessary being have often helped themselves to S5 without grounding it. The derivation grounds it, then puts it to work. The foundation is at [§2.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md). The rest of the book is what that foundation produces.


← [Author’s Notes](Author%E2%80%99s%20Notes.md) | [ On the Use of AI](On%20the%20Use%20of%20AI.md) →
