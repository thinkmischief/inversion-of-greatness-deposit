The notation used throughout the argument, collected for reference. The sections before **Scoped notation** are the **canonical legend**: symbols a reader may carry from one section to another. The scoped section records stable, readable forms confined to particular arguments.

Each symbol is defined in full where it’s introduced; the italic tag at the end of an entry points to the section where it first appears. Established logical, mathematical, and physical notation takes priority: the book introduces no private glyph where a standard sign already does the work. Book-defined single-letter constants are upright; schematic variables are italic; named operators, predicates, and multi-letter mnemonic propositions are upright. Bold is reserved for conventional system names and imported temporal operators. A numeric subscript picks out one specific member of the family its base letter names: $w_0$ is one particular configuration among the $w$, $t_0$ one particular moment, and $\mathrm{CG}_0$ one particular stipulated description rather than classical theism at large.

## Logical and modal notation

**$\Box$** · *Necessity operator* · $\Box P$ means Reality lacks the capacity for $P$’s failure, $\neg\operatorname{Capacity}(\mathrm{R},\neg P)$; equivalently, $P$ holds in every configuration Reality permits. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$\Diamond$** · *Possibility operator* · $\Diamond P$ means Reality has the capacity for $P$, $\operatorname{Capacity}(\mathrm{R},P)$; equivalently, $P$ holds in some configuration Reality permits. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$\land\ \lor\ \neg\ \to\ \leftrightarrow$** · *Logical connectives* · Conjunction, disjunction, negation, material conditional, biconditional.

**$\forall\ \exists$** · *Quantifiers* · $\forall$ is the universal quantifier, read *for all*; $\exists$ is the existential quantifier, read *there exists*.

**$\top$** · *Logical truth* · Any logical truth, used to witness that the possible pole is non-empty. *First use: [§2.1.3](../2.%20The%20Argument/2.1.3%20Modal%20Constitution.md).*

**$\bot$** · *Contradiction* · Any contradiction, used to witness that the impossible pole is non-empty. *First use: [§2.1.3](../2.%20The%20Argument/2.1.3%20Modal%20Constitution.md).*

**$\therefore$** · *Therefore* · Reserved for the conclusion lines of formal syllogisms.

**$=_{\mathrm{df}}$** · *Defined as* · Introduces a stipulative definition.

**$\equiv$** · *Logically equivalent* · Marks interdefinable formulas in the modal-logic primer; unlike $=_{\mathrm{df}}$, it doesn’t introduce a stipulative definition. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*

**$\models$** · *Semantic consequence* · $M\models Q$ says that every admissible realization of the profile $M$ satisfies $Q$. Here $M$ names a profile, a class of structures fixed by its elements and relations, so the sign is used for consequence over that class, as in $T\models Q$ for a theory, not for satisfaction by one model. It is not a further modal operator. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*

## Variables

**$P, Q$** · *Propositional variables* · Schematic propositional variables, ranging over contentful claims. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$M$** · *Model or profile variable* · A schematic mathematical or physical-mathematical profile. Italic $M$ follows the ordinary model-theoretic convention and is distinct from upright $\mathrm{M}$, the book’s fixed symbol for Movement. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*

**$L$** · *Law-profile variable* · A schematic independently specified physical law-profile in a conditional such as $\Box\forall x(\operatorname{Realizes}(x,L)\to Q(x))$. It is a local variable, not a proposition or a second necessity operator. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*

**$p$** · *Contingent-configuration variable* · A propositional variable ranging over claims about which contingent configuration is occupied. Lowercase $p$ is the scoped variable used in *Necessity Permits Contingency*, not a second book-wide propositional-variable convention. *First use: [§2.9.4](../2.%20The%20Argument/2.9.4%20Necessity%20Precedes%20Contingency.md).*

**$x, y, z$** · *Individual variables* · Variables ranging over individuals or relata. In a locally defined predicate such as $\operatorname{Grounds}(x,y)$, the arguments are variables even when the predicate name has a separate fixed use elsewhere.

**$g$** · *Ground-candidate variable* · A proposed additional ground of Nature or concrete actuality, bound fresh in each argument that tests a candidate ground. *First use: [§2.8](../2.%20The%20Argument/2.8%20Reality%E2%80%93Nature%20Identity.md).*

**$t$** · *Temporal index variable* · A time or temporal evaluation point within a locally indexed argument. *First use: [§2.7.2](../2.%20The%20Argument/2.7.2%20Incoherence%20of%20%E2%88%85.md).*

**$w, w’, w_0, w_1, w_2$** · *Possible-world representation variables* · These belong to the standard or rival semantic apparatus and represent complete configurations $\mathrm{R}$ could be claimed to admit; they don’t denote plural Realities. $w$ is generic; $w_0$ is the candidate representation posited to lack the structural conditions in [§2.7.4](../2.%20The%20Argument/2.7.4%20Preclusion%20Boundary.md); $w_1, w_2, \ldots$ enumerate representations. *First use: [§2.1.5](../2.%20The%20Argument/2.1.5%20The%20S5%20Bottleneck.md).*

## The Conditions

The book uses related structural vocabularies at different levels of resolution. The two symbolic columns come first; the prose columns then give the role disclosed by change and the condition’s name as borne in Reality. The rows mark corresponding role-families, not identities or automatic entailments. In particular, the generic Chapter 3 roles $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ don’t by themselves establish the fully specified conditions $\mathrm{T}$, $\mathrm{S}$, and $\Phi$.

| Modal-core Condition | Generic role-floor | Role disclosed by Change | Condition as borne in Reality |
| --- | --- | --- | --- |
| $\mathrm{T}$ · Temporality | $\mathrm{O}$ · directed order | Succession | Time |
| $\mathrm{S}$ · Spatiality | $\mathrm{D}$ · determinate difference | Distinction | Space |
| $\Phi$ · Substantiality | $\mathrm{B}$ · bearing or realization | Exchange | Substance |

### Modal-core Conditions

**$\mathrm{T}$** · *Temporality* · The condition of Reality’s modal constitution that permits ordered succession (asymmetric, transitive) and precludes self-reversing order; directionality belongs to the realization tier. Its necessity, $\Box\mathrm{T}$, is earned in [§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md). *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\mathrm{S}$** · *Spatiality* · The condition of Reality’s modal constitution that permits positional distinction across a crossable interval and precludes positional collapse ($\mathrm{SC}$). Bare difference is $\mathrm{D}$, not $\mathrm{S}$. Its necessity, $\Box\mathrm{S}$, is earned in [§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md). *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\Phi$** · *Substantiality* · The condition of Reality’s modal constitution that permits bearing across transition and precludes unborne exchange. Its necessity, $\Box\Phi$, is earned in [§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md). Because the glyph is stipulated, the chapters avoid lowercase Greek for schematic formulas: propositions are $\mathrm{P}$ and $\mathrm{Q}$, so that $\varphi$ is never set beside $\Phi$ where only case would tell them apart. Six such uses in [§2.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md) were converted to $\mathrm{P}$ on 2026-08-27. Unlike $\mathrm{T}$ and $\mathrm{S}$, the glyph is stipulated rather than mnemonic: it was fixed when the condition was named *Physicality* and is retained across the rename so that every formula in print keeps its reference. *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\mathrm{T}(x),\ \mathrm{S}(x),\ \Phi(x)$** · *Predicate form* · Applied to an individual $x$, each says that $x$ instantiates the corresponding condition.

**$\operatorname{Concrete}(x)$** · *Existence predicate* · $\operatorname{Concrete}(x) =_{\mathrm{df}} \mathrm{T}(x) \land \mathrm{S}(x) \land \Phi(x)$. To exist is to instantiate all three conditions; *concrete* marks no second kind of existence. This replaces the private notation $\operatorname{Exists}^{\mathrm{c}}(x)$: the superscript $\mathrm{c}$ was a local qualifier, not a standard operator. Quantification over numbers, sets, and propositions is read as talk about structure, not about further existents, and isn’t represented by this predicate. *First use: [§1.5](../1.%20Groundwork/1.5%20Existence.md).*

### Generic role-floor

The *Notation* paragraph in [§2.2](../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md) introduces $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ together; the derivation in [§3.2](../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20The%20Floor%20Beneath%20It.md) establishes them and uses them throughout.

**$\mathrm{O}$** · *Directed order* · The generic role of asymmetric ordering. It isn’t yet temporality: $\mathrm{O}$ is directed order, not temporal succession.

**$\mathrm{D}$** · *Determinate difference* · The generic role of distinctness. It isn’t yet spatiality: $\mathrm{D}$ is difference, not concrete relational exteriority.

**$\mathrm{X}$** · *Variable over the Conditions* · A bound variable ranging over the conditions themselves, $\mathrm{X} \in \{\mathrm{T}, \mathrm{S}, \Phi\}$, used where a claim holds for each and is stated once. It isn’t one of the generic roles: those are $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ above, which are thinner than the conditions, whereas $\mathrm{X}$ takes the conditions as its values. *Used at: [§2.1.5](../2.%20The%20Argument/2.1.5%20The%20S5%20Bottleneck.md) (Parasitic Negation, Negation Seal); [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) (Triconditional Closure).* The letter was chosen in 2026-08-30 to replace an earlier use of $\mathrm{D}$ in this role, which collided with the generic-difference $\mathrm{D}$ and inverted its sense—the role stands *against* spatiality while the variable *includes* it.

**$\mathrm{B}$** · *Bearing or realization* · The generic role of carrying a fact, act, state, or arrangement. It isn’t yet substantiality: $\mathrm{B}$ is bearing, not persistence across a transition.

## Structural notation

**$\mathrm{R}$** · *Reality* · The whole within which any thing is a thing, identified with Nature in $\mathrm{N} = \mathrm{R}$. The necessity established by the completed line attaches explicitly to Reality’s T ∧ S ∧ Φ constitution. *First use: [§1.1](../1.%20Groundwork/1.1%20Reality.md).*

**$\operatorname{Capacity}(\mathrm{R},P)$** · *Capacity relation* · Reality has the standing capacity for $P$ to obtain. Thus $\Diamond P$ means $\operatorname{Capacity}(\mathrm{R},P)$, while $\Box P$ means $\neg\operatorname{Capacity}(\mathrm{R},\neg P)$. *First use: [§1.2.1](../1.%20Groundwork/1.2.1%20Possibility.md).*

**$\operatorname{Range}(\mathrm{R})$** · *Complete admissible range* · The set of propositions Reality has the capacity to admit: $\operatorname{Range}(\mathrm{R}) =_{\mathrm{df}} \{P \mid \operatorname{Capacity}(\mathrm{R},P)\}$. Possible-world variables represent members or arrangements within this range; they don’t denote plural Realities or ground the range. *First use: [§1.2.1](../1.%20Groundwork/1.2.1%20Possibility.md).*

**$\mathrm{C}$** · *Change* · The kind of transition of which the concrete transition witnessed in reading, doubting, and recognizing the doubt is a token, fixed at minimum resolution as *one state, then another*. Reflection is evidential, not part of its intension. Formal $\mathrm{C}$ retains that referent at book scope; it doesn’t denote maximally thin generic succession. *First use: [§1.3](../1.%20Groundwork/1.3%20Change.md).*

**$\mathrm{N}$** · *Nature* · The name of the joint structural complex of $\mathrm{T}$, $\mathrm{S}$, and $\Phi$. Because $\mathrm{N}$ names a structure rather than a proposition, the book states that definitional identity in prose; $\mathrm{N} = \mathrm{R}$ states the later Reality–Nature Identity. The necessity $\Box(\mathrm{T} \land \mathrm{S} \land \Phi)$ is the separately earned Triconditional Necessity ([§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md)). *First use: [§1.4.4](../1.%20Groundwork/1.4.4%20Triconditional%20Structure.md).*

**$\mathrm{M}$** · *Movement* · Change of position: one thing at a position and afterwards at another, having crossed what lay between. A species of $\mathrm{C}$, so $\Diamond\mathrm{M}$ entails $\Diamond\mathrm{C}$. Its containment of $\mathrm{T}$, $\mathrm{S}$, and $\Phi$ is constitutive rather than inferred, which is what lets *From Movement* spend none of the three constitutive premises. *First use: [§2.4.7](../2.%20The%20Argument/2.4.7%20Distinction%20Requires%20Spatiality.md).*

**$\varnothing$** · *Null State* · At modal-core resolution, the joint absence of $\mathrm{T}$, $\mathrm{S}$, and $\Phi$, excluded by $\Box(\mathrm{T} \land \mathrm{S} \land \Phi)$. Read as absolute nothingness, the absence of every fact, it fails worldhood outright; that the modal-core absence is also the absence of every fact holds only given the no-free-standing-residue thesis ([§2.7.4](../2.%20The%20Argument/2.7.4%20Preclusion%20Boundary.md)). *First use: [§2.7.1](../2.%20The%20Argument/2.7.1%20Null%20State%20%28%E2%88%85%29.md).*

**$\mathrm{Con}$** · *Convergence proposition* · Some separated physical trajectories reduce their separation and enter a common region or phase. Paired with $\mathrm{Div}$ in the Bidirectional Modal Capacity theorem: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. The modal operators have global scope; the embedded proposition remains minimal convergence and doesn’t abbreviate total cosmic reconvergence. *First use: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

**$\mathrm{Div}$** · *Divergence proposition* · Some separated physical trajectories increase their separation. Paired with $\mathrm{Con}$ in the Bidirectional Modal Capacity theorem: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. *First use: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

**$\mathrm{Con}^{>}_U,\ \mathrm{Div}^{>}_U$** · *Totality-scale dominance propositions* · $\mathrm{Con}^{>}_U$ says convergence dominates expansion at the scale of the total universe; $\mathrm{Div}^{>}_U$ says expansion dominates convergence there. The superscript marks dominance and the subscript marks totality scale. In Dominance-Scale Bidirectional Capacity, the conditional witness to the contraction before the bounce and observed expansion yield $\Box\Diamond\mathrm{Con}^{>}_U\land\Box\Diamond\mathrm{Div}^{>}_U$. Neither proposition is interchangeable with the minimal local $\mathrm{Con}$ or $\mathrm{Div}$ above. *First use: [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).*

**$H(t),\ A(t),\ t_0,\ t_1,\ t_*,\ \varepsilon$** · *Dominance-crossing notation* · $H(t)$ is the totality-scale expansion rate: positive in expansion, zero at turnaround, and negative in contraction. $A(t)=-\dot H(t)$ is its net contraction-directed change, not gravity alone. In Integrated Dominance Crossing, $t_0$ begins the evaluated expansion interval, $t_1$ is a finite point by which integrated reduction exceeds $H(t_0)$, and $t_*$ is the intervening zero-crossing. A persistent floor $A\geq\varepsilon>0$ is a stronger sufficient condition. *First use: [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).*

## Scoped notation

These forms have a stable, readable job within the indicated argument but aren’t book-wide metaphysical constants.

**$\operatorname{Acc}(x,y)$, $\operatorname{Reach}(x,P)$** · *Accessibility relation; reachability predicate* · In the locally introduced rival semantics, $\operatorname{Acc}(x,y)$ says that $y$ is accessible from $x$, and $\operatorname{Reach}(x,P) =_{\mathrm{df}} \exists y(\operatorname{Acc}(x,y) \land P(y))$. These are readable names for the rival apparatus; neither belongs to the book’s capacity-based ground of modality. *First use: [§2.1.4](../2.%20The%20Argument/2.1.4%20Modal%20Stability.md).*

**$\mathrm{SC}$** · *Square-circle proposition* · Two complete, incompatible configurations at one position in the same respect ([§2.4.9](../2.%20The%20Argument/2.4.9%20Forward%20Conditional%20Necessity.md)); its familiar metric instance, used in [§2.1.10](../2.%20The%20Argument/2.1.10%20Necessary%20Possibility.md), is one figure square and circular in the same respect at the same boundary. Its invariant exclusion, $\neg\Diamond\mathrm{SC} \to \Box\neg\Diamond\mathrm{SC}$, supplies the spatial example of the negative modal arm. *First use: [§2.1.10](../2.%20The%20Argument/2.1.10%20Necessary%20Possibility.md).*

**$\operatorname{Begin}(x)$, $\operatorname{Place}(x)$, $\operatorname{Produce}(x)$** · *Onset predicates* · Respectively: $x$ begins, $x$ is placed, and $x$ is produced. They occur only in the three Parasitic-Negation reductios and remain distinct because they carry distinct warrants. *First use: [§2.4.6](../2.%20The%20Argument/2.4.6%20Succession%20Requires%20Temporality.md).*

**$\operatorname{Past}(\varnothing)$** · *Past-null proposition* · The Null State $\varnothing$ obtained at some past time $t$. The temporal reductio concludes $\neg\operatorname{Past}(\varnothing)$. *First use: [§2.7.2](../2.%20The%20Argument/2.7.2%20Incoherence%20of%20%E2%88%85.md).*

**$\operatorname{Grounds}(x,y)$** · *Grounding relation* · A locally introduced two-place predicate saying that $x$ grounds $y$. *First use: [§3.1](../3.%20Convergence/3.1%20Necessary%20Possibility%20of%20Change%20-%20Stress-Tested.md).*

**$\operatorname{Realizes}(x,M)$** · *Realization predicate* · The concrete system or configuration $x$ instantiates the elements or positions of profile $M$ and preserves the relations relevant to the stated consequence. The named predicate is used because no single standard logical glyph expresses physical realization; its typography follows the standard convention for multi-letter predicates. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*

**$M_{\Delta}, I, X, \gamma$** · *Transformation-profile notation* · $M_{\Delta}$ is the locally defined non-trivial transformation profile; $I$ is its ordered index set, $X$ its state space, and $\gamma:I\to X$ the map assigning states to indices. The symbols retain their standard schematic mathematical roles. Italic $X$ is a state-space variable and is distinct from upright $\mathrm{X}$, the book’s variable over the conditions. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*

**$\mathrm{MGB}$** · *Maximally-great-being proposition* · The proposition that a maximally great being is instantiated in Plantinga’s modal ontological argument. S5 validates $\Diamond\Box\mathrm{MGB} \to \Box\mathrm{MGB}$ without supplying the possibility premise. *First use: [§2.1.9](../2.%20The%20Argument/2.1.9%20What%20Necessity%20Transfer%20Needs.md).*

**$\mathrm{MGB}_0$** · *Maximally-great-being description, as classically specified* · $\mathrm{MGB}$ conjoined with necessary maximal excellence, concrete personal powers, and denial of $\mathrm{T}$, $\mathrm{S}$, and $\Phi$ together with every determinate analogue that could perform their roles. The Modal Ontological Reductio establishes $\Box\neg\mathrm{MGB}_0$ for that conjunction only; Plantinga’s thinner maximal-greatness predicate is untouched by it. *First use: [§10.1.1](../10.%20Rival%20Ultimates/10.1.1%20The%20Modal%20Ontological%20Argument.md).*

**$\mathrm{CG}_0$** · *Contentless-God description* · The stipulated description that combines atemporality, aspatiality, and denial of any bearer-role with determinate active-ground predicates while refusing every thinner or analogical truth-condition for them. The Contentless God Has No Referent establishes $\Box\neg\mathrm{CG}_0$ for that description only. *First use: [§11.10](../11.%20Reclaiming%20Greatness/11.10%20What%20Remains%20of%20God.md).*

**$\mathrm{Resolution}$** · *Resolution proposition* · The proposition that a history or mechanism preserves $\mathrm{T} \land \mathrm{S} \land \Phi$ through a would-be classical singular boundary. Necessary Resolution Possibility is $\Diamond\mathrm{Resolution} \to \Box\Diamond\mathrm{Resolution}$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6.3%20Predictions.md).*

**$A$** · *Aggregation proposition* · Gravitational aggregation: matter converges into bound systems under mutual attraction. As a locally bound propositional letter it remains italic: $A \to \Diamond A \to \Box\Diamond A$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6.3%20Predictions.md).*

**Bounce, expansion, contraction** · *Cycle phases (standard cosmology terms, no symbols)* · The three phases of the cycle in [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md), named as cosmology names them: *expansion* (the expansion-dominant phase, Hubble rate $H>0$), *contraction* (the compression-dominant return, $H<0$), and the *bounce* (the maximal-compression boundary at which contraction turns into expansion). In Conditional Phase Recurrence a *bounce class* is a dynamically complete maximal-compression phase-class. The cycle runs bounce → expansion → contraction → bounce. Earlier drafts wrote these $K$, $E$ and $C$; the words replace them so that $\mathbf{K}$ names only the modal logic and $C$ only change. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6.3%20Predictions.md).*

**$\langle p_n\rangle,\ \mathcal{P},\ f,\ i,\ j,\ r,\ m,\ N,\ q$** · *Autonomous phase-dynamics notation* · $\langle p_n\rangle$ is a macro-phase history, $\mathcal{P}$ its phase-type set, and $f:\mathcal{P}\to \mathcal{P}$ the time-independent successor function satisfying $p_{n+1}=f(p_n)$. In Repeated-Phase Propagation, $p_i=p_j$ for $i<j$ entails $p_{i+r}=p_{j+r}$ for every $r\geq0$, with period $m=j-i$. In Finite-Past-Depth Recurrence, $N=|\mathcal{P}|$ and $q$ indexes the target phase. The specialization $\langle p_n\rangle_{n\in\mathbb Z}$ marks the two-sided history used by Bi-Infinite Autonomous Phase Recurrence. These are local mathematical variables; $F$ elsewhere denotes force, and $\mathbf{F}$ the temporal operator. *First use: [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).*

**$\Gamma,\ \phi,\ \sim,\ [x]$** · *Physical-state quotient notation* · $\Gamma$ is the complete physical state space, $\phi:\Gamma\to\Gamma$ its one-step evolution, $\sim$ the equivalence relation grouping complete states into phase-types, and $[x]$ the phase-class of $x$. The induced phase map $f([x])=[\phi(x)]$ is well-defined when $\sim$ is a forward dynamical congruence. If the induced $f$ is also injective on finite $\mathcal{P}=\Gamma/{\sim}$, Finite Reversible Phase Closure makes it a permutation. *First use: [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).*

**$M_{\mathrm{phase}}$** · *Autonomous physical phase-profile* · Whichever complete phase-level autonomous profile is used to apply Invariant Realization and Strict Actualization to a recurrence result: a finite injective phase map, an actual repeated complete phase, a finite profile with sufficient past depth, or the bi-infinite finite profile. The transfer establishes the conditional consequence of realizing the profile; it doesn’t establish that the universe realizes it. *First use: [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).*

**$\mathrm{Sustain}$** · *Gradient-sustaining phase-type* · In Phase Recurrence Without Token Recurrence, $\mathrm{Sustain}$ names a bounded totality-scale functional phase-class in which usable gradients sufficient for macroscopic productivity are maintained or renewed. It may recur after depletion or remain continuously occupied in a nonequilibrium steady regime. The symbol fixes a functional phase-type, not a repeated token configuration or a return to the bounce. Introduced in [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).

**Low-entropy bounce** · *Phase type (words, no new symbol)* · In The Cycle, a low-entropy bounce is the dense, nearly smooth compressed phase from which the present expansion proceeded, together with its passage into expansion. It is more specific than $\mathrm{Sustain}$: recurrent gradient-sustaining productivity entails recurrent low-entropy bounces only through the physical return-to-bounce bridge and a recurring Past Hypothesis. Introduced in [§4.6.5](../4.%20Nature%20Alone/4.6.5%20Conclusions.md).

## Conventional notation in local examples

These symbols retain established meanings within the indicated technical example. They aren’t additional book-wide metaphysical constants.

**@** · *Actual world* · The actual world, the point from which other worlds are surveyed in a modal model. *First use: [§2.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md).*

**$\operatorname{Ch}$, $\Omega$, $A$** · *Chance notation* · $\operatorname{Ch}$ is an objective chance function, $\Omega$ its possibility-respecting sample space, and expansion an event assigned positive chance. Here italic expansion is an event variable, not upright $\mathrm{E}$ for outward continuation. *First use: [§2.9.5](../2.%20The%20Argument/2.9.5%20Possibility%20Precedes%20Probability.md).*

**$\mathbf{K}$, $\mathbf{T}$, $\mathbf{S4}$, $\mathbf{B}$, $\mathbf{S5}$** · *Modal-system names* · Conventional names for normal modal systems in Appendix A. Bold system-name $\mathbf{T}$ and $\mathbf{B}$ are metalogical labels, not the book’s constants $\mathrm{T}$ and $\mathrm{B}$. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*

**$\mathbf{F}$, $\mathbf{P}$, $\mathbf{G}$, $\mathbf{H}$** · *Temporal-logic operators* · Conventional operators for *will sometime*, *was sometime*, *will always*, and *has always been*. The singularity analysis ([§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md)) uses $\mathbf{G}\mathbf{F}P$ diagnostically for a liveness claim—at every point, $P$ occurs again later—without adding that claim to the modal derivation. Bold distinguishes these operators from the conventional physical variables $F$ and $G$ below. *First use: [§2.11](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md).*

**$F, G, m_1, m_2, r$** · *Newtonian symbols* · Force, the gravitational constant, two masses, and their separation in $F = Gm_1m_2/r^2$. Italic $F$ and $G$ retain their conventional physical meanings locally; they aren’t upright $\mathrm{F}$ or $\mathrm{G}$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6.3%20Predictions.md).*

**$M_{\mathrm{SR}}, E, E_0, p, m, c$** · *Special-relativistic example* · $M_{\mathrm{SR}}$ is the locally specified special-relativistic profile; $E$ is energy, $E_0$ rest energy, $p$ momentum, $m$ invariant mass, and $c$ invariant speed in $E^2=p^2c^2+m^2c^4$. The roman subscript is a descriptive abbreviation; the physical symbols retain their standard meanings. *First use: [§3.5](../3.%20Convergence/3.5%20Formal%20and%20Physical%20Realization.md).*


← [ On Publication](On%20Publication.md) | [Glossary](Glossary.md) →
