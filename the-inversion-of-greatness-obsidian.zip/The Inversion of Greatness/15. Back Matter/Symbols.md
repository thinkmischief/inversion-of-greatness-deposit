The notation used throughout the argument, collected for reference. The sections before **Scoped notation** are the **canonical legend**: symbols a reader may carry from one section to another. The scoped section records stable, readable forms confined to particular arguments.

Each symbol is defined in full where it’s introduced; the italic tag at the end of an entry points to the section where it first appears. Established logical, mathematical, and physical notation takes priority: the book introduces no private glyph where a standard sign already does the work. Book-defined single-letter constants are upright; schematic variables are italic; named operators, predicates, and multi-letter mnemonic propositions are upright. Bold is reserved for conventional system names and imported temporal operators.

## Logical and modal notation

**$\Box$** · *Necessity operator* · $\Box P$ is true just when $P$ holds across every configuration of Reality. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$\Diamond$** · *Possibility operator* · $\Diamond P$ is true just when $P$ holds in at least one configuration of Reality. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$\land\ \lor\ \neg\ \to\ \leftrightarrow$** · *Logical connectives* · Conjunction, disjunction, negation, material conditional, biconditional.

**$\forall\ \exists$** · *Quantifiers* · $\forall$ is the universal quantifier, read *for all*; $\exists$ is the existential quantifier, read *there exists*.

**$\top$** · *Logical truth* · Any logical truth, used to witness that the possible pole is non-empty. *First use: [§2.1.3](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).*

**$\bot$** · *Contradiction* · Any contradiction, used to witness that the impossible pole is non-empty. *First use: [§2.1.3](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).*

**$\therefore$** · *Therefore* · Reserved for the conclusion lines of formal syllogisms.

**$=_{\mathrm{df}}$** · *Defined as* · Introduces a stipulative definition.

**$\equiv$** · *Logically equivalent* · Marks interdefinable formulas in the modal-logic primer; unlike $=_{\mathrm{df}}$, it doesn’t introduce a stipulative definition. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*

**$\models$** · *Semantic consequence* · $M\models Q$ says that every admissible realization of the profile or model $M$ satisfies $Q$. This is the standard model-theoretic consequence sign, not a further modal operator. *First use: [§2.11.4](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.4%20Mathematical%20Necessity%20and%20Analytic%20Language).*

## Variables

**$P, Q$** · *Propositional variables* · Schematic propositional variables, ranging over contentful claims. *First use: [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md).*

**$M$** · *Model or profile variable* · A schematic mathematical or physical-mathematical profile. Italic $M$ follows the ordinary model-theoretic convention and is distinct from upright $\mathrm{M}$, the book’s fixed symbol for Movement. *First use: [§2.11.4](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.4%20Mathematical%20Necessity%20and%20Analytic%20Language).*

**$L$** · *Law-profile variable* · A schematic independently specified physical law-profile in a conditional such as $\Box\forall x(\operatorname{Realizes}(x,L)\to Q(x))$. It is a local variable, not a proposition or a second necessity operator. *First use: [§2.11.5](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.5%20Physical%20Necessity).*

**$p$** · *Contingent-configuration variable* · A propositional variable ranging over claims about which contingent configuration is occupied. Lowercase $p$ is the scoped variable used in *Necessity Permits Contingency*, not a second book-wide propositional-variable convention. *First use: [§2.9.4](../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.4%20Necessity%20Precedes%20Contingency).*

**$x, y, z$** · *Individual variables* · Variables ranging over individuals or relata. In a locally defined predicate such as $\operatorname{Grounds}(x,y)$, the arguments are variables even when the predicate name has a separate fixed use elsewhere.

**$g$** · *Ground-candidate variable* · A proposed additional ground of Nature or concrete actuality, bound fresh in each argument that tests a candidate ground. *First use: [§2.8](../2.%20The%20Argument/2.8%20Reality%E2%80%93Nature%20Identity.md).*

**$t$** · *Temporal index variable* · A time or temporal evaluation point within a locally indexed argument. *First use: [§2.7.2](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.2%20Incoherence%20of%20%E2%88%85).*

**$w, w’, w_0, w_1, w_2, w^*$** · *Possible-world representation variables* · These belong to the standard or rival semantic apparatus and represent complete configurations $\mathrm{R}$ could be claimed to admit; they don’t denote plural Realities. $w$ is generic; $w_0$ is the candidate representation posited to lack the structural Conditions at [§2.7.4](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.4%20Preclusion%20Boundary); $w_1, w_2, \ldots$ enumerate representations; $w^*$ is the dual representation introduced at [§11.1](../11.%20Reclaiming%20Greatness/11.1%20Greatness.md) and Appendix B item 16. *First use: [§2.1.5](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.5%20The%20S5%20Bottleneck).*

## The Conditions

The book uses related structural vocabularies at different levels of resolution. The two symbolic columns come first; the prose columns then give the role disclosed by Change and the Condition’s name as borne in Reality. The rows mark corresponding role-families, not identities or automatic entailments. In particular, the generic Chapter 3 roles $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ don’t by themselves establish the fully specified Conditions $\mathrm{T}$, $\mathrm{S}$, and $\Phi$.

| Modal-core Condition | Generic role-floor | Role disclosed by Change | Condition as borne in Reality |
| --- | --- | --- | --- |
| $\mathrm{T}$ · Temporality | $\mathrm{O}$ · directed order | Succession | Time |
| $\mathrm{S}$ · Spatiality | $\mathrm{D}$ · determinate difference | Distinction | Space |
| $\Phi$ · Substantiality | $\mathrm{B}$ · bearing or realization | Exchange | Substance |

### Modal-core Conditions

**$\mathrm{T}$** · *Temporality* · The Condition of Reality such that succession is necessarily possible. *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\mathrm{S}$** · *Spatiality* · The Condition of Reality such that distinction is necessarily possible. *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\Phi$** · *Substantiality* · The Condition of Reality such that exchange is necessarily possible. Because the glyph is stipulated, the chapters avoid lowercase Greek for schematic formulas: propositions are $\mathrm{P}$, $\mathrm{Q}$, $\mathrm{R}$, so that $\varphi$ is never set beside $\Phi$ where only case would tell them apart. Six such uses in [§2.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md) were converted to $\mathrm{P}$ on 2026-08-27. [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md) is the deliberate exception and keeps $\varphi(x)$: it expounds standard modal logic in the notation its readers already know, and the schematic sense is the only one in play there. Unlike $\mathrm{T}$ and $\mathrm{S}$, the glyph is stipulated rather than mnemonic: it was fixed when the Condition was named *Physicality* and is retained across the rename so that every formula in print keeps its reference. *First use: [§1.4](../1.%20Groundwork/1.4%20Three%20Conditions.md).*

**$\mathrm{T}(x),\ \mathrm{S}(x),\ \Phi(x)$** · *Predicate form* · Applied to an individual $x$, each says that $x$ instantiates the corresponding Condition.

**$\operatorname{Concrete}(x)$** · *Concrete-existence predicate* · $\operatorname{Concrete}(x) =_{\mathrm{df}} \mathrm{T}(x) \land \mathrm{S}(x) \land \Phi(x)$. To exist concretely is to instantiate all three Conditions. This replaces the private notation $\operatorname{Exists}^{\mathrm{c}}(x)$: the superscript $\mathrm{c}$ was a local qualifier, not a standard operator. Abstract existential quantification isn’t represented by this predicate. *First use: [§1.5](../1.%20Groundwork/1.5%20Existence.md).*

### Generic role-floor

The *Notation* paragraph at [§2.2](../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md) introduces $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ together; the derivation at [§3.2](../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md) establishes them and uses them throughout.

**$\mathrm{O}$** · *Directed order* · The generic role of asymmetric ordering. It isn’t yet Temporality: $\mathrm{O}$ is directed order, not temporal succession.

**$\mathrm{D}$** · *Determinate difference* · The generic role of distinctness. It isn’t yet Spatiality: $\mathrm{D}$ is difference, not concrete relational exteriority.

**$\mathrm{X}$** · *Variable over the Conditions* · A bound variable ranging over the Conditions themselves, $\mathrm{X} \in \{\mathrm{T}, \mathrm{S}, \Phi\}$, used where a claim holds for each and is stated once. It isn’t one of the generic roles: those are $\mathrm{O}$, $\mathrm{D}$, and $\mathrm{B}$ above, which are thinner than the Conditions, whereas $\mathrm{X}$ takes the Conditions as its values. *Used at: [§2.1.5](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.5%20The%20S5%20Bottleneck) (Parasitic Negation, Negation Seal); [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) (Triconditional Closure).* The letter was chosen in 2026-08-30 to replace an earlier use of $\mathrm{D}$ in this role, which collided with the generic-difference $\mathrm{D}$ and inverted its sense—the role stands *against* Spatiality while the variable *includes* it.

**$\mathrm{B}$** · *Bearing or realization* · The generic role of carrying a fact, act, state, or arrangement. It isn’t yet Substantiality: $\mathrm{B}$ is bearing, not causal persistence.

## Structural notation

**$\mathrm{R}$** · *Reality* · The totality of what is real, identified with Nature in $\Box(\mathrm{R} = \mathrm{N})$. *First use: [§1.1](../1.%20Groundwork/1.1%20Reality.md).*

**$\operatorname{Capacity}(\mathrm{R},P)$** · *Capacity relation* · Reality has the standing capacity for $P$ to obtain. Thus $\Diamond P$ means $\operatorname{Capacity}(\mathrm{R},P)$, while $\Box P$ means $\neg\operatorname{Capacity}(\mathrm{R},\neg P)$. *First use: [§1.2.1](../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.1%20Possibility).*

**$\operatorname{Range}(\mathrm{R})$** · *Complete admissible range* · The set of propositions Reality has the capacity to admit: $\operatorname{Range}(\mathrm{R}) =_{\mathrm{df}} \{P \mid \operatorname{Capacity}(\mathrm{R},P)\}$. Possible-world variables represent members or arrangements within this range; they don’t denote plural Realities or ground the range. *First use: [§1.2.1](../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.1%20Possibility).*

**$\mathrm{C}$** · *Change* · The concrete reflective transition witnessed in reading, doubting, and recognizing the doubt, reference-fixed at minimum resolution as *one state, then another*. Formal $\mathrm{C}$ retains that referent at book scope; it doesn’t denote maximally thin generic succession. *First use: [§1.3](../1.%20Groundwork/1.3%20Change.md).*

**$\mathrm{N}$** · *Nature* · $\mathrm{N} =_{\mathrm{df}} \mathrm{T} \land \mathrm{S} \land \Phi$. The definition is box-free; the necessity $\Box(\mathrm{T} \land \mathrm{S} \land \Phi)$ is the earned result Triconditional Necessity ([§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md)). *First use: [§1.4.4](../1.%20Groundwork/1.4%20Three%20Conditions.md#1.4.4%20Triconditional%20Structure).*

**$\mathrm{M}$** · *Movement* · Change of position: one thing at a position and afterwards at another, having crossed what lay between. A species of $\mathrm{C}$, so $\Diamond\mathrm{M}$ entails $\Diamond\mathrm{C}$. Its containment of $\mathrm{T}$, $\mathrm{S}$, and $\Phi$ is constitutive rather than inferred, which is what lets the Movement Line spend none of the three constitutive premises. *First use: [§2.4.7](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.7%20Distinction%20Requires%20Spatiality).*

**$\varnothing$** · *Null State* · Absolute nothingness. *First use: [§2.7.1](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.1%20Null%20State%20%28%E2%88%85%29).*

**$\mathrm{Con}$** · *Convergence proposition* · Some separated physical trajectories reduce their separation and enter a common region or phase. Paired with $\mathrm{Div}$ in the Bidirectional Modal Capacity theorem: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. The modal operators have global scope; the embedded proposition remains minimal convergence and doesn’t abbreviate total cosmic reconvergence. *First use: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

**$\mathrm{Div}$** · *Divergence proposition* · Some separated physical trajectories increase their separation. Paired with $\mathrm{Con}$ in the Bidirectional Modal Capacity theorem: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. *First use: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

## Scoped notation

These forms have a stable, readable job within the indicated argument but aren’t book-wide metaphysical constants.

**$\operatorname{Acc}(x,y)$, $\operatorname{Reach}(x,P)$** · *Accessibility relation; reachability predicate* · In the locally introduced rival semantics, $\operatorname{Acc}(x,y)$ says that $y$ is accessible from $x$, and $\operatorname{Reach}(x,P) =_{\mathrm{df}} \exists y(\operatorname{Acc}(x,y) \land P(y))$. These are readable names for the rival apparatus; neither belongs to the book’s capacity-based ground of modality. *First use: [§2.1.4](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.4%20Modal%20Stability).*

**$\mathrm{SC}$** · *Square-circle proposition* · One figure is square and circular in the same respect at the same boundary. Its invariant exclusion, $\neg\Diamond\mathrm{SC} \to \Box\neg\Diamond\mathrm{SC}$, supplies the spatial example of the negative modal arm. *First use: [§2.1.10](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.10%20Necessary%20Possibility).*

**$\operatorname{Begin}(x)$, $\operatorname{Place}(x)$, $\operatorname{Produce}(x)$** · *Onset predicates* · Respectively: $x$ begins, $x$ is placed, and $x$ is produced. They occur only in the three Parasitic-Negation reductios and remain distinct because they carry distinct warrants. *First use: [§2.4.6](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality).*

**$\operatorname{Past}(\varnothing)$** · *Past-null proposition* · The Null State $\varnothing$ obtained at some past time $t$. The temporal reductio concludes $\neg\operatorname{Past}(\varnothing)$. *First use: [§2.7.2](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.2%20Incoherence%20of%20%E2%88%85).*

**$\operatorname{Grounds}(x,y)$** · *Grounding relation* · A locally introduced two-place predicate saying that $x$ grounds $y$. *First use: [§2.2.2](../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md#2.2.2%20Actuality%E2%80%99s%20Reach).*

**$\operatorname{Realizes}(x,M)$** · *Realization predicate* · The concrete system or configuration $x$ instantiates the elements or positions of profile $M$ and preserves the relations relevant to the stated consequence. The named predicate is used because no single standard logical glyph expresses physical realization; its typography follows the standard convention for multi-letter predicates. *First use: [§2.11.4](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.4%20Mathematical%20Necessity%20and%20Analytic%20Language).*

**$M_{\Delta}, I, X, \gamma$** · *Transformation-profile notation* · $M_{\Delta}$ is the locally defined non-trivial transformation profile; $I$ is its ordered index set, $X$ its state space, and $\gamma:I\to X$ the map assigning states to indices. The symbols retain their standard schematic mathematical roles. Italic $X$ is a state-space variable and is distinct from upright $\mathrm{X}$, the book’s variable over the Conditions. *First use: [§3.5.6](../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.6%20Formal%20Realization%20Preserves%20Structure%20Without%20Supplying%20It).*

**$\mathrm{MGB}$** · *Maximally-great-being proposition* · The proposition that a maximally great being is instantiated in Plantinga’s modal ontological argument. S5 validates $\Diamond\Box\mathrm{MGB} \to \Box\mathrm{MGB}$ without supplying the possibility premise. *First use: [§2.1.9](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.9%20What%20Necessity%20Transfer%20Needs).*

**$\mathrm{CG}_0$** · *Contentless-God description* · The stipulated description that combines atemporality, aspatiality, and denial of any bearer-role with determinate active-ground predicates while refusing every thinner or analogical truth-condition for them. The Contentless God Has No Referent establishes $\Box\neg\mathrm{CG}_0$ for that description only. *First use: [§11.10](../11.%20Reclaiming%20Greatness/11.10%20What%20Remains%20of%20God.md).*

**$\mathrm{Resolution}$** · *Resolution proposition* · The proposition that a history or mechanism preserves $\mathrm{T} \land \mathrm{S} \land \Phi$ through a would-be classical singular boundary. Necessary Resolution Possibility is $\Diamond\mathrm{Resolution} \to \Box\Diamond\mathrm{Resolution}$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions).*

**$A$** · *Aggregation proposition* · Gravitational aggregation: matter converges into bound systems under mutual attraction. As a locally bound propositional letter it remains italic: $A \to \Diamond A \to \Box\Diamond A$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions).*

**$K, E$** · *Compression-profile and expansion-phase variables* · In Conditional Phase Recurrence, $K$ ranges over a dynamically complete maximal-compression phase-class and $E$ over entry into an expanding phase. The standard schematic conditional is $\Box(K\to E)$. These italic variables are local to the argument: $E$ elsewhere retains its locally declared conventional meaning, including energy or an event. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions).*

## Conventional notation in local examples

These symbols retain established meanings within the indicated technical example. They aren’t additional book-wide metaphysical constants.

**$\operatorname{Ch}$, $\Omega$, $E$** · *Chance notation* · $\operatorname{Ch}$ is an objective chance function, $\Omega$ its possibility-respecting sample space, and $E$ an event assigned positive chance. Here italic $E$ is an event variable, not upright $\mathrm{E}$ for outward continuation. *First use: [§2.9.5](../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.5%20Possibility%20Precedes%20Probability).*

**$\mathbf{K}$, $\mathbf{T}$, $\mathbf{S4}$, $\mathbf{B}$, $\mathbf{S5}$** · *Modal-system names* · Conventional names for normal modal systems in Appendix A. Bold system-name $\mathbf{T}$ and $\mathbf{B}$ are metalogical labels, not the book’s constants $\mathrm{T}$ and $\mathrm{B}$. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*

**$\mathbf{F}$, $\mathbf{P}$, $\mathbf{G}$, $\mathbf{H}$** · *Temporal-logic operators* · Conventional operators for *will sometime*, *was sometime*, *will always*, and *has always been*. Section 4.6 uses $\mathbf{G}\mathbf{F}P$ diagnostically for a liveness claim—at every point, $P$ occurs again later—without adding that claim to the modal derivation. Bold distinguishes these operators from the conventional physical variables $F$ and $G$ below. *First use: [§2.11](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md).*

**$F, G, m_1, m_2, r$** · *Newtonian symbols* · Force, the gravitational constant, two masses, and their separation in $F = Gm_1m_2/r^2$. Italic $F$ and $G$ retain their conventional physical meanings locally; they aren’t upright $\mathrm{F}$ or $\mathrm{G}$. *First use: [§4.6.3](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions).*

**$M_{\mathrm{SR}}, E, E_0, p, m, c$** · *Special-relativistic example* · $M_{\mathrm{SR}}$ is the locally specified special-relativistic profile; $E$ is energy, $E_0$ rest energy, $p$ momentum, $m$ invariant mass, and $c$ invariant speed in $E^2=p^2c^2+m^2c^4$. The roman subscript is a descriptive abbreviation; the physical symbols retain their standard meanings. *First use: [§2.11.5](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.5%20Physical%20Necessity).*

**$\varphi$, $a$** · *Formula and individual metavariables* · Conventional schematic letters in Appendix A’s quantified-modal examples. They have no fixed book-wide referent. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*

**$\mathrm{MP}$, $\mathrm{UI}$** · *Inference-rule abbreviations* · Modus ponens and universal instantiation in Appendix A’s proof summary. *First use: [Appendix A](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).*


---

← [ On Publication](On%20Publication.md) | [Glossary](Glossary.md) →
