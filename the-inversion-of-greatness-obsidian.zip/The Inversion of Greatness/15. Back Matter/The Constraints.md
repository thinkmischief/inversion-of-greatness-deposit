*Accuracy is non-optional.* A claim that outruns the step that earned it isn’t a stronger claim, it’s an unearned one. The quiet failure runs the other way: a hedge that withdraws what the argument already secured reads as modesty and costs a result. Both are the same defect. Confidence should never exceed the derivation.

*Agreeableness is failure, adversary is the resistance.* Without backstops in place, models can feed you what you want to hear. Models were granted no room for agreeableness. They were instructed to break the argument wherever they could and to keep anything out that wasn’t earned. The result isn’t a book written by AI. It’s the ideas that survived it.

*Contribution is owed.* Every position engaged with is a contribution to the question, not an obstacle in the way. Rival accounts need to be engaged charitably, and at full strength. A conclusion earned against a weaker presentation isn’t concluding anything.

*Maximum accessibility.* Philosophy belongs to everyone, not just philosophers. The goal was to make the work as accessible as possible, both in format and in content. Where a technical word had an ordinary substitute, I used it. Where substitution would blur a necessary distinction, the technical word remained. The mixed use of contractions is intentional. The difference between *does not* and *doesn’t* isn’t merely one of formality. When *not* is doing the heavy lifting, I leave it standing. Elsewhere, the contraction keeps the sentence moving.

*Words have to mean one thing.* Every discipline builds edges into its vocabulary that ordinary language blurs. The difficulty is in carrying an argument through interdisciplinary work without filing those edges off. A term-sense ledger keeps each word to one sense. Nothing here turns on a word doing double duty.

*My voice.* The content produced by AI can be sound, but the voicework isn’t built in. Every model and every update comes with its own change in prose. I needed a way to rein in the voice across the use of different models. To do that, I used copyediting sessions to double as voice-building opportunities. If anything was written in a way I wouldn’t say it, I recorded what I didn’t like about it, and how I would fix it. The findings accumulated into a voice that was more “me.” This isn’t a substitute for book-wide editing, but it’s a good baseline until I can afford to work through it more thoroughly.

*Model for the task.* Different models have different strengths and weaknesses, and many of those fluctuate model to model, version to version. In my experience, Anthropic models seemed more capable when it came to refining ideas, writing, and voice. Models like Opus rarely broke leash, and stood firm against allowing anything into the book that didn’t earn its way in.

*Review everything, often.* Auditing standards were built around soundness, voice, consistency, and the like. Those standards were then used by frontier models (GPT, Claude, Grok, Kimi) for independent blind audits. What audited a passage was never what wrote it—a model reading its own output has already agreed with it. GPT models tended to produce the most genuine findings, while also being the most likely to overshoot the correction. Where the auditors disagreed, I read the passage and decided. That is internal review. It is not external review and does not substitute for it.


---

← [ On the Use of AI](On%20the%20Use%20of%20AI.md) | [ On Publication](On%20Publication.md) →
