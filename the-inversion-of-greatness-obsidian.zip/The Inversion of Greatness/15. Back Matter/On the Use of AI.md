Books are normally written slowly—drafted, read back, argued over with a field, and revised over the years that process takes. That slowness isn’t incidental; it’s what makes the output seamless, well researched, and comprehensible. The process is necessary, and so is review.

What AI supplied was the process without the pace. It was used as a backstop, a research aid, and a tool for review. It worked only within the constraints built into the process and on the ideas I provided.


---

← [Author’s Notes](Author%E2%80%99s%20Notes.md) | [ The Constraints](The%20Constraints.md) →
