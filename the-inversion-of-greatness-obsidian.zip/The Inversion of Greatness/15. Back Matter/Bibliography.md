European Food Safety Authority (EFSA) and Panel on Animal Health and Welfare (AHAW). 2005. “Opinion of the Scientific Panel on Animal Health and Welfare on a Request from the Commission Related to the Aspects of the Biology and Welfare of Animals Used for Experimental and Other Scientific Purposes.” *EFSA Journal* 3 (12): 292.
^ref-efsa2005

Intergovernmental Panel on Climate Change (IPCC). 2014. “Climate Change 2014: Synthesis Report (Fifth Assessment Report, AR5).” IPCC, Geneva, Switzerland.
^ref-ipcc2014

Intergovernmental Panel on Climate Change (IPCC). 2021. “Climate Change 2021: The Physical Science Basis (Sixth Assessment Report, AR6, Working Group I).” Cambridge University Press / IPCC.
^ref-ipcc2021

Intergovernmental Panel on Climate Change (IPCC). 2023. “Climate Change 2023: Synthesis Report. Contribution of Working Groups I, II and III to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change.” IPCC, Geneva, Switzerland.
^ref-ipcc2023

(Marcus), Ruth C. Barcan. 1946. “A Functional Calculus of First Order Based on Strict Implication.” *Journal of Symbolic Logic* 11 (1): 1–16.
^ref-barcanMarcus1946

World Wildlife Fund (WWF). 2022. “Living Planet Report 2022: Building a Nature-Positive Society.” WWF, Gland, Switzerland.
^ref-wwf2022

Adamala, K., and J. W. Szostak. 2013. “Nonenzymatic Template-Directed RNA Synthesis Inside Model Protocells.” *Science* 342 (6162): 1098–1100.
^ref-adamalaSzostak2013

Adamo, Shelley A. 2013. “Parasites: Evolution's Neurobiologists.” Journal of Experimental Biology 216 (1): 3-10.
^ref-adamo2013

Adams, Robert Merrihew. 1971. “The Logical Structure of Anselm's Arguments.” *The Philosophical Review* 80 (1): 28–54.
^ref-adams1971

Adams, Robert Merrihew. 1972. “Must God Create the Best?” *The Philosophical Review* 81, no. 3: 317–332.
^ref-adams1972

Adams, Robert Merrihew. 1974. “Theories of Actuality.” *Noûs* 8(3): 211–231.
^ref-adams1974

Adams, Robert Merrihew. 1977. “Middle Knowledge and the Problem of Evil.” *American Philosophical Quarterly* 14, no. 2: 109–117.
^ref-adams1977

Adams, R. M. 1979. “Primitive Thisness and Primitive Identity.” *Journal of Philosophy*.
^ref-adams1979

Adams, Robert Merrihew. 1981. “Actualism and Thisness.” *Synthese* 49 (1): 3–41.
^ref-adams1981

Adams, R. M. 1983. “Divine Necessity.” *Journal of Philosophy* 80 (11): 741–752.
^ref-adams1983

Adams, Robert Merrihew. 1987. “Flavors, Colors, and God.” First published as ch. 16 (pp. 243–262) of The Virtue of Faith and Other Essays in Philosophical Theology. Oxford University Press.
^ref-adams1987

Adams, Robert Merrihew. 1999. *Finite and Infinite Goods: A Framework for Ethics*. New York: Oxford University Press.
^ref-adams1999

Adams, Marilyn McCord. 1999. *Horrendous Evils and the Goodness of God*. Ithaca, NY: Cornell University Press.
^ref-adamsMM1999

Adamson, Peter. 2013. “From the Necessary Existent to God.” In Interpreting Avicenna: Critical Essays, ed. Peter Adamson, 170–189. Cambridge University Press.
^ref-adamson2013

Adler, Emanuel, and Michael Barnett. 1998. *Security Communities*. Cambridge University Press.
^ref-adlerBarnett1998

Adolphs, Ralph. 2013. “The Biology of Fear.” *Current Biology* 23(2): R79–R93.
^ref-adolphs2013

Adolphs, Ralph. 2017. “How Should Neuroscience Study Emotions? By Distinguishing Emotion States, Concepts, and Experiences.” *Social Cognitive and Affective Neuroscience* 12(1): 24–31.
^ref-adolphs2017

Adorno, Theodor W. 1970. *Aesthetic Theory (Ästhetische Theorie)*. Suhrkamp.
^ref-adorno1970

Agamben, Giorgio. 1998. *Homo Sacer: Sovereign Power and Bare Life*. Translated by Daniel Heller-Roazen. Stanford, CA: Stanford University Press.
^ref-agamben1998

Aguirre, Anthony, and Steven Gratton. 2002. “Steady-State Eternal Inflation.” *Physical Review D* 65: 083507.
^ref-aguirreGratton2002

Aharonov, Yakir, and David Bohm. 1959. “Significance of Electromagnetic Potentials in the Quantum Theory.” *Physical Review* 115(3):485–491.
^ref-aharonovBohm1959

Aiello, M., I. Pratt-Hartmann, and J. van Benthem. 2007. *Handbook of Spatial Logics*. Dordrecht: Springer.
^ref-aielloPrattHartmannVanBenthem2007

Ainsworth, Mary D. Salter, Mary C. Blehar, Everett Waters, and Sally Wall. 1978. *Patterns of Attachment: A Psychological Study of the Strange Situation*. Erlbaum.
^ref-ainsworth1978

Akerlof, George A. 1970. “The Market for 'Lemons': Quality Uncertainty and the Market Mechanism.” *Quarterly Journal of Economics* 84 (3): 488–500.
^ref-akerlof1970

al-Ghazālī. c. 1095. *The Incoherence of the Philosophers (Tahāfut al-Falāsifa)*. Trans. Michael E. Marmura. 2nd ed. Brigham Young University Press, 2000.
^ref-alGhazali1095

al-Kindī. c. 850. *On First Philosophy (Fī al-Falsafa al-Ūlā)*. Trans. Alfred L. Ivry. Al-Kindī's Metaphysics. SUNY Press, 1974.
^ref-alKindi850

Albert, D. Z. 1992. *Quantum Mechanics and Experience*. Cambridge, MA: Harvard University Press.
^ref-albert1992

Albert, David Z. 2000. *Time and Chance*. Harvard University Press.
^ref-albert2000

Albert, David Z. 2015. *After Physics*. Harvard University Press.
^ref-albert2015

Albertin, Caroline B., et al. 2015. “The Octopus Genome and the Evolution of Cephalopod Neural and Morphological Novelties.” *Nature* 524(7564):220–224.
^ref-albertin2015

Albrecht, Andreas, and Lorenzo Sorbo. 2004. “Can the Universe Afford Inflation?” *Physical Review D* 70(6):063528.
^ref-albrechtSorbo2004

Alexander, Michelle. 2010. *The New Jim Crow: Mass Incarceration in the Age of Colorblindness*. The New Press.
^ref-alexander2010

Allcott, Hunt, Luca Braghieri, Sarah Eichmeyer, and Matthew Gentzkow. 2020. “The Welfare Effects of Social Media.” *American Economic Review* 110 (3): 629–676.
^ref-allcott2020

Allison, Dale C., Jr. 1985. *The End of the Ages Has Come: An Early Interpretation of the Passion and Resurrection of Jesus*. Fortress Press.
^ref-allison1985

Allison, Dale C., Jr. 2010. *Constructing Jesus: Memory, Imagination, and History*. Grand Rapids: Baker Academic.
^ref-allison2010

Allison, Dale C., Jr. 2021. *The Resurrection of Jesus: Apologetics, Polemics, History*. London; New York: T&T Clark (Bloomsbury).
^ref-allison2021

Allport, Gordon W., and Leo Postman. 1947. *The Psychology of Rumor*. New York: Henry Holt.
^ref-allportPostman1947

Allport, Gordon W. 1954. *The Nature of Prejudice*. Addison-Wesley.
^ref-allport1954

Almeida, Michael J. 2008. *The Metaphysics of Perfect Beings*. Routledge (Routledge Studies in the Philosophy of Religion).
^ref-almeida2008

Almheiri, A., T. Hartman, J. Maldacena, E. Shaghoulian, and A. Tajdini. 2020. “The Entropy of Hawking Radiation.” *Reviews of Modern Physics* 93 (3): 035002.
^ref-almheiri2020

Alston, William P. 1988. “The Deontological Conception of Epistemic Justification.” *Philosophical Perspectives* 2: 257–299.
^ref-alston1988

Alston, William P. 1991a. “The Inductive Argument from Evil and the Human Cognitive Condition.” *Philosophical Perspectives* 5 (1991): 29–67.
^ref-alston1991

Alston, William P. 1991b. *Perceiving God: The Epistemology of Religious Experience*. Cornell University Press.
^ref-alston1991b

Alter, Torin, and Yujin Nagasawa. 2015. *Consciousness in the Physical World: Perspectives on Russellian Monism*. Oxford University Press.
^ref-alterNagasawa2015

Altieri, Miguel A. 1995. *Agroecology: The Science of Sustainable Agriculture*. Westview Press.
^ref-altieri1995

Ambady, Nalini, and Robert Rosenthal. 1992. “Thin Slices of Expressive Behavior as Predictors of Interpersonal Consequences: A Meta-Analysis.” Psychological Bulletin 111 (2): 256-274.
^ref-ambadyRosenthal1992

An, Daniel, Krzysztof A. Meissner, Paweł Nurowski, and Roger Penrose. 2018. “Apparent Evidence for Hawking Points in the CMB Sky.” arXiv:1808.01740 \[later published in Monthly Notices of the Royal Astronomical Society 495(3):3403–3430, 2020].
^ref-anEtAl2018

An, Daniel, Krzysztof A. Meissner, Paweł Nurowski, and Roger Penrose. 2020. “Apparent Evidence for Hawking Points in the CMB Sky.” *Monthly Notices of the Royal Astronomical Society* 495(3):3403–3430.
^ref-anEtAl2020

Andersen, Sandra B. et al. 2009. “The Life of a Dead Ant: The Expression of an Adaptive Extended Phenotype.” American Naturalist 174 (3): 424-433.
^ref-andersen2009

Anderson, Terry L., and Donald R. Leal. 1991. *Free Market Environmentalism*. Westview Press / Pacific Research Institute.
^ref-andersonleal1991

Anderson, Elizabeth. 1999. “What Is the Point of Equality?” *Ethics*.
^ref-anderson1999

Anderson, Elizabeth. 2010. *The Imperative of Integration*. Princeton University Press.
^ref-anderson2010

Anderson, Elizabeth. 2017. *Private Government: How Employers Rule Our Lives (and Why We Don't Talk about It)*. Princeton University Press.
^ref-anderson2017

Anderson, Edward. 2017. *The Problem of Time: Quantum Mechanics Versus General Relativity*. Springer (Fundamental Theories of Physics).
^ref-andersonEdward2017

Andrei, C., A. Ijjas, and P. J. Steinhardt. 2022. “Rapidly Descending Dark Energy and the End of Cosmic Expansion.” *Proceedings of the National Academy of Sciences* 119 (15): e2200539119.
^ref-andreiIjjasSteinhardt2022

Andrews-Hanna, Jessica R., Jonathan Smallwood, and R. Nathan Spreng. 2014. “The Default Network and Self-Generated Thought: Component Processes, Dynamic Control, and Clinical Relevance.” *Annals of the New York Academy of Sciences* 1316: 29–52.
^ref-andrewsHanna2014

Anscombe, G. E. M. 1971. *Causality and Determination*. Cambridge: Cambridge University Press.
^ref-anscombe1971

Antczak, Marcin, Martin Hromada, and Piotr Tryjanowski. 2012. “Sex Differences in Impaling Behaviour of Great Grey Shrike Lanius excubitor: Do Males Have Better Impaling Skills Than Females?” Behavioural Processes 91(1): 50-53.
^ref-antczakEtAl2012

Aos, Steve, and Elizabeth Drake. 2013. “Prison, Police, and Programs: Evidence-Based Options That Reduce Crime and Save Money.” Washington State Institute for Public Policy, Doc. 13-11-1901.
^ref-aosDrake2013

Apel, Karl-Otto. 1976. “The Apriori of the Communication Community.” in Towards a Transformation of Philosophy.
^ref-apel1976

Apel, Karl-Otto. 1980. *Towards a Transformation of Philosophy*. Routledge & Kegan Paul.
^ref-apel1980

Aquinas, Thomas. (1265–1266) 1932. *De Potentia*. In On the Power of God, translated by E. English. Westminster, MD: Newman Press.
^ref-aquinas1932

Aquinas, Thomas. (1265–1274) 1947. *Summa Theologiae*. New York: Benziger Brothers.
^ref-aquinas1947

Aristotle. (4th c. BCE) 1984. *The Complete Works of Aristotle*. Edited by J. Barnes. Princeton, NJ: Princeton University Press.
^ref-aristotle1984

Arminius, Jacobus. 1608. “A Declaration of the Sentiments of Arminius.” Address delivered before the States of Holland and West Friesland, The Hague.
^ref-arminius1608

Armstrong, D. M. 1983. *What Is a Law of Nature?* Cambridge: Cambridge University Press.
^ref-armstrong1983

Armstrong, D. M. 1989. *A Combinatorial Theory of Possibility*. Cambridge University Press (Cambridge Studies in Philosophy).
^ref-armstrong1989

Armstrong, D. M. 1997. *A World of States of Affairs*. Cambridge University Press (Cambridge Studies in Philosophy).
^ref-armstrong1997

Asad, Talal. 1993. *Genealogies of Religion: Discipline and Reasons of Power in Christianity and Islam*. Johns Hopkins University Press.
^ref-asad1993

Asad, Talal. 2003. *Formations of the Secular: Christianity, Islam, Modernity*. Stanford University Press.
^ref-asad2003

Ashtekar, A., and P. Singh. 2011. “Loop Quantum Cosmology: A Status Report.” *Classical and Quantum Gravity* 28 (21): 213001.
^ref-ashtekarSingh2011

Aspect, A., J. Dalibard, and G. Roger. 1982. “Experimental Test of Bell's Inequalities Using Time-Varying Analyzers.” *Physical Review Letters* 49 (25): 1804–1807.
^ref-aspect1982

American Heart Association. 2025. “What Is Cardiac Arrest?” American Heart Association.
^ref-americanHeartAssociation2025

Atkinson, Anthony B. 2015. *Inequality: What Can Be Done?* Harvard University Press.
^ref-atkinson2015

Atran, Scott. 2002. *In Gods We Trust: The Evolutionary Landscape of Religion*. Oxford University Press.
^ref-atran2002

Aubert, Maxime et al. 2014. “Pleistocene Cave Art from Sulawesi, Indonesia.” Nature 514: 223-227.
^ref-aubert2014

Aubert, Maxime et al. 2019. “Earliest Hunting Scene in Prehistoric Art.” Nature 576: 442-445.
^ref-aubert2019

Aulén, Gustaf. 1931. *Christus Victor: An Historical Study of the Three Main Types of the Idea of the Atonement*. trans. A. G. Hebert; London: SPCK, 1931 (orig. Swedish Den kristna försoningstanken, 1930).
^ref-aulen1931

Austin, J. L. 1962. *How to Do Things with Words*. Clarendon Press / Harvard University Press.
^ref-austin1962

Avalos, Hector. 2011. *Slavery, Abolitionism, and the Ethics of Biblical Scholarship*. Sheffield Phoenix Press.
^ref-avalos2011

Avicenna. (c. 1020) 1959. *Avicenna's De Anima (Kitāb al-Nafs), Being the Psychological Part of Kitāb al-Shifāʾ*. Oxford University Press.
^ref-avicenna1020a

Avicenna. (c. 1020) 2005. *The Metaphysics of The Healing*. Translated by Michael E. Marmura. Provo, UT: Brigham Young University Press.
^ref-avicenna1020

Axelrod, R. 1984. *The Evolution of Cooperation*. New York: Basic Books.
^ref-axelrod1984

Ayer, A. J. 1936. *Language, Truth and Logic*. Victor Gollancz (London).
^ref-ayer1936

Bacevich, Andrew J. 2008. *The Limits of Power: The End of American Exceptionalism*. Metropolitan Books.
^ref-bacevich2008

Bacevich, Andrew J. 2010. *Washington Rules: America's Path to Permanent War*. Metropolitan Books.
^ref-bacevich2010

Bach, Kent, and Robert M. Harnish. 1979. *Linguistic Communication and Speech Acts*. MIT Press.
^ref-bachHarnish1979

Bagdikian, Ben H. 2004. *The New Media Monopoly*. Beacon Press.
^ref-bagdikian2004

Bagemihl, B. 1999. *Biological Exuberance: Animal Homosexuality and Natural Diversity*. New York: St. Martin's Press.
^ref-bagemihl1999

Baggett, David, and Jerry L. Walls. 2011. *Good God: The Theistic Foundations of Morality*. Oxford University Press.
^ref-baggettWalls2011

Baggett, David, and Jerry L. Walls. 2016. *God and Cosmos: Moral Truth and Human Meaning*. Oxford University Press.
^ref-baggettWalls2016

Bahnsen, Greg L. 1998. *Van Til's Apologetic: Readings and Analysis*. Presbyterian and Reformed (P&R Publishing), Phillipsburg, NJ.
^ref-bahnsen1998

Bailey, N. W., and M. Zuk. 2009. “Same-Sex Sexual Behavior and Evolution.” *Trends in Ecology & Evolution* 24 (8): 439–446.
^ref-baileyZuk2009

Baker, G. P., and P. M. S. Hacker. 1980. *Wittgenstein: Understanding and Meaning (Analytical Commentary on the Philosophical Investigations, Vol. 1)*. Blackwell.
^ref-bakerHacker1980

Baker, G. P., and P. M. S. Hacker. 1985. *Wittgenstein: Rules, Grammar and Necessity (Analytical Commentary on the Philosophical Investigations, Vol. 2)*. Basil Blackwell.
^ref-bakerHacker1985

Baker, Lynne Rudder. 1995. “Need a Christian Be a Mind/Body Dualist?” *Faith and Philosophy* 12 (4): 489–504.
^ref-baker1995

Baker, D. J. 2009. “Against Field Interpretations of Quantum Field Theory.” *British Journal for the Philosophy of Science* 60 (3): 585–609.
^ref-baker2009

Bakshy, E., S. Messing, and L. A. Adamic. 2015. “Exposure to Ideologically Diverse News and Opinion on Facebook.” *Science* 348 (6239): 1130–1132.
^ref-bakshy2015

Bakunin, Mikhail. 1883. *God and the State*. Boston: Benjamin R. Tucker.
^ref-bakunin1882

Balaban, N. Q., J. Merrin, R. Chait, L. Kowalik, and S. Leibler. 2004. “Bacterial Persistence as a Phenotypic Switch.” *Science* 305 (5690): 1622–1625.
^ref-balaban2004

Balaguer, Mark. 1998. *Platonism and Anti-Platonism in Mathematics*. Oxford University Press.
^ref-balaguer1998

Balashov, Yuri, and Michel Janssen. 2003. “Presentism and Relativity.” *The British Journal for the Philosophy of Science* 54 (2): 327–346.
^ref-balashovJanssen2003

Baldwin, Thomas. 1996. “There Might Be Nothing.” *Analysis*.
^ref-baldwin1996

Balko, Radley. 2013. *Rise of the Warrior Cop: The Militarization of America's Police Forces*. PublicAffairs.
^ref-balko2013

Balzeau, Antoine et al. 2020. “Pluridisciplinary Evidence for Burial for the La Ferrassie 8 Neandertal Child.” Scientific Reports 10: 21230.
^ref-balzeau2020

Bar-On, Yinon M., Rob Phillips, and Ron Milo. 2018. “The Biomass Distribution on Earth.” *PNAS* 115(25):6506–6511.
^ref-barOn2018

Barbour, Julian. 1999. *The End of Time: The Next Revolution in Physics*. Weidenfeld & Nicolson (London).
^ref-barbour1999

Bardon, Adrian. 2013. *A Brief History of the Philosophy of Time*. Oxford University Press.
^ref-bardon2013

Barkley, Russell A. 2015. *Attention-Deficit Hyperactivity Disorder: A Handbook for Diagnosis and Treatment (4th ed.)*. Guilford Press.
^ref-barkley2015

Barnes, Luke A. 2012. “The Fine-Tuning of the Universe for Intelligent Life.” *Publications of the Astronomical Society of Australia* 29 (4): 529–564.
^ref-barnes2012

Barrett, Justin L. 2000. “Exploring the Natural Foundations of Religion.” Trends in Cognitive Sciences 4 (1): 29-34.
^ref-barrett2000

Barrett, J. L. 2004. *Why Would Anyone Believe in God?* Walnut Creek, CA: AltaMira Press.
^ref-barrett2004

Barrett, Lisa Feldman. 2017. *How Emotions Are Made: The Secret Life of the Brain*. Houghton Mifflin Harcourt (Boston).
^ref-barrett2017

Barsalou, Lawrence W. 1999. “Perceptual symbol systems.” *Behavioral and Brain Sciences* 22 (4): 577–609.
^ref-barsalou1999

Bartels, Larry M. 2008. *Unequal Democracy: The Political Economy of the New Gilded Age*. Princeton University Press.
^ref-bartels2008

Barth, Karl. (1932) 1975. *Church Dogmatics I/1, The Doctrine of the Word of God, Part I*. 2d ed. Edited by Thomas F. Torrance and G. W. Bromiley. Translated by G. W. Bromiley. Edinburgh: T&T Clark.
^ref-barth1932

Bateson, G. 1972. *Steps to an Ecology of Mind*. New York: Ballantine Books.
^ref-bateson1972

Batson, C. Daniel. 2011. *Altruism in Humans*. Oxford University Press.
^ref-batson2011

Battin, Margaret Pabst. 2005. *Ending Life: Ethics and the Way We Die*. Oxford University Press.
^ref-battin2005

Bauckham, Richard. 1984. “'Only the Suffering God Can Help': Divine Passibility in Modern Theology.” *Themelios* 9, no. 3: 6–12.
^ref-bauckham1984

Baum, L., and P. H. Frampton. 2007. “Turnaround in Cyclic Cosmology.” *Physical Review Letters* 98 (7): 071301.
^ref-baumFrampton2007

Baumeister, Roy F., Kathleen D. Vohs, Jennifer L. Aaker, and Emily N. Garbinsky. 2013. “Some Key Differences between a Happy Life and a Meaningful Life.”
^ref-baumeister2013

Beall, JC, and Greg Restall. 2006. *Logical Pluralism*. Oxford: Clarendon Press.
^ref-beallRestall2006

Beardsley, Monroe C. 1958. *Aesthetics: Problems in the Philosophy of Criticism*. Harcourt, Brace & Company.
^ref-beardsley1958

Beauchamp, Tom L., and James F. Childress. 1979. *Principles of Biomedical Ethics*. Oxford University Press.
^ref-beauchampchildress1979

Beauchamp, Miriam H., Julian J. Dooley, and Vicki Anderson. 2013. “A preliminary investigation of moral reasoning and empathy after traumatic brain injury in adolescents.” *Brain Injury* 27(7–8): 896–902.
^ref-beauchamp2013

Beauchamp, Miriam H., Evelyn Vera-Estay, F. Morasse, Vicki Anderson, and Julian Dooley. 2019. “Moral reasoning and decision-making in adolescents who sustain traumatic brain injury.” *Brain Injury* 33(1): 32–39 (Epub 2018 Oct 16).
^ref-beauchamp2019

Beauchamp, Tom L., and James F. Childress. 2019. *Principles of Biomedical Ethics*. Oxford University Press.
^ref-beauchampChildress2019

Beaudoin, John. 2007. “The World's Continuance: Divine Conservation or Existential Inertia?” *International Journal for Philosophy of Religion* 61 (2): 83–98.
^ref-beaudoin2007

Beauvoir, Simone de. 1947. *The Ethics of Ambiguity (Pour une morale de l'ambiguïté)*. Gallimard.
^ref-beauvoir1947

Bebchuk, Lucian A., and Jesse M. Fried. 2004. *Pay without Performance: The Unfulfilled Promise of Executive Compensation*. Harvard University Press.
^ref-bebchukFried2004

Bechara, Antoine, Antonio R. Damasio, Hanna Damasio, and Steven W. Anderson. 1994. “Insensitivity to Future Consequences Following Damage to Human Prefrontal Cortex.” Cognition 50 (1-3): 7-15.
^ref-bechara1994

Becker, E. 1973. *The Denial of Death*. New York: Free Press.
^ref-becker1973

Becker, S., J. Feldmann, S. Wiedemann, H. Okamura, C. Schneider, K. Iwan, A. Crisp, M. Rossa, T. Amatov, and T. Carell. 2019. “Unified Prebiotically Plausible Synthesis of Pyrimidine and Purine RNA Ribonucleotides.” *Science* 366 (6461): 76–82.
^ref-becker2019

Bedau, Mark A. 1992. “Where's the Good in Teleology?”
^ref-bedau1992

Beebee, Helen. 2006. *Hume on Causation*. London: Routledge.
^ref-beebee2006

Beebee, Helen, Christopher Hitchcock, and Peter Menzies. 2009. *The Oxford Handbook of Causation*. Oxford University Press.
^ref-beebeeHitchcockMenzies2009

Behe, Michael J. 1996. *Darwin's Black Box: The Biochemical Challenge to Evolution*. Free Press (New York).
^ref-behe1996

Behe, Michael J. 2007. *The Edge of Evolution: The Search for the Limits of Darwinism*. Free Press (New York).
^ref-behe2007

Beitz, Charles R. 1979. *Political Theory and International Relations*. Princeton University Press.
^ref-beitz1979

Beitz, Charles R. 1989. *Political Equality: An Essay in Democratic Theory*. Princeton, NJ: Princeton University Press.
^ref-beitz1989

Bekoff, Marc. 1995. “Play Signals as Punctuation: The Structure of Social Play in Canids.” Behaviour.
^ref-bekoff1995

Bekoff, M., and J. A. Byers. 1998. *Animal Play: Evolutionary, Comparative, and Ecological Perspectives*. Cambridge: Cambridge University Press.
^ref-bekoffByers1998

Bekoff, Marc. 2007. *The Emotional Lives of Animals: A Leading Scientist Explores Animal Joy, Sorrow, and Empathy—and Why They Matter*. New World Library (Novato, CA).
^ref-bekoff2007

Bekoff, Marc, and Jessica Pierce. 2009. *Wild Justice: The Moral Lives of Animals*. University of Chicago Press.
^ref-bekoffPierce2009

Bell, Clive. 1914. *Art*. Chatto & Windus.
^ref-bell1914

Bell, J. S. 1964. “On the Einstein Podolsky Rosen Paradox.” *Physics* 1 (3): 195–200.
^ref-bell1964

Bell, John S. 1976. “How to Teach Special Relativity.” Speakable and Unspeakable in Quantum Mechanics (Cambridge University Press, 1987); orig. Progress in Scientific Culture 1 (1976).
^ref-bell1976

Bell, E. A., P. Boehnke, T. M. Harrison, and W. L. Mao. 2015. “Potentially Biogenic Carbon Preserved in a 4.1 Billion-Year-Old Zircon.” *Proceedings of the National Academy of Sciences* 112 (47): 14518–14521.
^ref-bell2015

Bellah, Robert N. 2011. *Religion in Human Evolution: From the Paleolithic to the Axial Age*. Belknap Press of Harvard University Press.
^ref-bellah2011

Benacerraf, Paul. 1965. “What Numbers Could Not Be.” *The Philosophical Review*.
^ref-benacerraf1965

Benacerraf, Paul. 1973. “Mathematical Truth.” *The Journal of Philosophy*.
^ref-benacerraf1973

Benatar, David. 2006. *Better Never to Have Been: The Harm of Coming into Existence*. Oxford: Oxford University Press.
^ref-benatar2006

Bench, Shane W., and Heather C. Lench. 2013. “On the Function of Boredom.” *Behavioral Sciences* 3 (3): 459–472.
^ref-bench2013

Bender, Emily M., and Alexander Koller. 2020. “Climbing Towards NLU: On Meaning, Form, and Understanding in the Age of Data.” ACL 2020: 5185-5198.
^ref-benderKoller2020

Bender, Emily M., Timnit Gebru, Angelina McMillan-Major, and Shmargaret Shmitchell. 2021. “On the Dangers of Stochastic Parrots: Can Language Models Be Too Big?” FAccT 2021: 610-623.
^ref-bender2021

Bengson, John, and Marc A. Moffett. 2011. *Knowing How: Essays on Knowledge, Mind, and Action*. New York: Oxford University Press.
^ref-bengsonMoffett2011

Benjamin, Walter. 1936. “The Work of Art in the Age of Mechanical Reproduction (Das Kunstwerk im Zeitalter seiner technischen Reproduzierbarkeit).” *Zeitschrift für Sozialforschung* 5 (1).
^ref-benjamin1936

Benkler, Yochai. 2006. *The Wealth of Networks: How Social Production Transforms Markets and Freedom*. Yale University Press.
^ref-benkler2006

Benkler, Yochai, Robert Faris, and Hal Roberts. 2018. *Network Propaganda: Manipulation, Disinformation, and Radicalization in American Politics*. Oxford University Press.
^ref-benklerfarisroberts2018

Benson, Herbert, et al. 2006. “Study of the Therapeutic Effects of Intercessory Prayer (STEP) in Cardiac Bypass Patients: A Multicenter Randomized Trial of Uncertainty and Certainty of Receiving Intercessory Prayer.” *American Heart Journal*.
^ref-benson2006

Bentham, Jeremy. 1789. *An Introduction to the Principles of Morals and Legislation*. London: T. Payne and Son.
^ref-bentham1789

Berdoy, M., J. P. Webster, and D. W. Macdonald. 2000. “Fatal Attraction in Rats Infected with Toxoplasma gondii.” *Proceedings of the Royal Society B* 267 (1452): 1591–1594.
^ref-berdoy2000

Bergmann, Michael. 2001. “Skeptical Theism and Rowe's New Evidential Argument from Evil.” *Noûs* 35, no. 2 (2001): 278–296.
^ref-bergmann2001

Bergmann, Michael, and Jeffrey E. Brower. 2006. “A Theistic Argument against Platonism (and in Support of Truthmakers and Divine Simplicity).” In D. Zimmerman (ed.), Oxford Studies in Metaphysics, vol. 2: 357–386. Oxford University Press.
^ref-bergmannBrower2006

Bergmann, Michael. 2012. “Commonsense Skeptical Theism.” in Reason, Metaphysics, and Mind: New Essays on the Philosophy of Alvin Plantinga, eds. Clark and Rea (Oxford University Press): 9–30.
^ref-bergmann2012

Bergson, Henri. 1907. *Creative Evolution (L'Évolution créatrice)*. Félix Alcan (Paris).
^ref-bergson1907

Berkeley, George. 1710. *A Treatise Concerning the Principles of Human Knowledge*. Dublin: Aaron Rhames, for Jeremy Pepyat (1710).
^ref-berkeley1710

Berkeley, George. 1713. *Three Dialogues between Hylas and Philonous*. London: Printed by G. James for Henry Clements (1713).
^ref-berkeley1713

Berlin, Isaiah. 1958. *Two Concepts of Liberty*. Oxford: Clarendon Press.
^ref-berlin1958

Berlin, Isaiah. 1969. *Four Essays on Liberty*. Oxford University Press.
^ref-berlin1969

Berlyne, Daniel E. 1960. *Conflict, Arousal, and Curiosity*. McGraw-Hill.
^ref-berlyne1960

Berridge, Kent C., and Terry E. Robinson. 1998. “What Is the Role of Dopamine in Reward: Hedonic Impact, Reward Learning, or Incentive Salience?” *Brain Research Reviews* 28(3): 309–369.
^ref-berridgeRobinson1998

Berridge, Kent C. 2007. “The Debate over Dopamine's Role in Reward: The Case for Incentive Salience.” *Psychopharmacology* 191(3): 391–431.
^ref-berridge2007

Berry, Wendell. 1977. *The Unsettling of America: Culture and Agriculture*. San Francisco: Sierra Club Books.
^ref-berry1977

Berto, Francesco, and Mark Jago. 2019. *Impossible Worlds*. Oxford University Press.
^ref-bertoJago2019

Bettcher, Talia Mae. 2014. “Trapped in the Wrong Theory: Rethinking Trans Oppression and Resistance.” Signs: Journal of Women in Culture and Society 39 (2): 383-406.
^ref-bettcher2014

Beveridge, William. 1942. “Social Insurance and Allied Services (The Beveridge Report).” HMSO.
^ref-beveridge1942

Bickerton, Derek. 1981. *Roots of Language*. Karoma Publishers.
^ref-bickerton1981

Bickerton, Derek. 1984. “The Language Bioprogram Hypothesis.”
^ref-bickerton1984

Bijker, Wiebe E. 1995. *Of Bicycles, Bakelites, and Bulbs: Toward a Theory of Sociotechnical Change*. MIT Press.
^ref-bijker1995

Bird, Alexander. 2007. *Nature's Metaphysics: Laws and Properties*. Oxford University Press.
^ref-bird2007

Bird, Christopher D., and Nathan J. Emery. 2009. “Insightful Problem Solving and Creative Tool Modification by Captive Nontool-Using Rooks.” *PNAS* 106(25): 10370–10375.
^ref-birdEmery2009

Bird, Alexander. 2010. “Social Knowing: The Social Sense of 'Scientific Knowledge'.” *Philosophical Perspectives* 24(1): 23–56.
^ref-bird2010

Black, Max. 1952. “The Identity of Indiscernibles.” *Mind*.
^ref-black1952

Blackburn, Simon. 1984. *Spreading the Word: Groundings in the Philosophy of Language*. Oxford University Press.
^ref-blackburn1984

Blackburn, Simon. 1986. “Morals and Modals.” In Fact, Science and Morality: Essays on A. J. Ayer's Language, Truth and Logic, ed. Macdonald & Wright. Oxford: Blackwell.
^ref-blackburn1986

Blackburn, Simon. 1993. *Essays in Quasi-Realism*. Oxford University Press (New York).
^ref-blackburn1993

Blackburn, Simon. 1998. *Ruling Passions: A Theory of Practical Reasoning*. Oxford University Press.
^ref-blackburn1998

Block, Ned. 1995. “On a Confusion about a Function of Consciousness.” *Behavioral and Brain Sciences* 18 (2): 227–247.
^ref-block1995

Block, Daniel I. 1998. *The Book of Ezekiel, Chapters 25–48*. Eerdmans.
^ref-blockDaniel1998

Block, Ned. 1998. “Conceptual Role Semantics.” Routledge Encyclopedia of Philosophy (online edn 1998).
^ref-block1998

Bloom, Paul. 2010. *How Pleasure Works: The New Science of Why We Like What We Like*. W. W. Norton.
^ref-bloom2010

Bloom, Paul. 2013. *Just Babies: The Origins of Good and Evil*. Crown Publishers.
^ref-bloom2013

Bodnia, Eve et al. 2024. “The Quest for CMB Signatures of Conformal Cyclic Cosmology.” Journal of Cosmology and Astroparticle Physics 2024 (5): 009.
^ref-bodnia2024

Boersma, Hans. 2004. *Violence, Hospitality, and the Cross: Reappropriating the Atonement Tradition*. Baker Academic.
^ref-boersma2004

Boethius. (524) 1969. *The Consolation of Philosophy*. Translated by V. E. Watts. London: Penguin.
^ref-boethius524

Bogaert, Anthony F. 2004. “Asexuality: Prevalence and Associated Factors in a National Probability Sample.”
^ref-bogaert2004

Bogaert, Anthony F. 2012. *Understanding Asexuality*. Rowman & Littlefield Publishers.
^ref-bogaert2012

Bogardus, Tomas. 2016. “Only All Naturalists Should Worry About Only One Evolutionary Debunking Argument.” Ethics 126(3): 636-661.
^ref-bogardus2016

Boghossian, Paul. 1998. “What the Externalist Can Know A Priori.” *Philosophical Issues* 9 (Concepts): 197-211.
^ref-boghossian1998

Boghossian, Paul. 2006. *Fear of Knowledge: Against Relativism and Constructivism*. Oxford University Press.
^ref-boghossian2006

Bojowald, Martin. 2010. *Once Before Time: A Whole Story of the Universe*. New York: Alfred A. Knopf.
^ref-bojowald2010

Bollier, David. 2014. *Think Like a Commoner: A Short Introduction to the Life of the Commons*. New Society Publishers.
^ref-bollier2014

Boltzmann, Ludwig. 1877. “Über die Beziehung zwischen dem zweiten Hauptsatze der mechanischen Wärmetheorie und der Wahrscheinlichkeitsrechnung.” *Sitzungsberichte der Kaiserlichen Akademie der Wissenschaften (Wien)* 76:373–435.
^ref-boltzmann1877

Bonanno, George A. 2009. *The Other Side of Sadness: What the New Science of Bereavement Tells Us About Life After Loss*. Basic Books.
^ref-bonanno2009

BonJour, Laurence, and Ernest Sosa. 2003. *Epistemic Justification: Internalism vs. Externalism, Foundations vs. Virtues*. Malden, MA: Blackwell.
^ref-bonjour2003

Bonner, J. T. 1998. “The Origins of Multicellularity.” *Integrative Biology* 1 (1): 27–36.
^ref-bonner1998

Boraas, M. E., D. B. Seale, and J. E. Boxhorn. 1998. “Phagotrophy by a Flagellate Selects for Colonial Prey: A Possible Origin of Multicellularity.” *Evolutionary Ecology* 12 (2): 153–164.
^ref-boraas1998

Borde, Arvind, Alan H. Guth, and Alexander Vilenkin. 2003. “Inflationary Spacetimes Are Incomplete in Past Directions.” *Physical Review Letters* 90 (15): 151301.
^ref-bordeGuthVilenkin2003

Borden, Iain. 2001. *Skateboarding, Space and the City: Architecture and the Body*. Oxford: Berg.
^ref-borden2001

Borghini, Andrea, and Neil E. Williams. 2008. “A Dispositional Theory of Possibility.” *Dialectica* 62 (1): 21-41.
^ref-borghiniWilliams2008

Borgia, Gerald. 1985. “Bower Quality, Number of Decorations, and Mating Success of Male Satin Bowerbirds (Ptilonorhynchus violaceus): An Experimental Analysis.” Animal Behaviour 33: 266-271.
^ref-borgia1985

Borgmann, Albert. 1984. *Technology and the Character of Contemporary Life: A Philosophical Inquiry*. University of Chicago Press.
^ref-borgmann1984

Boroditsky, Lera. 2001. “Does Language Shape Thought? Mandarin and English Speakers' Conceptions of Time.”
^ref-boroditsky2001

Boroditsky, Lera. 2011. “How Language Shapes Thought.” Scientific American.
^ref-boroditsky2011

Bostrom, Nick. 2002. *Anthropic Bias: Observation Selection Effects in Science and Philosophy*. Routledge (New York).
^ref-bostrom2002

Bostrom, Nick. 2003. “Are You Living in a Computer Simulation?” *The Philosophical Quarterly* 53(211): 243–255.
^ref-bostrom2003

Bostrom, Nick. 2005. “Transhumanist Values.” Review of Contemporary Philosophy 4 (1-2): 87-101.
^ref-bostrom2005

Bostrom, Nick. 2014. *Superintelligence: Paths, Dangers, Strategies*. Oxford University Press.
^ref-bostrom2014

Botero, Carlos A., et al. 2014. “The Ecology of Religious Beliefs.” Proceedings of the National Academy of Sciences.
^ref-botero2014

Bourdieu, Pierre, and Jean-Claude Passeron. 1970. *Reproduction in Education, Society and Culture*. Éditions de Minuit, Paris; Eng. trans. Sage, 1977.
^ref-bourdieuPasseron1970

Bowen, Joshua. 2021. *Did the Old Testament Endorse Slavery?* Digital Hammurabi Press.
^ref-bowen2021

Bowlby, John. 1969. *Attachment and Loss, Vol. 1: Attachment*. Basic Books.
^ref-bowlby1969

Bowles, Samuel, and Herbert Gintis. 1976. *Schooling in Capitalist America: Educational Reform and the Contradictions of Economic Life*. Basic Books.
^ref-bowlesGintis1976

Bowman, Samuel R. 2023. “Eight Things to Know About Large Language Models.” arXiv:2304.00612.
^ref-bowman2023

Boyarin, Daniel. 2004. *Border Lines: The Partition of Judaeo-Christianity*. Philadelphia: University of Pennsylvania Press.
^ref-boyarin2004

Boyd, Richard N. 1988. “How to Be a Moral Realist.”
^ref-boyd1988

Boyd, Richard. 1991. “Realism, Anti-Foundationalism and the Enthusiasm for Natural Kinds.” *Philosophical Studies* 61 (1/2): 127–148.
^ref-boyd1991

Boyd, Gregory A. 2001. *Satan and the Problem of Evil: Constructing a Trinitarian Warfare Theodicy*. InterVarsity Press (IVP Academic).
^ref-boyd2001

Boyd, Brian. 2009. *On the Origin of Stories: Evolution, Cognition, and Fiction*. Belknap Press of Harvard University Press.
^ref-boyd2009

Boyd, Robert, Peter J. Richerson, and Joseph Henrich. 2011. “The Cultural Niche: Why Social Learning Is Essential for Human Adaptation.”
^ref-boydRichersonHenrich2011

Boyer, P. 2001. *Religion Explained: The Evolutionary Origins of Religious Thought*. New York: Basic Books.
^ref-boyer2001

Bracken, Joseph A. 1985. *The Triune Symbol: Persons, Process and Community*. University Press of America (Lanham, MD).
^ref-bracken1985

Bracken, Joseph A. 1991. *Society and Spirit: A Trinitarian Cosmology*. Susquehanna University Press / Associated University Presses (Cranbury, NJ).
^ref-bracken1991

Bradley, Ben. 2009. *Well-Being and Death*. Clarendon Press.
^ref-bradley2009

Bradshaw, David. 2004. *Aristotle East and West: Metaphysics and the Division of Christendom*. Cambridge University Press.
^ref-bradshaw2004

Brady, William J., Julian A. Wills, John T. Jost, Joshua A. Tucker, and Jay J. Van Bavel. 2017. “Emotion Shapes the Diffusion of Moralized Content in Social Networks.” *PNAS* 114 (28): 7313–7318.
^ref-brady2017

Braithwaite, John. 1989. *Crime, Shame and Reintegration*. Cambridge University Press.
^ref-braithwaite1989

Branas, Charles C., Eugenia South, Michelle C. Kondo, Bernadette C. Hohl, Philippe Bourgois, Douglas J. Wiebe, and John M. MacDonald. 2018. “Citywide Cluster Randomized Trial to Restore Blighted Vacant Land and Its Effects on Violence, Crime, and Fear.” *Proceedings of the National Academy of Sciences* 115 (12): 2946–2951.
^ref-branas2018

Brandenberger, R., and P. Peter. 2017. “Bouncing Cosmologies: Progress and Problems.” *Foundations of Physics* 47 (6): 797–850.
^ref-brandenbergerPeter2017

Brandom, Robert B. 1994. *Making It Explicit: Reasoning, Representing, and Discursive Commitment*. Harvard University Press.
^ref-brandom1994

Brandom, Robert B. 2008. *Between Saying and Doing: Towards an Analytic Pragmatism*. Oxford University Press.
^ref-brandom2008

Bratman, Michael E. 2007. *Structures of Agency: Essays*. Oxford University Press (New York).
^ref-bratman2007

Braverman, Harry. 1974. *Labor and Monopoly Capital: The Degradation of Work in the Twentieth Century*. Monthly Review Press.
^ref-braverman1974

Brennan, Patricia L. R., and Richard O. Prum. 2015. “Mechanisms and Evidence of Genital Coevolution: The Roles of Natural Selection, Mate Choice, and Sexual Conflict.” *Cold Spring Harbor Perspectives in Biology* 7 (7): a017749.
^ref-brennanprum2015

Brennan, Jason. 2016. *Against Democracy*. Princeton University Press.
^ref-brennan2016

Brentano, Franz. 1874. *Psychology from an Empirical Standpoint*. Duncker & Humblot.
^ref-brentano1874

Brewer, Judson A., Patrick D. Worhunsky, Jeremy R. Gray, Yi-Yuan Tang, Jochen Weber, and Hedy Kober. 2011. “Meditation Experience Is Associated with Differences in Default Mode Network Activity and Connectivity.” *Proceedings of the National Academy of Sciences* 108 (50): 20254–20259.
^ref-brewer2011

Bricker, Phillip. 2020. *Modal Matters: Essays in Metaphysics*. Oxford University Press.
^ref-bricker2020

Bridgman, Percy Williams. 1922. *Dimensional Analysis*. New Haven: Yale University Press.
^ref-bridgman1922

Briggs, Robert, Mark Ward, and Rose Anne Kenny. 2021. “The 'Wish to Die' in later life: prevalence, longitudinal course and mortality. Data from TILDA.” *Age and Ageing* 50(4): 1321–1328.
^ref-briggs2021

Brink, David O. 1986. “Externalist Moral Realism.” *Southern Journal of Philosophy* 24 (S1): 23–41.
^ref-brink1986

Brink, David O. 1989. *Moral Realism and the Foundations of Ethics*. Cambridge University Press.
^ref-brink1989

Broad, C. D. 1938. *An Examination of McTaggart's Philosophy*. Cambridge University Press.
^ref-broad1938

Brock, Stuart. 1993. “Modal Fictionalism: A Response to Rosen.” *Mind* 102(405): 147–150.
^ref-brock1993

Brondízio, E. S., J. Settele, S. Díaz, and H. T. Ngo. 2019. “Global Assessment Report on Biodiversity and Ecosystem Services of the Intergovernmental Science-Policy Platform on Biodiversity and Ecosystem Services.” IPBES secretariat, Bonn, Germany.
^ref-ipbes2019

Broom, Donald M. 1991. “Animal Welfare: Concepts and Measurement.” *Journal of Animal Science* 69 (10): 4167–4175.
^ref-broom1991

Brosnan, Sarah F., and Frans B. M. de Waal. 2003. “Monkeys Reject Unequal Pay.” Nature.
^ref-brosnanDeWaal2003

Brouwer, L. E. J. 1907. “Over de grondslagen der wiskunde (On the Foundations of Mathematics).” Doctoral dissertation, University of Amsterdam.
^ref-brouwer1907

Brower, Jeffrey E., and Michael C. Rea. 2005. “Material Constitution and the Trinity.” *Faith and Philosophy* 22 (1): 57–76.
^ref-browerRea2005

Brower, Jeffrey E. 2009. “Simplicity and Aseity.” In The Oxford Handbook of Philosophical Theology, edited by Thomas P. Flint and Michael C. Rea, 105–128. Oxford: Oxford University Press.
^ref-brower2009

Brown, D. E. 1991. *Human Universals*. New York: McGraw-Hill.
^ref-brown1991

Brown, Raymond E. 1993. *The Birth of the Messiah: A Commentary on the Infancy Narratives in the Gospels of Matthew and Luke*. New updated ed. New York: Doubleday.
^ref-brown1993birth

Brown, Raymond E. 1997. *An Introduction to the New Testament*. New York: Doubleday.
^ref-brown1997

Brown, Culum. 2015. “Fish Intelligence, Sentience and Ethics.” *Animal Cognition* 18 (1): 1–17.
^ref-brown2015

Brulle, Robert J. 2014. “Institutionalizing delay: foundation funding and the creation of U.S. climate change counter-movement organizations.” *Climatic Change* 122(4): 681–694.
^ref-brulle2014

Buchanan, James M., and Gordon Tullock. 1962. *The Calculus of Consent: Logical Foundations of Constitutional Democracy*. University of Michigan Press.
^ref-buchanantullock1962

Buchanan, Allen E., and Dan W. Brock. 1989. *Deciding for Others: The Ethics of Surrogate Decision Making*. Cambridge University Press.
^ref-buchananBrock1989

Buchanan, Allen. 2004. *Justice, Legitimacy, and Self-Determination: Moral Foundations for International Law*. Oxford University Press.
^ref-buchanan2004

Buckareff, Andrei A., and Yujin Nagasawa. 2016. *Alternative Concepts of God: Essays on the Metaphysics of the Divine*. Oxford University Press.
^ref-buckareffNagasawa2016

Buckingham, Edgar. 1914. “On Physically Similar Systems; Illustrations of the Use of Dimensional Equations.” *Physical Review* 4(4):345–376.
^ref-buckingham1914

Buckner, Randy L., Jessica R. Andrews-Hanna, and Daniel L. Schacter. 2008. “The Brain's Default Network: Anatomy, Function, and Relevance to Disease.” *Annals of the New York Academy of Sciences* 1124: 1–38.
^ref-buckner2008

Bueno, Otávio, and Steven French. 2018. *Applying Mathematics: Immersion, Inference, Interpretation*. Oxford University Press.
^ref-buenoFrench2018

Bugnyar, Thomas, Stephan A. Reber, and Cameron Buckner. 2016. “Ravens attribute visual access to unseen competitors.” *Nature Communications* 7: 10506.
^ref-bugnyar2016

Bühler, Karl. 1934. *Sprachtheorie: Die Darstellungsfunktion der Sprache*. Gustav Fischer (Jena).
^ref-buhler1934

Bullard, Robert D. 1990. *Dumping in Dixie: Race, Class, and Environmental Quality*. Westview Press.
^ref-bullard1990

Bunge, Mario. 1985. *Treatise on Basic Philosophy, Vol. 7: Philosophy of Science and Technology*. Reidel.
^ref-bunge1985

Burgess, John P. 1997. “Quinus ab Omni Naevo Vindicatus.” *Canadian Journal of Philosophy, Supplementary Volume* 23.
^ref-burgess1997

Burghardt, Gordon M. 2005. *The Genesis of Animal Play: Testing the Limits*. MIT Press.
^ref-burghardt2005

Burke, Edmund. (1790) 1987. *Reflections on the Revolution in France*. Edited by J. G. A. Pocock. Indianapolis: Hackett.
^ref-burke1790

Burke, Edmund. 1774. “Speech to the Electors of Bristol.” Delivered at Bristol, 3 November 1774.
^ref-burke1774

Burrell, David B. 1979. *Aquinas: God and Action*. Routledge & Kegan Paul (London).
^ref-burrell1979

Burrell, David B. 1986. *Knowing the Unknowable God: Ibn-Sina, Maimonides, Aquinas*. Notre Dame: University of Notre Dame Press.
^ref-burrell1986

Buss, David M. 1989. “Sex Differences in Human Mate Preferences: Evolutionary Hypotheses Tested in 37 Cultures.”
^ref-buss1989

Buss, David M. 2019. *Evolutionary Psychology: The New Science of the Mind*. Routledge.
^ref-buss2019

Butler, Judith. 1990. *Gender Trouble: Feminism and the Subversion of Identity*. Routledge.
^ref-butler1990

Butler, Judith. 1993. *Bodies That Matter: On the Discursive Limits of Sex*. Routledge.
^ref-butler1993

Byne, W., S. Tobet, L. A. Mattiace, M. S. Lasco, E. Kemether, M. A. Edgar, S. Morgello, M. S. Buchsbaum, L. B. Jones, and B. MacEwen. 2001. “The Interstitial Nuclei of the Human Anterior Hypothalamus: An Investigation of Variation with Sex, Sexual Orientation, and HIV Status.” *Hormones and Behavior* 40 (2): 86–92.
^ref-byne2001

Byrne, R. W., and A. Whiten. 1988. *Machiavellian Intelligence: Social Expertise and the Evolution of Intellect in Monkeys, Apes, and Humans*. Oxford: Clarendon Press.
^ref-byrneWhiten1988

Cajetan. (1498) 1953. *De Nominum Analogia*. Translated by E. Bushinski. Pittsburgh: Duquesne University Press.
^ref-cajetan1498

Calhoun, Craig. 1992. *Habermas and the Public Sphere*. MIT Press.
^ref-calhoun1992

Call, Josep, and Michael Tomasello. 2008. “Does the Chimpanzee Have a Theory of Mind? 30 Years Later.” *Trends in Cognitive Sciences* 12 (5): 187–192.
^ref-callTomasello2008

Callan, Eamonn. 1997. *Creating Citizens: Political Education and Liberal Democracy*. Oxford University Press (Clarendon Press).
^ref-callan1997

Callender, Craig. 2011. *The Oxford Handbook of Philosophy of Time*. Oxford University Press.
^ref-callender2011

Calvin, John. (1559) 1960. *Institutes of the Christian Religion*. Ed. John T. McNeill, trans. Ford Lewis Battles. Louisville: Westminster John Knox Press, 1960.
^ref-calvin1559

Calvo, Paco. 2016. “The Philosophy of Plant Neurobiology: A Manifesto.” *Synthese* 193(5): 1323–1343.
^ref-calvo2016

Cameron, Ross P. 2008. “Truthmakers and Ontological Commitment.” *Philosophical Studies* 140(1): 1–18.
^ref-cameron2008

Cameron, Ross P. 2010. “On the Source of Necessity.” in Bob Hale & Aviv Hoffmann (eds.), Modality: Metaphysics, Logic, and Epistemology (Oxford University Press), pp. 137–152.
^ref-cameron2010

Campbell, Keith. 1990. *Abstract Particulars*. Basil Blackwell (Oxford).
^ref-campbell1990

Camus, Albert. 1942. *The Myth of Sisyphus (Le Mythe de Sisyphe)*. Gallimard.
^ref-camus1942

Cannon, Walter B. 1932. *The Wisdom of the Body*. W. W. Norton.
^ref-cannon1932

Anselm of Canterbury. (1078) 1998. “Proslogion.” In The Major Works, edited by B. Davies and G. Evans. Oxford: Oxford University Press.
^ref-anselm1078

Anselm of Canterbury. (1098) 1998. *Cur Deus Homo (Why God Became Man)*. in Anselm of Canterbury: The Major Works, eds. Brian Davies & G. R. Evans, trans. Janet Fairweather; Oxford: Oxford University Press, 1998.
^ref-anselm1098

Cao, Tian Yu. 1997. *Conceptual Developments of 20th Century Field Theories*. Cambridge University Press.
^ref-cao1997

Caplan, Bryan. 2007. *The Myth of the Rational Voter: Why Democracies Choose Bad Policies*. Princeton University Press.
^ref-caplan2007

Carhart-Harris, R. L., D. Erritzoe, T. Williams, J. M. Stone, L. J. Reed, A. Colasanti, R. J. Tyacke, R. Leech, A. L. Malizia, K. Murphy, P. Hobden, J. Evans, A. Feilding, R. G. Wise, and D. J. Nutt. 2012. “Neural Correlates of the Psychedelic State as Determined by fMRI Studies with Psilocybin.” *Proceedings of the National Academy of Sciences* 109 (6): 2138–2143.
^ref-carhartHarris2012

Carhart-Harris, Robin L. et al. 2014. “The Entropic Brain: A Theory of Conscious States Informed by Neuroimaging Research with Psychedelic Drugs.” Frontiers in Human Neuroscience 8: 20.
^ref-carhartHarris2014

Carhart-Harris, Robin L., and Karl J. Friston. 2019. “REBUS and the Anarchic Brain: Toward a Unified Model of the Brain Action of Psychedelics.” *Pharmacological Reviews* 71 (3): 316–344.
^ref-carhartHarris2019

Carnap, Rudolf. 1928. *Der logische Aufbau der Welt (The Logical Structure of the World)*. Berlin: Weltkreis-Verlag.
^ref-carnap1928

Carnap, Rudolf. 1932. “Überwindung der Metaphysik durch logische Analyse der Sprache (The Elimination of Metaphysics Through Logical Analysis of Language).” *Erkenntnis* 2.
^ref-carnap1932

Carnap, Rudolf. 1934. *The Unity of Science*. London: Kegan Paul (trans. M. Black).
^ref-carnap1934

Carnap, Rudolf. 1937. *The Logical Syntax of Language*. London: Kegan Paul (trans. A. Smeaton).
^ref-carnap1937

Carnap, Rudolf. 1950. “Empiricism, Semantics, and Ontology.” *Revue Internationale de Philosophie* 4 (11): 20–40.
^ref-carnap1950

Carnegie, Andrew. 1889. “Wealth.” *North American Review* 148 (June): 653–664.
^ref-carnegie1889

Carr, Nicholas. 2010. *The Shallows: What the Internet Is Doing to Our Brains*. W. W. Norton.
^ref-carr2010

Carr, David M. 2020. *The Formation of Genesis 1–11: Biblical and Other Precursors*. Oxford University Press.
^ref-carr2020genesis

Carroll, Sean M. 2004. *Spacetime and Geometry: An Introduction to General Relativity*. San Francisco: Addison-Wesley.
^ref-carroll2004

Carroll, Sean. 2010. *From Eternity to Here: The Quest for the Ultimate Theory of Time*. Dutton (New York).
^ref-carroll2010

Carroll, Sean M. 2012. “Does the Universe Need God?” In The Blackwell Companion to Science and Christianity, ed. J. B. Stump and Alan G. Padgett (Wiley-Blackwell), pp. 185–197.
^ref-carroll2012

Carroll, Sean. 2016. *The Big Picture: On the Origins of Life, Meaning, and the Universe Itself*. Dutton (New York).
^ref-carroll2016

Carroll, Sean M. 2017. “Why Boltzmann Brains Are Bad.” In S. Dasgupta, B. Weslake, and R. Dotan (eds.), Current Controversies in Philosophy of Science (Routledge); arXiv:1702.00850.
^ref-carroll2017

Carruthers, Peter. 2000. *Phenomenal Consciousness: A Naturalistic Theory*. Cambridge University Press.
^ref-carruthers2000

Carruthers, Peter. 2008. “Meta-cognition in Animals: A Skeptical Look.” *Mind & Language* 23(1): 58–89.
^ref-carruthers2008

Carter, Brandon. 1974. “Large Number Coincidences and the Anthropic Principle in Cosmology.” in M. S. Longair (ed.), Confrontation of Cosmological Theories with Observational Data (IAU Symposium No. 63), D. Reidel (Dordrecht/Boston), pp. 291–298.
^ref-carter1974

Carter, B. 1983. “The Anthropic Principle and Its Implications for Biological Evolution.” *Philosophical Transactions of the Royal Society of London A* 310 (1512): 347–363.
^ref-carter1983

Carter, C. S. 1998. “Neuroendocrine Perspectives on Social Attachment and Love.” *Psychoneuroendocrinology* 23 (8): 779–818.
^ref-carter1998

Cartwright, Nancy. 1983. *How the Laws of Physics Lie*. Oxford University Press.
^ref-cartwright1983

Cartwright, Nancy. 1999. *The Dappled World: A Study of the Boundaries of Science*. Cambridge University Press.
^ref-cartwright1999

Caruso, Gregg D. 2012. *Free Will and Consciousness: A Determinist Account of the Illusion of Free Will*. Lexington Books.
^ref-caruso2012

Case, Anne, and Angus Deaton. 2020. *Deaths of Despair and the Future of Capitalism*. Princeton University Press.
^ref-caseDeaton2020

Casey, B. J., Rebecca M. Jones, and Todd A. Hare. 2008. “The Adolescent Brain.” Annals of the New York Academy of Sciences 1124: 111-126.
^ref-casey2008

Castelnovo, Anna, Simone Cavallotti, Orsola Gambini, and Armando D'Agostino. 2015. “Post-bereavement hallucinatory experiences: A critical overview of population and clinical studies.” *Journal of Affective Disorders* 186: 266–274.
^ref-castelnovo2015

Cavell, Stanley. 1979. *The Claim of Reason: Wittgenstein, Skepticism, Morality, and Tragedy*. Clarendon Press (Oxford) / Oxford University Press (New York).
^ref-cavell1979

Cavin, Robert Greg, and Carlos A. Colombetti. 2013. “Swinburne on the Resurrection: Negative versus Christian Ramified Natural Theology.” *Philosophia Christi* 15, no. 2 (2013): 253–263.
^ref-cavinColombetti2013

Ceballos, Gerardo, Paul R. Ehrlich, Anthony D. Barnosky, et al. 2015. “Accelerated modern human–induced species losses: Entering the sixth mass extinction.” *Science Advances* 1(5): e1400253.
^ref-ceballosEtAl2015

Cech, T. R., A. J. Zaug, and P. J. Grabowski. 1981. “In Vitro Splicing of the Ribosomal RNA Precursor of Tetrahymena: Involvement of a Guanosine Nucleotide in the Excision of the Intervening Sequence.” *Cell* 27 (3): 487–496.
^ref-cech1981

Centers for Disease Control and Prevention. 2011. “CDC Health Disparities and Inequalities Report — United States, 2011.” Morbidity and Mortality Weekly Report (MMWR) Supplement, Vol. 60; U.S. Dept. of Health and Human Services / CDC.
^ref-cdc2011

Chadwick, Edwin. 1842. “Report on the Sanitary Condition of the Labouring Population of Great Britain.” HMSO, London.
^ref-chadwick1842

Chaisson, E. J. 2001. *Cosmic Evolution: The Rise of Complexity in Nature*. Cambridge, MA: Harvard University Press.
^ref-chaisson2001

Chakravartty, Anjan. 2007. *A Metaphysics for Scientific Realism: Knowing the Unobservable*. Cambridge University Press.
^ref-chakravartty2007

Chalmers, David J. 1996. *The Conscious Mind: In Search of a Fundamental Theory*. Oxford University Press.
^ref-chalmers1996

Chalmers, David J., and Frank Jackson. 2001. “Conceptual Analysis and Reductive Explanation.” *The Philosophical Review* 110 (3): 315–360.
^ref-chalmersJackson2001

Chalmers, David J. 2002. “Does Conceivability Entail Possibility?” in Conceivability and Possibility (eds. Gendler & Hawthorne), Oxford University Press.
^ref-chalmers2002

Chalmers, David J. 2009. “Ontological Anti-Realism.” in Chalmers, Manley & Wasserman (eds.), Metametaphysics: New Essays on the Foundations of Ontology (Oxford University Press), pp. 77–129.
^ref-chalmers2009

Chalmers, David J. 2010. *The Character of Consciousness*. Oxford University Press.
^ref-chalmers2010

Chalmers, David J. 2012. *Constructing the World*. Oxford University Press.
^ref-chalmers2012

Chalmers, David J. 2015. “Panpsychism and Panprotopsychism.” in T. Alter & Y. Nagasawa (eds.), Consciousness in the Physical World: Perspectives on Russellian Monism (Oxford University Press).
^ref-chalmers2015

Chalmers, David J. 2016. “The Combination Problem for Panpsychism.” in G. Brüntrup & L. Jaskolla (eds.), Panpsychism: Contemporary Perspectives (Oxford University Press), ch. 7.
^ref-chalmers2016

Chalmers, David J. 2018. “The Meta-Problem of Consciousness.” *Journal of Consciousness Studies* 25(9–10): 6–61.
^ref-chalmers2018

Chalmers, David J. 2022. *Reality+: Virtual Worlds and the Problems of Philosophy*. W. W. Norton & Company.
^ref-chalmers2022

Chalmers, David J. 2023. “Could a Large Language Model Be Conscious?” arXiv:2303.07103.
^ref-chalmers2023

Chandler, Hugh S. 1976. “Plantinga and the Contingently Possible.” *Analysis* 36 (2): 106–109.
^ref-chandler1976

Charnov, Eric L. 1976. “Optimal Foraging, the Marginal Value Theorem.” *Theoretical Population Biology* 9(2): 129–136.
^ref-charnov1976

Chisholm, Roderick M. 1964. “Human Freedom and the Self.”
^ref-chisholm1964

Chisholm, Roderick M. 1967. “Identity through Possible Worlds: Some Questions.” *Noûs* 1 (1): 1–8.
^ref-chisholm1967

Chittka, Lars. 2022. *The Mind of a Bee*. Princeton University Press.
^ref-chittka2022

Chomsky, Noam. 1965. *Aspects of the Theory of Syntax*. MIT Press.
^ref-chomsky1965

Chomsky, Noam. 1986. *Knowledge of Language: Its Nature, Origin, and Use*. Praeger.
^ref-chomsky1986

Christensen, David. 2007. “Epistemology of Disagreement: The Good News.” The Philosophical Review 116 (2): 187-217.
^ref-christensen2007

Christian, David. 2004. *Maps of Time: An Introduction to Big History*. Berkeley: University of California Press.
^ref-christian2004

Christiano, Thomas. 2008. *The Constitution of Equality: Democratic Authority and Its Limits*. Oxford: Oxford University Press.
^ref-christiano2008

Churchland, Paul M. 1981. “Eliminative Materialism and the Propositional Attitudes.” *The Journal of Philosophy* 78(2): 67–90.
^ref-churchland1981

Churchland, Paul M. 1986. “Some Reductive Strategies in Cognitive Neurobiology.” *Mind* 95(379): 279–309.
^ref-churchland1986

Churchland, Paul M. 1989. *A Neurocomputational Perspective: The Nature of Mind and the Structure of Science*. MIT Press / Bradford Books (Cambridge, MA).
^ref-churchland1989

Clark, Andy. 1997. *Being There: Putting Brain, Body, and World Together Again*. Cambridge, MA: MIT Press.
^ref-clark1997

Clark, Andy, and David J. Chalmers. 1998. “The Extended Mind.”
^ref-clarkChalmers1998

Clark, Andy. 2008. *Supersizing the Mind: Embodiment, Action, and Cognitive Extension*. Oxford / New York: Oxford University Press.
^ref-clark2008

Clark, A. 2013. “Whatever Next? Predictive Brains, Situated Agents, and the Future of Cognitive Science.” *Behavioral and Brain Sciences* 36 (3): 181–204.
^ref-clark2013

Clark, Andy. 2016. *Surfing Uncertainty: Prediction, Action, and the Embodied Mind*. Oxford University Press (New York).
^ref-clark2016

Clausius, Rudolf. 1865. “Ueber verschiedene für die Anwendung bequeme Formen der Hauptgleichungen der mechanischen Wärmetheorie.” *Annalen der Physik* 125:353–400.
^ref-clausius1865

Clayton, Philip. 1997. *God and Contemporary Science*. Edinburgh University Press / Eerdmans (Grand Rapids).
^ref-clayton1997

Clayton, Nicola S., and Anthony Dickinson. 1998. “Episodic-like memory during cache recovery by scrub jays.” *Nature* 395(6699): 272–274.
^ref-clayton1998

Clayton, Philip, and Arthur Peacocke. 2004. *In Whom We Live and Move and Have Our Being: Panentheistic Reflections on God's Presence in a Scientific World*. Eerdmans.
^ref-clayton2004

Cleland, Carol E. 2012. “Life Without Definitions.” *Synthese* 185(1):125–144.
^ref-cleland2012

Cleland, Carol E. 2019. *The Quest for a Universal Theory of Life: Searching for Life as We Don't Know It*. Cambridge: Cambridge University Press.
^ref-cleland2019

Cline, Eric H. 2014. *1177 B.C.: The Year Civilization Collapsed*. Princeton University Press (Turning Points in Ancient History).
^ref-cline2014

Coady, C. A. J. 1992. *Testimony: A Philosophical Study*. Oxford University Press.
^ref-coady1992

Coase, R. H. 1960. “The Problem of Social Cost.” *Journal of Law and Economics* 3: 1–44.
^ref-coase1960

Coates, Ta-Nehisi. 2014. “The Case for Reparations.” The Atlantic (June 2014 issue).
^ref-coates2014

Cobb, John B., Jr. 1965. *A Christian Natural Theology*. Westminster Press (Philadelphia).
^ref-cobb1965

Cobb, John B., Jr., and David Ray Griffin. 1976. *Process Theology: An Introductory Exposition*. Westminster Press (Philadelphia).
^ref-cobbGriffin1976

Cohen, G. A. 1978. *Karl Marx's Theory of History: A Defence*. Clarendon Press, Oxford.
^ref-cohen1978

Cohen, Neal J., and Larry R. Squire. 1980. “Preserved Learning and Retention of Pattern-Analyzing Skill in Amnesia: Dissociation of Knowing How and Knowing That.” *Science* 210(4466): 207–210.
^ref-cohenSquire1980

Cohen, Joshua. 1989. “Deliberation and Democratic Legitimacy.” In The Good Polity: Normative Analysis of the State, edited by Alan Hamlin and Philip Pettit, 17–34. Oxford: Blackwell.
^ref-cohen1989

Cohen, G. A. 1995. *Self-Ownership, Freedom, and Equality*. Cambridge University Press, Cambridge.
^ref-cohen1995

Cohen, Stewart. 1999. “Contextualism, Skepticism, and the Structure of Reasons.” *Philosophical Perspectives* 13 (Noûs Suppl. 13): 57–89.
^ref-cohen1999

Coleman, Sam. 2014. “The Real Combination Problem: Panpsychism, Micro-Subjects, and Emergence.” *Erkenntnis* 79, no. 1: 19–44.
^ref-coleman2014

Coleman, Gemma, Catharina Gress-Wright, Noémie Le Donné, and Hannah Ulferts. 2024. “Nurturing Social and Emotional Learning Across the Globe: Findings from the OECD Survey on Social and Emotional Skills 2023.” OECD Publishing.
^ref-oecd2023

Collingwood, R. G. 1938. *The Principles of Art*. Clarendon Press (Oxford).
^ref-collingwood1938

Collins, Randall. 1979. *The Credential Society: An Historical Sociology of Education and Stratification*. Columbia University Press.
^ref-collins1979

Collins, John J. 1993. *Daniel: A Commentary on the Book of Daniel*. Fortress Press.
^ref-collins1993

Collins, John J. 1995. *The Scepter and the Star: The Messiahs of the Dead Sea Scrolls and Other Ancient Literature*. Doubleday.
^ref-collins1995

Collins, C. John. 2006. *Genesis 1–4: A Linguistic, Literary, and Theological Commentary*. Phillipsburg, NJ: P&R Publishing.
^ref-collins2006

Collins, Robin. 2009. “The Teleological Argument: An Exploration of the Fine-Tuning of the Universe.” in W. L. Craig & J. P. Moreland (eds.), The Blackwell Companion to Natural Theology (Wiley-Blackwell), pp. 202–281.
^ref-collins2009

Colyvan, Mark. 2001. *The Indispensability of Mathematics*. Oxford University Press.
^ref-colyvan2001

Commission on Freedom of the Press (Robert M. Hutchins, chair). 1947. *A Free and Responsible Press: A General Report on Mass Communication*. University of Chicago Press.
^ref-hutchins1947

Commission on Social Determinants of Health (WHO), chaired by Michael Marmot. 2008. “Closing the Gap in a Generation: Health Equity through Action on the Social Determinants of Health — Final Report of the Commission on Social Determinants of Health.” World Health Organization, Geneva.
^ref-csdh2008

Comrie, Bernard. 1989. *Language Universals and Linguistic Typology*. Blackwell Publishers.
^ref-comrie1989

Conant, James. 2002. “The Method of the Tractatus.” in E. H. Reck (ed.), From Frege to Wittgenstein: Perspectives on Early Analytic Philosophy (Oxford University Press), pp. 374–462.
^ref-conant2002

Conard, Nicholas J., Maria Malina, and Susanne C. Münzel. 2009. “New Flutes Document the Earliest Musical Tradition in Southwestern Germany.” Nature 460: 737-740.
^ref-conard2009

Conee, Earl. 1994. “Phenomenal Knowledge.” *Australasian Journal of Philosophy* 72(2): 136–150.
^ref-conee1994

Cooke, L. 2022. *Bitch: On the Female of the Species*. New York: Basic Books.
^ref-cooke2022

Cooper, John W. 2006. *Panentheism—The Other God of the Philosophers: From Plato to the Present*. Baker Academic.
^ref-cooper2006

Cooper, Paul M. M. 2019–. “Fall of Civilizations.” Fall of Civilizations Podcast (audio/video series).
^ref-cooper2019

Copan, Paul. 2011. *Is God a Moral Monster? Making Sense of the Old Testament God*. Baker Books.
^ref-copan2011

Copan, Paul, and Matthew Flannagan. 2014. *Did God Really Command Genocide? Coming to Terms with the Justice of God*. Baker Books.
^ref-flannagan2014

Corcoran, Kevin. 2001. “Physical Persons and Postmortem Survival Without Temporal Gaps.” In Soul, Body, and Survival: Essays on the Metaphysics of Human Persons, ed. Kevin Corcoran, 201–217. Ithaca, NY: Cornell University Press.
^ref-corcoran2001

Correia, Fabrice, and Alexander Skiles. 2019. “Grounding, Essence, and Identity.” *Philosophy and Phenomenological Research*.
^ref-correiaSkiles2019

Costanza, Robert, Ralph d'Arge, Rudolf de Groot, et al. 1997. “The Value of the World's Ecosystem Services and Natural Capital.” *Nature* 387 (6630): 253–260.
^ref-costanza1997

Cottingham, John. 2003. *On the Meaning of Life*. Routledge.
^ref-cottingham2003

Cottrol, Robert J., and Raymond T. Diamond. 1991. “The Second Amendment: Toward an Afro-Americanist Reconsideration.” *Georgetown Law Journal* 80 (2): 309–361.
^ref-cottrolDiamond1991

Couenhoven, Jesse. 2013. *Stricken by Sin, Cured by Christ: Agency, Necessity, and Culpability in Augustinian Theology*. Oxford University Press.
^ref-couenhoven2013

Cowan, Tadlock; Feder, Jody. 2013. “The Pigford Cases: USDA Settlement of Discrimination Suits by Black Farmers.” Congressional Research Service, RS20430.
^ref-cowanFeder2013

Craig, William Lane. 1979. *The Kalām Cosmological Argument*. Macmillan (London) / Library of Philosophy and Religion.
^ref-craig1979

Craig, William Lane. 1987. *The Only Wise God: The Compatibility of Divine Foreknowledge and Human Freedom*. Baker Book House.
^ref-craig1987

Craig, William Lane. 1991. *Divine Foreknowledge and Human Freedom: The Coherence of Theism: Omniscience*. E. J. Brill (Brill's Studies in Intellectual History 19).
^ref-craig1991

Craig, William Lane, and Quentin Smith. 1993. *Theism, Atheism, and Big Bang Cosmology*. Oxford: Clarendon Press.
^ref-craigSmith1993

Craig, William Lane, and J. P. Moreland. 2000. *Naturalism: A Critical Analysis*. Routledge (London & New York), Routledge Studies in Twentieth Century Philosophy.
^ref-craigMoreland2000

Craig, William Lane. 2000. *The Tensed Theory of Time: A Critical Examination*. Kluwer Academic (Synthese Library, vol. 293), Dordrecht.
^ref-craig2000

Craig, William Lane. 2001a. *Time and the Metaphysics of Relativity*. Kluwer Academic Publishers.
^ref-craig2001

Craig, William Lane. 2001b. *God, Time, and Eternity: The Coherence of Theism II: Eternity*. Kluwer Academic Publishers.
^ref-craig2001b

Craig, William Lane. 2001c. *Time and Eternity: Exploring God's Relationship to Time*. Crossway.
^ref-craig2001c

Craig, William Lane. 2008. *Reasonable Faith: Christian Truth and Apologetics*. Wheaton: Crossway.
^ref-craig2008

Craig, William Lane, and James D. Sinclair. 2009. “The Kalam Cosmological Argument.” in W. L. Craig & J. P. Moreland (eds.), The Blackwell Companion to Natural Theology (Wiley-Blackwell), pp. 101–201.
^ref-craigSinclair2009

Craig, William Lane. 2016. *God Over All: Divine Aseity and the Challenge of Platonism*. Oxford University Press.
^ref-craig2016

Creel, Richard E. 1986. *Divine Impassibility: An Essay in Philosophical Theology*. Cambridge University Press.
^ref-creel1986

Crenshaw, Kimberlé. 1989. “Demarginalizing the Intersection of Race and Sex: A Black Feminist Critique of Antidiscrimination Doctrine, Feminist Theory and Antiracist Politics.” University of Chicago Legal Forum 1989: 139-167.
^ref-crenshaw1989

Crenshaw, Kimberlé. 1991. “Mapping the Margins: Intersectionality, Identity Politics, and Violence against Women of Color.” Stanford Law Review 43 (6): 1241-1299.
^ref-crenshaw1991

Crisp, Roger. 2006. *Reasons and the Good*. Oxford University Press.
^ref-crisp2006

Crisp, Oliver D. 2007. *Divinity and Humanity: The Incarnation Reconsidered*. Cambridge: Cambridge University Press.
^ref-crisp2007

Crisp, Oliver D. 2020. *Approaching the Atonement: The Reconciling Work of Christ*. Downers Grove, IL: IVP Academic, 2020.
^ref-crisp2020

Critchley, Simon. 2009. *The Book of Dead Philosophers*. Vintage.
^ref-critchley2009

Crivelli, Carlos, Sergio Jarillo, James A. Russell, and José-Miguel Fernández-Dols. 2016. “Reading Emotions from Faces in Two Indigenous Societies.” *Journal of Experimental Psychology: General* 145 (7): 830–843.
^ref-crivelli2016

Croft, William. 2003. *Typology and Universals*. Cambridge University Press.
^ref-croft2003

Crooks, G. E. 1999. “Entropy Production Fluctuation Theorem and the Nonequilibrium Work Relation for Free Energy Differences.” *Physical Review E* 60 (3): 2721–2726.
^ref-crooks1999

Crosby, Donald A. 2002. *A Religion of Nature*. State University of New York Press.
^ref-crosby2002

Cross, Frank Moore. 1973. *Canaanite Myth and Hebrew Epic: Essays in the History of the Religion of Israel*. Cambridge, MA: Harvard University Press.
^ref-cross1973

Cross, Richard. 2002. “Two Models of the Trinity?” *The Heythrop Journal* 43, no. 3: 275–294.
^ref-cross2002

Cross, Richard. 2005. *Duns Scotus on God*. Aldershot: Ashgate (Ashgate Studies in the History of Philosophical Theology).
^ref-cross2005

Crummett, Dustin, and Philip Swenson. 2019. “God and Moral Knowledge.” in Kevin Vallier and Joshua Rasmussen (eds.), A New Theist Response to the New Atheists (Routledge), 33-46.
^ref-crummettSwenson2019

Csete, Joanne et al. 2016. “Public Health and International Drug Policy.” The Lancet 387 (10026): 1427-1480.
^ref-csete2016

Curley, Edwin M. 1984. “Descartes on the Creation of the Eternal Truths.” *The Philosophical Review* 93 (4): 569–597.
^ref-curley1984

Currie, Gregory. 1990. *The Nature of Fiction*. Cambridge University Press.
^ref-currie1990

Currie, Gregory. 2010. *Narrative and Narrators: A Philosophy of Stories*. Oxford University Press.
^ref-currie2010

Curry, Oliver Scott, Daniel Austin Mullins, and Harvey Whitehouse. 2019. “Is It Good to Cooperate? Testing the Theory of Morality-as-Cooperation in 60 Societies.” Current Anthropology 60 (1): 47-69.
^ref-curry2019

Cutter, Brian, and Bradford Saad. 2024. “The Problem of Nomological Harmony.” Noûs 58(2): 482–504.
^ref-cutterSaad2024

Cutter, Brian, and Dustin Crummett. 2025. “Psychophysical Harmony: A New Argument for Theism.” Oxford Studies in Philosophy of Religion 11: 33–71.
^ref-cutterCrummett2025

Cutter, Brian, and Philip Swenson. forthcoming. “The Omission Theodicy.” Oxford Studies in Philosophy of Religion.
^ref-cutterSwensonForthcoming

Cyranoski, David, and Heidi Ledford. 2018. “Genome-Edited Baby Claim Provokes International Outcry.” Nature 563 (7733): 607-608.
^ref-cyranoskiLedford2018

D'Arms, Justin, and Daniel Jacobson. 2000. “Sentiment and Value.” *Ethics* 110 (4): 722–748.
^ref-dArmsJacobson2000

Dainton, Barry. 2010. *Time and Space*. Acumen (Durham) / McGill-Queen's University Press, 2nd ed.
^ref-dainton2010

Dalsgaard, Søren, Søren Dinesen Østergaard, James F. Leckman, et al. 2015. “Mortality in children, adolescents, and adults with attention deficit hyperactivity disorder: a nationwide cohort study.” *The Lancet* 385(9983):2190–2196.
^ref-dalsgaard2015

Daly, Herman E. 1977. *Steady-State Economics: The Economics of Biophysical Equilibrium and Moral Growth*. W. H. Freeman.
^ref-daly1977

Damasio, Antonio R. 1994. *Descartes' Error: Emotion, Reason, and the Human Brain*. New York: G. P. Putnam's Sons.
^ref-damasio1994

Damasio, Antonio R. 1996. “The Somatic Marker Hypothesis and the Possible Functions of the Prefrontal Cortex.” *Philosophical Transactions of the Royal Society B* 351 (1346): 1413–1420.
^ref-damasio1996

Damasio, Antonio R. 1999. *The Feeling of What Happens: Body and Emotion in the Making of Consciousness*. Harcourt Brace (New York).
^ref-damasio1999

Damasio, Antonio R. 2010. *Self Comes to Mind: Constructing the Conscious Brain*. Pantheon (New York).
^ref-damasio2010

Damasio, Antonio. 2018. *The Strange Order of Things: Life, Feeling, and the Making of Cultures*. Pantheon.
^ref-damasio2018

Damer, B., and D. Deamer. 2020. “The Hot Spring Hypothesis for an Origin of Life.” *Astrobiology* 20 (4): 429–452.
^ref-damerDeamer2020

Damon, William, and Daniel Hart. 1988. *Self-Understanding in Childhood and Adolescence*. Cambridge University Press.
^ref-damonHart1988

Danckert, James, and John D. Eastwood. 2020. *Out of My Skull: The Psychology of Boredom*. Harvard University Press.
^ref-danckert2020

Dancy, Jonathan. 1993. *Moral Reasons*. Blackwell.
^ref-dancy1993

Dancy, Jonathan. 2004. *Ethics Without Principles*. Oxford University Press.
^ref-dancy2004

Daniels, Norman. 1985. *Just Health Care*. Cambridge University Press.
^ref-daniels1985

Daniels, Norman. 2008. *Just Health: Meeting Health Needs Fairly*. Cambridge University Press.
^ref-daniels2008

Danto, Arthur C. 1964. “The Artworld.” The Journal of Philosophy.
^ref-danto1964

Danto, Arthur C. 1981. *The Transfiguration of the Commonplace: A Philosophy of Art*. Harvard University Press.
^ref-danto1981

Dasgupta, Shamik. 2009. “Individuals: An Essay in Revisionary Metaphysics.” *Philosophical Studies*.
^ref-dasgupta2009

Dasgupta, Shamik. 2014. “On the Plurality of Grounds.” *Philosophers' Imprint* 14 (20): 1–28.
^ref-dasgupta2014

Dasgupta, Shamik. 2015. “Substantivalism vs Relationalism About Space in Classical Physics.” *Philosophy Compass* 10(9):601–624.
^ref-dasgupta2015

Datson, Susan L., and Samuel J. Marwit. 1997. “Personality Constructs and Perceived Presence of Deceased Loved Ones.” Death Studies 21 (2): 131-146.
^ref-datsonMarwit1997

Davidson, Donald. 1967. “Truth and Meaning.” *Synthese* 17 (1): 304–323.
^ref-davidson1967

Davidson, Donald. 1970. “Mental Events.” In Experience and Theory, edited by Lawrence Foster and J. W. Swanson, 79–101. Amherst: University of Massachusetts Press.
^ref-davidson1970

Davidson, Donald. 1973. “Radical Interpretation.” *Dialectica* 27 (1): 313–328.
^ref-davidson1973

Davidson, Donald. 1974. “On the Very Idea of a Conceptual Scheme.”
^ref-davidson1974

Davidson, Donald. 1984. *Inquiries into Truth and Interpretation*. Oxford University Press.
^ref-davidson1984

Davidson, Herbert A. 1987. *Proofs for Eternity, Creation and the Existence of God in Medieval Islamic and Jewish Philosophy*. Oxford University Press (New York).
^ref-davidsonH1987

Davidson, Donald. 1987. “Knowing One's Own Mind.” *Proceedings and Addresses of the American Philosophical Association* 60 (3): 441–458.
^ref-davidson1987

Davies, Oliver, and Denys Turner. 2008. *Silence and the Word: Negative Theology and Incarnation*. Cambridge: Cambridge University Press.
^ref-davies2008

Davies, Paul C. W. 2011. “Searching for a Shadow Biosphere on Earth as a Test of the 'Cosmic Imperative'.” *Philosophical Transactions of the Royal Society A* 369(1936):624–632.
^ref-davies2011

Davis, Stephen T. 1993. *Risen Indeed: Making Sense of the Resurrection*. Grand Rapids, MI: Eerdmans.
^ref-davis1997

Davis, Angela Y. 2003. *Are Prisons Obsolete?* Seven Stories Press.
^ref-davis2003

Davison, Scott A. 2017. *Petitionary Prayer: A Philosophical Investigation*. Oxford: Oxford University Press.
^ref-davison2017

Daw, Nathaniel D., Yael Niv, and Peter Dayan. 2005. “Uncertainty-Based Competition Between Prefrontal and Dorsolateral Striatal Systems for Behavioral Control.” Nature Neuroscience.
^ref-dawNivDayan2005

Dawkins, Richard. 2006. *The God Delusion*. Bantam Press (London).
^ref-dawkins2006

de La Mettrie, Julien Offray. 1747. *Man a Machine (L'Homme Machine)*. Leiden: Elie Luzac.
^ref-laMettrie1747

de Molina, Luis. 1588. *Concordia liberi arbitrii cum gratiae donis (On the Compatibility of Free Choice with the Gifts of Grace)*. Lisbon (1st ed., 1588).
^ref-molina1588

de Waal, Frans B. M. 2008. “Putting the Altruism Back into Altruism: The Evolution of Empathy.”
^ref-deWaal2008

de Waal, Frans. 2016. *Are We Smart Enough to Know How Smart Animals Are?* W. W. Norton (New York).
^ref-deWaal2016

Deacon, Terrence W. 2012. *Incomplete Nature: How Mind Emerged from Matter*. New York: W. W. Norton.
^ref-deacon2012

Decety, Jean, and Philip L. Jackson. 2004. “The Functional Architecture of Human Empathy.”
^ref-decetyJackson2004

Dechêne, Alice, Christoph Stahl, Jochim Hansen, and Michaela Wänke. 2010. “The Truth About the Truth: A Meta-Analytic Review of the Truth Effect.” *Personality and Social Psychology Review* 14 (2): 238–257.
^ref-decheneEtAl2010

Deci, Edward L., and Richard M. Ryan. 2000. “The "What" and "Why" of Goal Pursuits: Human Needs and the Self-Determination of Behavior.”
^ref-deciRyan2000

Deecke, Volker B.; Ford, John K. B.; Spong, Paul. 2000. “Dialect Change in Resident Killer Whales: Implications for Vocal Learning and Cultural Transmission.” Animal Behaviour 60 (5): 629-638.
^ref-deeckeEtAl2000

DeFrancis, John. 1989. *Visible Speech: The Diverse Oneness of Writing Systems*. University of Hawaii Press.
^ref-defrancis1989

Della Rocca, Michael. 2010. “PSR.” *Philosophers' Imprint* 10 (7).
^ref-dellaRocca2010

Della Rocca, Michael. 2020. *The Parmenidean Ascent*. Oxford University Press.
^ref-dellaRocca2020

Dembski, William A. 1998. *The Design Inference: Eliminating Chance Through Small Probabilities*. Cambridge University Press (Cambridge Studies in Probability, Induction and Decision Theory).
^ref-dembski1998

Dembski, William A. 2002. *No Free Lunch: Why Specified Complexity Cannot Be Purchased Without Intelligence*. Rowman & Littlefield (Lanham, MD).
^ref-dembski2002

Dennett, Daniel C. 1984. *Elbow Room: The Varieties of Free Will Worth Wanting*. Cambridge, MA: MIT Press.
^ref-dennett1984

Dennett, Daniel C. 1991. *Consciousness Explained*. Little, Brown and Company (Boston).
^ref-dennett1991

Dennett, Daniel C. 2003. *Freedom Evolves*. New York: Viking.
^ref-dennett2003

Dennett, Daniel C. 2006. *Breaking the Spell: Religion as a Natural Phenomenon*. Viking.
^ref-dennett2006

Dennett, Daniel C. 2016. “Illusionism as the Obvious Default Theory of Consciousness.” *Journal of Consciousness Studies* 23 (11–12): 65–72.
^ref-dennett2016

Dennett, Daniel C. 2018. “Facing Up to the Hard Question of Consciousness.” *Philosophical Transactions of the Royal Society B* 373 (1755): 20170342.
^ref-dennett2018

DeRose, Keith. 1995. “Solving the Skeptical Problem.” *The Philosophical Review*.
^ref-deRose1995

Descartes, R. (1641) 1996. *Meditations on First Philosophy*. Translated by J. Cottingham. Cambridge: Cambridge University Press.
^ref-descartes1641

Descartes, René. 1630. “Letters to Mersenne (April–May 1630).” Letters to Mersenne, 15 April / 6 May / 27 May 1630 (AT I; trans. CSMK III).
^ref-descartes1630

Descartes, René. 1644. “Letters to Mesland (on the creation of the eternal truths).” In The Philosophical Writings of Descartes, vol. 3 (Correspondence).
^ref-descartes1644

DESI Collaboration and Adame, A. G. 2026. “DESI DR2 Results IV: Alcock-Paczyński Measurements from the Lyman Alpha Forest and Cosmological Constraints.” *arXiv:2607.27410*.
^ref-desiDR2Lya2026

Desposato, Scott. 2008. “Going Negative in Comparative Perspective: Electoral Rules and Campaign Strategies.” University of California, San Diego.
^ref-desposato2008

Deutsch, Eliot. 1969. *Advaita Vedānta: A Philosophical Reconstruction*. University of Hawaii Press.
^ref-deutsch1969

Deutsch, D. 1997. *The Fabric of Reality*. New York: Viking.
^ref-deutsch1997

Deutscher, Guy. 2010. *Through the Language Glass: Why the World Looks Different in Other Languages*. Metropolitan Books.
^ref-deutscher2010

Devall, Bill, and George Sessions. 1985. *Deep Ecology: Living as if Nature Mattered*. Gibbs M. Smith (Peregrine Smith Books).
^ref-devallsessions1985

Dever, William G. 2005. *Did God Have a Wife? Archaeology and Folk Religion in Ancient Israel*. Grand Rapids: Eerdmans.
^ref-dever2005

Dewey, John. 1899. *The School and Society*. University of Chicago Press.
^ref-dewey1899

Dewey, John. 1916. *Democracy and Education: An Introduction to the Philosophy of Education*. Macmillan.
^ref-dewey1916

Dewey, John. 1934. *Art as Experience*. Minton, Balch & Company.
^ref-dewey1934

Dewsbury, Donald A. 1972. “Patterns of Copulatory Behavior in Male Mammals.” *The Quarterly Review of Biology* 47 (1): 1–33.
^ref-dewsbury1972

Di Paolo, Ezequiel A. 2005. “Autopoiesis, Adaptivity, Teleology, Agency.”
^ref-diPaolo2005

Diamond, Cora. 1991. *The Realistic Spirit: Wittgenstein, Philosophy, and the Mind*. MIT Press (Cambridge, MA), Bradford Books / Representation and Mind series.
^ref-diamond1991

Diamond, Jared. 1997. *Guns, Germs, and Steel: The Fates of Human Societies*. W. W. Norton.
^ref-diamond1997

Diamond, Jared. 2005. *Collapse: How Societies Choose to Fail or Succeed*. Viking (Penguin Group), New York.
^ref-diamond2005

Diamond, Peter, and Emmanuel Saez. 2011. “The Case for a Progressive Tax: From Basic Research to Policy Recommendations.” *Journal of Economic Perspectives* 25 (4): 165–190.
^ref-diamondSaez2011

Dickie, George. 1974. *Art and the Aesthetic: An Institutional Analysis*. Cornell University Press.
^ref-dickie1974

Dickie, George. 1984. *The Art Circle: A Theory of Art*. Haven Publications.
^ref-dickie1984

DiNoia, J. A. 1992. *The Diversity of Religions: A Christian Perspective*. The Catholic University of America Press.
^ref-dinoia1992

Diósi, L. 1989. “Models for Universal Reduction of Macroscopic Quantum Fluctuations.” *Physical Review A* 40 (3): 1165–1174.
^ref-diosi1989

Dissanayake, Ellen. 1995. *Homo Aestheticus: Where Art Comes From and Why*. University of Washington Press.
^ref-dissanayake1995

Divers, John. 2002. *Possible Worlds*. Routledge (London), Problems of Philosophy series.
^ref-divers2002

Dolezal, James E. 2011. *God Without Parts: Divine Simplicity and the Metaphysics of God's Absoluteness*. Eugene, OR: Pickwick Publications.
^ref-dolezal2011

Dolezal, James E. 2017. *All That Is in God: Evangelical Theology and the Challenge of Classical Christian Theism*. Reformation Heritage Books (Grand Rapids).
^ref-dolezal2017

Domínguez-Rodrigo, Manuel, and Lucía Alcalá. 2016. “3.3-Million-Year-Old Stone Tools and Butchery Traces? More Evidence Needed.”
^ref-dominguezRodrigoAlcala2016

Donaldson, Sue, and Will Kymlicka. 2011. *Zoopolis: A Political Theory of Animal Rights*. Oxford University Press.
^ref-donaldsonkymlicka2011

Donaldson-Matasci, M. C., C. T. Bergstrom, and M. Lachmann. 2010. “The Fitness Value of Information.” *Oikos* 119 (2): 219–230.
^ref-donaldsonMatasci2010

Doolittle, W. Ford. 1999. “Phylogenetic Classification and the Universal Tree.” *Science* 284(5423):2124–2129.
^ref-doolittle1999

Doris, John M., and Alexandra Plakias. 2008. “How to Argue about Disagreement: Evaluative Diversity and Moral Realism.” In Moral Psychology, Volume 2: The Cognitive Science of Morality: Intuition and Diversity, edited by Walter Sinnott-Armstrong, 303–332. MIT Press.
^ref-dorisPlakias2008

Dorr, Cian. 2005. “What We Disagree About When We Disagree About Ontology.” in M. E. Kalderon (ed.), Fictionalism in Metaphysics (Oxford University Press), pp. 234–286.
^ref-dorr2005

Dougherty, Trent. 2014. *The Problem of Animal Pain: A Theodicy for All Creatures Great and Small*. New York: Palgrave Macmillan, 2014 (Palgrave Frontiers in Philosophy of Religion; xxiii+197 pp.; ISBN 9780230368484).
^ref-dougherty2014

Douglas-Hamilton, Iain, Shivani Bhalla, George Wittemyer, and Fritz Vollrath. 2006. “Behavioural Reactions of Elephants Towards a Dying and Deceased Matriarch.” Applied Animal Behaviour Science 100 (1-2): 87-102.
^ref-douglasHamilton2006

Dowe, Phil. 2000. *Physical Causation*. Cambridge: Cambridge University Press.
^ref-dowe2000

Draper, Paul. 1989. “Pain and Pleasure: An Evidential Problem for Theists.” *Noûs* 23(3).
^ref-draper1989

Dreier, James. 2004. “Meta-ethics and the Problem of Creeping Minimalism.” *Philosophical Perspectives* 18 (1): 23–44.
^ref-dreier2004

Dretske, F. I. 1970. “Epistemic Operators.” *Journal of Philosophy*.
^ref-dretske1970

Dretske, F. I. 1977. “Laws of Nature.” *Philosophy of Science* 44 (2): 248–268.
^ref-dretske1977

Dretske, Fred. 1995. *Naturalizing the Mind*. MIT Press.
^ref-dretske1995

Dreyfus, Hubert L. 1972. *What Computers Can't Do: A Critique of Artificial Reason*. New York: Harper & Row.
^ref-dreyfus1972

Dreyfus, Hubert L. 1992. *What Computers Still Can't Do: A Critique of Artificial Reason*. MIT Press.
^ref-dreyfus1992

Dreyfus, Hubert L. 2002. “Intelligence Without Representation – Merleau-Ponty's Critique of Mental Representation.” *Phenomenology and the Cognitive Sciences* 1(4): 367–383.
^ref-dreyfus2002

Driesch, Hans. 1908. *The Science and Philosophy of the Organism*. London: Adam and Charles Black.
^ref-driesch1908

Duff, R. A. 2001. *Punishment, Communication, and Community*. Oxford University Press.
^ref-duff2001

Dummett, Michael. 1960. “A Defence of McTaggart's Proof of the Unreality of Time.” *The Philosophical Review* 69 (4): 497–504.
^ref-dummett1960

Dunbar, Robin. 1996. *Grooming, Gossip, and the Evolution of Language*. Harvard University Press.
^ref-dunbar1996

Dunn, Barnaby D., Tim Dalgleish, and Andrew D. Lawrence. 2006. “The Somatic Marker Hypothesis: A Critical Evaluation.” *Neuroscience and Biobehavioral Reviews* 30 (2): 239–271.
^ref-dunn2006

Dunning, David, Kerri Johnson, Joyce Ehrlinger, and Justin Kruger. 2003. “Why people fail to recognize their own incompetence.” *Current Directions in Psychological Science* 12(3): 83–87.
^ref-dunning2003

Duns Scotus, John. (c. 1300) 1987. *Philosophical Writings*. Edited and translated by Allan Wolter. Indianapolis: Hackett.
^ref-dunsScotus1300

Dupré, John. 1993. *The Disorder of Things: Metaphysical Foundations of the Disunity of Science*. Harvard University Press (Cambridge, MA).
^ref-dupre1993

Durkheim, Émile. 1912. *The Elementary Forms of Religious Life (Les Formes élémentaires de la vie religieuse)*. Félix Alcan.
^ref-durkheim1912

Durkin, Kelley, Mark W. Lipsey, Dale C. Farran, and Sarah E. Wiesen. 2022. “Effects of a statewide pre-kindergarten program on children's achievement and behavior through sixth grade.” *Developmental Psychology* 58(3):470–484.
^ref-durkin2022

Dutton, Denis. 2009. *The Art Instinct: Beauty, Pleasure, and Human Evolution*. Oxford University Press.
^ref-dutton2009

Dworkin, Andrea. 1981. *Pornography: Men Possessing Women*. G. P. Putnam's Sons.
^ref-dworkin1981

Dyson, Lisa, Matthew Kleban, and Leonard Susskind. 2002. “Disturbing Implications of a Cosmological Constant.” *Journal of High Energy Physics* 2002 (10): 011.
^ref-dysonKlebanSusskind2002

Eagly, Alice H., and Wendy Wood. 1999. “The Origins of Sex Differences in Human Behavior: Evolved Dispositions Versus Social Roles.” American Psychologist 54 (6): 408-423.
^ref-eaglyWood1999

Earl, Douglas S. 2010. *The Joshua Delusion? Rethinking Genocide in the Bible*. Cascade Books.
^ref-earl2010

Earman, John, and John Norton. 1987. “What Price Spacetime Substantivalism? The Hole Story.” *The British Journal for the Philosophy of Science* 38(4):515–525.
^ref-earmanNorton1987

Earman, John. 1989. *World Enough and Space-Time: Absolute versus Relational Theories of Space and Time*. MIT Press.
^ref-earman1989

Earman, John. 2003. “Rough Guide to Spontaneous Symmetry Breaking.” In K. Brading and E. Castellani (eds.), Symmetries in Physics: Philosophical Reflections (Cambridge University Press), pp. 335–346.
^ref-earman2003

Earman, John. 2006. “The 'Past Hypothesis': Not Even False.” *Studies in History and Philosophy of Modern Physics* 37(3):399–430.
^ref-earman2006

Eastwood, John D., Alexandra Frischen, Mark J. Fenske, and Daniel Smilek. 2012. “The Unengaged Mind: Defining Boredom in Terms of Attention.” *Perspectives on Psychological Science* 7 (5): 482–495.
^ref-eastwood2012

Eddington, Arthur S. 1928. *The Nature of the Physical World*. Cambridge University Press / Macmillan (New York) (Gifford Lectures, 1927).
^ref-eddington1928

Edwards, Jonathan. (1765) 1989. “A Dissertation Concerning the End for Which God Created the World.” In Ethical Writings (The Works of Jonathan Edwards, vol. 8), ed. Paul Ramsey. New Haven: Yale University Press.
^ref-edwards1765

Edwards, Jonathan. 1754. *A Careful and Strict Enquiry into the Modern Prevailing Notions of That Freedom of Will, Which Is Supposed to Be Essential to Moral Agency, Virtue and Vice, Reward and Punishment, Praise and Blame*. Boston: S. Kneeland.
^ref-edwards1754

Edwards, Jonathan. 1758. *The Great Christian Doctrine of Original Sin Defended*. Boston: S. Kneeland (1st ed., 1758); critical ed. The Works of Jonathan Edwards, Vol. 3, ed. Clyde A. Holbrook, Yale University Press, 1970.
^ref-edwards1758

Edwards, Paul. 1959. “The Cosmological Argument.” *The Rationalist Annual for the Year* 1959 (London: Pemberton), pp. 63–77.
^ref-edwards1959

Efird, David, and Tom Stoneham. 2005. “The Subtraction Argument for Metaphysical Nihilism.” *The Journal of Philosophy*.
^ref-efirdStoneham2005

Ehrman, Bart D. 2005. *Misquoting Jesus: The Story Behind Who Changed the Bible and Why*. San Francisco: HarperSanFrancisco.
^ref-ehrman2005

Ehrman, Bart D. 2009. *Jesus, Interrupted: Revealing the Hidden Contradictions in the Bible (and Why We Don't Know About Them)*. New York: HarperOne.
^ref-ehrman2009

Ehrman, Bart D. 2014. *How Jesus Became God: The Exaltation of a Jewish Preacher from Galilee*. New York: HarperOne.
^ref-ehrman2014

Eigen, M. 1971. “Selforganization of Matter and the Evolution of Biological Macromolecules.” *Naturwissenschaften* 58 (10): 465–523.
^ref-eigen1971

Einstein, A. 1905. “Zur Elektrodynamik bewegter Körper.” *Annalen der Physik* 17 (10): 891–921.
^ref-einstein1905

Einstein, A. 1915. “Die Feldgleichungen der Gravitation.” *Sitzungsberichte der Preussischen Akademie der Wissenschaften,* 844–847.
^ref-einstein1915

Eisen, Lauren-Brooke. 2017. *Inside Private Prisons: An American Dilemma in the Age of Mass Incarceration*. Columbia University Press.
^ref-eisen2017

Eklund, Matti. 2008. “The Picture of Reality as an Amorphous Lump.” In Theodore Sider, John Hawthorne and Dean W. Zimmerman (eds.), Contemporary Debates in Metaphysics, Malden, MA: Blackwell, 2008: 382–396.
^ref-eklund2008

Ekman, Paul. 1972. “Universals and Cultural Differences in Facial Expressions of Emotion.” In Nebraska Symposium on Motivation 1971, ed. J. Cole, 19: 207–283. University of Nebraska Press.
^ref-ekman1972

Ekman, Paul. 1992. “An Argument for Basic Emotions.” *Cognition and Emotion* 6 (3–4): 169–200.
^ref-ekman1992

Elga, Adam. 2007. “Reflection and Disagreement.” Noûs 41 (3): 478-502.
^ref-elga2007

Eliade, Mircea. 1957. *The Sacred and the Profane: The Nature of Religion (Das Heilige und das Profane)*. Rowohlt.
^ref-eliade1957

Ellis, Samuel, Daniel W. Franks, Mia Lybkær Kronborg Nielsen, Michael N. Weiss, and Darren P. Croft. 2024. “The Evolution of Menopause in Toothed Whales.” Nature 627: 579-585.
^ref-ellis2024

Ellul, Jacques. 1954. *The Technological Society (La Technique ou l'enjeu du siècle)*. Armand Colin (Paris).
^ref-ellul1954

Emery, Nathan J., and Nicola S. Clayton. 2004. “The Mentality of Crows: Convergent Evolution of Intelligence in Corvids and Apes.” Science 306 (5703): 1903-1907.
^ref-emeryClayton2004

Engels, Friedrich. 1872. *The Housing Question*. Originally serialized in Der Volksstaat, Leipzig, 26 June 1872 – 22 Feb 1873; widely reprinted as a pamphlet.
^ref-engels1872

England, J. L. 2013. “Statistical Physics of Self-Replication.” *The Journal of Chemical Physics* 139 (12): 121923.
^ref-england2013

English, Jane. 1975. “Abortion and the Concept of a Person.” *Canadian Journal of Philosophy* 5(2):233–243.
^ref-english1975

Enoch, David. 2010. “The Epistemological Challenge to Metanormative Realism: How Best to Understand It, and How to Cope with It.” Philosophical Studies.
^ref-enoch2010

Enoch, David. 2011. *Taking Morality Seriously: A Defense of Robust Realism*. Oxford University Press.
^ref-enoch2011

Ens, Paul. 2024. “The "Minimal Witnesses" Naturalistic Hypothesis.” The Bart Ehrman Blog (bartehrman.com), guest article.
^ref-ens2024

Epstein, Richard A. 1985. *Takings: Private Property and the Power of Eminent Domain*. Cambridge, MA: Harvard University Press.
^ref-epstein1985

Erikson, Erik H. 1968. *Identity: Youth and Crisis*. W. W. Norton.
^ref-erikson1968

Erman, Adolf. 1924. “Eine Ägyptische Quelle der "Sprüche Salomos".” Sitzungsberichte der Preussischen Akademie der Wissenschaften 15: 86-93.
^ref-erman1924

Esfeld, Michael. 2004. “Quantum Entanglement and a Metaphysics of Relations.” *Studies in History and Philosophy of Modern Physics* 35 (4): 601–617.
^ref-esfeld2004

Esfeld, Michael, and Vincent Lam. 2008. “Moderate Structural Realism about Space-Time.” *Synthese* 160 (1): 27–46.
^ref-esfeldLam2008

Evans, Jonathan St B. T. 2008. “Dual-Processing Accounts of Reasoning, Judgment, and Social Cognition.” *Annual Review of Psychology* 59: 255–278.
^ref-evans2008

Evans, Nicholas, and Stephen C. Levinson. 2009. “The Myth of Language Universals: Language Diversity and Its Importance for Cognitive Science.”
^ref-evansLevinson2009

Evans, C. Stephen. 2013. *God and Moral Obligation*. Oxford University Press.
^ref-evans2013

Everett, H. 1957. “'Relative State' Formulation of Quantum Mechanics.” *Reviews of Modern Physics* 29 (3): 454–462.
^ref-everett1957

Everitt, Nicholas. 2004. *The Non-Existence of God*. Routledge (London & New York).
^ref-everitt2004

Fa, John E., James E. M. Watson, Ian Leiper, et al. 2020. “Importance of Indigenous Peoples' lands for the conservation of Intact Forest Landscapes.” *Frontiers in Ecology and the Environment* 18(3): 135–140.
^ref-faEtAl2020

Faber, Roland. 2008. *God as Poet of the World: Exploring Process Theologies*. Westminster John Knox Press (Louisville).
^ref-faber2008

Faden, Ruth R., and Tom L. Beauchamp. 1986. *A History and Theory of Informed Consent*. Oxford University Press.
^ref-fadenBeauchamp1986

Faraday, Michael. 1839–1855. *Experimental Researches in Electricity*. London: Richard and John Edward Taylor (3 vols.).
^ref-faraday1839

Farrell, Justin. 2016. “Corporate funding and ideological polarization about climate change.” *Proceedings of the National Academy of Sciences* 113(1): 92–97.
^ref-farrell2016

Feigl, Herbert. 1958. “The 'Mental' and the 'Physical'.” in Feigl, Scriven & Maxwell (eds.), Concepts, Theories, and the Mind-Body Problem (Minnesota Studies in the Philosophy of Science, vol. 2), University of Minnesota Press, pp. 370–497.
^ref-feigl1958

Feinberg, Joel. 1980. “The Child's Right to an Open Future.” In W. Aiken & H. LaFollette (eds.), Whose Child? Children's Rights, Parental Authority, and State Power (Rowman & Littlefield), pp. 124–53.
^ref-feinberg1980

Feinberg, John S. 2001. *No One Like Him: The Doctrine of God*. Wheaton, IL: Crossway (Foundations of Evangelical Theology).
^ref-feinberg2001

Feldman, Fred. 1992. *Confrontations with the Reaper: A Philosophical Study of the Nature and Value of Death*. Oxford University Press.
^ref-feldman1992

Feser, Edward. 2009. *Aquinas: A Beginner's Guide*. Oxford: Oneworld.
^ref-feser2009

Feser, Edward. 2017. *Five Proofs of the Existence of God*. Ignatius Press.
^ref-feser2017

Fiddes, Paul S. 1988. *The Creative Suffering of God*. Clarendon Press.
^ref-fiddes1988

Field, Nigel P., and Charles Filanosky. 2010. “Continuing Bonds, Risk Factors for Complicated Grief, and Adjustment to Bereavement.” Death Studies 34 (1): 1-29.
^ref-fieldFilanosky2010

Fine, Kit. 1994. “Essence and Modality.” *Philosophical Perspectives*.
^ref-fine1994

Fine, Kit. 1995. “Senses of Essence.” in Modality, Morality, and Belief (Cambridge University Press).
^ref-fine1995

Fine, Kit. 2001. “The Question of Realism.” *Philosophers' Imprint* 1 (2): 1–30.
^ref-fine2001

Fine, Kit. 2005. “Necessity and Non-Existence.” in Modality and Tense: Philosophical Papers (Oxford University Press), pp. 321–354.
^ref-fine2005

Fine, Kit. 2012. “Guide to Ground.” In Metaphysical Grounding: Understanding the Structure of Reality, edited by Fabrice Correia and Benjamin Schnieder, 37–80. Cambridge: Cambridge University Press.
^ref-fine2012

Finer, Lawrence B., Lori F. Frohwirth, Lindsay A. Dauphinee, Susheela Singh, and Ann M. Moore. 2005. “Reasons U.S. Women Have Abortions: Quantitative and Qualitative Perspectives.” *Perspectives on Sexual and Reproductive Health* 37 (3): 110–118.
^ref-finer2005

Finkel, Irving. 2014. *The Ark Before Noah: Decoding the Story of the Flood*. Doubleday.
^ref-finkel2014

Finkelstein, Israel, and Neil Asher Silberman. 2001. *The Bible Unearthed: Archaeology's New Vision of Ancient Israel and the Origin of Its Sacred Texts*. Free Press.
^ref-finkelsteinSilberman2001

Finn, Julian K., Tom Tregenza, and Mark D. Norman. 2009. “Defensive Tool Use in a Coconut-Carrying Octopus.”
^ref-finnTregenzaNorman2009

Finnis, John. 1980. *Natural Law and Natural Rights*. Clarendon Press.
^ref-finnis1980

Fischel, William A. 2001. *The Homevoter Hypothesis: How Home Values Influence Local Government Taxation, School Finance, and Land-Use Policies*. Cambridge, MA: Harvard University Press.
^ref-fischel2001

Fischer, Eric A. 1984. “Egg Trading in the Chalk Bass, Serranus tortugarum, a Simultaneous Hermaphrodite.” Zeitschrift für Tierpsychologie 66: 143-151.
^ref-fischer1984

Fischer, John Martin. 1994. *The Metaphysics of Free Will: An Essay on Control*. Blackwell.
^ref-fischer1994

Fischer, John Martin, and Mark Ravizza. 1998. *Responsibility and Control: A Theory of Moral Responsibility*. Cambridge: Cambridge University Press.
^ref-fischerRavizza1998

Fishkin, James S. 2018. *Democracy When the People Are Thinking: Revitalizing Our Politics Through Public Deliberation*. Oxford University Press.
^ref-fishkin2018

Flint, Thomas P., and Alfred J. Freddoso. 1983. “Maximal Power.” In The Existence and Nature of God, ed. Alfred J. Freddoso, 81–113. Notre Dame: University of Notre Dame Press.
^ref-flintFreddoso1983

Flint, Thomas P. 1998. *Divine Providence: The Molinist Account*. Cornell University Press.
^ref-flint1998

Fodor, Jerry A. 1974. “Special Sciences (or: The Disunity of Science as a Working Hypothesis).” *Synthese* 28 (2).
^ref-fodor1974

Føllesdal, Dagfinn. 1986. “Essentialism and Reference.” in The Philosophy of W. V. Quine (Library of Living Philosophers, Open Court).
^ref-follesdal1986

Food and Agriculture Organization of the United Nations. 2006. “Livestock's Long Shadow: Environmental Issues and Options.” Food and Agriculture Organization of the United Nations.
^ref-fao2006

Food and Agriculture Organization of the United Nations. 2013. “Tackling Climate Change Through Livestock: A Global Assessment of Emissions and Mitigation Opportunities.” Food and Agriculture Organization of the United Nations.
^ref-fao2013

Food and Agriculture Organization of the United Nations. 2015. “Status of the World's Soil Resources.” Food and Agriculture Organization of the United Nations.
^ref-fao2015

Foot, Philippa. 2001. *Natural Goodness*. Oxford University Press.
^ref-foot2001

Foote, Allison L., and Jonathan D. Crystal. 2007. “Metacognition in the Rat.” *Current Biology* 17 (6): 551–555.
^ref-footeCrystal2007

Foote, Andrew D. et al. 2016. “Genome-Culture Coevolution Promotes Rapid Divergence of Killer Whale Ecotypes.” Nature Communications 7: 11693.
^ref-footeEtAl2016

Forbes, Graeme. 1984. “Two Solutions to Chisholm's Paradox.” *Philosophical Studies* 46 (2): 171–187.
^ref-forbes1984

Forbes, Graeme. 1985. *The Metaphysics of Modality*. Oxford: Clarendon Press.
^ref-forbes1985

Forbes, Graeme. 1993. “Time, Events, and Modality.” In Robin Le Poidevin and Murray MacBeath (eds.), The Philosophy of Time (Oxford Readings in Philosophy). Oxford: Oxford University Press.
^ref-forbes1993

Ford, Lewis S. 1984. *The Emergence of Whitehead's Metaphysics, 1925–1929*. State University of New York Press (Albany).
^ref-ford1984

Forman, Robert K. C. 1990. *The Problem of Pure Consciousness: Mysticism and Philosophy*. Oxford University Press.
^ref-forman1990

Forman, Robert K. C. 1999. *Mysticism, Mind, Consciousness*. State University of New York Press.
^ref-forman1999

Forrest, Peter, and D. M. Armstrong. 1984. “An Argument Against David Lewis' Theory of Possible Worlds.” *Australasian Journal of Philosophy* 62 (2): 164–168.
^ref-forrestArmstrong1984

Forterre, Patrick. 2010. “Defining Life: The Virus Viewpoint.” *Origins of Life and Evolution of Biospheres* 40(2):151–160.
^ref-forterre2010

Foster, Diana Greene. 2020. *The Turnaway Study: Ten Years, a Thousand Women, and the Consequences of Having—or Being Denied—an Abortion*. New York: Scribner.
^ref-foster2020

Foucault, Michel. 1963. *The Birth of the Clinic: An Archaeology of Medical Perception*. Presses Universitaires de France.
^ref-foucault1963

Foucault, Michel. 1975. *Discipline and Punish: The Birth of the Prison*. Gallimard.
^ref-foucault1975

Foucault, Michel. 1976. *The History of Sexuality, Volume 1: An Introduction (La Volonté de savoir)*. Gallimard.
^ref-foucault1976

Francione, Gary L. 2000. *Introduction to Animal Rights: Your Child or the Dog?* Temple University Press.
^ref-francione2000

Francis Crick Memorial Conference. 2012. “The Cambridge Declaration on Consciousness.” Francis Crick Memorial Conference.
^ref-cambridgeDeclaration2012

Frank, Richard M. 1992. *Creation and the Cosmic System: Al-Ghazâlî and Avicenna*. Carl Winter Universitätsverlag (Heidelberg), Abhandlungen der Heidelberger Akademie der Wissenschaften, Phil.-hist. Kl. 1992, Abh. 1.
^ref-frank1992

Frankfurt, Harry G. 1964. “The Logic of Omnipotence.” *The Philosophical Review* 73, no. 2: 262–263.
^ref-frankfurt1964

Frankfurt, Harry G. 1969. “Alternate Possibilities and Moral Responsibility.” *The Journal of Philosophy* 66, no. 23: 829–839.
^ref-frankfurt1969

Frankfurt, Harry G. 1971. “Freedom of the Will and the Concept of a Person.” *Journal of Philosophy* 68 (1): 5–20.
^ref-frankfurt1971

Frankfurt, Harry G. 1977. “Descartes on the Creation of the Eternal Truths.” *The Philosophical Review* 86 (1): 36–57.
^ref-frankfurt1977

Frankfurt, Harry G. 1982. “The Importance of What We Care About.” *Synthese* 53 (2): 257–272.
^ref-frankfurt1982

Frankfurt, Harry G. 1988. *The Importance of What We Care About: Philosophical Essays*. Cambridge University Press (Cambridge).
^ref-frankfurt1988

Frankfurt, Harry G. 2004. *The Reasons of Love*. Princeton University Press.
^ref-frankfurt2004

Frankfurt, Harry G. 2005. *On Bullshit*. Princeton University Press.
^ref-frankfurt2005

Frankish, Keith. 2016. “Illusionism as a Theory of Consciousness.” *Journal of Consciousness Studies* 23 (11–12): 11–39.
^ref-frankish2016

Frankish, Keith. 2017. *Illusionism as a Theory of Consciousness*. Imprint Academic (Exeter).
^ref-frankish2017

Frankl, Viktor E. 1946. *Man's Search for Meaning*. Beacon Press.
^ref-frankl1946

Franklin, James. 2014. *An Aristotelian Realist Philosophy of Mathematics: Mathematics as the Science of Quantity and Structure*. Palgrave Macmillan.
^ref-franklin2014

Fraser, D. 2008. “The Fate of 'Particles' in Quantum Field Theories with Interactions.” *Studies in History and Philosophy of Modern Physics* 39 (4): 841–859.
^ref-fraser2008

Freddoso, Alfred J. 1991. “God's General Concurrence with Secondary Causes: Why Conservation Is Not Enough.” *Philosophical Perspectives* 5: 553–585.
^ref-freddoso1991

Freddoso, Alfred J. 1994. “God's General Concurrence with Secondary Causes: Pitfalls and Prospects.” *American Catholic Philosophical Quarterly* 68 (2): 131–156.
^ref-freddoso1994

Frege, Gottlob. 1879. *Begriffsschrift, eine der arithmetischen nachgebildete Formelsprache des reinen Denkens*. Halle: Louis Nebert.
^ref-frege1879

Frege, Gottlob. 1884. *Die Grundlagen der Arithmetik*. Verlag von Wilhelm Koebner (Breslau).
^ref-frege1884

Frege, Gottlob. 1892. “On Sense and Reference (Über Sinn und Bedeutung).” *Zeitschrift für Philosophie und philosophische Kritik* 100: 25–50.
^ref-frege1892

Frege, Gottlob. 1893–1903. *Grundgesetze der Arithmetik*. Jena: Hermann Pohle (2 vols.).
^ref-frege1893

Freire, Paulo. 1968. *Pedagogy of the Oppressed*. Herder and Herder.
^ref-freire1968

French, Steven, and Décio Krause. 2006. *Identity in Physics: A Historical, Philosophical, and Formal Analysis*. Oxford University Press.
^ref-frenchKrause2006

French, Steven. 2014. *The Structure of the World: Metaphysics and Representation*. Oxford University Press.
^ref-french2014

Freud, Sigmund. 1905. *Three Essays on the Theory of Sexuality (Drei Abhandlungen zur Sexualtheorie)*. Leipzig & Vienna: Franz Deuticke.
^ref-freud1905

Freud, Sigmund. 1920. *Beyond the Pleasure Principle (Jenseits des Lustprinzips)*. Leipzig: Internationaler Psychoanalytischer Verlag.
^ref-freud1920

Freud, Sigmund. 1923. *The Ego and the Id (Das Ich und das Es)*. Leipzig: Internationaler Psychoanalytischer Verlag.
^ref-freud1923

Freud, Sigmund. 1927. *The Future of an Illusion (Die Zukunft einer Illusion)*. Internationaler Psychoanalytischer Verlag.
^ref-freud1927

Friedman, Milton. 1962. *Capitalism and Freedom*. University of Chicago Press.
^ref-friedman1962

Friedman, Milton, and Rose D. Friedman. 1980. *Free to Choose: A Personal Statement*. Harcourt Brace Jovanovich.
^ref-friedmanfriedman1980

Friedman, Michael. 1983. *Foundations of Space-Time Theories: Relativistic Physics and Philosophy of Science*. Princeton University Press.
^ref-friedman1983

Friston, Karl J. 2010. “The Free-Energy Principle: A Unified Brain Theory?” *Nature Reviews Neuroscience* 11 (2): 127–138.
^ref-friston2010

Fritz, Peter, Tien-Chun Lo, and Joseph C. Schmid. 2026. “Symmetry Lost: A Modal Ontological Argument for Atheism?” *Noûs* 60 (2026): 313–327.
^ref-fritzLoSchmid2026

Fukami, Tadashi. 2015. “Historical Contingency in Community Assembly: Integrating Niches, Species Pools, and Priority Effects.” *Annual Review of Ecology, Evolution, and Systematics* 46:1–23.
^ref-fukami2015

Furlong, Peter. 2019. *The Challenges of Divine Determinism: A Philosophical Analysis*. Cambridge: Cambridge University Press.
^ref-furlong2019

Gadamer, Hans-Georg. 1960. *Truth and Method (Wahrheit und Methode)*. J. C. B. Mohr (Paul Siebeck).
^ref-gadamer1960

Gagliano, Monica. 2018. *Thus Spoke the Plant: A Remarkable Journey of Groundbreaking Scientific Discoveries and Personal Encounters with Plants*. North Atlantic Books.
^ref-gagliano2018

Gal, David, and Derek D. Rucker. 2018. “The Loss of Loss Aversion: Will It Loom Larger Than Its Gain?” Journal of Consumer Psychology 28 (3): 497-516.
^ref-galRucker2018

Gallese, Vittorio. 2003. “The Roots of Empathy: The Shared Manifold Hypothesis and the Neural Basis of Intersubjectivity.” Psychopathology 36 (4): 171-180.
^ref-gallese2003

Gallup, Gordon G. 1970. “Chimpanzees: Self-Recognition.” *Science* 167 (3914): 86–87.
^ref-gallup1970

Gallup, Gordon G., and James R. Anderson. 2020. “Self-Recognition in Animals: Where Do We Stand 50 Years Later? Lessons from Cleaner Wrasse and Other Species.” Psychology of Consciousness: Theory, Research, and Practice 7: 46-58.
^ref-gallup2020

Ganna, A. and Verweij, K. J. H. and Nivard, M. G. and Maier, R. and Wedow, R. and Busch, A. S. and Abdellaoui, A. and Guo, S. and Sathirapongsasuti, J. F. and Lichtenstein, P. and Lundström, S. and Långström, N. and Auton, A. and Harris, K. M. and Beecham, G. W. and Martin, E. R. and Sanders, A. R. and Perry, J. R. B. and Neale, B. M. and Zietsch, B. P. and 23andMe Research Team. 2019. “Large-Scale GWAS Reveals Insights into the Genetic Architecture of Same-Sex Sexual Behavior.” *Science* 365 (6456): eaat7693.
^ref-ganna2019

Gánti, Tibor. 2003. *The Principles of Life*. Oxford: Oxford University Press.
^ref-ganti2003

Gardiner, Stephen M. 2011. *A Perfect Moral Storm: The Ethical Tragedy of Climate Change*. Oxford University Press.
^ref-gardiner2011

Garfield, Jay L. 1995. *The Fundamental Wisdom of the Middle Way: Nāgārjuna's Mūlamadhyamakakārikā*. Oxford University Press (New York).
^ref-garfield1995

Garfield, Jay L. 2002. *Empty Words: Buddhist Philosophy and Cross-Cultural Interpretation*. Oxford University Press (New York).
^ref-garfield2002

Garland-Thomson, Rosemarie. 2012. “The Case for Conserving Disability.” *Journal of Bioethical Inquiry* 9(3):339–355.
^ref-garlandthomson2012

Garner, Richard. 1994. *Beyond Morality*. Temple University Press.
^ref-garner1994

Garnett, Stephen T., Neil D. Burgess, John E. Fa, et al. 2018. “A spatial overview of the global importance of Indigenous lands for conservation.” *Nature Sustainability* 1(7): 369–374.
^ref-garnettEtAl2018

Garrigou-Lagrange, Réginald. 1936. *La prédestination des saints et la grâce: Doctrine de saint Thomas comparée aux autres systèmes théologiques*. Paris: Desclée de Brouwer.
^ref-garrigouLagrange1936

Garrison, Kathleen A., Dustin Scheinost, R. Todd Constable, and Judson A. Brewer. 2015. “Effortless Awareness: Using Real-Time Neurofeedback to Investigate Correlates of Posterior Cingulate Cortex Activity in Meditators' Self-Report.” *Frontiers in Human Neuroscience*.
^ref-garrison2015

Garry, Maryanne, Charles G. Manning, Elizabeth F. Loftus, and Steven J. Sherman. 1996. “Imagination Inflation: Imagining a Childhood Event Inflates Confidence That It Occurred.” *Psychonomic Bulletin & Review* 3 (2): 208–214.
^ref-garryEtAl1996

Gasperini, M., and G. Veneziano. 1993. “Pre-Big-Bang in String Cosmology.” *Astroparticle Physics* 1 (3): 317–339.
^ref-gasperiniVeneziano1993

Gauthier, David. 1986. *Morals by Agreement*. Oxford University Press.
^ref-gauthier1986

Gavrilyuk, Paul L. 2004. *The Suffering of the Impassible God: The Dialectics of Patristic Thought*. Oxford University Press.
^ref-gavrilyuk2004

Geach, Peter. 1965. “Assertion.” *The Philosophical Review* 74 (4): 449–465.
^ref-geach1965

Geach, P. T. 1973. “Omnipotence.” *Philosophy* 48, no. 183: 7–20.
^ref-geach1973

Geertz, Clifford. 1973. “Religion as a Cultural System.” In The Interpretation of Cultures: Selected Essays, 87-125.
^ref-geertz1973

Gendler, Tamar Szabó. 2000. “The Puzzle of Imaginative Resistance.” *The Journal of Philosophy* 97 (2): 55–81.
^ref-gendler2000

Gendron, Maria, Debi Roberson, Jacoba M. van der Vyver, and Lisa Feldman Barrett. 2014. “Perceptions of Emotion from Facial Expressions Are Not Culturally Universal: Evidence from a Remote Culture.” *Emotion* 14 (2): 251–262.
^ref-gendron2014

George, Henry. 1879. *Progress and Poverty*. W. M. Hinton, San Francisco (author's ed.); trade ed. D. Appleton, New York, 1880.
^ref-george1879

George, Robert P. 1993. *Making Men Moral: Civil Liberties and Public Morality*. Oxford University Press.
^ref-george1993

Gerson, Lloyd P. 1994. *Plotinus*. London: Routledge.
^ref-gerson1994

Gettier, Edmund L. 1963. “Is Justified True Belief Knowledge?” *Analysis* 23(6): 121–123.
^ref-gettier1963

Gibbard, Allan. 1975. “Contingent Identity.” *Journal of Philosophical Logic* 4 (2): 187–221.
^ref-gibbard1975

Gibbard, Allan. 1990. *Wise Choices, Apt Feelings: A Theory of Normative Judgment*. Harvard University Press (Cambridge, MA).
^ref-gibbard1990

Gibbard, Allan. 2003. *Thinking How to Live*. Harvard University Press (Cambridge, MA).
^ref-gibbard2003

Giedd, Jay N. et al. 1999. “Brain Development During Childhood and Adolescence: A Longitudinal MRI Study.” Nature Neuroscience 2 (10): 861-863.
^ref-giedd1999

Gigerenzer, Gerd, and Peter M. Todd. 1999. *Simple Heuristics That Make Us Smart*. Oxford University Press.
^ref-gigerenzer1999

Gigerenzer, Gerd. 2007. *Gut Feelings: The Intelligence of the Unconscious*. Viking.
^ref-gigerenzer2007

Gilbert, Walter. 1986. “Origin of Life: The RNA World.” *Nature* 319:618.
^ref-gilbert1986

Gilbert, Margaret. 1989. *On Social Facts*. Routledge (London and New York); reprinted Princeton University Press, 1992.
^ref-gilbert1989

Gilbert, Daniel T., and Timothy D. Wilson. 2007. “Prospection: Experiencing the Future.” *Science* 317 (5843): 1351–1354.
^ref-gilbertWilson2007

Gilens, Martin, and Benjamin I. Page. 2014. “Testing Theories of American Politics: Elites, Interest Groups, and Average Citizens.” *Perspectives on Politics* 12(3): 564–581.
^ref-gilensPage2014

Gilligan, Carol. 1982. *In a Different Voice: Psychological Theory and Women's Development*. Harvard University Press.
^ref-gilligan1982

Gilmore, Ruth Wilson. 2007. *Golden Gulag: Prisons, Surplus, Crisis, and Opposition in Globalizing California*. University of California Press.
^ref-gilmore2007

Ginsburg, S., and E. Jablonka. 2019. *The Evolution of the Sensitive Soul: Learning and the Origins of Consciousness*. Cambridge, MA: MIT Press.
^ref-ginsburgJablonka2019

Girle, R. 2009. *Modal Logics and Philosophy*. 2nd ed. Montreal: McGill-Queen's University Press.
^ref-girle2009

Giustina, M., M. A. M. Versteegh, S. Wengerowsky, J. Handsteiner, A. Hochrainer, K. Phelan, F. Steinlechner, J. Kofler, J.-Å. Larsson, C. Abellán, W. Amaya, V. Pruneri, M. W. Mitchell, J. Beyer, T. Gerrits, A. E. Lita, L. K. Shalm, S. W. Nam, T. Scheidl, R. Ursin, B. Wittmann, and A. Zeilinger. 2015. “Significant-Loophole-Free Test of Bell's Theorem with Entangled Photons.” *Physical Review Letters* 115 (25): 250401.
^ref-giustina2015

Gladyshev, E. A., M. Meselson, and I. R. Arkhipova. 2008. “Massive Horizontal Gene Transfer in Bdelloid Rotifers.” *Science* 320 (5880): 1210–1213.
^ref-gladyshev2008

Glancy, Jennifer A. 2002. *Slavery in Early Christianity*. Oxford University Press.
^ref-glancy2002

Glenberg, Arthur M. 1997. “What memory is for.” *Behavioral and Brain Sciences* 20 (1): 1–19.
^ref-glenberg1997

Gliessman, Stephen R. 1998. *Agroecology: Ecological Processes in Sustainable Agriculture*. Ann Arbor Press.
^ref-gliessman1998

Gödel, Kurt. 1944. “Russell's Mathematical Logic.” in P. A. Schilpp (ed.), The Philosophy of Bertrand Russell (Library of Living Philosophers, vol. 5), Northwestern University, pp. 123–153.
^ref-godel1944

Gödel, Kurt. 1947. “What Is Cantor's Continuum Problem?” *The American Mathematical Monthly*.
^ref-godel1947

Gödel, Kurt. 1964. “What Is Cantor's Continuum Problem? (revised).” in P. Benacerraf & H. Putnam (eds.), Philosophy of Mathematics: Selected Readings (Prentice-Hall), pp. 258–273.
^ref-godel1964

Godfrey-Smith, P. 1996. *Complexity and the Function of Mind in Nature*. Cambridge: Cambridge University Press.
^ref-godfreySmith1996

Godfrey-Smith, P. 2016. *Other Minds: The Octopus, the Sea, and the Deep Origins of Consciousness*. New York: Farrar, Straus and Giroux.
^ref-godfreySmith2016

Goff, Philip. 2017. *Consciousness and Fundamental Reality*. Oxford University Press (New York), Philosophy of Mind series.
^ref-goff2017

Goff, Philip. 2018. “Conscious Thought and the Cognitive Fine-Tuning Problem.” Philosophical Quarterly 68(270): 98–122.
^ref-goff2018

Goff, Philip. 2019. *Galileo's Error: Foundations for a New Science of Consciousness*. Pantheon Books (New York).
^ref-goff2019

Goff, Philip. 2023. *Why?: The Purpose of the Universe*. Oxford University Press.
^ref-goff2023

Goheer, Naureen, Matthew Kleban, and Leonard Susskind. 2003. “The Trouble with de Sitter Space.” *Journal of High Energy Physics* 2003 (07): 056.
^ref-goheerKlebanSusskind2003

Goldberg, Adele E. 2006. *Constructions at Work: The Nature of Generalization in Language*. Oxford University Press.
^ref-goldberg2006

Goldblatt, Robert. 1992. *Logics of Time and Computation (2nd ed.)*. Stanford: CSLI Publications.
^ref-goldblatt1992

Goldman, Alvin I. 1967. “A Causal Theory of Knowing.” *The Journal of Philosophy* 64(12): 357–372.
^ref-goldman1967

Goldman, Alvin I. 1979. “What Is Justified Belief?” In Justification and Knowledge, ed. G. S. Pappas, pp. 1–23. Dordrecht: D. Reidel.
^ref-goldman1979

Goldman, Alvin I. 1986. *Epistemology and Cognition*. Cambridge, MA: Harvard University Press.
^ref-goldman1986

Goldman, Alvin I. 1999. *Knowledge in a Social World*. Oxford University Press.
^ref-goldman1999

Goleman, Daniel, and Richard J. Davidson. 2017. *Altered Traits: Science Reveals How Meditation Changes Your Mind, Brain, and Body*. Avery.
^ref-golemanDavidson2017

Goodall, Jane. 1968. “The Behaviour of Free-Living Chimpanzees in the Gombe Stream Reserve.”
^ref-goodall1968

Goodall, Jane. 1971. *In the Shadow of Man*. Houghton Mifflin (Boston).
^ref-goodall1971

Goodall, Jane. 1986. *The Chimpanzees of Gombe: Patterns of Behavior*. Belknap Press of Harvard University Press.
^ref-goodall1986

Goodenough, Ursula. 1998. *The Sacred Depths of Nature*. Oxford University Press.
^ref-goodenough1998

Goodman, Nelson. 1951. *The Structure of Appearance*. Harvard University Press (Cambridge, MA).
^ref-goodman1951

Goody, Jack. 1977. *The Domestication of the Savage Mind*. Cambridge University Press.
^ref-goody1977

Gottman, John M., and Nan Silver. 1994. *Why Marriages Succeed or Fail: What You Can Learn from the Breakthrough Research to Make Your Marriage Last*. Simon and Schuster.
^ref-gottman1994

Gottman, John M., and Robert W. Levenson. 2000. “The Timing of Divorce: Predicting When a Couple Will Divorce Over a 14-Year Period.” Journal of Marriage and Family 62 (3): 737-745.
^ref-gottmanLevenson2000

Graeber, David. 2004. *Fragments of an Anarchist Anthropology*. Prickly Paradigm Press.
^ref-graeber2004

Graham, A. C. 1989. *Disputers of the Tao: Philosophical Argument in Ancient China*. Open Court.
^ref-graham1989

Greco, John. 2010. *Achieving Knowledge: A Virtue-Theoretic Account of Epistemic Normativity*. Cambridge: Cambridge University Press.
^ref-greco2010

Greenberg, Clement. 1960. “Modernist Painting.” *Forum Lectures (Voice of America)*.
^ref-greenberg1960

Greenberg, Joseph H. 1963. “Some Universals of Grammar with Particular Reference to the Order of Meaningful Elements.”
^ref-greenberg1963

Greenberg, Jeff, Tom Pyszczynski, and Sheldon Solomon. 1986. “The Causes and Consequences of a Need for Self-Esteem: A Terror Management Theory.” Springer.
^ref-greenberg1986

Greenwald, Glenn. 2009. “Drug Decriminalization in Portugal: Lessons for Creating Fair and Successful Drug Policies.” Cato Institute.
^ref-greenwald2009

Greer, David M.; Kirschen, Matthew P.; Lewis, Ariane;, et al. 2023. “Pediatric and Adult Brain Death/Death by Neurologic Criteria Consensus Guideline.” *Neurology* 101 (24): 1112–1132.
^ref-greerEtAl2023

Grice, H. Paul. 1975. “Logic and Conversation.”
^ref-grice1975

Griffel, Frank. 2009. *Al-Ghazālī's Philosophical Theology*. Oxford University Press (New York).
^ref-griffel2009

Griffin, David Ray. 2001. *Reenchantment Without Supernaturalism: A Process Philosophy of Religion*. Cornell University Press (Ithaca, NY).
^ref-griffin2001

Griffiths, R. B. 2002. *Consistent Quantum Theory*. Cambridge: Cambridge University Press.
^ref-griffiths2002

Griffiths, Roland R., William A. Richards, Una McCann, and Robert Jesse. 2006. “Psilocybin Can Occasion Mystical-Type Experiences Having Substantial and Sustained Personal Meaning and Spiritual Significance.” Psychopharmacology 187 (3): 268-283.
^ref-griffiths2006

Griffiths, Roland R., William A. Richards, Matthew W. Johnson, Una D. McCann, and Robert Jesse. 2008. “Mystical-Type Experiences Occasioned by Psilocybin Mediate the Attribution of Personal Meaning and Spiritual Significance 14 Months Later.” Journal of Psychopharmacology 22 (6): 621-632.
^ref-griffiths2008

Grim, Patrick. 1984. “There Is No Set of All Truths.” *Analysis* 44 (4): 206–208.
^ref-grim1984

Grim, Patrick. 1991. *The Incomplete Universe: Totality, Knowledge, and Truth*. MIT Press / Bradford Books (Cambridge, MA).
^ref-grim1991

Grosberg, R. K., and R. R. Strathmann. 2007. “The Evolution of Multicellularity: A Minor Major Transition?” *Annual Review of Ecology, Evolution, and Systematics* 38: 621–654.
^ref-grosbergStrathmann2007

Gross, M. R., and E. L. Charnov. 1980. “Alternative Male Life Histories in Bluegill Sunfish.” *Proceedings of the National Academy of Sciences* 77 (11): 6937–6940.
^ref-grossCharnov1980

Gross, D. J. 1996. “The Role of Symmetry in Fundamental Physics.” *Proceedings of the National Academy of Sciences* 93 (25): 14256–14259.
^ref-gross1996

Grotius, Hugo. (1625) 2005. *The Rights of War and Peace*. Edited by Richard Tuck. Indianapolis: Liberty Fund.
^ref-grotius1625

Grünbaum, Adolf. 1989. “The Pseudo-Problem of Creation in Physical Cosmology.” *Philosophy of Science* 56(3):373–394.
^ref-grunbaum1989

Grünbaum, Adolf. 1998. “Theological Misinterpretations of Current Physical Cosmology.” *Philo* 1 (1): 15–34.
^ref-grunbaum1998

Guerrier-Takada, C., K. Gardiner, T. Marsh, N. Pace, and S. Altman. 1983. “The RNA Moiety of Ribonuclease P Is the Catalytic Subunit of the Enzyme.” *Cell* 35 (3): 849–857.
^ref-guerrierTakada1983

Guess, Andrew M., Michael Lerner, Benjamin Lyons, Jacob M. Montgomery, Brendan Nyhan, Jason Reifler, and Neelanjan Sircar. 2020. “A Digital Media Literacy Intervention Increases Discernment between Mainstream and False News in the United States and India.” *PNAS* 117 (27): 15536–15545.
^ref-guess2020

Gurzadyan, Vahe G., and Roger Penrose. 2010. “Concentric Circles in WMAP Data May Provide Evidence of Violent Pre-Big-Bang Activity.” arXiv:1011.3706.
^ref-gurzadyanPenrose2010

Guthrie, S. E. 1993. *Faces in the Clouds: A New Theory of Religion*. New York: Oxford University Press.
^ref-guthrie1993

Gutmann, Amy. 1987. *Democratic Education*. Princeton University Press.
^ref-gutmann1987

Gyekye, Kwame. 1997. *Tradition and Modernity: Philosophical Reflections on the African Experience*. Oxford University Press.
^ref-gyekye1997

Habermas, Jürgen. (1983) 1990. *Moral Consciousness and Communicative Action*. MIT Press.
^ref-habermas1983

Habermas, Jürgen. (1992) 1996. *Between Facts and Norms: Contributions to a Discourse Theory of Law and Democracy*. MIT Press.
^ref-habermas1992

Habermas, Jürgen. (1998) 2001. *The Postnational Constellation: Political Essays*. MIT Press.
^ref-habermas2001

Habermas, Jürgen. 1985. “Civil Disobedience: Litmus Test for the Democratic Constitutional State.” *Berkeley Journal of Sociology*.
^ref-habermas1985

Habermas, Jürgen. 2003. *The Future of Human Nature*. Polity Press.
^ref-habermas2003

Habermas, Gary R. 2005. “Resurrection Research from 1975 to the Present: What Are Critical Scholars Saying?” *Journal for the Study of the Historical Jesus* 3.2: 135–153.
^ref-habermas2005

Habermas, Gary R. 2024a. *On the Resurrection, Volume 1: Evidences*. Nashville: B&H Academic.
^ref-habermas2024evidences

Habermas, Gary R. 2024b. *On the Resurrection, Volume 2: Refutations*. Nashville: B&H Academic.
^ref-habermas2024refutations

Habermas, Gary R. 2025. *On the Resurrection, Volume 3: Scholarly Perspectives*. Nashville: B&H Academic.
^ref-habermas2025perspectives

Habermas, Gary R. 2026. *On the Resurrection, Volume 4: Theology and Practice*. Nashville: B&H Academic.
^ref-habermas2026theology

Hacker, P. M. S. 2001. *Wittgenstein: Connections and Controversies*. Clarendon Press / Oxford University Press (Oxford).
^ref-hacker2001

Haidt, Jonathan. 2012. *The Righteous Mind: Why Good People Are Divided by Politics and Religion*. Pantheon Books.
^ref-haidt2012

Hájek, Alan. 2003. “Waging War on Pascal's Wager.” *The Philosophical Review* 112 (1): 27–56.
^ref-hajek2003

Hale, Bob. 1995. “Modal Fictionalism: A Simple Dilemma.” *Analysis* 55 (2): 63–67.
^ref-hale1995

Hale, B. 2013. *Necessary Beings: An Essay on Ontology, Modality, and the Relations Between Them*. Oxford: Oxford University Press.
^ref-hale2013

Hallin, Daniel C., and Paolo Mancini. 2004. *Comparing Media Systems: Three Models of Media and Politics*. Cambridge University Press.
^ref-hallinmancini2004

Hamilton, W. D. 1964. “The Genetical Evolution of Social Behaviour.” Journal of Theoretical Biology 7 (1): 1-52.
^ref-hamilton1964

Hamilton, W. D. 1966. “The Moulding of Senescence by Natural Selection.” Journal of Theoretical Biology 12 (1): 12-45.
^ref-hamilton1966

Hamilton, W. D., R. Axelrod, and R. Tanese. 1990. “Sexual Reproduction as an Adaptation to Resist Parasites: A Review.” *Proceedings of the National Academy of Sciences* 87 (9): 3566–3573.
^ref-hamilton1990

Hamming, Richard W. 1980. “The Unreasonable Effectiveness of Mathematics.” *The American Mathematical Monthly* 87 (2): 81–90.
^ref-hamming1980

Hampton, Robert R. 2001. “Rhesus Monkeys Know When They Remember.” *Proceedings of the National Academy of Sciences* 98 (9): 5359–5362.
^ref-hampton2001

Hansen, Chad. 1992. *A Daoist Theory of Chinese Thought: A Philosophical Interpretation*. Oxford University Press.
^ref-hansen1992

Haraway, Donna J. 1985. “A Manifesto for Cyborgs: Science, Technology, and Socialist Feminism for the 1980s.” Socialist Review 15 (2): 65-107.
^ref-haraway1985

Harb, Lara. 2020. “Naẓm, Wonder, and the Inimitability of the Quran.” Cambridge University Press.
^ref-harb2020

Hardin, Garrett. 1968. “The Tragedy of the Commons.” *Science* 162 (3859): 1243–1248.
^ref-hardin1968

Hare, R. M. 1981. *Moral Thinking: Its Levels, Method, and Point*. Clarendon Press.
^ref-hare1981

Hare, John E. 1996. *The Moral Gap: Kantian Ethics, Human Limits, and God's Assistance*. Clarendon Press / Oxford University Press (Oxford), Oxford Studies in Theological Ethics.
^ref-hare1996

Harman, Gilbert. 1975. “Moral Relativism Defended.”
^ref-harman1975

Harman, Gilbert. 1987. “(Nonsolipsistic) Conceptual Role Semantics.” in E. LePore (ed.), New Directions in Semantics (Academic Press), pp. 55–81.
^ref-harman1987

Harman, Gilbert, and Judith Jarvis Thomson. 1996. *Moral Relativism and Moral Objectivity*. Blackwell Publishers.
^ref-harman1996

Harmand, Sonia, et al. 2015. “3.3-Million-Year-Old Stone Tools from Lomekwi 3, West Turkana, Kenya.”
^ref-harmand2015

Harris, Sam. 2004. *The End of Faith: Religion, Terror, and the Future of Reason*. W. W. Norton.
^ref-harris2004

Harrop, Stephen. 2024. “On the Necessity of Priority Monism.” *Erkenntnis* 89 (2): 685–703.
^ref-harrop2024

Hart, H. L. A. 1968. *Punishment and Responsibility: Essays in the Philosophy of Law*. Oxford University Press.
^ref-hart1968

Hart, Mary K., Andrew W. Kratter, and Philip H. Crowley. 2016. “Partner Fidelity and Reciprocal Investments in the Mating System of a Simultaneous Hermaphrodite.” Behavioral Ecology 27 (5): 1471-1479.
^ref-hart2016

Hart, David Bentley. 2019. *That All Shall Be Saved: Heaven, Hell, and Universal Salvation*. Yale University Press.
^ref-hart2019

Hartle, James B., and Stephen W. Hawking. 1983. “Wave Function of the Universe.” *Physical Review D* 28, no. 12, pp. 2960–2975.
^ref-hartleHawking1983

Hartshorne, Charles. 1941. *Man's Vision of God and the Logic of Theism*. Willett, Clark & Company (Chicago & New York).
^ref-hartshorne1941

Hartshorne, Charles. 1948. *The Divine Relativity: A Social Conception of God*. Yale University Press (New Haven).
^ref-hartshorne1948

Hartshorne, Charles. 1962. *The Logic of Perfection and Other Essays in Neoclassical Metaphysics*. Open Court (La Salle, IL).
^ref-hartshorne1962

Hartshorne, Charles. 1965. *Anselm's Discovery: A Re-Examination of the Ontological Proof for God's Existence*. Open Court (La Salle, IL).
^ref-hartshorne1965

Hartshorne, Charles. 1967. *A Natural Theology for Our Time*. Open Court (La Salle, IL).
^ref-hartshorne1967

Hartshorne, Charles. 1970. *Creative Synthesis and Philosophic Method*. SCM Press (London) / Open Court (La Salle, IL).
^ref-hartshorne1970

Hartshorne, Charles. 1984. *Omnipotence and Other Theological Mistakes*. State University of New York Press (Albany).
^ref-hartshorne1984

Harvey, David. 1973. *Social Justice and the City*. London: Edward Arnold.
^ref-harvey1973

Hasher, Lynn, David Goldstein, and Thomas Toppino. 1977. “Frequency and the Conference of Referential Validity.” *Journal of Verbal Learning and Verbal Behavior* 16 (1): 107–112.
^ref-hasherGoldsteinToppino1977

Hasker, William. 1986. “A Refutation of Middle Knowledge.” *Noûs* 20, no. 4: 545–557.
^ref-hasker1986

Hasker, William. 1989. *God, Time, and Knowledge*. Ithaca, NY: Cornell University Press.
^ref-hasker1989

Hasker, William. 2013. *Metaphysics and the Tri-Personal God*. Oxford University Press, Oxford Studies in Analytic Theology.
^ref-hasker2013

Haslanger, Sally. 2000. “Gender and Race: (What) Are They? (What) Do We Want Them to Be?” *Noûs* 34 (1): 31–55.
^ref-haslanger2000

Haslanger, Sally. 2012. *Resisting Reality: Social Construction and Social Critique*. Oxford University Press.
^ref-haslanger2012

Hauerwas, Stanley. 1983. *The Peaceable Kingdom: A Primer in Christian Ethics*. University of Notre Dame Press.
^ref-hauerwas1983

Hauser, Marc D., Noam Chomsky, and W. Tecumseh Fitch. 2002. “The Faculty of Language: What Is It, Who Has It, and How Did It Evolve?”
^ref-hauserChomskyFitch2002

Haushofer, Johannes, and Ernst Fehr. 2014. “On the Psychology of Poverty.” *Science* 344 (6186): 862–867.
^ref-haushoferFehr2014

Havelock, Eric A. 1986. *The Muse Learns to Write: Reflections on Orality and Literacy from Antiquity to the Present*. Yale University Press.
^ref-havelock1986

Hawke, Peter. 2011. “Van Inwagen's Modal Skepticism.” *Philosophical Studies* 153 (3): 351-364.
^ref-hawke2011

Hawking, Stephen W., and Roger Penrose. 1970. “The Singularities of Gravitational Collapse and Cosmology.” *Proceedings of the Royal Society of London A* 314(1519):529–548.
^ref-hawkingPenrose1970

Hawking, S. W., and G. F. R. Ellis. 1973. *The Large Scale Structure of Space-Time*. Cambridge: Cambridge University Press.
^ref-hawkingEllis1973

Hawking, S. W. 1976. “Breakdown of Predictability in Gravitational Collapse.” *Physical Review D* 14 (10): 2460–2473.
^ref-hawking1976

Hawley, Katherine. 2001. *How Things Persist*. Clarendon Press / Oxford University Press (Oxford).
^ref-hawley2001

Hawthorne, John. 2004. *Knowledge and Lotteries*. Oxford: Oxford University Press.
^ref-hawthorne2004

Hayek, Friedrich A. 1944. *The Road to Serfdom*. University of Chicago Press.
^ref-hayek1944

Hayek, Friedrich A. 1945. “The Use of Knowledge in Society.” *American Economic Review* 35 (4): 519–530.
^ref-hayek1945

Hayek, Friedrich A. 1960. *The Constitution of Liberty*. University of Chicago Press.
^ref-hayek1960

Hayek, Friedrich A. 1976. *Law, Legislation and Liberty, Volume 2: The Mirage of Social Justice*. London: Routledge & Kegan Paul.
^ref-hayek1976

Hayles, N. Katherine. 1999. *How We Became Posthuman: Virtual Bodies in Cybernetics, Literature, and Informatics*. University of Chicago Press.
^ref-hayles1999

Healey, Richard. 2017. *The Quantum Revolution in Philosophy*. Oxford: Oxford University Press.
^ref-healey2017

Hebert), Anders Nygren (trans. A. G. 1932. *Agape and Eros: A Study of the Christian Idea of Love (Part I)*. London: SPCK (orig. Swedish 1930–36).
^ref-nygren1932

Heckman, James J. 2006. “Skill Formation and the Economics of Investing in Disadvantaged Children.” *Science* 312 (5782): 1900–1902.
^ref-heckman2006

Heckman, James J., and Dimitriy V. Masterov. 2007. “The Productivity Argument for Investing in Young Children.” *Review of Agricultural Economics* 29 (3): 446–493.
^ref-heckmanMasterov2007

Heckman, James J. 2013. *Giving Kids a Fair Chance*. MIT Press.
^ref-heckman2013

Hegel, G. W. F. (1807) 1977. *Phenomenology of Spirit*. Translated by A. V. Miller. Oxford: Oxford University Press.
^ref-hegel1807

Heidegger, M. (1927) 1962. *Being and Time*. Translated by J. Macquarrie and E. Robinson. New York: Harper & Row.
^ref-heidegger1927

Heidegger, Martin. (1954) 1977. “The Question Concerning Technology.” In The Question Concerning Technology and Other Essays, translated by William Lovitt, 3–35. New York: Harper & Row.
^ref-heidegger1954

Heidegger, Martin. 1957. *Identity and Difference (Identität und Differenz)*. Verlag Günther Neske (Pfullingen); Eng. trans. J. Stambaugh, Harper & Row (New York), 1969.
^ref-heidegger1957

Heil, John. 2003. *From an Ontological Point of View*. Clarendon Press / Oxford University Press (Oxford).
^ref-heil2003

Heim, S. Mark. 1995. *Salvations: Truth and Difference in Religion*. Orbis Books (Maryknoll, NY).
^ref-heim1995

Heinrich, Bernd. 1995. “Neophilia and Exploration in Juvenile Common Ravens, Corvus corax.” *Animal Behaviour* 50(3): 695–704.
^ref-heinrich1995

Held, David. 1995. *Democracy and the Global Order: From the Modern State to Cosmopolitan Governance*. Stanford University Press.
^ref-heldd1995

Held, Virginia. 2006. *The Ethics of Care: Personal, Political, and Global*. Oxford University Press.
^ref-held2006

Heller, Mark. 1990. *The Ontology of Physical Objects: Four-Dimensional Hunks of Matter*. Cambridge University Press.
^ref-heller1990

Helliwell, John F., Richard Layard, and Jeffrey D. Sachs. 2020. “World Happiness Report 2020.” Sustainable Development Solutions Network.
^ref-helliwell2020

Helm, Paul. 1988. *Eternal God: A Study of God Without Time*. Clarendon Press / Oxford University Press (Oxford & New York).
^ref-helm1988

Helm, Paul. 1993. *The Providence of God*. Leicester: Inter-Varsity Press (Contours of Christian Theology).
^ref-helm1993

Helm, Paul. 2010. *Eternal God: A Study of God Without Time*. Oxford University Press (2nd ed.).
^ref-helm2010

Hempel, Carl G. 1969. “Reduction: Ontological and Linguistic Facets.” In S. Morgenbesser, P. Suppes, and M. White (eds.), Philosophy, Science, and Method: Essays in Honor of Ernest Nagel, New York: St. Martin's Press.
^ref-hempel1969

Hennock, E. P. 2007. *The Origin of the Welfare State in England and Germany, 1850-1914: Social Policies Compared*. Cambridge University Press.
^ref-hennock2007

Henrich, Joseph. 2009. “The Evolution of Costly Displays, Cooperation and Religion: Credibility Enhancing Displays and Their Implications for Cultural Evolution.” *Evolution and Human Behavior* 30 (4): 244–260.
^ref-henrich2009

Henrich, Joseph. 2015. *The Secret of Our Success: How Culture Is Driving Human Evolution, Domesticating Our Species, and Making Us Smarter*. Princeton University Press.
^ref-henrich2015

Hensen, B., H. Bernien, A. E. Dréau, A. Reiserer, N. Kalb, M. S. Blok, J. Ruitenberg, R. F. L. Vermeulen, R. N. Schouten, C. Abellán, W. Amaya, V. Pruneri, M. W. Mitchell, M. Markham, D. J. Twitchen, D. Elkouss, S. Wehner, T. H. Taminiau, and R. Hanson. 2015. “Loophole-Free Bell Inequality Violation Using Electron Spins Separated by 1.3 Kilometres.” *Nature* 526 (7575): 682–686.
^ref-hensen2015

Henshilwood, Christopher S., Francesco d'Errico, Karen L. van Niekerk, Yvan Coquinot, Zenobia Jacobs, Stein-Erik Lauritzen, Michel Menu, and Renata García-Moreno. 2011. “A 100,000-Year-Old Ochre-Processing Workshop at Blombos Cave, South Africa.” Science 334 (6053): 219-222.
^ref-henshilwood2011

Herdt, G. 1994. *Third Sex, Third Gender: Beyond Sexual Dimorphism in Culture and History*. New York: Zone Books.
^ref-herdt1994

Herman, Edward S., and Noam Chomsky. 1988. *Manufacturing Consent: The Political Economy of the Mass Media*. Pantheon Books.
^ref-hermanchomsky1988

Herman, Judith Lewis. 1992. *Trauma and Recovery: The Aftermath of Violence—From Domestic Abuse to Political Terror*. Basic Books.
^ref-herman1992

Herron, M. D., J. M. Borin, J. C. Boswell, J. Walker, I.-C. K. Chen, C. A. Knox, M. Boyd, F. Rosenzweig, and W. C. Ratcliff. 2019. “De Novo Origins of Multicellularity in Response to Predation.” *Scientific Reports* 9 (1): 2328.
^ref-herron2019

Herschy, B., A. Whicher, E. Camprubí, C. Watson, L. Dartnell, J. Ward, J. R. G. Evans, and N. Lane. 2014. “An Origin-of-Life Reactor to Simulate Alkaline Hydrothermal Vents.” *Journal of Molecular Evolution* 79 (5–6): 213–227.
^ref-herschy2014

Heyman, Richard E., and Amy M. Smith Slep. 2001. “The Hazards of Predicting Divorce Without Crossvalidation.” *Journal of Marriage and Family* 63 (2): 473–479.
^ref-heymanSmithSlep2001

Heyting, Arend. 1956. *Intuitionism: An Introduction*. Amsterdam: North-Holland.
^ref-heyting1956

Hick, John. 1966. *Evil and the God of Love*. London: Macmillan, 1966 (pp. 403; 2nd ed. 1977; reissued Palgrave Macmillan, 2010).
^ref-hick1966

Hick, John. 1977. *The Myth of God Incarnate*. London: SCM Press.
^ref-hick1977

Hick, John. 1989. *An Interpretation of Religion: Human Responses to the Transcendent*. Yale University Press (Gifford Lectures).
^ref-hick1989

Hickok, Gregory. 2014. *The Myth of Mirror Neurons: The Real Neuroscience of Communication and Cognition*. W. W. Norton.
^ref-hickok2014

Higham, Tom et al. 2012. “Testing Models for the Beginnings of the Aurignacian and the Advent of Figurative Art and Music: The Radiocarbon Chronology of Geißenklösterle.” Journal of Human Evolution 62 (6): 664-676.
^ref-higham2012

Hilbert, David. 1899. *Grundlagen der Geometrie (Foundations of Geometry)*. Leipzig: Teubner.
^ref-hilbert1899

Hill, Lance. 2004. *The Deacons for Defense: Armed Resistance and the Civil Rights Movement*. Chapel Hill: University of North Carolina Press.
^ref-hill2004

Hill Collins, Patricia. 1990. *Black Feminist Thought: Knowledge, Consciousness, and the Politics of Empowerment*. Unwin Hyman.
^ref-collins1990

Hinckfuss, Ian. 1987. “The Moral Society: Its Structure and Effects.” Discussion Papers in Environmental Philosophy, Australian National University.
^ref-hinckfuss1987

Hintikka, Jaakko. 1962. “Cogito, Ergo Sum: Inference or Performance?” *The Philosophical Review*.
^ref-hintikka1962

Augustine of Hippo. (397–400) 1991. *Confessions*. Translated by H. Chadwick. Oxford: Oxford University Press.
^ref-augustine397

Augustine of Hippo. (400–428) 1991. *The Trinity*. Translated by Edmund Hill. Brooklyn, NY: New City Press.
^ref-augustine416

Augustine of Hippo. (413–426) 1998. *The City of God against the Pagans*. Edited and translated by R. W. Dyson. Cambridge: Cambridge University Press.
^ref-augustine413

Hirsch, Fred. 1976. *Social Limits to Growth*. Harvard University Press (Cambridge, MA).
^ref-hirsch1976

Hirsch, Eli. 2011. *Quantifier Variance and Realism: Essays in Metaontology*. Oxford University Press (New York).
^ref-hirsch2011

Hirschman, Albert O. 1970. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Harvard University Press.
^ref-hirschman1970

Hitchens, Christopher. 2007. *God Is Not Great: How Religion Poisons Everything*. Twelve (Hachette Book Group).
^ref-hitchens2007

Hjortland, Ole Thomassen. 2017. “Anti-exceptionalism About Logic.” *Philosophical Studies* 174 (3): 631–658.
^ref-hjortland2017

Hobbes, Thomas. 1651. *Leviathan*. Andrew Crooke.
^ref-hobbes1651

Hobbes, Thomas. 1654. *Of Liberty and Necessity*. London: W. B. for F. Eaglesfield.
^ref-hobbes1654

Hoffman, Martin L. 2000. *Empathy and Moral Development: Implications for Caring and Justice*. Cambridge University Press.
^ref-hoffman2000

Hoffman, Joshua, and Gary S. Rosenkrantz. 2002. *The Divine Attributes*. Blackwell.
^ref-hoffmannRosenkrantz2002

Hoffmann, Dirk L. et al. 2018. “U-Th Dating of Carbonate Crusts Reveals Neandertal Origin of Iberian Cave Art.” Science 359 (6378): 912-915.
^ref-hoffmann2018

Hoffmann, Dirk L. et al. 2020. “Response to White et al.'s Reply: 'Still No Archaeological Evidence That Neanderthals Created Iberian Cave Art'.” Journal of Human Evolution 144: 102810.
^ref-hoffmann2020

Hohwy, J. 2013. *The Predictive Mind*. Oxford: Oxford University Press.
^ref-hohwy2013

Holland, Tom. 2019. *Dominion: How the Christian Revolution Remade the World*. New York: Basic Books.
^ref-holland2019

Honneth, Axel. 1995. *The Struggle for Recognition: The Moral Grammar of Social Conflicts*. Polity Press / MIT Press.
^ref-honneth1995

Hood, Ralph W. 1975. “The Construction and Preliminary Validation of a Measure of Reported Mystical Experience.” Journal for the Scientific Study of Religion 14(1): 29–41.
^ref-hood1975

Hooft, Gerard 't. 1993. “Dimensional Reduction in Quantum Gravity.” In A. Ali, J. Ellis, and S. Randjbar-Daemi (eds.), Salamfestschrift, World Scientific Series in 20th Century Physics, vol. 4; arXiv:gr-qc/9310026.
^ref-tHooft1993

Hope, David, and Julian Limberg. 2022. “The Economic Consequences of Major Tax Cuts for the Rich.” *Socio-Economic Review* 20 (2): 539–559.
^ref-hopeLimberg2022

Horgan, Terence, and Mark Timmons. 1991. “New Wave Moral Realism Meets Moral Twin Earth.” *Journal of Philosophical Research* 16: 447–465.
^ref-horganTimmons1991

Horning, D. P., and G. F. Joyce. 2016. “Amplification of RNA by an RNA Polymerase Ribozyme.” *Proceedings of the National Academy of Sciences* 113 (35): 9786–9791.
^ref-horningJoyce2016

Horwich, Paul. 1987. *Asymmetries in Time: Problems in the Philosophy of Science*. MIT Press / Bradford Books (Cambridge, MA).
^ref-horwich1987

Hourani, George F. 1985. *Reason and Tradition in Islamic Ethics*. Cambridge University Press.
^ref-hourani1985

Howard, Philip H. 2016. *Concentration and Power in the Food System: Who Controls What We Eat?* Bloomsbury Academic.
^ref-howard2016

Howard-Snyder, Daniel, and Paul K. Moser. 2002. *Divine Hiddenness: New Essays*. Cambridge: Cambridge University Press.
^ref-howardSnyderMoser2002

Howard-Snyder, Daniel. 2009. “Epistemic Humility, Arguments from Evil, and Moral Skepticism.” Oxford Studies in Philosophy of Religion 2: 17–57.
^ref-howardSnyder2009

Hsu, Hsiang-Wen, et al. 2015. “Ongoing Hydrothermal Activities within Enceladus.” *Nature* 519(7542):207–210.
^ref-hsu2015

Hubble, Edwin. 1929. “A Relation between Distance and Radial Velocity among Extra-Galactic Nebulae.” *Proceedings of the National Academy of Sciences* 15(3):168–173.
^ref-hubble1929

Hudson, Hud. 2001. *A Materialist Metaphysics of the Human Person*. Cornell University Press (Ithaca, NY).
^ref-hudson2001

Hudson, Hud. 2005. *The Metaphysics of Hyperspace*. Oxford University Press.
^ref-hudson2005

Hudson, Hud. 2009. “Omnipresence.” In The Oxford Handbook of Philosophical Theology, ed. Thomas P. Flint and Michael C. Rea, 199–216. Oxford University Press.
^ref-hudson2009

Hudson, R., R. de Graaf, M. Strandoo Rodin, A. Ohno, N. Lane, S. E. McGlynn, Y. M. A. Yamada, R. Nakamura, L. M. Barge, D. Braun, and V. Sojo. 2020. “CO₂ Reduction Driven by a pH Gradient.” *Proceedings of the National Academy of Sciences* 117 (37): 22873–22879.
^ref-hudson2020

Huemer, Michael. 2009. “When is Parsimony a Virtue?” *The Philosophical Quarterly* 59 (235): 216–236.
^ref-huemer2009

Hughes, Christopher. 1989. *On a Complex Theory of a Simple God: An Investigation in Aquinas' Philosophical Theology*. Ithaca, NY: Cornell University Press.
^ref-hughes1989

Hughes, G. E., and M. J. Cresswell. 1996. *A New Introduction to Modal Logic*. London: Routledge.
^ref-hughesCresswell1996

Hughes, Caitlin E., and Alex Stevens. 2010. “What Can We Learn from the Portuguese Decriminalization of Illicit Drugs?” *British Journal of Criminology* 50 (6): 999–1022.
^ref-hughesStevens2010

Hughes, David P., Sandra B. Andersen, Nigel L. Hywel-Jones, Winanda Himaman, Johan Billen, and Jacobus J. Boomsma. 2011. “Behavioral Mechanisms and Morphological Symptoms of Zombie Ants Dying from Fungal Infection.” *BMC Ecology* 11: 13.
^ref-hughes2011

Hughes, David P., Jacques Brodeur, and Frédéric Thomas. 2012. *Host Manipulation by Parasites*. Oxford University Press.
^ref-hughes2012

Hull, David L. 1976. “Are Species Really Individuals?” Systematic Zoology 25 (2): 174-191.
^ref-hull1976

Hume, David. (1739–1740) 2000. *A Treatise of Human Nature*. Edited by D. F. Norton and M. J. Norton. Oxford: Oxford University Press.
^ref-hume1739

Hume, David. (1748) 1999. *An Enquiry concerning Human Understanding*. Edited by Tom L. Beauchamp. Oxford: Oxford University Press.
^ref-hume1748

Hume, David. 1779. *Dialogues concerning Natural Religion*. London (publisher not named), 1779 (posthumous).
^ref-hume1779

Humphrey, N. K. 1976. “The Social Function of Intellect.” In Growing Points in Ethology, edited by P. P. G. Bateson and R. A. Hinde, 303–317. Cambridge: Cambridge University Press.
^ref-humphrey1976

Hunsinger, George. 1991. *How to Read Karl Barth: The Shape of His Theology*. New York: Oxford University Press.
^ref-hunsinger1991

Hunt, Gavin R. 1996. “Manufacture and Use of Hook-Tools by New Caledonian Crows.”
^ref-hunt1996

Hursthouse, Rosalind. 1999. *On Virtue Ethics*. Oxford University Press.
^ref-hursthouse1999

Husak, Douglas. 2010. *The Philosophy of Criminal Law: Selected Essays*. Oxford University Press.
^ref-husak2010

Husserl, Edmund. 1900–01. *Logical Investigations*. Halle: M. Niemeyer (2 vols.; Eng. trans. J. N. Findlay, Routledge & Kegan Paul, 1970).
^ref-husserl1900

Husserl, Edmund. 1913. *Ideas Pertaining to a Pure Phenomenology (Ideas I)*. Halle: M. Niemeyer (Ideen I; Eng. trans. Boyce Gibson 1931 / Kersten 1983).
^ref-husserl1913

Hutchins, Edwin. 1995. *Cognition in the Wild*. MIT Press.
^ref-hutchins1995

Huxley, Aldous. 1945. *The Perennial Philosophy*. Harper & Brothers.
^ref-huxley1945

Ickes, William. 2003. *Everyday Mind Reading: Understanding What Other People Think and Feel*. Prometheus Books.
^ref-ickes2003

Ijjas, A., and P. J. Steinhardt. 2019. “A New Kind of Cyclic Universe.” *Physics Letters B* 795: 666–672.
^ref-ijjasSteinhardt2019

Ijjas, A., and P. J. Steinhardt. 2022. “Entropy, Black Holes, and the New Cyclic Universe.” *Physics Letters B* 824: 136823.
^ref-ijjasSteinhardt2022

Ikeda, Michael, and Bill Jefferys. 2006. “The Anthropic Principle Does Not Support Supernaturalism.” in M. Martin & R. Monnier (eds.), The Improbability of God (Prometheus Books, Amherst, NY), pp. 150–166.
^ref-ikedaJefferys2006

Illich, Ivan. 1971. *Deschooling Society*. Harper & Row.
^ref-illich1971

Imachi, H., M. K. Nobu, N. Nakahara, Y. Morono, M. Ogawara, Y. Takaki, Y. Takano, K. Uematsu, T. Ikuta, M. Ito, et al. 2020. “Isolation of an Archaeon at the Prokaryote–Eukaryote Interface.” *Nature* 577 (7791): 519–525.
^ref-imachi2020

Inglehart, Ronald, and Christian Welzel. 2005. *Modernization, Cultural Change, and Democracy: The Human Development Sequence*. Cambridge University Press.
^ref-inglehartWelzel2005

Inglehart, Ronald F. 2018. *Cultural Evolution: People's Motivations Are Changing, and Reshaping the World*. Cambridge University Press.
^ref-inglehart2018

Inglehart, Ronald F. 2020. *Religion's Sudden Decline: What's Causing It, and What Comes Next?* Oxford University Press (New York).
^ref-inglehart2020

Inman, Ross D. 2017. “Omnipresence and the Location of the Immaterial.” Oxford Studies in Philosophy of Religion 8: 167–206.
^ref-inman2017

Institute of Medicine (US), Committee on LGBT Health Issues and Research Gaps and Opportunities. 2011. “The Health of Lesbian, Gay, Bisexual, and Transgender People: Building a Foundation for Better Understanding.” National Academies Press, Washington, DC.
^ref-iom2011

International Council on Biblical Inerrancy. 1978. “The Chicago Statement on Biblical Inerrancy.” Chicago: International Council on Biblical Inerrancy.
^ref-icbi1978

International Theological Commission. 2007. “The Hope of Salvation for Infants Who Die without Being Baptised.” Libreria Editrice Vaticana.
^ref-internationaltheologicalcommission2007

IRENA. 2024. “Renewable Power Generation Costs in 2023.” International Renewable Energy Agency.
^ref-irena2023

Jablonka, Eva, and Marion J. Lamb. 2005. *Evolution in Four Dimensions: Genetic, Epigenetic, Behavioral, and Symbolic Variation in the History of Life*. Cambridge, MA: MIT Press.
^ref-jablonkaLamb2005

Jackson, Frank. 1982. “Epiphenomenal Qualia.” *The Philosophical Quarterly* 32 (127): 127–136.
^ref-jackson1982

Jackson, Frank. 1998. *From Metaphysics to Ethics: A Defence of Conceptual Analysis*. Clarendon Press / Oxford University Press (Oxford).
^ref-jackson1998

Jackson, C. Kirabo, Rucker C. Johnson, and Claudia Persico. 2016. “The Effects of School Spending on Educational and Economic Outcomes: Evidence from School Finance Reforms.” *Quarterly Journal of Economics* 131 (1): 157–218.
^ref-jacksonJohnsonPersico2016

Jacobs, Jane. 1961. *The Death and Life of Great American Cities*. New York: Random House.
^ref-jacobs1961

Jacobs, Jonathan D. 2010. “A Powers Theory of Modality: Or, How I Learned to Stop Worrying and Reject Possible Worlds.” *Philosophical Studies* 151 (2): 227-248.
^ref-jacobs2010

James, William. 1884. “What Is an Emotion?” *Mind os-IX (34):* 188–205.
^ref-james1884

James, William. 1890. *The Principles of Psychology*. New York: Henry Holt and Company.
^ref-james1890

James, William. 1896. “The Will to Believe.” *The New World* 5: 327–347.
^ref-james1896

James, William. 1902. *The Varieties of Religious Experience*. Longmans, Green, and Co.
^ref-james1902

James, William. 1904. “Does 'Consciousness' Exist?” *The Journal of Philosophy, Psychology and Scientific Methods* 1 (18): 477–491.
^ref-james1904

Janik, Vincent M., and Peter J. B. Slater. 1998. “Vocal Learning in Mammals.”
^ref-janikSlater1998

Jarzynski, C. 1997. “Nonequilibrium Equality for Free Energy Differences.” *Physical Review Letters* 78 (14): 2690–2693.
^ref-jarzynski1997

Jaspers, Karl. 1949. *Vom Ursprung und Ziel der Geschichte*. Artemis Verlag.
^ref-jaspers1949

Jaubert, Jacques et al. 2016. “Early Neanderthal Constructions Deep in Bruniquel Cave in Southwestern France.” Nature 534 (7605): 111-114.
^ref-jaubert2016

Jelbert, Sarah A., Alex H. Taylor, Lucy G. Cheke, Nicola S. Clayton, and Russell D. Gray. 2014. “Using the Aesop's Fable Paradigm to Investigate Causal Understanding of Water Displacement by New Caledonian Crows.” *PLOS ONE* 9 (3): e92895.
^ref-jelbertEtAl2014

Jenkins, C. S. 2011. “Is Metaphysical Dependence Irreflexive?” *The Monist* 94 (2): 267–276.
^ref-jenkins2011

Jervis, Robert. 1976. *Perception and Misperception in International Politics*. Princeton University Press.
^ref-jervis1976

Ji, Ziwei et al. 2023. “Survey of Hallucination in Natural Language Generation.” ACM Computing Surveys 55 (12): 1-38.
^ref-ji2023

Johnson, Marcia K., Shahin Hashtroudi, and D. Stephen Lindsay. 1993. “Source Monitoring.” *Psychological Bulletin* 114 (1): 3–28.
^ref-johnsonHashtroudiLindsay1993

Jonas, Hans. 1966. *The Phenomenon of Life: Toward a Philosophical Biology*. Harper & Row.
^ref-jonas1966

Jonas, Hans. 1984. *The Imperative of Responsibility: In Search of an Ethics for the Technological Age*. University of Chicago Press.
^ref-jonas1984

Joordens, Josephine C. A. et al. 2014. “Homo erectus at Trinil on Java Used Shells for Tool Production and Engraving.” Nature 518 (7538): 228-231.
^ref-joordens2014

Joos, Erich, H. Dieter Zeh, Claus Kiefer, Domenico Giulini, Joachim Kupsch, and Ion-Olimpiu Stamatescu. 2003. *Decoherence and the Appearance of a Classical World in Quantum Theory*. Springer (2nd ed.).
^ref-joos2003

Jordan, Jeff. 2006. *Pascal's Wager: Pragmatic Arguments and Belief in God*. Clarendon Press / Oxford University Press (Oxford).
^ref-jordan2006

Joule, James Prescott. 1843–1845. “On the Calorific Effects of Magneto-Electricity, and on the Mechanical Value of Heat.” *The London, Edinburgh, and Dublin Philosophical Magazine (3rd series)* 23:263–276.
^ref-joule1843

Jow, D. L., and D. Scott. 2020. “Re-Evaluating Evidence for Hawking Points in the CMB.” *Journal of Cosmology and Astroparticle Physics* 2020 (3): 021.
^ref-jowScott2020

Joyce, G. F. 1994. “Foreword.” In Origins of Life: The Central Concepts, edited by D. W. Deamer and G. R. Fleischaker, xi–xii. Boston: Jones and Bartlett.
^ref-joyce1994

Joyce, Richard. 2001. *The Myth of Morality*. Cambridge University Press.
^ref-joyce2001

Joyce, G. F. 2002. “The Antiquity of RNA-Based Evolution.” *Nature* 418 (6894): 214–221.
^ref-joyce2002

Joyce, Richard. 2006. *The Evolution of Morality*. MIT Press.
^ref-joyce2006

Joyce, Helen. 2021. *Trans: When Ideology Meets Reality*. Oneworld Publications.
^ref-joyce2021

Kaba, Mariame. 2021. *We Do This 'Til We Free Us: Abolitionist Organizing and Transforming Justice*. Haymarket Books.
^ref-kaba2021

Kabadayi, Can, and Mathias Osvath. 2017. “Ravens Parallel Great Apes in Flexible Planning for Tool-Use and Bartering.” Science 357 (6347): 202-204.
^ref-kabadayiOsvath2017

Kabat-Zinn, Jon. 1990. *Full Catastrophe Living: Using the Wisdom of Your Body and Mind to Face Stress, Pain, and Illness*. Delta.
^ref-kabatZinn1990

Kafer, Alison. 2013. *Feminist, Queer, Crip*. Indiana University Press.
^ref-kafer2013

Kagan, Shelly. 1989. *The Limits of Morality*. Oxford University Press.
^ref-kagan1989

Kagan, Shelly. 2012. *Death*. Yale University Press.
^ref-kagan2012

Kahn, Charles H. 1979. *The Art and Thought of Heraclitus*. Cambridge University Press.
^ref-kahn1979

Kahneman, Daniel, and Amos Tversky. 1979. “Prospect Theory: An Analysis of Decision under Risk.” *Econometrica* 47 (2): 263–291.
^ref-kahnemanTversky1979

Kahneman, D., and A. Deaton. 2010. “High Income Improves Evaluation of Life but Not Emotional Well-Being.” *Proceedings of the National Academy of Sciences* 107 (38): 16489–16493.
^ref-kahnemanDeaton2010

Kahneman, Daniel. 2011. *Thinking, Fast and Slow*. Farrar, Straus and Giroux (New York).
^ref-kahneman2011

Kamm, Frances M. 2007. *Intricate Ethics: Rights, Responsibilities, and Permissible Harm*. Oxford University Press.
^ref-kamm2007

Kane, Robert. 1996. *The Significance of Free Will*. New York: Oxford University Press.
^ref-kane1996

Kant, I. (1781) 1998. *Critique of Pure Reason*. Translated by P. Guyer and A. W. Wood. Cambridge: Cambridge University Press.
^ref-kant1781

Kant, Immanuel. 1785. *Groundwork of the Metaphysics of Morals*. Riga: Johann Friedrich Hartknoch.
^ref-kant1785

Kant, Immanuel. 1788. *Critique of Practical Reason*. Riga: Johann Friedrich Hartknoch.
^ref-kant1788

Kant, Immanuel. 1793. *Religion within the Boundaries of Mere Reason*. Cambridge University Press (Cambridge Edition of the Works of Immanuel Kant).
^ref-kant1793

Kant, Immanuel. 1795. *Perpetual Peace: A Philosophical Sketch*. F. Nicolovius.
^ref-kant1795

Kant, Immanuel. 1797. *The Metaphysics of Morals*. Cambridge University Press.
^ref-kant1797

Kaplan, David. 1989. “Demonstratives.”
^ref-kaplan1989

Karban, Richard. 2015. *Plant Sensing and Communication*. University of Chicago Press.
^ref-karban2015

Karkazis, Katrina. 2008. *Fixing Sex: Intersex, Medical Authority, and Lived Experience*. Duke University Press.
^ref-karkazis2008

Karofsky, Amy. 2021. *A Case for Necessitarianism*. Routledge (Routledge Studies in Metaphysics).
^ref-karofsky2021

Kastrup, Bernardo. 2014. *Why Materialism Is Baloney*. Iff Books (Winchester, UK).
^ref-kastrup2014

Kastrup, Bernardo. 2019. *The Idea of the World: A Multi-Disciplinary Argument for the Mental Nature of Reality*. Iff Books (Winchester, UK).
^ref-kastrup2019

Kastrup, Bernardo. 2024. *Analytic Idealism in a Nutshell*. Iff Books (Winchester, UK).
^ref-kastrup2024

Katz, Steven T. 1978. “Language, Epistemology, and Mysticism.” In Mysticism and Philosophical Analysis, ed. Steven T. Katz (Oxford University Press), pp. 22–74.
^ref-katz1978

Kauffman, Stuart A. 1986. “Autocatalytic Sets of Proteins.” *Journal of Theoretical Biology* 119(1):1–24.
^ref-kauffman1986

Kauffman, Stuart A. 1993. *The Origins of Order: Self-Organization and Selection in Evolution*. New York: Oxford University Press.
^ref-kauffman1993

Kauffman, Stuart A. 1995. *At Home in the Universe: The Search for the Laws of Self-Organization and Complexity*. New York: Oxford University Press.
^ref-kauffman1995

Kauffman, Stuart A. 2008. *Reinventing the Sacred: A New View of Science, Reason, and Religion*. New York: Basic Books.
^ref-kauffman2008

Kegl, Judy, Ann Senghas, and Marie Coppola. 1999. “Creation Through Contact: Sign Language Emergence and Sign Language Change in Nicaragua.”
^ref-keglSenghasCoppola1999

Kelemen, Deborah. 2004. “Are Children 'Intuitive Theists'? Reasoning About Purpose and Design in Nature.” *Psychological Science* 15(5): 295–301.
^ref-kelemen2004

Kelly, Thomas. 2010. “Peer Disagreement and Higher-Order Evidence.” In Disagreement, Oxford University Press.
^ref-kelly2010

Keltner, Dacher, and Jonathan Haidt. 2003. “Approaching Awe, a Moral, Spiritual, and Aesthetic Emotion.” Cognition and Emotion 17 (2): 297-314.
^ref-keltnerHaidt2003

Kern, David M., M. Soledad Cepeda, and Frank Wiegand. 2021. “Treatment patterns of patients diagnosed with major depressive disorder and suicidal ideation or attempt: a U.S. population-based study utilizing real-world data.” *BMC Psychiatry* 21:608.
^ref-kern2021

Kerr, Gaven. 2015. *Aquinas's Way to God: The Proof in De Ente et Essentia*. New York: Oxford University Press.
^ref-kerr2015

Kerring, Marlowe. 2022. “The Afterlife Dilemma: A Problem for the Christian Pro-Life Movement.” *Journal of Controversial Ideas* 2 (2): article 210.
^ref-kerring2022

Key, Brian. 2016. “Why Fish Do Not Feel Pain.” *Animal Sentience* 3 (1): 1–34.
^ref-key2016

Keysers, Christian. 2011. *The Empathic Brain*. Social Brain Press.
^ref-keysers2011

Keyssar, Alexander. 2009. *The Right to Vote: The Contested History of Democracy in the United States*. Basic Books.
^ref-keyssar2009

Khalil, Atif. 2011. “Is God Obliged to Answer Prayers of Petition (Du'a)? The Response of Classical Sufis and Qur'anic Exegetes.” Journal of Medieval Religious Cultures 37 (2).
^ref-khalil2011

Killingsworth, M. A. 2021. “Experienced Well-Being Rises with Income, Even above $75,000 per Year.” *Proceedings of the National Academy of Sciences* 118 (4): e2016976118.
^ref-killingsworth2021

Killingsworth, M. A., D. Kahneman, and B. Mellers. 2023. “Income and Emotional Well-Being: A Conflict Resolved.” *Proceedings of the National Academy of Sciences* 120 (10): e2208661120.
^ref-killingsworth2023

Kim, Jaegwon. 1998. *Mind in a Physical World: An Essay on the Mind-Body Problem and Mental Causation*. Cambridge, MA: MIT Press.
^ref-kim1998

Kimmerer, Robin Wall. 2013. *Braiding Sweetgrass: Indigenous Wisdom, Scientific Knowledge and the Teachings of Plants*. Milkweed Editions.
^ref-kimmerer2013

King, Stephanie L., and Vincent M. Janik. 2013. “Bottlenose Dolphins Can Use Learned Vocal Labels to Address Each Other.”
^ref-kingJanik2013

Kipping, D. 2020. “An Objective Bayesian Analysis of Life's Early Start and Our Late Arrival.” *Proceedings of the National Academy of Sciences* 117 (22): 11995–12003.
^ref-kipping2020

Kirchhoff, M., T. Parr, E. Palacios, K. Friston, and J. Kiverstein. 2018. “The Markov Blankets of Life: Autonomy, Active Inference and the Free Energy Principle.” *Journal of the Royal Society Interface* 15 (138): 20170792.
^ref-kirchhoff2018

Kirkwood, Thomas B. L. 1977. “Evolution of Ageing.” Nature 270 (5635): 301-304.
^ref-kirkwood1977

Kittay, Eva Feder. 1999. *Love's Labor: Essays on Women, Equality, and Dependency*. Routledge.
^ref-kittay1999

Klein, Peter D. 1971. “A Proposed Definition of Propositional Knowledge.” *The Journal of Philosophy* 68(16): 471–482.
^ref-klein1971

Klein, Naomi. 2007. *The Shock Doctrine: The Rise of Disaster Capitalism*. Knopf Canada / Metropolitan Books.
^ref-klein2007

Klein, Colin. 2015. *What the Body Commands: The Imperative Theory of Pain*. MIT Press.
^ref-klein2015

Klein, Richard A. et al. 2022. “Many Labs 4: Failure to Replicate Mortality Salience Effect With and Without Original Author Involvement.” Collabra: Psychology 8 (1): 35271.
^ref-klein2022

Klinenberg, Eric. 2002. *Heat Wave: A Social Autopsy of Disaster in Chicago*. University of Chicago Press.
^ref-klinenberg2002

Klinenberg, Eric. 2018. *Palaces for the People: How Social Infrastructure Can Help Fight Inequality, Polarization, and the Decline of Civic Life*. Crown.
^ref-klinenberg2018

Knitter, Paul F. 2002. *Introducing Theologies of Religions*. Orbis Books (Maryknoll, NY).
^ref-knitter2002

Knott, Cheryl D. 2009. “Orangutans: Sexual Coercion without Sexual Violence.” In Sexual Coercion in Primates and Humans: An Evolutionary Perspective on Male Aggression against Females, edited by Martin N. Muller and Richard W. Wrangham, 81–111. Cambridge, MA: Harvard University Press.
^ref-knott2009

Koch, Klaus. 1955. “Gibt es ein Vergeltungsdogma im Alten Testament?” *Zeitschrift für Theologie und Kirche* 52: 1–42.
^ref-koch1953

Koch, Christof. 2019. *The Feeling of Life Itself: Why Consciousness Is Widespread but Can't Be Computed*. MIT Press.
^ref-koch2019

Koelsch, Stefan. 2014. “Brain Correlates of Music-Evoked Emotions.” Nature Reviews Neuroscience 15: 170-180.
^ref-koelsch2014

Kohda, Masanori, Takashi Hotta, Tomohiro Takeyama, Satoshi Awata, Hirokazu Tanaka, Jun-ya Asai, and Alex L. Jordan. 2019. “If a fish can pass the mark test, what are the implications for consciousness and self-awareness testing in animals?” PLOS Biology 17 (2): e3000021.
^ref-kohda2019

Koons, Robert C. 1997. “A New Look at the Cosmological Argument.” *American Philosophical Quarterly* 34 (2): 171–192.
^ref-koons1997

Koons, Robert C. 2014. “A New Kalam Argument: Revenge of the Grim Reaper.” *Noûs* 48 (2): 256–267.
^ref-koons2014

Korman, Daniel Z., and Dustin Locke. 2020. “Against Minimalist Responses to Moral Debunking Arguments.” Oxford Studies in Metaethics 15: 309-332.
^ref-kormanLocke2020

Korman, Daniel Z., and Dustin Locke. 2023. “An Explanationist Account of Genealogical Defeat.” Philosophy and Phenomenological Research 106(1): 176-195.
^ref-kormanLocke2023

Korsgaard, Christine M. 1996. *The Sources of Normativity*. Cambridge University Press.
^ref-korsgaard1996

Korsgaard, Christine M. 2009. *Self-Constitution: Agency, Identity, and Integrity*. Oxford University Press.
^ref-korsgaard2009

Korsgaard, Christine M. 2018. *Fellow Creatures: Our Obligations to the Other Animals*. Oxford University Press.
^ref-korsgaard2018

Kosslyn, Stephen M., Giorgio Ganis, and William L. Thompson. 2001. “Neural foundations of imagery.” *Nature Reviews Neuroscience* 2(9): 635–642.
^ref-kosslyn2001

Kraay, Klaas J. 2010. “Theism, Possible Worlds, and the Multiverse.” *Philosophical Studies* 147, no. 3: 355–368.
^ref-kraay2010

Kratzer, Angelika. 2012. *Modals and Conditionals: New and Revised Perspectives*. Oxford University Press.
^ref-kratzer2012

Kraus, Elizabeth M. 1979. *The Metaphysics of Experience: A Companion to Whitehead's Process and Reality*. Fordham University Press (New York).
^ref-kraus1979

Kraut, Richard. 2007. *What Is Good and Why: The Ethics of Well-Being*. Harvard University Press.
^ref-kraut2007

Kretzmann, Norman. 1966. “Omniscience and Immutability.” *Journal of Philosophy* 63, no. 14: 409–421.
^ref-kretzmann1966

Kriegel, Uriah. 2009. *Subjective Consciousness: A Self-Representational Theory*. Oxford University Press.
^ref-kriegel2009

Kripke, Saul A. 1963. “Semantical Analysis of Modal Logic I: Normal Modal Propositional Calculi.” *Zeitschrift für mathematische Logik und Grundlagen der Mathematik* 9 (5–6): 67–96.
^ref-kripke1963

Kripke, Saul A. 1980. *Naming and Necessity*. Cambridge, MA: Harvard University Press.
^ref-kripke1980

Kripke, Saul A. 1982. *Wittgenstein on Rules and Private Language*. Harvard University Press.
^ref-kripke1982

Kropotkin, Peter. 1902. *Mutual Aid: A Factor of Evolution*. William Heinemann, London.
^ref-kropotkin1902

Kruijver, F. P. M., J.-N. Zhou, C. W. Pool, M. A. Hofman, L. J. G. Gooren, and D. F. Swaab. 2000. “Male-to-Female Transsexuals Have Female Neuron Numbers in a Limbic Nucleus.” *The Journal of Clinical Endocrinology & Metabolism* 85 (5): 2034–2041.
^ref-kruijver2000

Krupenye, Christopher, Fumihiro Kano, Satoshi Hirata, Josep Call, and Michael Tomasello. 2016. “Great apes anticipate that other individuals will act according to false beliefs.” *Science* 354(6308): 110–114.
^ref-krupenye2016

Kühl, Hjalmar S. et al. 2016. “Chimpanzee Accumulative Stone Throwing.” Scientific Reports 6: 22219.
^ref-kuhl2016

Kurth, Charlie. 2018. *The Anxious Mind: An Investigation into the Varieties and Virtues of Anxiety*. MIT Press.
^ref-kurth2018

Kussell, E., and S. Leibler. 2005. “Phenotypic Diversity, Population Growth, and Information in Fluctuating Environments.” *Science* 309 (5743): 2075–2078.
^ref-kussell2005

Kvanvig, Jonathan L., and Hugh J. McCann. 1988. “Divine Conservation and the Persistence of the World.” In Thomas V. Morris (ed.), Divine and Human Action: Essays in the Metaphysics of Theism, Ithaca, NY: Cornell University Press, pp. 13–49.
^ref-kvanvigMccann1988

Kvanvig, Jonathan L. 1993. *The Problem of Hell*. Oxford University Press.
^ref-kvanvig1993

La Scola, Bernard, Christelle Desnues, and Didier Raoult. 2008. “The Virophage as a Unique Parasite of the Giant Mimivirus.” *Nature* 455(7209):100–104.
^ref-raoultLaScola2008

LaCanne, Claire E., and Jonathan G. Lundgren. 2018. “Regenerative Agriculture: Merging Farming and Natural Resource Conservation Profitably.” *PeerJ* 6: e4428.
^ref-laCanneLundgren2018

Lackey, Jennifer. 2014. *Essays in Collective Epistemology*. Oxford University Press.
^ref-lackey2014

Laclau, Ernesto, and Chantal Mouffe. 1985. *Hegemony and Socialist Strategy: Towards a Radical Democratic Politics*. Verso.
^ref-laclauMouffe1985

LaDuke, Winona. 1999. *All Our Relations: Native Struggles for Land and Life*. South End Press.
^ref-laduke1999

Ladyman, James, Don Ross, David Spurrett, and John Collier. 2007. *Every Thing Must Go: Metaphysics Naturalized*. Oxford: Oxford University Press.
^ref-ladymanRoss2007

Lagercrantz, Hugo, and Jean-Pierre Changeux. 2009. “The Emergence of Human Consciousness: From Fetal to Neonatal Life.” *Pediatric Research* 65(3):255–260.
^ref-lagercrantzchangeux2009

Laidre, Mark E. 2021. “Animal Architecture.” Current Biology 31 (22): R1458-R1464.
^ref-laidre2021

Laland, Kevin N. 2017. *Darwin's Unfinished Symphony: How Culture Made the Human Mind*. Princeton University Press.
^ref-laland2017

Lamb, David T. 2022. *God Behaving Badly: Is the God of the Old Testament Angry, Sexist, and Racist?* IVP Academic (expanded edition; orig. 2011).
^ref-lamb2022

Landauer, R. 1961. “Irreversibility and Heat Generation in the Computing Process.” *IBM Journal of Research and Development* 5 (3): 183–191.
^ref-landauer1961

Landemore, Hélène. 2013. *Democratic Reason: Politics, Collective Intelligence, and the Rule of the Many*. Princeton University Press.
^ref-landemore2013

Landemore, Hélène. 2020. *Open Democracy: Reinventing Popular Rule for the Twenty-First Century*. Princeton, NJ: Princeton University Press.
^ref-landemore2020

Lane, N., and W. F. Martin. 2012. “The Origin of Membrane Bioenergetics.” *Cell* 151 (7): 1406–1416.
^ref-laneMartin2012

Lane, N. 2015. *The Vital Question: Energy, Evolution, and the Origins of Complex Life*. New York: W. W. Norton.
^ref-lane2015

Lane, Z. G., A. Seifert, R. Ridden-Harper, and D. L. Wiltshire. 2025. “Cosmological Foundations Revisited with Pantheon+.” *Monthly Notices of the Royal Astronomical Society* 536 (2): 1752–1777.
^ref-laneEtAl2025

Lang, Martin. 2026. “Flood Story.” Oxford Classical Dictionary.
^ref-lang2026flood

Lango, John W. 1972. *Whitehead's Ontology*. State University of New York Press (Albany).
^ref-lango1972

Langsam, Harold. 2011. *The Wonder of Consciousness: Understanding the Mind through Philosophical Reflection*. The MIT Press.
^ref-langsam2011

Langton, Rae. 1998. *Kantian Humility: Our Ignorance of Things in Themselves*. Oxford University Press.
^ref-langton1998

Laozi. (c. 4th c. BCE) 1963. *Tao Te Ching*. Translated by D. C. Lau. London: Penguin.
^ref-laozi1963

Laplace, Pierre-Simon. 1814. *A Philosophical Essay on Probabilities*. Paris: Courcier (Essai philosophique sur les probabilités).
^ref-laplace1814

Lareau, Annette. 2003. *Unequal Childhoods: Class, Race, and Family Life*. University of California Press.
^ref-lareau2003

Larmer, Robert A. 2014. *The Legitimacy of Miracle*. Lanham, MD: Lexington Books.
^ref-larmer2014

Lasch, Christopher. 1995. *The Revolt of the Elites and the Betrayal of Democracy*. W. W. Norton.
^ref-lasch1995

Latour, Bruno. 1986. “Visualization and Cognition: Thinking with Eyes and Hands.” Knowledge and Society 6: 1-40.
^ref-latour1986

Latour, Bruno. 1987. *Science in Action: How to Follow Scientists and Engineers Through Society*. Harvard University Press.
^ref-latour1987

Latour, Bruno. 2005. *Reassembling the Social: An Introduction to Actor-Network-Theory*. Oxford University Press.
^ref-latour2005

Law, Stephen. 2010. “The evil-god challenge.” *Religious Studies* 46 (3): 353–373.
^ref-law2010

Lawford-Smith, Holly. 2022. *Gender-Critical Feminism*. Oxford University Press.
^ref-lawfordSmith2022

Lazard. 2023. “Lazard's Levelized Cost of Energy Analysis—Version 16.0.” Lazard.
^ref-lazard2023

Lazarus, Richard S. 1991. *Emotion and Adaptation*. Oxford University Press (New York).
^ref-lazarus1991

Le Poidevin, Robin. 1991. *Change, Cause, and Contradiction*. Macmillan (London) / St. Martin's Press (New York).
^ref-lePoidevin1991

LeDoux, Joseph E. 1996. *The Emotional Brain: The Mysterious Underpinnings of Emotional Life*. Simon & Schuster (New York).
^ref-ledoux1996

LeDoux, Joseph E. 2012. “Rethinking the Emotional Brain.” *Neuron* 73(4): 653–676.
^ref-ledoux2012

Leftow, Brian. 1991. *Time and Eternity*. Cornell University Press (Ithaca, NY & London).
^ref-leftow1991

Leftow, Brian. 2004. “A Latin Trinity.” *Faith and Philosophy* 21 (3): 304–333.
^ref-leftow2004

Leftow, Brian. 2012. *God and Necessity*. Oxford: Oxford University Press.
^ref-leftow2012

Lehrer, Keith, and Thomas Paxson. 1969. “Knowledge: Undefeated Justified True Belief.” *The Journal of Philosophy* 66(8): 225–237.
^ref-lehrerPaxson1969

Leibniz, G. W. (1714) 1989. “Monadology.” Philosophical Essays, translated by R. Ariew and D. Garber. Indianapolis: Hackett.
^ref-leibniz1714

Leibniz, G. W. 1710. *Theodicy: Essays on the Goodness of God, the Freedom of Man and the Origin of Evil*. Original: Essais de Théodicée (Amsterdam, 1710); standard Eng. ed. trans. E. M. Huggard, ed. A. Farrer (Routledge & Kegan Paul, 1951; repr. Open Court, 1985).
^ref-leibniz1710

Leibniz, G. W., and Samuel Clarke. 1715–1716. *The Leibniz–Clarke Correspondence*. Ed. H. G. Alexander, Manchester University Press (1956).
^ref-leibniz1715

Lenin, Vladimir I. 1917. *The State and Revolution*. Zhizn' i Znanie, Petrograd (pub. 1918).
^ref-lenin1917

Lenton, Timothy M. 1998. “Gaia and Natural Selection.” *Nature* 394: 439–447.
^ref-lenton1998

León-Portilla, Miguel. 1963. *Aztec Thought and Culture: A Study of the Ancient Nahuatl Mind*. University of Oklahoma Press.
^ref-leonPortilla1963

Leslie, John. 1979. *Value and Existence*. Oxford: Basil Blackwell.
^ref-leslie1979

Leśniewski, Stanisław. 1916. “Podstawy ogólnej teorii mnogości I (Foundations of the General Theory of Sets I).” Moscow: Prace Polskiego Koła Naukowego w Moskwie.
^ref-lesniewski1916

Letheby, Chris. 2021. *Philosophy of Psychedelics*. Oxford University Press.
^ref-letheby2021

LeVay, S. 1991. “A Difference in Hypothalamic Structure between Heterosexual and Homosexual Men.” *Science* 253 (5023): 1034–1037.
^ref-levay1991

Levin, M. 2019. “The Computational Boundary of a 'Self': Developmental Bioelectricity Drives Multicellularity and Scale-Free Cognition.” *Frontiers in Psychology* 10: 2688.
^ref-levin2019

Levinas, Emmanuel. 1961. *Totality and Infinity: An Essay on Exteriority (Totalité et Infini: essai sur l'extériorité)*. M. Nijhoff (French orig. 1961); Duquesne University Press (English trans. A. Lingis, 1969).
^ref-levinas1961

Levine, Joseph. 1983. “Materialism and Qualia: The Explanatory Gap.” *Pacific Philosophical Quarterly* 64 (4): 354–361.
^ref-levine1983

Levine, Michael P. 1994. *Pantheism: A Non-Theistic Concept of Deity*. Routledge.
^ref-levine1994

Levinson, Sanford. 1989. “The Embarrassing Second Amendment.” *Yale Law Journal* 99 (3): 637–659.
^ref-levinson1989

Levinson, Jerrold. 1990. *Music, Art, and Metaphysics: Essays in Philosophical Aesthetics*. Cornell University Press.
^ref-levinson1990

Levinson, Stephen C. 2003. *Space in Language and Cognition: Explorations in Cognitive Diversity*. Cambridge University Press.
^ref-levinson2003

Levinson, Stephen C. 2004. “Deixis.”
^ref-levinson2004

Levinson, Jerrold. 2006. *Contemplating Art: Essays in Aesthetics*. Oxford University Press.
^ref-levinson2006

Lewis, C. I., and C. H. Langford. 1932. *Symbolic Logic*. New York: Century.
^ref-lewisLangford1932

Lewis, C. S. 1940. *The Problem of Pain*. London: The Centenary Press (Geoffrey Bles), 1940 (US: New York: Macmillan).
^ref-lewis1940

Lewis, David. 1968. “Counterpart Theory and Quantified Modal Logic.” *The Journal of Philosophy* 65 (5): 113–126.
^ref-lewis1968

Lewis, David. 1969. *Convention: A Philosophical Study*. Harvard University Press.
^ref-lewis1969

Lewis, David. 1973a. “Causation.” *The Journal of Philosophy* 70, no. 17: 556–567.
^ref-lewis1973a

Lewis, David. 1973b. *Counterfactuals*. Cambridge, MA: Harvard University Press.
^ref-lewis1973

Lewis, David. 1976. “Survival and Identity.” In The Identities of Persons, edited by Amélie Oksenberg Rorty, 17–40. Berkeley: University of California Press.
^ref-lewis1976

Lewis, David. 1986a. *On the Plurality of Worlds*. Oxford: Blackwell.
^ref-lewis1986

Lewis, David. 1986b. *Philosophical Papers, Volume II*. Oxford University Press (New York & Oxford).
^ref-lewis1986b

Lewis, David. 1991. *Parts of Classes*. Basil Blackwell (Oxford & Cambridge, MA).
^ref-lewis1991

Lewis, David. 1994. “Humean Supervenience Debugged.” *Mind*.
^ref-lewis1994

Lewis, David. 1996. “Elusive Knowledge.” *Australasian Journal of Philosophy* 74(4): 549–567.
^ref-lewis1996

Lewis-Williams, David. 2002. *The Mind in the Cave: Consciousness and the Origins of Art*. Thames and Hudson.
^ref-lewisWilliams2002

Li, Tian-Nuo, Guo-Hong Du, Hao Wang, Yun-He Li, Jing-Fei Zhang, and Xin Zhang. 2026. “Dark Energy in the DESI Era: A Brief Review of Evidence, Beyond-ΛCDM Interpretations, and Tensions.” *Research in Astronomy and Astrophysics* 26(8).
^ref-liDESIera2026

Licona, Michael R. 2010. *The Resurrection of Jesus: A New Historiographical Approach*. Downers Grove, IL: InterVarsity Press.
^ref-licona2010

Lincoln, T. A., and G. F. Joyce. 2009. “Self-Sustained Replication of an RNA Enzyme.” *Science* 323 (5918): 1229–1232.
^ref-lincolnJoyce2009

Lindsell, Harold. 1949. *A Christian Philosophy of Missions*. Van Kampen Press.
^ref-lindsell1949

Linnebo, Øystein, and Agustín Rayo. 2012. “Hierarchies Ontological and Ideological.” *Mind* 121 (482): 269–308.
^ref-linneboRayo2012

Linnebo, Øystein. 2018. *Thin Objects: An Abstractionist Account*. Oxford University Press.
^ref-linnebo2018

Lipka, Michael, and Claire Gecewicz. 2017. “More Americans Now Say They're Spiritual But Not Religious.” Pew Research Center.
^ref-pew2017

Lipsey, Mark W., Dale C. Farran, and Kelley Durkin. 2018. “Effects of the Tennessee Prekindergarten Program on children's achievement and behavior through third grade.” *Early Childhood Research Quarterly* 45:155–176.
^ref-lipsey2018

Liscovitch-Brauer, Noa, et al. 2017. “Trade-off between Transcriptome Plasticity and Genome Evolution in Cephalopods.” *Cell* 169(2):191–202.
^ref-liscovitchBrauer2017

Lloyd, James E. 1965. “Aggressive Mimicry in Photuris: Firefly Femmes Fatales.” Science 149(3684): 653-654.
^ref-lloyd1965

Lloyd, S. 2006. *Programming the Universe: A Quantum Computer Scientist Takes on the Cosmos*. New York: Knopf.
^ref-lloyd2006

Locke, John. (1689) 1975. *An Essay Concerning Human Understanding*. Edited by Peter H. Nidditch. Oxford: Clarendon Press.
^ref-lockeEssay1689

Locke, John. (1689) 1988. *Two Treatises of Government*. Edited by Peter Laslett. Cambridge: Cambridge University Press.
^ref-locke1689

Loewenstein, George. 1994. “The Psychology of Curiosity: A Review and Reinterpretation.” *Psychological Bulletin* 116(1): 75–98.
^ref-loewenstein1994

Loewer, B. 1996. “Humean Supervenience.” *Philosophical Topics* 24 (1): 101–127.
^ref-loewer1996

Loewer, Barry. 2007. “Counterfactuals and the Second Law.” In Huw Price & Richard Corry (eds.), Causation, Physics, and the Constitution of Reality: Russell's Republic Revisited (Oxford University Press).
^ref-loewer2007

Loftus, Elizabeth F. 1979. *Eyewitness Testimony*. Harvard University Press (Cambridge, MA).
^ref-loftus1979

Loke, Andrew Ter Ern. 2017. *God and Ultimate Origins: A Novel Cosmological Argument*. Palgrave Macmillan / Springer (Cham).
^ref-loke2017

Lombard, Lawrence Brian. 1986. *Events: A Metaphysical Study*. Routledge & Kegan Paul (London & Boston).
^ref-lombard1986

Lomborg, Bjørn. 2001. *The Skeptical Environmentalist: Measuring the Real State of the World*. Cambridge University Press.
^ref-lomborg2001

Long, A. A., and D. N. Sedley. 1987. *The Hellenistic Philosophers*. Vol. 1. Cambridge: Cambridge University Press.
^ref-longSedley1987

Long, Steven A. 2011. *Analogia Entis: On the Analogy of Being, Metaphysics, and the Act of Faith*. University of Notre Dame Press.
^ref-long2011

Lossky, Vladimir. 1957. *The Mystical Theology of the Eastern Church*. James Clarke & Co.
^ref-lossky1957

Loukola, Olli J., Clint J. Perry, Louie Coscos, and Lars Chittka. 2017. “Bumblebees Show Cognitive Flexibility by Improving on an Observed Complex Behavior.” *Science* 355(6327): 833–836.
^ref-loukola2017

Lovelock, James E., and Lynn Margulis. 1974. “Atmospheric Homeostasis by and for the Biosphere: The Gaia Hypothesis.” *Tellus* 26(1–2):2–10.
^ref-lovelockMargulis1974

Low, Philip, Jaak Panksepp, Diana Reiss, David Edelman, Bruno Van Swinderen, and Christof Koch. 2012. “The Cambridge Declaration on Consciousness.” Francis Crick Memorial Conference, Cambridge, UK.
^ref-low2012

Lowe, E. J. 1996. *Subjects of Experience*. Cambridge University Press.
^ref-lowe1996

Lowe, E. J. 1998. *The Possibility of Metaphysics: Substance, Identity, and Time*. Oxford: Oxford University Press.
^ref-lowe1998

Lowe, E. J. 2006. *The Four-Category Ontology: A Metaphysical Foundation for Natural Science*. Oxford: Oxford University Press.
^ref-lowe2006

Lucca, Kelsey, Francis Yuen, Yiyi Wang, et al. 2025. “Infants' Social Evaluation of Helpers and Hinderers: A Large-Scale, Multi-Lab, Coordinated Replication Study.” Developmental Science 28(1): e13581.
^ref-luccaEtAl2025

Lucretius. (c. 50 BCE) 1992. *De Rerum Natura*. Translated by W. H. D. Rouse, revised by M. F. Smith. Cambridge, MA: Harvard University Press (Loeb Classical Library).
^ref-lucretius1992

Lucy, John A. 1992. *Grammatical Categories and Cognition: A Case Study of the Linguistic Relativity Hypothesis*. Cambridge University Press.
^ref-lucy1992

Lüdemann, Gerd. 1994. *The Resurrection of Jesus: History, Experience, Theology*. Fortress Press.
^ref-ludemann1994

Lutz, Antoine, Heleen A. Slagter, John D. Dunne, and Richard J. Davidson. 2008. “Attention Regulation and Monitoring in Meditation.” *Trends in Cognitive Sciences* 12 (4): 163–169.
^ref-lutz2008

Luxemburg, Rosa. 1913. *The Accumulation of Capital*. Vorwärts (Paul Singer), Berlin; Eng. trans. Routledge & Kegan Paul, 1951.
^ref-luxemburg1913

Lycan, William G., and George N. Schlesinger. 1989. “You Bet Your Life: Pascal's Wager Defended.” in J. Feinberg (ed.), Reason and Responsibility (Wadsworth).
^ref-lycanSchlesinger1989

Lyon, P. 2015. “The Cognitive Cell: Bacterial Behavior Reconsidered.” *Frontiers in Microbiology* 6: 264.
^ref-lyon2015

MacAskill, William. 2022. *What We Owe the Future*. Basic Books.
^ref-macaskill2022

Macedo, Stephen. 2000. *Diversity and Distrust: Civic Education in a Multicultural Democracy*. Harvard University Press.
^ref-macedo2000

MacIntyre, Alasdair. 1981. *After Virtue: A Study in Moral Theory*. Notre Dame, IN: University of Notre Dame Press (first edition; simultaneously published London: Gerald Duckworth & Co.).
^ref-macintyre1981

Mackie, J. L. 1955. “Evil and Omnipotence.” *Mind* 64, no. 254, pp. 200–212.
^ref-mackie1955

Mackie, J. L. 1977. *Ethics: Inventing Right and Wrong*. Penguin Books (Harmondsworth).
^ref-mackie1977

Mackie, J. L. 1982. *The Miracle of Theism: Arguments For and Against the Existence of God*. Clarendon Press / Oxford University Press (Oxford).
^ref-mackie1982

MacKinnon, Catharine A. 1987. *Feminism Unmodified: Discourses on Life and Law*. Harvard University Press.
^ref-mackinnon1987

Madden, Joah R. 2003. “Bower Decorations Are Good Predictors of Mating Success in the Spotted Bowerbird.” Behavioral Ecology and Sociobiology 53: 269-277.
^ref-madden2003

Maddy, Penelope. 1990. *Realism in Mathematics*. Oxford University Press (Clarendon).
^ref-maddy1990

Maddy, Penelope. 1997. *Naturalism in Mathematics*. Clarendon Press / Oxford University Press (Oxford).
^ref-maddy1997

Maddy, Penelope. 2007. *Second Philosophy: A Naturalistic Method*. Oxford University Press.
^ref-maddy2007

Maddy, Penelope. 2011. *Defending the Axioms: On the Philosophical Foundations of Set Theory*. Oxford University Press.
^ref-maddy2011

Madell, Geoffrey. 1981. *The Identity of the Self*. Edinburgh University Press.
^ref-madell1981

Maffie, James. 2014. *Aztec Philosophy: Understanding a World in Motion*. University Press of Colorado.
^ref-maffie2014

Maia, Tiago V., and James L. McClelland. 2004. “A Reexamination of the Evidence for the Somatic Marker Hypothesis: What Participants Really Know in the Iowa Gambling Task.” *Proceedings of the National Academy of Sciences* 101 (45): 16075–16080.
^ref-maiaMcClelland2004

Maimonides, Moses. (c. 1190) 1963. *The Guide of the Perplexed*. Translated by Shlomo Pines. Chicago: University of Chicago Press.
^ref-maimonides1190

Maitzen, Stephen. 2006. “Divine Hiddenness and the Demographics of Theism.” *Religious Studies* 42, no. 2: 177–191.
^ref-maitzen2006

Maitzen, Stephen. 2009. “Ordinary Morality Implies Atheism.” *European Journal for Philosophy of Religion* 1, no. 2: 107–126.
^ref-maitzen2009

Maitzen, Stephen. 2012. “Stop Asking Why There's Anything.” *Erkenntnis*.
^ref-maitzen2012

Mallozzi, Antonella, Anand Vaidya, and Michael Wallner. 2021. “The Epistemology of Modality.” The Stanford Encyclopedia of Philosophy, ed. Edward N. Zalta.
^ref-mallozziVaidyaWallner2021

Mann, Horace. 1848. “Twelfth Annual Report of the Secretary of the Massachusetts Board of Education.” Dutton & Wentworth, State Printers, Boston (Massachusetts Board of Education).
^ref-mann1848

Mann, William E. 1982. “Divine Simplicity.” *Religious Studies* 18 (4): 451–471.
^ref-mann1982

Manne, Kate. 2017. *Down Girl: The Logic of Misogyny*. Oxford University Press.
^ref-manne2017

Mannheim, Karl. (1928) 1952. “The Problem of Generations.” In Essays on the Sociology of Knowledge, edited by Paul Kecskemeti. London: Routledge & Kegan Paul.
^ref-mannheim1928

Mar, Raymond A., and Keith Oatley. 2008. “The Function of Fiction Is the Abstraction and Simulation of Social Experience.” Perspectives on Psychological Science 3 (3): 173-192.
^ref-marOatley2008

Marion, Jean-Luc. 1991. *God Without Being: Hors-Texte*. University of Chicago Press (trans. T. A. Carlson).
^ref-marion1991

Marion, Jean-Luc. 2002. *Being Given: Toward a Phenomenology of Givenness*. Stanford University Press (trans. J. L. Kosky).
^ref-marion2002

Markosian, Ned. 1998. “Brutal Composition.” *Philosophical Studies* 92 (3): 211–249.
^ref-markosian1998

Markus, Hazel Rose, and Shinobu Kitayama. 1991. “Culture and the Self: Implications for Cognition, Emotion, and Motivation.”
^ref-markusKitayama1991

Marmot, Michael. 2004. *The Status Syndrome: How Social Standing Affects Our Health and Longevity*. Times Books / Henry Holt.
^ref-marmot2004

Gaunilo of Marmoutiers. c. 1078. “Pro Insipiente (On Behalf of the Fool).” Reply to Anselm's Proslogion; standard editions in Anselm collections.
^ref-gaunilo1078

Marquis, Don. 1989. “Why Abortion Is Immoral.” *Journal of Philosophy* 86(4):183–202.
^ref-marquis1989

Marsh, Jason. 2008. “Do the Demographics of Theistic Belief Disconfirm Theism? A Reply to Maitzen.” *Religious Studies* 44, no. 4: 465–471.
^ref-marsh2008

Marshall, Alfred. 1890. *Principles of Economics*. London: Macmillan.
^ref-marshall1890

Marshall, T. H. 1950. *Citizenship and Social Class and Other Essays*. Cambridge: Cambridge University Press.
^ref-marshall1950

Martin, Michael. 1990. *Atheism: A Philosophical Justification*. Temple University Press (Philadelphia).
^ref-martin1990

Martin, C. B. 1994. “Dispositions and Conditionals.” *The Philosophical Quarterly*.
^ref-martin1994

Martin, W., and M. J. Russell. 2003. “On the Origins of Cells: A Hypothesis for the Evolutionary Transitions from Abiotic Geochemistry to Chemoautotrophic Prokaryotes, and from Prokaryotes to Nucleated Cells.” *Philosophical Transactions of the Royal Society B* 358 (1429): 59–85.
^ref-martinRussell2003

Martin, W., and M. J. Russell. 2007. “On the Origin of Biochemistry at an Alkaline Hydrothermal Vent.” *Philosophical Transactions of the Royal Society B* 362 (1486): 1887–1926.
^ref-martinRussell2007

Marx, Karl, and Friedrich Engels. 1848. *Manifesto of the Communist Party*. Printed by J. E. Burghard for the Communist League, London.
^ref-marxEngels1848

Marx, Karl. 1867. *Capital: A Critique of Political Economy, Volume 1*. Otto Meissner, Hamburg.
^ref-marx1867

Marx, Karl. 1875. *Critique of the Gotha Program*. Die Neue Zeit, Stuttgart (first pub. 1891).
^ref-marx1875

Mather, Jennifer A., and Roland C. Anderson. 1993. “Personalities of Octopuses (Octopus rubescens).” *Journal of Comparative Psychology* 107(3): 336–340.
^ref-matherAnderson1993

Mathews, Freya. 2003. *For Love of Matter: A Contemporary Panpsychism*. State University of New York Press.
^ref-mathews2003

Matilal, Bimal Krishna. 1986. *Perception: An Essay on Classical Indian Theories of Knowledge*. Oxford University Press.
^ref-matilal1986

Maturana, Humberto R., and Francisco J. Varela. 1980. *Autopoiesis and Cognition: The Realization of the Living*. Dordrecht: D. Reidel.
^ref-maturanaVarela1980

Maudlin, Tim. 2002. *Quantum Non-Locality and Relativity*. Blackwell (Malden, MA), 2nd ed.
^ref-maudlin2002

Maudlin, Tim. 2007. *The Metaphysics within Physics*. Oxford: Oxford University Press.
^ref-maudlin2007

Maudlin, Tim. 2011. *Quantum Non-Locality and Relativity: Metaphysical Intimations of Modern Physics*. 3rd ed. Malden, MA: Wiley-Blackwell.
^ref-maudlin2011

Maudlin, Tim. 2012. *Philosophy of Physics: Space and Time*. Princeton University Press.
^ref-maudlin2012

Maudlin, Tim. 2019. *Philosophy of Physics: Quantum Theory*. Princeton, NJ: Princeton University Press.
^ref-maudlin2019

Maurin, Anna-Sofia. 2002. *If Tropes*. Kluwer Academic Publishers (Dordrecht), Synthese Library vol. 308.
^ref-maurin2002

Mavrodes, George I. 1963. “Some Puzzles Concerning Omnipotence.” *The Philosophical Review* 72, no. 2: 221–223.
^ref-mavrodes1963

Mavrodes, George I. 1986. “Religion and the Queerness of Morality.” in R. Audi & W. J. Wainwright (eds.), Rationality, Religious Belief, and Moral Commitment, Cornell University Press: 213–226.
^ref-mavrodes1986

Maxwell, J. C. 1865. “A Dynamical Theory of the Electromagnetic Field.” *Philosophical Transactions of the Royal Society of London* 155: 459–512.
^ref-maxwell1865

Maxwell, James Clerk. 1873. *A Treatise on Electricity and Magnetism*. Oxford: Clarendon Press (2 vols.).
^ref-maxwell1873

May, Larry. 2008. *Aggression and Crimes Against Peace*. Cambridge University Press.
^ref-may2008

Mayer, Julius Robert. 1842. “Bemerkungen über die Kräfte der unbelebten Natur.” *Annalen der Chemie und Pharmacie* 42:233–240.
^ref-mayer1842

Maynard Smith, J. 1978. *The Evolution of Sex*. Cambridge: Cambridge University Press.
^ref-maynardSmith1978

Maynard Smith, J., and E. Szathmáry. 1995. *The Major Transitions in Evolution*. Oxford: W. H. Freeman.
^ref-maynardSmithSzathmary1995

Mazzucato, Mariana. 2013. *The Entrepreneurial State: Debunking Public vs. Private Sector Myths*. Anthem Press.
^ref-mazzucato2013

McAdams, Dan P. 1993. *The Stories We Live By: Personal Myths and the Making of the Self*. William Morrow.
^ref-mcadams1993

McCann, Hugh J. 2012. *Creation and the Sovereignty of God*. Bloomington: Indiana University Press.
^ref-mccann2012

McChesney, Robert W. 1999. *Rich Media, Poor Democracy: Communication Politics in Dubious Times*. University of Illinois Press.
^ref-mcchesney1999

McComb, Karen, Lucy Baker, and Cynthia Moss. 2006. “African Elephants Show High Levels of Interest in the Skulls and Ivory of Their Own Species.” Biology Letters 2 (1): 26-28.
^ref-mccomb2006

McCormack, Bruce L. 1995. *Karl Barth's Critically Realistic Dialectical Theology: Its Genesis and Development, 1909-1936*. Oxford: Clarendon Press.
^ref-mccormack1995

McDowell, John. 1994. *Mind and World*. Harvard University Press.
^ref-mcdowell1994

McGinn, Bernard. 1991. *The Presence of God: A History of Western Christian Mysticism, Vol. 1: The Foundations of Mysticism*. Crossroad.
^ref-mcginn1991

McGinnis, Jon. 2010. *Avicenna*. Oxford University Press (Oxford & New York).
^ref-mcginnis2010

McGrew, Timothy, Lydia McGrew, and Eric Vestrup. 2001. “Probabilities and the Fine-Tuning Argument: A Sceptical View.” *Mind* 110 (440): 1027–1037.
^ref-mcgrewMcgrewVestrup2001

McInerny, Ralph M. 1996. *Aquinas and Analogy*. Washington, DC: Catholic University of America Press.
^ref-mcinerny1996

McKay, Noah. 2023. “A New Aesthetic Argument for Theism.” Faith and Philosophy 40(2): 221-244.
^ref-mckay2023

McKee, Patrick. 2025. “Dualism Leads to Many Minds.” Synthese 205(2).
^ref-mckee2025

McLuhan, Marshall. 1964. *Understanding Media: The Extensions of Man*. McGraw-Hill.
^ref-mcluhan1964

McMahan, Jeff. 2009. *Killing in War*. Oxford University Press.
^ref-mcmahan2009

McTaggart, J. M. E. 1908. “The Unreality of Time.” *Mind* 17 (68): 457–474.
^ref-mctaggart1908

Mead, George Herbert. 1934. *Mind, Self, and Society: From the Standpoint of a Social Behaviorist*. University of Chicago Press.
^ref-mead1934

Mearsheimer, John J. 2001. *The Tragedy of Great Power Politics*. W. W. Norton & Company.
^ref-mearsheimer2001

Meissner, Krzysztof A., and Roger Penrose. 2025. “The Physics of Conformal Cyclic Cosmology.” *arXiv preprint arXiv:2503.24263 [gr-qc],* 31 March 2025 (unrefereed).
^ref-meissnerPenrose2025

Melamed, Yitzhak Y. 2013. *Spinoza's Metaphysics: Substance and Thought*. Oxford: Oxford University Press.
^ref-melamed2013

Mele, Alfred R. 2006. *Free Will and Luck*. Oxford University Press.
^ref-mele2006

Mellor, D. H. 1981. *Real Time*. Cambridge University Press.
^ref-mellor1981

Mellor, D. H. 1998. *Real Time II*. London: Routledge.
^ref-mellor1998

Mellor, D. J., and N. J. Beausoleil. 2015. “Extending the 'Five Domains' Model for Animal Welfare Assessment to Incorporate Positive Welfare States.” *Animal Welfare* 24 (3): 241–253.
^ref-mellorBeausoleil2015

Mellor, David J. 2017. “Operational Details of the Five Domains Model and Its Key Applications to the Assessment and Management of Animal Welfare.” *Animals* 7 (8): 60.
^ref-mellor2017

Mendl, Michael, Oliver H. P. Burman, and Elizabeth S. Paul. 2010. “An Integrative and Functional Framework for the Study of Animal Emotion and Mood.” *Proceedings of the Royal Society B: Biological Sciences* 277 (1696): 2895–2904.
^ref-mendlBurmanPaul2010

Menkiti, Ifeanyi A. 1984. “Person and Community in African Traditional Thought.” In African Philosophy: An Introduction, 3rd ed., 171-181.
^ref-menkiti1984

Merleau-Ponty, Maurice. 1945. *Phenomenology of Perception*. Paris: Gallimard (Phénoménologie de la perception; Eng. trans. Colin Smith, Routledge & Kegan Paul, 1962).
^ref-merleauPonty1945

Merleau-Ponty, Maurice. 1964. *Eye and Mind (L'Œil et l'esprit)*. Gallimard.
^ref-merleauPonty1964

Merricks, Trenton. 2001. *Objects and Persons*. Clarendon Press / Oxford University Press (Oxford).
^ref-merricks2001

Merricks, Trenton. 2009. “The Resurrection of the Body.” In The Oxford Handbook of Philosophical Theology, ed. Thomas P. Flint and Michael C. Rea. Oxford: Oxford University Press.
^ref-merricks2009

Metz, Thaddeus. 2007. “Toward an African Moral Theory.” Journal of Political Philosophy 15 (3): 321-341.
^ref-metz2007

Metz, Thaddeus. 2011. “Ubuntu as a Moral Theory and Human Rights in South Africa.” African Human Rights Law Journal 11 (2): 532-559.
^ref-metz2011

Metz, Thaddeus. 2013. *Meaning in Life: An Analytic Study*. Oxford University Press.
^ref-metz2013

Metzger, Bruce M. 1987. *The Canon of the New Testament: Its Origin, Development, and Significance*. Oxford: Clarendon Press.
^ref-metzger1987

Metzger, Bruce M., and Bart D. Ehrman. 2005. *The Text of the New Testament: Its Transmission, Corruption, and Restoration*. New York: Oxford University Press.
^ref-metzgerEhrman2005

Metzinger, Thomas. 2003. “Being No One: The Self-Model Theory of Subjectivity.”
^ref-metzinger2003

Metzinger, Thomas. 2009. “The Ego Tunnel: The Science of the Mind and the Myth of the Self.”
^ref-metzinger2009

Meyer, Stephen C. 2009. *Signature in the Cell: DNA and the Evidence for Intelligent Design*. HarperOne (New York).
^ref-meyer2009

Meyer, Stephen C. 2013. *Darwin's Doubt: The Explosive Origin of Animal Life and the Case for Intelligent Design*. HarperOne (HarperCollins).
^ref-meyer2013

Middleton, J. Richard. 1994. “The Liberating Image? Interpreting the Imago Dei in Context.” Christian Scholar's Review 24 (1): 8-25.
^ref-middleton1994

Mill, John Stuart. 1859. *On Liberty*. London: John W. Parker and Son.
^ref-mill1859

Miller, Earl K., and Jonathan D. Cohen. 2001. “An Integrative Theory of Prefrontal Cortex Function.” Annual Review of Neuroscience 24: 167-202.
^ref-millerCohen2001

Miller, Gregory. 2018. “Can Subjects Be Proper Parts of Subjects? The De-Combination Problem.” *Ratio* 31 (2): 137–154.
^ref-miller2018

Millikan, Ruth Garrett. 1984. *Language, Thought, and Other Biological Categories: New Foundations for Realism*. MIT Press.
^ref-millikan1984

Millikan, Ruth Garrett. 1995. “Pushmi-Pullyu Representations.” *Philosophical Perspectives* 9: 185–200.
^ref-millikan1995

Mills, Charles W. 1997. *The Racial Contract*. Cornell University Press.
^ref-mills1997

Mills, Charles W. 2005. ““Ideal Theory” as Ideology.” *Hypatia* 20 (3): 165–184.
^ref-mills2005

Mills, Charles W. 2017. *Black Rights/White Wrongs: The Critique of Racial Liberalism*. Oxford University Press.
^ref-mills2017

Minkowski, H. 1908. “Raum und Zeit.” *Physikalische Zeitschrift* 10: 75–88.
^ref-minkowski1908

Mirrlees, James A. 1971. “An Exploration in the Theory of Optimum Income Taxation.” *Review of Economic Studies* 38 (2): 175–208.
^ref-mirrlees1971

Misner, C. W., K. S. Thorne, and J. A. Wheeler. 1973. *Gravitation*. San Francisco: W. H. Freeman.
^ref-misner1973

Mitchell, P. 1961. “Coupling of Phosphorylation to Electron and Hydrogen Transfer by a Chemi-Osmotic Type of Mechanism.” *Nature* 191 (4784): 144–148.
^ref-mitchell1961

Mitchell, Melanie, and David C. Krakauer. 2023. “The Debate Over Understanding in AI's Large Language Models.” Proceedings of the National Academy of Sciences 120 (13): e2215907120.
^ref-mitchellKrakauer2023

Mithani, Audrey, and Alexander Vilenkin. 2012. “Did the Universe Have a Beginning?” arXiv:1204.4658 [hep-th].
^ref-mithaniVilenkin2012

Mojzsis, S. J., G. Arrhenius, K. D. McKeegan, T. M. Harrison, A. P. Nutman, and C. R. L. Friend. 1996. “Evidence for Life on Earth before 3,800 Million Years Ago.” *Nature* 384 (6604): 55–59.
^ref-mojzsis1996

Moltmann, Jürgen. 1974. *The Crucified God: The Cross of Christ as the Foundation and Criticism of Christian Theology*. Harper & Row.
^ref-moltmann1974

Monk, J. D., E. Giglio, A. Kamath, M. R. Lambert, and C. E. McDonough. 2019. “An Alternative Hypothesis for the Evolution of Same-Sex Sexual Behaviour in Animals.” *Nature Ecology & Evolution* 3: 1622–1631.
^ref-monk2019

Monroy, Maria, and Dacher Keltner. 2023. “Awe as a Pathway to Mental and Physical Health.” Perspectives on Psychological Science 18 (2): 309-320.
^ref-monroyKeltner2023

Montessori, Maria. 1949. *The Absorbent Mind*. Theosophical Publishing House.
^ref-montessori1949

Montgomery, David R. 2007. *Dirt: The Erosion of Civilizations*. University of California Press.
^ref-montgomery2007

Monton, Bradley. 2006. “God, Fine-Tuning, and the Problem of Old Evidence.” *The British Journal for the Philosophy of Science* 57(2): 405–424.
^ref-monton2006

Moore, G. E. 1903. *Principia Ethica*. Cambridge University Press.
^ref-moore1903

Moore, Michael S. 1997. *Placing Blame: A Theory of the Criminal Law*. Oxford University Press (Clarendon Press).
^ref-moore1997

Mørch, Hedda Hassel. 2017. “The Evolutionary Argument for Phenomenal Powers.” Philosophical Perspectives 31(1): 293–316.
^ref-morch2017

More, Max, and Natasha (eds.) Vita-More. 2013. *The Transhumanist Reader: Classical and Contemporary Essays on the Science, Technology, and Philosophy of the Human Future*. Wiley-Blackwell.
^ref-moreVitaMore2013

Moreland, J. P., and William Lane Craig. 2003. *Philosophical Foundations for a Christian Worldview*. Downers Grove, IL: InterVarsity Press (1st ed. 2003; 2nd ed. 2017).
^ref-morelandcraig2003

Moreno, Alvaro; Mossio, Matteo. 2015. *Biological Autonomy: A Philosophical and Theoretical Enquiry*. Springer.
^ref-morenoMossio2015

Morgenthau, Hans J. 1948. *Politics Among Nations: The Struggle for Power and Peace*. Alfred A. Knopf.
^ref-morgenthau1948

Morris, Thomas V. 1986. *The Logic of God Incarnate*. Ithaca: Cornell University Press.
^ref-morris1986

Morris, Thomas V., and Christopher Menzel. 1986. “Absolute Creation.” *American Philosophical Quarterly* 23(4): 353–362.
^ref-morrisMenzel1986

Morris, Thomas V. 1987. *Anselmian Explorations: Essays in Philosophical Theology*. Notre Dame: University of Notre Dame Press.
^ref-morris1987

Morris, Thomas V. 1991. *Our Idea of God: An Introduction to Philosophical Theology*. Downers Grove, IL: InterVarsity Press (Contours of Christian Philosophy).
^ref-morris1991

Morriston, Wes. 2000. “Must the Beginning of the Universe Have a Personal Cause?: A Critical Examination of the Kalam Cosmological Argument.” *Faith and Philosophy* 17, no. 2: 149–169.
^ref-morriston2000

Morriston, Wes. 2002. “Creation Ex Nihilo and the Big Bang.” *Philo* 5(1): 23–33.
^ref-morriston2002

Morriston, Wes. 2010. “Beginningless Past, Endless Future, and the Actual Infinite.” *Faith and Philosophy* 27(4): 439–450.
^ref-morriston2010

Morriston, Wes. 2013. “Doubts about the Kalām Cosmological Argument.” In Debating Christian Theism, ed. J. P. Moreland, Chad Meister, and Khaldoun A. Sweis, 20–32. Oxford: Oxford University Press.
^ref-morriston2013

Moss, Candida. 2013. *The Myth of Persecution: How Early Christians Invented a Story of Martyrdom*. New York: HarperOne.
^ref-moss2013

Mouffe, Chantal. 2000. *The Democratic Paradox*. Verso.
^ref-mouffe2000

Mouffe, Chantal. 2005. *On the Political*. Routledge.
^ref-mouffe2005

Mrnjavac, Natalia, Nadja K. Hoffmann, Manon L. Schlikker, Maximilian Burmeister, Loraine Schwander, Carolina García García, Max Brabender, Mike Steel, Daniel H. Huson, Sabine Metzger, Quentin Dherbassy, Bernhard Schink, Mirko Basen, Joseph Moran, Harun Tüysüz, Martina Preiner, and William F. Martin. 2026. “Intermediate Stages in the Origin of Metabolism at a Phosphorylating Hydrothermal Vent.” *Science Advances* 12 (32).
^ref-mrnjavac2026

Muchowska, K. B., S. J. Varma, E. Chevallot-Beroux, L. Lethuillier-Karl, G. Li, and J. Moran. 2017. “Metals Promote Sequences of the Reverse Krebs Cycle.” *Nature Ecology & Evolution* 1 (11): 1716–1721.
^ref-muchowska2017

Muchowska, K. B., S. J. Varma, and J. Moran. 2019. “Synthesis and Breakdown of Universal Metabolic Precursors Promoted by Iron.” *Nature* 569 (7754): 104–107.
^ref-muchowska2019

Mullainathan, Sendhil, and Eldar Shafir. 2013. *Scarcity: Why Having Too Little Means So Much*. Times Books (Henry Holt).
^ref-mullainathanShafir2013

Mullins, R. T. 2013. “Simply Impossible: A Case Against Divine Simplicity.” *Journal of Reformed Theology* 7(2): 181–203.
^ref-mullins2013

Mullins, R. T. 2016. *The End of the Timeless God*. Oxford: Oxford University Press.
^ref-mullins2016

Mullins, R. T., and Shannon Byrd. 2022. “Divine Simplicity and Modal Collapse: A Persistent Problem.” *European Journal for Philosophy of Religion* 14, no. 1: 21–52.
^ref-mullinsByrd2022

Mumford, Lewis. 1934. *Technics and Civilization*. Harcourt, Brace and Company.
^ref-mumford1934

Mumford, Lewis. 1967. *The Myth of the Machine: Technics and Human Development*. Harcourt, Brace and World.
^ref-mumford1967

Mumford, Stephen. 2004. *Laws in Nature*. Routledge.
^ref-mumford2004

Mumford, Stephen, and Rani Lill Anjum. 2011. *Getting Causes from Powers*. Oxford University Press.
^ref-mumfordAnjum2011

Murata, Sachiko, and William C. Chittick. 1994. *The Vision of Islam*. Paragon House.
^ref-murataChittick1994

Murphy, Mark C. 2002. *An Essay on Divine Authority*. Cornell University Press (Cornell Studies in the Philosophy of Religion).
^ref-murphy2002

Murphy, Mark C. 2017. *God's Own Ethics: Norms of Divine Agency and the Argument from Evil*. New York: Oxford University Press.
^ref-murphy2017

Murray, John. 1955. *Redemption Accomplished and Applied*. Eerdmans.
^ref-murray1955

Murray, John. 1959. *The Imputation of Adam's Sin*. Grand Rapids: Eerdmans, 1959 (orig. WTJ article series, 1955-57; repr. P&R, 1977).
^ref-murray1959

Murray, Michael J., and Kurt Meyers. 1994. “Ask and It Will Be Given to You.” *Religious Studies* 30, no. 3: 311–330.
^ref-murrayMeyers1994

Murray, Michael J. 2008. *Nature Red in Tooth and Claw: Theism and the Problem of Animal Suffering*. Oxford: Oxford University Press, 2008 (pp. x+209; ISBN 978-0-19-923727-2).
^ref-murray2008

Næss, Arne. 1973. “The Shallow and the Deep, Long-Range Ecology Movement. A Summary.” *Inquiry* 16 (1–4): 95–100.
^ref-naess1973

Nāgārjuna. (c. 2nd c. CE) 1995. *Mūlamadhyamakakārikā: The Fundamental Wisdom of the Middle Way*. Translated by J. L. Garfield. New York: Oxford University Press.
^ref-nagarjuna1995

Nagasawa, Yujin. 2008. *God and Phenomenal Consciousness: A Novel Approach to Knowledge Arguments*. Cambridge University Press.
^ref-nagasawa2008

Nagel, Thomas. 1970. “Death.” *Noûs* 4 (1): 73–80.
^ref-nagel1970

Nagel, Thomas. 1971. “The Absurd.” *Journal of Philosophy* 68 (20): 716–727.
^ref-nagel1971

Nagel, Thomas. 1974. “What Is It Like to Be a Bat?” *The Philosophical Review* 83(4): 435–450.
^ref-nagel1974

Nagel, Thomas. 2012. *Mind and Cosmos: Why the Materialist Neo-Darwinian Conception of Nature Is Almost Certainly False*. Oxford University Press.
^ref-nagel2012

Nai, Alessandro, and Annemarie S. Walter. 2015. *New Perspectives on Negative Campaigning: Why Attack Politics Matters*. Colchester: ECPR Press.
^ref-naiWalter2015

Naselaris, Thomas, Cheryl A. Olman, Dustin E. Stansbury, Kamil Ugurbil, and Jack L. Gallant. 2015. “A voxel-wise encoding model for early visual areas decodes mental images of remembered scenes.” *NeuroImage* 105: 215–228.
^ref-naselaris2015

Neisser, Ulric, and Nicole Harsch. 1992. “Phantom Flashbulbs: False Recollections of Hearing the News about Challenger.” In E. Winograd and U. Neisser, eds., Affect and Accuracy in Recall: Studies of "Flashbulb" Memories, 9–31. Cambridge: Cambridge University Press.
^ref-neisserHarsch1992

Neurath, Otto. 1944. “Foundations of the Social Sciences.” International Encyclopedia of Unified Science, vol. 2, no. 1, Chicago: University of Chicago Press.
^ref-neurath1944

Newton, Isaac. 1687. *Philosophiæ Naturalis Principia Mathematica*. London: Jussu Societatis Regiae (Royal Society).
^ref-newton1687

Newton-Smith, W. H. 1980. *The Structure of Time*. London: Routledge & Kegan Paul.
^ref-newtonSmith1980

Ney, Alyssa, and David Z. Albert. 2013. *The Wave Function: Essays on the Metaphysics of Quantum Mechanics*. Oxford University Press.
^ref-neyAlbert2013

Ney, Alyssa. 2021. *The World in the Wave Function: A Metaphysics for Quantum Physics*. Oxford University Press.
^ref-ney2021

Nietzsche, Friedrich. (1881) 1997. *Daybreak: Thoughts on the Prejudices of Morality*. Translated by R. J. Hollingdale; edited by M. Clark and B. Leiter. Cambridge: Cambridge University Press.
^ref-nietzsche1881

Nietzsche, Friedrich. (1886) 2002. *Beyond Good and Evil: Prelude to a Philosophy of the Future*. Translated by J. Norman; edited by R.-P. Horstmann and J. Norman. Cambridge: Cambridge University Press.
^ref-nietzsche1886

Nietzsche, Friedrich. 1882. *The Gay Science*. Original: E. W. Fritzsch; various English editions.
^ref-nietzsche1882

Nissen, P., J. Hansen, N. Ban, P. B. Moore, and T. A. Steitz. 2000. “The Structural Basis of Ribosome Activity in Peptide Bond Synthesis.” *Science* 289 (5481): 920–930.
^ref-nissen2000

Noble, Safiya Umoja. 2018. *Algorithms of Oppression: How Search Engines Reinforce Racism*. NYU Press.
^ref-noble2018

Noddings, Nel. 1984. *Caring: A Feminine Approach to Ethics and Moral Education*. University of California Press.
^ref-noddings1984

Noether, Emmy. 1918. “Invariante Variationsprobleme.” *Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen* 1918: 235–257.
^ref-noether1918

Nolan, Daniel. 1996. “Recombination Unbound.” *Philosophical Studies* 84 (2–3): 239–262.
^ref-nolan1996

Nolan, Daniel. 1997. “Impossible Worlds: A Modest Approach.” *Notre Dame Journal of Formal Logic* 38 (4): 535-572.
^ref-nolan1997

Nolan, Daniel. 2002. *Topics in the Philosophy of Possible Worlds*. New York: Routledge.
^ref-nolan2002

Noll, Mark A. 2015. *The Civil War as a Theological Crisis*. University of North Carolina Press.
^ref-noll2015

Noonan, Harold W. 1994. “In Defence of the Letter of Fictionalism.” *Analysis* 54(3): 133–139.
^ref-noonan1994

Norcross, Alastair. 2020. *Morality by Degrees: Reasons Without Demands*. Oxford University Press.
^ref-norcross2020

Nordhaus, William D. 2013. *The Climate Casino: Risk, Uncertainty, and Economics for a Warming World*. Yale University Press.
^ref-nordhaus2013

Nordhaus, William D. 2017. “Revisiting the social cost of carbon.” *Proceedings of the National Academy of Sciences* 114(7): 1518–1523.
^ref-nordhaus2017

Norenzayan, Ara, Will M. Gervais, and Kali H. Trzesniewski. 2012. “Mentalizing Deficits Constrain Belief in a Personal God.” PLoS ONE 7(5): e36880.
^ref-norenzayanEtAl2012

Norenzayan, Ara. 2013. *Big Gods: How Religion Transformed Cooperation and Conflict*. Princeton University Press.
^ref-norenzayan2013

Norenzayan, Ara, et al. 2016. “The Cultural Evolution of Prosocial Religions.” Behavioral and Brain Sciences.
^ref-norenzayan2016

Norman, Donald A. 1991. “Cognitive Artifacts.” In Designing Interaction, 17-38.
^ref-norman1991

Norris, Pippa, and Ronald Inglehart. 2004. *Sacred and Secular: Religion and Politics Worldwide*. Cambridge University Press.
^ref-norrisInglehart2004

Northoff, Georg, and Felix Bermpohl. 2004. “Cortical Midline Structures and the Self.” Trends in Cognitive Sciences 8 (3): 102-107.
^ref-northoffBermpohl2004

Norton, J. D. 2003. “Causation as Folk Science.” *Philosophers' Imprint* 3 (4): 1–22.
^ref-norton2003

Nowak, Martin A., and Karl Sigmund. 2005. “Evolution of Indirect Reciprocity.” Nature 437 (7063): 1291-1298.
^ref-nowakSigmund2005

Nozick, Robert. 1974. *Anarchy, State, and Utopia*. Basic Books.
^ref-nozick1974

Nozick, Robert. 1981. *Philosophical Explanations*. Harvard University Press.
^ref-nozick1981

Nussbaum, Martha C. 2000. *Women and Human Development: The Capabilities Approach*. Cambridge: Cambridge University Press.
^ref-nussbaum2000

Nussbaum, Martha C. 2001. *Upheavals of Thought: The Intelligence of Emotions*. Cambridge: Cambridge University Press.
^ref-nussbaum2001

Nussbaum, Martha C. 2006. *Frontiers of Justice: Disability, Nationality, Species Membership*. Cambridge, MA: Belknap Press of Harvard University Press.
^ref-nussbaum2006

Nussbaum, Martha C. 2011. *Creating Capabilities: The Human Development Approach*. Cambridge, MA: Belknap Press of Harvard University Press.
^ref-nussbaum2011

Nussbaum, Martha C. 2023. *Justice for Animals: Our Collective Responsibility*. Simon & Schuster.
^ref-nussbaum2023

Nyanaponika, Thera, and Bhikkhu Bodhi. 1999. *Numerical Discourses of the Buddha: An Anthology of Suttas from the Anguttara Nikaya*. AltaMira Press.
^ref-nyanaponikaBodhi1999

O'Connor, Timothy. 2000. *Persons and Causes: The Metaphysics of Free Will*. New York: Oxford University Press.
^ref-oconnor2000

O'Hanlon, James C., Gregory I. Holwell, and Marie E. Herberstein. 2014. “Pollinator Deception in the Orchid Mantis.” The American Naturalist 183(1): 126-132.
^ref-ohanlonEtAl2014

Oakeshott, Michael. 1962. *Rationalism in Politics and Other Essays*. Methuen.
^ref-oakeshott1962

Oaklander, L. Nathan. 2004. *The Ontology of Time*. Prometheus Books.
^ref-oaklander2004

Odling-Smee, F. J., K. N. Laland, and M. W. Feldman. 2003. *Niche Construction: The Neglected Process in Evolution*. Princeton, NJ: Princeton University Press.
^ref-odlingSmee2003

Olson, Mancur. 1982. *The Rise and Decline of Nations: Economic Growth, Stagflation, and Social Rigidities*. Yale University Press.
^ref-olson1982

Olson, Eric T. 1997. *The Human Animal: Personal Identity Without Psychology*. Oxford University Press.
^ref-olson1997

Omnès, R. 1994. *The Interpretation of Quantum Mechanics*. Princeton, NJ: Princeton University Press.
^ref-omnes1994

Ong, Walter J. 1982. *Orality and Literacy: The Technologizing of the Word*. Methuen.
^ref-ong1982

Oord, Thomas Jay. 2015. *The Uncontrolling Love of God: An Open and Relational Account of Providence*. Downers Grove, IL: IVP Academic (InterVarsity Press).
^ref-oord2015

Oppenheim, Paul, and Hilary Putnam. 1958. “Unity of Science as a Working Hypothesis.” In H. Feigl, M. Scriven, and G. Maxwell (eds.), Minnesota Studies in the Philosophy of Science, vol. 2, Minneapolis: University of Minnesota Press.
^ref-oppenheimPutnam1958

Oppy, Graham. 1995. *Ontological Arguments and Belief in God*. Cambridge: Cambridge University Press.
^ref-oppy1995

Oppy, Graham. 2006. *Arguing about Gods*. Cambridge: Cambridge University Press.
^ref-oppy2006

Oppy, Graham. 2013. *The Best Argument Against God*. Basingstoke: Palgrave Macmillan.
^ref-oppy2013

Oppy, Graham. 2018a. *Atheism and Agnosticism*. Cambridge: Cambridge University Press.
^ref-oppy2018

Oppy, Graham. 2018b. *Naturalism and Religion: A Contemporary Philosophical Investigation*. Routledge (Investigating Philosophy of Religion).
^ref-oppy2018b

Ord, Toby. 2008. “The Scourge: Moral Implications of Natural Embryo Loss.” *American Journal of Bioethics* 8 (7): 12–19.
^ref-ord2008

Ord, Toby. 2020. *The Precipice: Existential Risk and the Future of Humanity*. Bloomsbury Publishing.
^ref-ord2020

Oren, Noam. 2025. “The Evidential Challenge for Petitionary Prayer.” Religious Studies 61 (3).
^ref-oren2025prayer

Oreskes, Naomi, and Erik M. Conway. 2010. *Merchants of Doubt: How a Handful of Scientists Obscured the Truth on Issues from Tobacco Smoke to Global Warming*. Bloomsbury Press.
^ref-oreskesconway2010

Origgi, Gloria. 2018. *Reputation: What It Is and Why It Matters*. Princeton University Press.
^ref-origgi2018

Ostrom, Elinor. 1990. *Governing the Commons: The Evolution of Institutions for Collective Action*. Cambridge University Press.
^ref-ostrom1990

Otsuka, Michael. 2003. *Libertarianism Without Inequality*. Oxford University Press.
^ref-otsuka2003

Otto, Rudolf. 1917. *The Idea of the Holy: An Inquiry into the Non-Rational Factor in the Idea of the Divine and its Relation to the Rational (Das Heilige)*. Breslau (German orig. 1917); Oxford University Press (English trans. 1923).
^ref-otto1917

Otto, Sarah P. 2009. “The Evolutionary Enigma of Sex.” *American Naturalist* 174 (S1): S1–S14.
^ref-otto2009

Owen, John. 1648. *Salus Electorum, Sanguis Jesu; or, The Death of Death in the Death of Christ*. London: Philemon Stephens.
^ref-owen1647

Padgett, Alan G. 1992. *God, Eternity and the Nature of Time*. New York: St. Martin's Press.
^ref-padgett1992

Page, Don N., and William K. Wootters. 1983. “Evolution Without Evolution: Dynamics Described by Stationary Observables.” *Physical Review D* 27(12): 2885–2892.
^ref-pageWootters1983

Page, D. N. 1993. “Information in Black Hole Radiation.” *Physical Review Letters* 71 (23): 3743–3746.
^ref-page1993

Page, Benjamin I., Larry M. Bartels, and Jason Seawright. 2013. “Democracy and the Policy Preferences of Wealthy Americans.” *Perspectives on Politics* 11(1): 51–73.
^ref-pageBartelsSeawright2013

Paine, Thomas. 1794. *The Age of Reason*. Paris: Barrois, 1794 (Part I; Part II 1795).
^ref-paine1794

Pakkanen, Petra. 1996. *Interpreting Early Hellenistic Religion: A Study Based on the Mystery Cult of Demeter and the Cult of Isis*. Finnish Institute at Athens / University of Helsinki.
^ref-pakkanen1996

Paley, William. 1802. *Natural Theology; or, Evidences of the Existence and Attributes of the Deity*. London: R. Faulder.
^ref-paley1802

Panksepp, J. 1998. *Affective Neuroscience: The Foundations of Human and Animal Emotions*. Oxford: Oxford University Press.
^ref-panksepp1998

Papineau, David. 1987. *Reality and Representation*. Basil Blackwell.
^ref-papineau1987

Parens, Erik, and Adrienne Asch. 2000. *Prenatal Testing and Disability Rights*. Georgetown University Press.
^ref-aschParens2000

Parfit, Derek. 1984. *Reasons and Persons*. Oxford University Press (Clarendon Press).
^ref-parfit1984

Parfit, Derek. 2011. *On What Matters*. Oxford University Press.
^ref-parfit2011

Pariser, Eli. 2011. *The Filter Bubble: What the Internet Is Hiding from You*. The Penguin Press.
^ref-pariser2011

Parnia, Sam, Ken Spearpoint, and Gabriele et al. de Vos. 2014. “AWARE—AWAreness during REsuscitation—A Prospective Study.” Resuscitation 85 (12): 1799-1805.
^ref-parnia2014

Pascal, Blaise. 1670. *Pensées*. Paris: Guillaume Desprez.
^ref-pascal1670

Pasquini, Luca, Fernanda Palhano-Fontes, and Draulio B. Araujo. 2020. “Subacute Effects of the Psychedelic Ayahuasca on the Salience and Default Mode Networks.” *Journal of Psychopharmacology* 34 (6): 623–635.
^ref-pasquini2020

Patel, B. H., C. Percivalle, D. J. Ritson, C. D. Duffy, and J. D. Sutherland. 2015. “Common Origins of RNA, Protein and Lipid Precursors in a Cyanosulfidic Protometabolism.” *Nature Chemistry* 7 (4): 301–307.
^ref-patel2015

Paul, L. A. 2017. “A One Category Ontology.” in J. A. Keller (ed.), Being, Freedom, and Method: Themes from the Philosophy of Peter van Inwagen (New York: Oxford University Press), 32–62.
^ref-paul2017

Pauling, Linus. 1939. *The Nature of the Chemical Bond and the Structure of Molecules and Crystals*. Ithaca, NY: Cornell University Press.
^ref-pauling1939

Pauly, Mark V. 1968. “The Economics of Moral Hazard: Comment.” *American Economic Review* 58(3):531–537.
^ref-pauly1968

Pautz, Adam. 2020. “Consciousness and Coincidence: Comments on Chalmers.” Journal of Consciousness Studies 27(5–6): 143–155.
^ref-pautz2020

Pawl, Timothy. 2016. *In Defense of Conciliar Christology: A Philosophical Essay*. Oxford: Oxford University Press.
^ref-pawl2016

Pawl, Timothy. 2019. *In Defense of Extended Conciliar Christology: A Philosophical Essay*. Oxford: Oxford University Press.
^ref-pawl2019

Pawl, Timothy. 2020. “Divine Immutability.” Internet Encyclopedia of Philosophy.
^ref-pawl2020

Peacocke, Arthur. 2007. *All That Is: A Naturalistic Faith for the Twenty-First Century*. Minneapolis: Fortress Press.
^ref-peacocke2007

Pearson, Joel. 2019. “The human imagination: the cognitive neuroscience of visual mental imagery.” *Nature Reviews Neuroscience* 20(10): 624–634.
^ref-pearson2019

Peirce, Charles Sanders. 1903. *Pragmatism as a Principle and Method of Right Thinking: The 1903 Harvard Lectures on Pragmatism*. State University of New York Press.
^ref-peirce1903

Peirce, Charles Sanders. 1931–1958. *Collected Papers of Charles Sanders Peirce*. Harvard University Press.
^ref-peirce1931

Pellis, Sergio, and Vivien Pellis. 2009. *The Playful Brain: Venturing to the Limits of Neuroscience*. Oneworld Publications.
^ref-pellisPellis2009

Penington, G. 2020. “Entanglement Wedge Reconstruction and the Information Paradox.” *Journal of High Energy Physics* 2020 (9): 002.
^ref-penington2020

Penrose, Roger. 1979. “Singularities and Time-Asymmetry.” In S. W. Hawking and W. Israel (eds.), General Relativity: An Einstein Centenary Survey (Cambridge University Press), pp. 581–638.
^ref-penrose1979

Penrose, R. 1989. *The Emperor's New Mind*. Oxford: Oxford University Press.
^ref-penrose1989

Penrose, R. 1996. “On Gravity's Role in Quantum State Reduction.” *General Relativity and Gravitation* 28 (5): 581–600.
^ref-penrose1996

Penrose, R. 2010. *Cycles of Time: An Extraordinary New View of the Universe*. London: Bodley Head.
^ref-penrose2010

Pereboom, Derk. 2001. *Living Without Free Will*. Cambridge University Press.
^ref-pereboom2001

Pereboom, Derk. 2011. *Consciousness and the Prospects of Physicalism*. New York: Oxford University Press.
^ref-pereboom2011

Pereboom, Derk. 2014. *Free Will, Agency, and Meaning in Life*. Oxford University Press.
^ref-pereboom2014

Pereira, J. (José). 2011. “Legalizing Euthanasia or Assisted Suicide: The Illusion of Safeguards and Controls.” *Current Oncology* 18 (2): e38–e45.
^ref-pereira2011

Perl, Eric D. 2014. *Thinking Being: Introduction to Metaphysics in the Classical Tradition*. Leiden: Brill.
^ref-perl2014

Perlmutter, Saul, et al. 1999. “Measurements of Ω and Λ from 42 High-Redshift Supernovae.” *The Astrophysical Journal* 517(2):565–586.
^ref-perlmutter1999

Pettigrew, Thomas F., and Linda R. Tropp. 2006. “A Meta-Analytic Test of Intergroup Contact Theory.” *Journal of Personality and Social Psychology* 90(5): 751–783.
^ref-pettigrewtropp2006

Pettit, Philip. 1997. *Republicanism: A Theory of Freedom and Government*. Oxford: Oxford University Press.
^ref-pettit1997

Pettit, Philip. 2012. *On the People's Terms: A Republican Theory and Model of Democracy*. Cambridge: Cambridge University Press.
^ref-pettit2012

Pfeifer, Karl. 2016. “Pantheism as Panpsychism.” In Alternative Concepts of God, ed. Andrei A. Buckareff and Yujin Nagasawa. Oxford University Press.
^ref-pfeifer2016

Philippi, Carissa L., Melissa C. Duff, Natalie L. Denburg, Daniel Tranel, and Daniel Rudrauf. 2012. “Medial PFC Damage Abolishes the Self-Referential Memory Advantage.” *Social Cognitive and Affective Neuroscience*.
^ref-philippi2012

Philipse, Herman. 2012. *God in the Age of Science? A Critique of Religious Reason*. Oxford: Oxford University Press.
^ref-philipse2012

Pigliucci, Massimo, and Gerd B. Müller. 2010. *Evolution: The Extended Synthesis*. Cambridge, MA: MIT Press.
^ref-pigliucciMuller2010

Pigou, Arthur Cecil. 1920. *The Economics of Welfare*. Macmillan and Co., London.
^ref-pigou1920

Piketty, Thomas. 2014. *Capital in the Twenty-First Century*. Belknap Press of Harvard University Press.
^ref-piketty2014

Piketty, Thomas; Saez, Emmanuel; Zucman, Gabriel. 2018. “Distributional National Accounts: Methods and Estimates for the United States.” *The Quarterly Journal of Economics* 133(2): 553–609.
^ref-pikettySaezZucman2018

Pimm, Stuart L., Clinton N. Jenkins, Robin Abell, et al. 2014. “The biodiversity of species and their rates of extinction, distribution, and protection.” *Science* 344(6187): 1246752.
^ref-pimmEtAl2014

Pinch, Trevor J., and Wiebe E. Bijker. 1984. “The Social Construction of Facts and Artefacts: Or How the Sociology of Science and the Sociology of Technology Might Benefit Each Other.” Social Studies of Science 14 (3): 399-441.
^ref-pinchBijker1984

Pincock, Christopher. 2012. *Mathematics and Scientific Representation*. Oxford: Oxford University Press.
^ref-pincock2012

Pinker, Steven, and Ray Jackendoff. 2005. “The Faculty of Language: What's Special About It?”
^ref-pinkerJackendoff2005

Pinker, Steven. 2011. *The Better Angels of Our Nature: Why Violence Has Declined*. New York: Viking.
^ref-pinker2011

Pinker, Steven. 2018. *Enlightenment Now: The Case for Reason, Science, Humanism, and Progress*. New York: Viking.
^ref-pinker2018

Pinnock, Clark H., Richard Rice, John Sanders, William Hasker, and David Basinger. 1994. *The Openness of God: A Biblical Challenge to the Traditional Understanding of God*. Downers Grove, IL: InterVarsity Press.
^ref-pinnock1994

Pitkin, Hanna Fenichel. 1967. *The Concept of Representation*. University of California Press.
^ref-pitkin1967

Pittard, John. 2024. “Deceptive Worlds, Skepticism, and Axiarchism.” *Inquiry* 67 (6): 1367–1402.
^ref-pittard2024

Pizzi, David. 2025. “The Impossibility of Nothingness: A Foundational Argument for Necessary Existence.” PhilArchive (preprint).
^ref-pizzi2025

Plantinga, Alvin. 1967. *God and Other Minds: A Study of the Rational Justification of Belief in God*. Ithaca, NY: Cornell University Press.
^ref-plantinga1967

Plantinga, A. 1974. *The Nature of Necessity*. Oxford: Oxford University Press.
^ref-plantinga1974b

Plantinga, Alvin. 1974. *God, Freedom, and Evil*. New York: Harper & Row, 1974; Grand Rapids: Eerdmans, 1974 (repr. 1977, 1989).
^ref-plantinga1974a

Plantinga, Alvin. 1976. “Actualism and Possible Worlds.” *Theoria* 42(1–3): 139–160.
^ref-plantinga1976

Plantinga, A. 1980. *Does God Have a Nature?* Milwaukee: Marquette University Press.
^ref-plantinga1980

Plantinga, Alvin. 1986. “On Ockham's Way Out.” *Faith and Philosophy* 3, no. 3, pp. 235–269.
^ref-plantinga1986b

Plantinga, Cornelius, Jr. 1986. “Gregory of Nyssa and the Social Analogy of the Trinity.” *The Thomist* 50, no. 3, pp. 325–352.
^ref-plantinga1986

Plantinga, Cornelius, Jr. 1989. “Social Trinity and Tritheism.” In R. J. Feenstra and C. Plantinga Jr. (eds.), Trinity, Incarnation, and Atonement: 21–47. Univ. of Notre Dame Press.
^ref-plantinga1989

Plantinga, Alvin. 1993. *Warrant and Proper Function*. New York: Oxford University Press.
^ref-plantinga1993

Plantinga, A. 2000. *Warranted Christian Belief*. Oxford University Press.
^ref-plantinga2000

Plantinga, Alvin. 2004. “Supralapsarianism, or 'O Felix Culpa'.” in Peter van Inwagen (ed.), Christian Faith and the Problem of Evil (Grand Rapids, MI: Eerdmans), 1–25.
^ref-plantinga2004

Plantinga, Alvin. 2007. “Two Dozen (or So) Theistic Arguments.” Appendix in Deane-Peter Baker (ed.), Alvin Plantinga (Cambridge: Cambridge University Press), 203–227.
^ref-plantinga2007

Plantinga, A. 2011. *Where the Conflict Really Lies: Science, Religion, and Naturalism*. Oxford University Press.
^ref-plantinga2011

Plotinus. c. 270 CE. *The Enneads*. Cambridge, MA: Harvard University Press (Loeb Classical Library).
^ref-plotinus270

Plotnik, Joshua M., Frans B. M. de Waal, and Diana Reiss. 2006. “Self-Recognition in an Asian Elephant.” Proceedings of the National Academy of Sciences 103 (45): 17053-17057.
^ref-plotnik2006

Plummer, Thomas W., et al. 2023. “Expanded Geographic Distribution and Dietary Strategies of the Earliest Oldowan Hominins and Paranthropus.”
^ref-plummer2023

Pnueli, Amir. 1977. “The Temporal Logic of Programs.” *Proceedings of the* 18th Annual Symposium on Foundations of Computer Science (FOCS), IEEE.
^ref-pnueli1977

Pogge, Thomas W. 2002. *World Poverty and Human Rights: Cosmopolitan Responsibilities and Reforms*. Polity Press.
^ref-pogge2002

Poincaré, Henri. 1890. “Sur le problème des trois corps et les équations de la dynamique.” *Acta Mathematica* 13:1–270.
^ref-poincare1890

Polanyi, Karl. 1944. *The Great Transformation: The Political and Economic Origins of Our Time*. Farrar & Rinehart.
^ref-polanyi1944

Polanyi, Michael. 1966. *The Tacit Dimension*. Garden City, NY: Doubleday (repr. University of Chicago Press).
^ref-polanyi1966

Pomeroy, Emma et al. 2020. “New Neanderthal Remains Associated with the 'Flower Burial' at Shanidar Cave.” Antiquity 94 (373): 11-26.
^ref-pomeroy2020

Pooley, Oliver. 2013. “Substantivalist and Relationalist Approaches to Spacetime.” In Robert Batterman (ed.), The Oxford Handbook of Philosophy of Physics (Oxford University Press).
^ref-pooley2013

Poplawski, N. J. 2010. “Cosmology with Torsion: An Alternative to Cosmic Inflation.” *Physics Letters B* 694 (3): 181–185.
^ref-poplawski2010

Poplawski, N. J. 2012. “Nonsingular, Big-Bounce Cosmology from Spinor-Torsion Coupling.” *Physical Review D* 85 (10): 107502.
^ref-poplawski2012

Postman, Neil. 1985. *Amusing Ourselves to Death: Public Discourse in the Age of Show Business*. Viking Penguin.
^ref-postman1985

Powner, Matthew W., Béatrice Gerland, and John D. Sutherland. 2009. “Synthesis of Activated Pyrimidine Ribonucleotides in Prebiotically Plausible Conditions.” *Nature* 459(7244):239–242.
^ref-pownerGerlandSutherland2009

Premack, David, and Guy Woodruff. 1978. “Does the chimpanzee have a theory of mind?” *Behavioral and Brain Sciences* 1(4): 515–526.
^ref-premack1978

Preston, Stephanie D., and Frans B. M. de Waal. 2002. “Empathy: Its Ultimate and Proximate Bases.” *Behavioral and Brain Sciences* 25(1): 1–20.
^ref-prestonDeWaal2002

Price, Huw. 1996. *Time's Arrow and Archimedes' Point: New Directions for the Physics of Time*. New York: Oxford University Press.
^ref-price1996

Priest, Graham. 2005. *Towards Non-Being: The Logic and Metaphysics of Intentionality*. Oxford University Press.
^ref-priest2005

Prigogine, I., and G. Nicolis. 1977. *Self-Organization in Nonequilibrium Systems*. New York: Wiley.
^ref-prigogineNicolis1977

Prigogine, Ilya. 1980. *From Being to Becoming: Time and Complexity in the Physical Sciences*. W. H. Freeman.
^ref-prigogine1980

Prigogine, I., and I. Stengers. 1984. *Order Out of Chaos: Man's New Dialogue with Nature*. New York: Bantam.
^ref-prigogineStengers1984

Prinz, Jesse J. 2004. *Gut Reactions: A Perceptual Theory of Emotion*. Oxford University Press (New York).
^ref-prinz2004

Prinz, Jesse J. 2007. *The Emotional Construction of Morals*. Oxford University Press.
^ref-prinz2007

Prior, A. N. 1957. *Time and Modality*. Oxford: Clarendon Press.
^ref-prior1957

Prior, A. N. 1959. “Thank Goodness That's Over.” *Philosophy* 34, no. 128: 12–17.
^ref-prior1959

Prior, A. N. 1962. “The Formalities of Omniscience.” *Philosophy* 37, no. 140: 114–129.
^ref-prior1962

Prior, A. N. 1967. *Past, Present and Future*. Oxford University Press (Clarendon).
^ref-prior1967

Prior, A. N. 1968. “Changes in Events and Changes in Things.” in Papers on Time and Tense (Oxford: Clarendon Press), 1–14.
^ref-prior1968

Prior, Helmut, Ariane Schwarz, and Onur Güntürkün. 2008. “Mirror-Induced Behavior in the Magpie (Pica pica): Evidence of Self-Recognition.” PLoS Biology 6 (8): e202.
^ref-prior2008

Pritchard, Duncan. 2005. *Epistemic Luck*. Oxford: Clarendon Press / Oxford University Press.
^ref-pritchard2005

Pruss, Alexander R. 2006. *The Principle of Sufficient Reason: A Reassessment*. Cambridge: Cambridge University Press.
^ref-pruss2006

Pruss, Alexander R. 2008. “On Two Problems of Divine Simplicity.” In J. Kvanvig (ed.), Oxford Studies in Philosophy of Religion, vol. 1: 150–167. Oxford University Press.
^ref-pruss2008

Pruss, A. R. 2011. *Actuality, Possibility, and Worlds*. New York: Continuum.
^ref-pruss2011

Pruss, Alexander R. 2013. “Omnipresence, Multilocation, the Real Presence and Time Travel.” *Journal of Analytic Theology* 1, no. 1: 60–73.
^ref-pruss2013

Pruss, Alexander R., and Joshua L. Rasmussen. 2018. *Necessary Existence*. Oxford University Press.
^ref-prussRasmussen2018

Pruss, Alexander R. 2018. *Infinity, Causation, and Paradox*. Oxford: Oxford University Press.
^ref-pruss2018

Putnam, Hilary. 1967a. “Psychological Predicates.” In W. H. Capitan and D. D. Merrill (eds.), Art, Mind, and Religion, Pittsburgh: University of Pittsburgh Press.
^ref-putnam1967

Putnam, Hilary. 1967b. “Time and Physical Geometry.” *The Journal of Philosophy* 64(8): 240–247.
^ref-putnam1967b

Putnam, Hilary. 1971. *Philosophy of Logic*. New York: Harper & Row.
^ref-putnam1971

Putnam, Hilary. 1975. “The Meaning of 'Meaning'.” Minnesota Studies in the Philosophy of Science 7: 131–193 (University of Minnesota Press).
^ref-putnam1975

Putnam, Hilary. 1979. *Mathematics, Matter and Method: Philosophical Papers, Volume 1*. Cambridge: Cambridge University Press (2nd ed.).
^ref-putnam1979

Putnam, Hilary. 1981. *Reason, Truth and History*. Cambridge: Cambridge University Press.
^ref-putnam1981

Putnam, Robert D. 2000. *Bowling Alone: The Collapse and Revival of American Community*. New York: Simon & Schuster.
^ref-putnam2000

Putnam, Robert D. 2015. *Our Kids: The American Dream in Crisis*. Simon & Schuster.
^ref-putnam2015

Pyszczynski, Tom, Sheldon Solomon, and Jeff Greenberg. 2003. *In the Wake of 9/11: The Psychology of Terror*. American Psychological Association.
^ref-pyszczynski2003

Quesnay, François. 1758. *Tableau économique*. Versailles: Imprimerie royale.
^ref-quesnay1758

Quine, W. V. O. 1948. “On What There Is.” *Review of Metaphysics* 2 (5): 21–38.
^ref-quine1948

Quine, W. V. O. 1951. “Two Dogmas of Empiricism.” *The Philosophical Review* 60 (1).
^ref-quine1951

Quine, W. V. 1951. “On Carnap's Views on Ontology.” *Philosophical Studies* 2(5): 65–72.
^ref-quine1951b

Quine, W. V. 1953. “Reference and Modality.” in From a Logical Point of View (Cambridge, MA: Harvard University Press), 139–159.
^ref-quine1953

Quine, W. V. O. 1960. *Word and Object*. Cambridge, MA: MIT Press.
^ref-quine1960

Quine, W. V. O. 1969. “Epistemology Naturalized.” In Ontological Relativity and Other Essays, New York: Columbia University Press.
^ref-quine1969

Quine, W. V. 1969. “Natural Kinds.” in Ontological Relativity and Other Essays (New York: Columbia University Press), 114–138.
^ref-quine1969b

Quinn, Philip L. 1978. *Divine Commands and Moral Requirements*. Clarendon Press.
^ref-quinn1978

Radford, Colin. 1975. “How Can We Be Moved by the Fate of Anna Karenina?” *Proceedings of the Aristotelian Society, Supplementary Volume* 49: 67–80.
^ref-radford1975

Rahner, Karl. 1976. *Foundations of Christian Faith: An Introduction to the Idea of Christianity*. Herder (orig. Grundkurs des Glaubens, 1976; Eng. trans. Seabury Press, 1978).
^ref-rahner1976

Raichle, Marcus E., Ann Mary MacLeod, Abraham Z. Snyder, William J. Powers, Debra A. Gusnard, and Gordon L. Shulman. 2001. “A Default Mode of Brain Function.” *Proceedings of the National Academy of Sciences* 98 (2): 676–682.
^ref-raichle2001

Railton, Peter. 1986. “Moral Realism.” *Philosophical Review* 95 (2): 163–207.
^ref-railton1986

Räisänen, Heikki. 1986. *Paul and the Law*. Fortress Press.
^ref-raisanen1986

Rametti, G., B. Carrillo, E. Gómez-Gil, C. Junque, S. Segovia, Á. Gomez, and A. Guillamon. 2011. “White Matter Microstructure in Female to Male Transsexuals before Cross-Sex Hormonal Treatment: A Diffusion Tensor Imaging Study.” *Journal of Psychiatric Research* 45 (2): 199–204.
^ref-rametti2011a

Rametti, G., B. Carrillo, E. Gómez-Gil, C. Junque, L. Zubiaurre-Elorza, S. Segovia, Á. Gomez, K. Karadi, and A. Guillamon. 2011. “The Microstructure of White Matter in Male to Female Transsexuals before Cross-Sex Hormonal Treatment: A DTI Study.” *Journal of Psychiatric Research* 45 (7): 949–954.
^ref-rametti2011b

Randell, D. A., Z. Cui, and A. G. Cohn. 1992. “A Spatial Logic Based on Regions and Connection.” In Proceedings of the 3rd International Conference on Principles of Knowledge Representation and Reasoning (KR'92), Morgan Kaufmann.
^ref-randellCuiCohn1992

Rasmussen, Joshua. 2009. “From a Necessary Being to God.” *International Journal for Philosophy of Religion* 66(1): 1–13.
^ref-rasmussen2009

Rasmussen, Joshua. 2019. *How Reason Can Lead to God: A Philosopher's Bridge to Faith*. Downers Grove, IL: IVP Academic.
^ref-rasmussen2019

Ratcliff, W. C., R. F. Denison, M. Borrello, and M. Travisano. 2012. “Experimental Evolution of Multicellularity.” *Proceedings of the National Academy of Sciences* 109 (5): 1595–1600.
^ref-ratcliff2012

Ratcliffe, Matthew. 2008. *Feelings of Being: Phenomenology, Psychiatry and the Sense of Reality*. Oxford University Press.
^ref-ratcliffe2008

Rawls, John. 1971. *A Theory of Justice*. Belknap Press of Harvard University Press.
^ref-rawls1971

Rawls, John. 1993. *Political Liberalism*. Columbia University Press.
^ref-rawls1993

Rawls, John. 2001. *Justice as Fairness: A Restatement*. ed. Erin Kelly.
^ref-rawls2001

Raworth, Kate. 2017. *Doughnut Economics: Seven Ways to Think Like a 21st-Century Economist*. White River Junction, VT: Chelsea Green Publishing.
^ref-raworth2017

Rea, Michael C. 2007. “The Metaphysics of Original Sin.” in Persons: Human and Divine, eds. van Inwagen and Zimmerman (Oxford University Press): 319–356.
^ref-rea2007

Rea, Michael C. 2009. “The Trinity.” In The Oxford Handbook of Philosophical Theology, eds. Thomas P. Flint & Michael C. Rea (Oxford University Press), pp. 403–29.
^ref-rea2009

Read, Kay Almere. 1998. *Time and Sacrifice in the Aztec Cosmos*. Indiana University Press.
^ref-read1998

Redhead, Michael. 1982. “Quantum Field Theory for Philosophers.” *PSA: Proceedings of the Biennial Meeting of the Philosophy of Science Association* 1982, vol. 2, pp. 57–99.
^ref-redhead1982

Rees, W. Dewi. 1971. “The Hallucinations of Widowhood.” British Medical Journal 4 (5778): 37-41.
^ref-rees1971

Regan, Tom. 1983. *The Case for Animal Rights*. University of California Press.
^ref-regan1983

Reich, Robert B. 1991. *The Work of Nations: Preparing Ourselves for 21st Century Capitalism*. Alfred A. Knopf.
^ref-reich1991

Reichenbach, Hans. 1956. *The Direction of Time*. Berkeley: University of California Press.
^ref-reichenbach1956

Reichenbach, Bruce R. 1982. *Evil and a Good God*. New York: Fordham University Press, 1982 (pp. ix+198).
^ref-reichenbach1982

Rescher, Nicholas. 1996. *Process Metaphysics: An Introduction to Process Philosophy*. Albany: State University of New York Press.
^ref-rescher1996

Resnik, Michael D. 1997. *Mathematics as a Science of Patterns*. Oxford: Clarendon Press (Oxford University Press).
^ref-resnik1997

Reynolds, Glenn Harlan. 1995. “A Critical Guide to the Second Amendment.” *Tennessee Law Review* 62 (3): 461–512.
^ref-reynolds1995

Rheingold, Howard. 1993. *The Virtual Community: Homesteading on the Electronic Frontier*. Addison-Wesley.
^ref-rheingold1993

Richardson, Katherine, Will Steffen, Wolfgang Lucht, Jørgen Bendtsen, Sarah E. Cornell, Jonathan F. Donges, Markus Drüke, Ingo Fetzer, Govindasamy Bala, Werner von Bloh, et al. 2023. “Earth beyond Six of Nine Planetary Boundaries.” *Science Advances* 9 (37): eadh2458.
^ref-richardson2023

Ricoeur, Paul. 1990. *Oneself as Another (Soi-même comme un autre)*. Éditions du Seuil (French); University of Chicago Press (English trans. 1992).
^ref-ricoeur1990

Ricoeur, Paul. 1992. *Oneself as Another*. University of Chicago Press.
^ref-ricoeur1992

Riess, Adam G., et al. 1998. “Observational Evidence from Supernovae for an Accelerating Universe and a Cosmological Constant.” *The Astronomical Journal* 116(3):1009–1038.
^ref-riess1998

Rietdijk, C. W. 1966. “A Rigorous Proof of Determinism Derived from the Special Theory of Relativity.” *Philosophy of Science* 33(4): 341–344.
^ref-rietdijk1966

Ritov, Oded, Christoph J. Völter, Nichola J. Raihani, and Jan M. Engelmann. 2024. “No Evidence for Inequity Aversion in Non-Human Animals: A Meta-Analysis of Accept/Reject Paradigms.” Proceedings of the Royal Society B: Biological Sciences 291(2035): 20241452.
^ref-ritovEtAl2024

Roberts, Dorothy E. 1997. *Killing the Black Body: Race, Reproduction, and the Meaning of Liberty*. Pantheon Books.
^ref-roberts1997

Roberts, Robert C. 2003. *Emotions: An Essay in Aid of Moral Psychology*. Cambridge University Press.
^ref-roberts2003

Robinson, Paul H. 1997. *Structure and Function in Criminal Law*. Clarendon Press.
^ref-robinson1997

Roca-Royes, Sonia. 2011. “Conceivability and De Re Modal Knowledge.” *Nous* 45 (1): 22-49.
^ref-rocaRoyes2011

Rocca, Gregory P. 2004. *Speaking the Incomprehensible God: Thomas Aquinas on the Interplay of Positive and Negative Theology*. Catholic University of America Press.
^ref-rocca2004

Rocker, Rudolf. 1938. *Anarcho-Syndicalism: Theory and Practice*. Secker and Warburg.
^ref-rocker1938

Rockström, Johan, Will Steffen, Kevin Noone, Åsa Persson, F. Stuart, III Chapin, Eric F. Lambin, Timothy M. Lenton, Marten Scheffer, Carl Folke, Hans Joachim Schellnhuber, et al. 2009. “A Safe Operating Space for Humanity.” *Nature* 461 (7263): 472–475.
^ref-rockstrom2009

Rodríguez-Prat, Andrea, Denise Pergolizzi, Iris Crespo, Joaquim Julià-Torras, Albert Balaguer, Kerstin Kremeike, Raymond Voltz, and Cristina Monforte-Royo. 2024. “The Wish to Hasten Death in Patients With Life-Limiting Conditions: A Systematic Overview.” *Journal of Pain and Symptom Management* 68(2): e91–e115.
^ref-rodriguezPrat2024

Roediger, Henry L., III, and Kathleen B. McDermott. 1995. “Creating false memories: Remembering words not presented in lists.” *Journal of Experimental Psychology: Learning, Memory, and Cognition* 21(4): 803–814.
^ref-roediger1995

Roemer, John E. 1994. *A Future for Socialism*. Harvard University Press, Cambridge, MA.
^ref-roemer1994

Rogers, Katherin A. 2000. *Perfect Being Theology*. Edinburgh: Edinburgh University Press.
^ref-rogers2000

Rolston, Holmes, III. 1988. *Environmental Ethics: Duties to and Values in the Natural World*. Temple University Press.
^ref-rolston1988

Rolston, Holmes, III. 1994. *Conserving Natural Value*. Columbia University Press.
^ref-rolston1994

Romanides, John S. 2002. *The Ancestral Sin*. Zephyr Publishing.
^ref-romanides2002

Romer, Paul M. 1990. “Endogenous Technological Change.” *Journal of Political Economy* 98 (5): S71–S102.
^ref-romer1990

Romer, Christina D., and David H. Romer. 2010. “The Macroeconomic Effects of Tax Changes: Estimates Based on a New Measure of Fiscal Shocks.” *American Economic Review* 100 (3): 763–801.
^ref-romerRomer2010

Römer, Thomas. 2015. *The Invention of God*. Cambridge, MA: Harvard University Press.
^ref-romer2015

Roosevelt, Franklin D. 1944. “Message to the Congress on the State of the Union (Second Bill of Rights).” January 11, 1944.
^ref-roosevelt1944

Rorty, Richard. 1979. *Philosophy and the Mirror of Nature*. Princeton, NJ: Princeton University Press.
^ref-rorty1979

Rose, J. D., R. Arlinghaus, S. J. Cooke, B. K. Diggles, W. Sawynok, E. D. Stevens, and C. D. L. Wynne. 2014. “Can Fish Really Feel Pain?” *Fish and Fisheries* 15 (1): 97–133.
^ref-rose2014

Roselli, C. E., K. Larkin, J. M. Schrunk, and F. Stormshak. 2004. “Sexual Partner Preference, Hypothalamic Morphology and Aromatase in Rams.” *Physiology & Behavior* 83 (2): 233–245.
^ref-roselli2004

Rosen, Gideon. 1990. “Modal Fictionalism.” *Mind* 99(395): 327–354.
^ref-rosen1990

Rosen, Gideon. 2010. “Metaphysical Dependence: Grounding and Reduction.” In Modality: Metaphysics, Logic, and Epistemology, edited by Bob Hale and Aviv Hoffmann, 109–135. Oxford: Oxford University Press.
^ref-rosen2010

Rosen, Gideon. 2015. “Real Definition.” *Analytic Philosophy* 56 (3): 189–209.
^ref-rosen2015

Rosenberg, Marshall B. 2003. *Nonviolent Communication: A Language of Life*. PuddleDancer Press.
^ref-rosenberg2003

Rosenthal, David M. 2005. *Consciousness and Mind*. Oxford: Clarendon Press (Oxford University Press).
^ref-rosenthal2005

Ross, W. D. 1930. *The Right and the Good*. Clarendon Press.
^ref-ross1930

Rothbard, Murray N. 1971. *Education: Free and Compulsory*. The Individualist (Center for Independent Education).
^ref-rothbard1971

Rothbard, Murray N. 1973. *For a New Liberty: The Libertarian Manifesto*. Macmillan.
^ref-rothbard1973

Rothbard, Murray N. 1982. *The Ethics of Liberty*. Humanities Press.
^ref-rothbard1982

Rothschild, Michael, and Joseph Stiglitz. 1976. “Equilibrium in Competitive Insurance Markets: An Essay on the Economics of Imperfect Information.” *Quarterly Journal of Economics* 90 (4): 629–649.
^ref-rothschildStiglitz1976

Roughgarden, J. 2004. *Evolution's Rainbow: Diversity, Gender, and Sexuality in Nature and People*. Berkeley: University of California Press.
^ref-roughgarden2004

Rovelli, Carlo. 2018. *The Order of Time*. New York: Riverhead Books.
^ref-rovelli2018

Rowe, William L. 1975. *The Cosmological Argument*. Princeton University Press.
^ref-rowe1975

Rowe, William L. 2004. *Can God Be Free?* Oxford: Clarendon Press (Oxford University Press).
^ref-rowe2004

Rowlandson, Jane. 1998. *Women and Society in Greek and Roman Egypt: A Sourcebook*. Cambridge: Cambridge University Press.
^ref-rowlandson1998

Ruetsche, L. 2011. *Interpreting Quantum Theories*. Oxford: Oxford University Press.
^ref-ruetsche2011

Rundle, Bede. 2004. *Why there is Something rather than Nothing*. Oxford: Clarendon Press (Oxford University Press).
^ref-rundle2004

Russell, Bertrand. 1903. *The Principles of Mathematics*. Cambridge University Press.
^ref-russell1903

Russell, Bertrand. 1905. “On Denoting.” *Mind* 14 (56): 479–493.
^ref-russell1905

Russell, B. 1913. “On the Notion of Cause.” *Proceedings of the Aristotelian Society* 13: 1–26.
^ref-russell1913

Russell, Bertrand. 1927. *The Analysis of Matter*. London: Kegan Paul, Trench, Trubner & Co.
^ref-russell1927

Russell, Bertrand. 1940. *An Inquiry into Meaning and Truth*. London: George Allen & Unwin / New York: W. W. Norton.
^ref-russell1940

Russell, James A. 2003. “Core Affect and the Psychological Construction of Emotion.” *Psychological Review* 110 (1): 145–172.
^ref-russell2003

Rutz, Christian, Lucas A. Bluff, Nicola Reed, Jolyon Troscianko, Jason Newton, Richard Inger, Alex Kacelnik, and Stuart Bearhop. 2010. “The Ecological Significance of Tool Use in New Caledonian Crows.”
^ref-rutz2010

Ryff, Carol D. 1989. “Happiness Is Everything, or Is It? Explorations on the Meaning of Psychological Well-Being.” Journal of Personality and Social Psychology 57 (6): 1069-1081.
^ref-ryff1989

Ryff, Carol D., and Burton H. Singer. 2008. “Know Thyself and Become What You Are: A Eudaimonic Approach to Psychological Well-Being.” Journal of Happiness Studies 9: 13-39.
^ref-ryffSinger2008

Ryle, Gilbert. 1949. *The Concept of Mind*. London: Hutchinson.
^ref-ryle1949

Saad, Bradford. 2019. “A Teleological Strategy for Solving the Meta-Problem of Consciousness.” Journal of Consciousness Studies 26(9–10): 205–216.
^ref-saad2019

Sadeghi, Behnam, and Uwe Bergmann. 2010. “The Codex of a Companion of the Prophet and the Qur'ān of the Prophet.” Arabica 57 (Brill).
^ref-sadeghibergmann2010

Sahlberg, Pasi. 2011. *Finnish Lessons: What Can the World Learn from Educational Change in Finland?* Teachers College Press.
^ref-sahlberg2011

Sakenfeld, Katharine Doob. 1978. *The Meaning of Hesed in the Hebrew Bible: A New Inquiry*. Scholars Press (Harvard Semitic Monographs 17).
^ref-sakenfeld1978

Sakharov, A. D. 1967. “Violation of CP Invariance, C Asymmetry, and Baryon Asymmetry of the Universe.” *JETP Letters* 5: 24–27 (Pisma Zh. Eksp. Teor. Fiz. 5: 32–35).
^ref-sakharov1967

Salmon, Nathan U. 1981. *Reference and Essence*. Princeton, NJ: Princeton University Press.
^ref-salmon1981

Salmon, Wesley C. 1984. *Scientific Explanation and the Causal Structure of the World*. Princeton, NJ: Princeton University Press.
^ref-salmon1984

Salmon, Nathan U. 1989. “The Logic of What Might Have Been.” *The Philosophical Review* 98 (1): 3–34.
^ref-salmon1989

Sampson, Robert J., Stephen W. Raudenbush, and Felton Earls. 1997. “Neighborhoods and Violent Crime: A Multilevel Study of Collective Efficacy.” *Science* 277 (5328): 918–924.
^ref-sampsonRaudenbushEarls1997

Samuelson, Paul A. 1954. “The Pure Theory of Public Expenditure.” *Review of Economics and Statistics* 36 (4): 387–389.
^ref-samuelson1954

Sandel, Michael J. 1996. *Democracy's Discontent: America in Search of a Public Philosophy*. Cambridge, MA: Belknap Press of Harvard University Press.
^ref-sandel1996

Sandel, Michael J. 2007. *The Case Against Perfection: Ethics in the Age of Genetic Engineering*. Belknap Press of Harvard University Press.
^ref-sandel2007

Sanders, John. 1992. *No Other Name: An Investigation into the Destiny of the Unevangelized*. Eerdmans.
^ref-sanders1992

Sanders, John. 1998. *The God Who Risks: A Theology of Providence*. Downers Grove, IL: InterVarsity Press.
^ref-sanders1998

Sapolsky, Robert M. 2017. *Behave: The Biology of Humans at Our Best and Worst*. Penguin Press.
^ref-sapolsky2017

Sartre, J.-P. (1943) 1956. *Being and Nothingness*. Translated by H. E. Barnes. New York: Philosophical Library.
^ref-sartre1943

Sartre, Jean-Paul. 1946. *Existentialism Is a Humanism*. Éditions Nagel (Paris).
^ref-sartre1946

Saucy, Robert L. 1993. *The Case for Progressive Dispensationalism: The Interface Between Dispensational and Non-Dispensational Theology*. Zondervan.
^ref-saucy1993

Saunders, Simon. 2002. “Is the Zero-Point Energy Real?” In M. Kuhlmann, H. Lyre, and A. Wayne (eds.), Ontological Aspects of Quantum Field Theory (World Scientific).
^ref-saunders2002

Saunders, S., J. Barrett, A. Kent, and D. Wallace. 2010. *Many Worlds? Everett, Quantum Theory, and Reality*. Oxford: Oxford University Press.
^ref-saunders2010

Saussure, Ferdinand de. 1916. *Course in General Linguistics (Cours de linguistique générale)*. Payot (Lausanne/Paris).
^ref-saussure1916

Saxton, Marsha. 2000. “Why Members of the Disability Community Oppose Prenatal Diagnosis and Selective Abortion.” In Prenatal Testing and Disability Rights (eds. Parens & Asch), Georgetown University Press.
^ref-saxton2000

Scanlon, T. M. 1998. *What We Owe to Each Other*. Belknap Press of Harvard University Press.
^ref-scanlon1998

Scanlon, T. M. 2014. *Being Realistic about Reasons*. Oxford University Press.
^ref-scanlon2014

Scarry, Elaine. 1985. *The Body in Pain: The Making and Unmaking of the World*. Oxford University Press.
^ref-scarry1985

Schachter, Stanley, and Jerome E. Singer. 1962. “Cognitive, Social, and Physiological Determinants of Emotional State.” *Psychological Review* 69 (5): 379–399.
^ref-schachterSinger1962

Schaffer, Jonathan. 2009. “On What Grounds What.” In Metametaphysics: New Essays on the Foundations of Ontology, edited by David J. Chalmers, David Manley, and Ryan Wasserman, 347–383. Oxford: Oxford University Press.
^ref-schaffer2009

Schaffer, Jonathan. 2010. “Monism: The Priority of the Whole.” *Philosophical Review* 119 (1): 31–76.
^ref-schaffer2010

Schaffer, Jonathan. 2017. “Laws for Metaphysical Explanation.” *Philosophical Issues* 27(1): 302–321.
^ref-schaffer2017

Schellenberg, J. L. 1993. *Divine Hiddenness and Human Reason*. Cornell University Press.
^ref-schellenberg1993

Schellenberg, J. L. 2007. *The Wisdom to Doubt: A Justification of Religious Skepticism*. Cornell University Press.
^ref-schellenberg2007

Schellenberg, J. L. 2015. *The Hiddenness Argument: Philosophy's New Challenge to Belief in God*. Oxford University Press.
^ref-schellenberg2015

Schellnhuber, Hans Joachim. 2009. “Tipping Elements in the Earth System.” *PNAS* 106(49):20561–20563.
^ref-schellnhuber2009

Scherer, Klaus R. 1984. “On the Nature and Function of Emotion: A Component Process Approach.” In Approaches to Emotion, ed. K. R. Scherer and P. Ekman, 293–317. Erlbaum (Hillsdale, NJ).
^ref-scherer1984

Scherrer, Robert J., and A. A. Sen. 2008. “Thawing Quintessence with a Nearly Flat Potential.” *Physical Review D* 77 (8): 083515.
^ref-scherrerSen2008

Schmid, Joseph C. 2021. “Existential Inertia and the Aristotelian Proof.” *International Journal for Philosophy of Religion* 89 (3): 201–220.
^ref-schmid2021

Schmid, Joseph C., and Daniel J. Linford. 2022. *Existential Inertia and Classical Theistic Proofs*. Springer (Cham).
^ref-schmidLinford2022

Schmid, Joseph C. 2022. “From Modal Collapse to Providential Collapse.” *Philosophia* 50 (3): 1413–1435.
^ref-schmid2022

Schmid, Joseph C. 2024. “The End is Near: Grim Reapers and Endless Futures.” Mind 133(532): 1057–1077.
^ref-schmid2024

Schmid, Joseph C., and Alex Malpass. 2025. “Benardete Paradoxes, Causal Finitism, and the Unsatisfiable Pair Diagnosis.” Mind 134(534): 397–421.
^ref-schmidMalpass2025

Schneider, Eric D., and Dorion Sagan. 2005. *Into the Cool: Energy Flow, Thermodynamics, and Life*. University of Chicago Press.
^ref-schneiderSagan2005

Schopenhauer, A. (1819) 1969. *The World as Will and Representation*. Translated by E. F. J. Payne. New York: Dover.
^ref-schopenhauer1819

Schopenhauer, Arthur. 1813. *On the Fourfold Root of the Principle of Sufficient Reason*. Doctoral dissertation (rev. 1847); trans. E. F. J. Payne (La Salle, IL: Open Court, 1974).
^ref-schopenhauer1813

Schopenhauer, Arthur. 1818. *The World as Will and Representation (Die Welt als Wille und Vorstellung), Vol. 1*. Leipzig: F. A. Brockhaus.
^ref-schopenhauer1818

Schrödinger, E. 1944. *What Is Life?* Cambridge: Cambridge University Press.
^ref-schrodinger1944

Schroeder, Mark. 2007. *Slaves of the Passions*. Oxford University Press.
^ref-schroeder2007

Schroeder, Mark. 2008. *Being For: Evaluating the Semantic Program of Expressivism*. Oxford: Clarendon Press (Oxford University Press).
^ref-schroeder2008

Schumpeter, Joseph A. 1942. *Capitalism, Socialism and Democracy*. Harper & Brothers.
^ref-schumpeter1942

Schuon, Frithjof. 1953. *The Transcendent Unity of Religions*. Faber and Faber.
^ref-schuon1953

Searle, John R. 1969. *Speech Acts: An Essay in the Philosophy of Language*. Cambridge University Press.
^ref-searle1969

Searle, John R. 1980. “Minds, Brains, and Programs.” *Behavioral and Brain Sciences* 3 (3): 417–424.
^ref-searle1980

Seeley, Thomas D. 1995. *The Wisdom of the Hive: The Social Physiology of Honey Bee Colonies*. Harvard University Press.
^ref-seeley1995

Seeskin, Kenneth. 2000. *Searching for a Distant God: The Legacy of Maimonides*. New York: Oxford University Press.
^ref-seeskin2000

Seibt, Johanna. 2017. “Process Philosophy.” The Stanford Encyclopedia of Philosophy, ed. Edward N. Zalta (Summer 2017 ed.).
^ref-seibt2017

Seifert, A., Z. G. Lane, M. Galoppo, R. Ridden-Harper, and D. L. Wiltshire. 2025. “Supernovae Evidence for Foundational Change to Cosmological Models.” *Monthly Notices of the Royal Astronomical Society: Letters* 537 (1): L55–L60.
^ref-seifertEtAl2025

Sellars, Wilfrid. 1956. “Empiricism and the Philosophy of Mind.” Minnesota Studies in the Philosophy of Science, vol. 1.
^ref-sellars1956

Sells, Michael A. 1994. *Mystical Languages of Unsaying*. Chicago: University of Chicago Press.
^ref-sells1994

Selman, Donna, and Paul Leighton. 2010. *Punishment for Sale: Private Prisons, Big Business, and the Incarceration Binge*. Rowman and Littlefield.
^ref-selmanLeighton2010

Sen, Amartya. 1985. *Commodities and Capabilities*. North-Holland.
^ref-sen1985

Sen, Amartya. 1992. *Inequality Reexamined*. Cambridge, MA: Harvard University Press.
^ref-sen1992a

Sen, Amartya. 1999. *Development as Freedom*. New York: Knopf.
^ref-sen1999a

Senghas, Ann, Sotaro Kita, and Asli Özyürek. 2004. “Children Creating Core Properties of Language: Evidence from an Emerging Sign Language in Nicaragua.”
^ref-senghasKitaOzyurek2004

Serano, Julia. 2007. *Whipping Girl: A Transsexual Woman on Sexism and the Scapegoating of Femininity*. Seal Press.
^ref-serano2007

Seth, Anil K. 2013. “Interoceptive Inference, Emotion, and the Embodied Self.” *Trends in Cognitive Sciences* 17 (11): 565–573.
^ref-seth2013

Seth, Anil. 2021. *Being You: A New Science of Consciousness*. Faber & Faber / Dutton.
^ref-seth2021

Seyfarth, Robert M., Dorothy L. Cheney, and Peter Marler. 1980. “Monkey Responses to Three Different Alarm Calls: Evidence of Predator Classification and Semantic Communication.” *Science* 210 (4471): 801–803.
^ref-seyfarthCheneyMarler1980

Shackel, Nicholas. 2005. “The Form of the Benardete Dichotomy.” The British Journal for the Philosophy of Science 56(2): 397–417.
^ref-shackel2005

Shafer-Landau, Russ. 2003. *Moral Realism: A Defence*. Oxford University Press.
^ref-shaferLandau2003

Shalm, Lynden K., et al. 2015. “Strong Loophole-Free Test of Local Realism.” *Physical Review Letters* 115(25):250402.
^ref-shalm2015

Shani, Itay. 2015. “Cosmopsychism: A Holistic Approach to the Metaphysics of Experience.” *Philosophical Papers* 44(3): 389–437.
^ref-shani2015

Shannon, C. E. 1948. “A Mathematical Theory of Communication.” *Bell System Technical Journal* 27 (3): 379–423; (4): 623–656.
^ref-shannon1948

Shapiro, Stewart. 1997. *Philosophy of Mathematics: Structure and Ontology*. Oxford: Oxford University Press.
^ref-shapiro1997

Sher, Gila. 2016. *Epistemic Friction: An Essay on Knowledge, Truth, and Logic*. Oxford: Oxford University Press.
^ref-sher2016

Shirky, Clay. 2008. *Here Comes Everybody: The Power of Organizing Without Organizations*. Penguin Press.
^ref-shirky2008

Shoemaker, Sydney. 1969. “Time Without Change.” *The Journal of Philosophy* 66(12): 363–381.
^ref-shoemaker1969

Shue, Henry. 1980. *Basic Rights: Subsistence, Affluence, and U.S. Foreign Policy*. Princeton, NJ: Princeton University Press.
^ref-shue1980

Sidelle, Alan. 1989. *Necessity, Essence, and Individuation: A Defense of Conventionalism*. Ithaca, NY: Cornell University Press.
^ref-sidelle1989

Sidelle, Alan. 2010. “Modality and Objects.” *The Philosophical Quarterly* 60 (238): 109–125.
^ref-sidelle2010

Sider, Theodore. 2001. *Four-Dimensionalism: An Ontology of Persistence and Time*. Oxford: Clarendon Press (Oxford University Press).
^ref-sider2001

Sider, Theodore. 2003. “Reductive Theories of Modality.” in M. J. Loux & D. W. Zimmerman (eds.), The Oxford Handbook of Metaphysics (Oxford: Oxford University Press), 180–208.
^ref-sider2003

Sider, Theodore. 2011. *Writing the Book of the World*. Oxford University Press.
^ref-sider2011

Sider, Theodore. 2013. “Against Parthood.” in K. Bennett & D. W. Zimmerman (eds.), Oxford Studies in Metaphysics, vol. 8 (Oxford: Oxford University Press), 237–293.
^ref-sider2013

Siderits, Mark. 2003. *Personal Identity and Buddhist Philosophy: Empty Persons*. Aldershot / Burlington, VT: Ashgate.
^ref-siderits2003

Siderits, Mark. 2007. *Buddhism as Philosophy: An Introduction*. Indianapolis: Hackett / Aldershot: Ashgate.
^ref-siderits2007

Simon, Herbert A. 1957. *Models of Man: Social and Rational*. John Wiley & Sons.
^ref-simon1957

Simon, Julian L. 1981. *The Ultimate Resource*. Princeton University Press.
^ref-simon1981

Simons, Peter. 1987. *Parts: A Study in Ontology*. Oxford: Clarendon Press.
^ref-simons1987

Simons, Daniel J., and Christopher F. Chabris. 1999. “Gorillas in our midst: sustained inattentional blindness for dynamic events.” *Perception* 28(9): 1059–1074.
^ref-simons1999

Sinervo, B., and C. M. Lively. 1996. “The Rock-Paper-Scissors Game and the Evolution of Alternative Male Strategies.” *Nature* 380: 240–243.
^ref-sinervoLively1996a

Singer, Peter. 1975. *Animal Liberation: A New Ethics for Our Treatment of Animals*. New York Review / Random House.
^ref-singer1975

Singer, Peter. 1979. *Practical Ethics*. Cambridge University Press.
^ref-singer1979

Singer, Tania, and Claus Lamm. 2009. “The Social Neuroscience of Empathy.”
^ref-singerLamm2009

Sklar, Lawrence. 1974. *Space, Time, and Spacetime*. University of California Press.
^ref-sklar1974

Skow, Bradford. 2008. “Haecceitism, Anti-Haecceitism and Possible Worlds.” *The Philosophical Quarterly,* 58 (230): 98–107.
^ref-skow2008

Slobodchikoff, Con N. 2002. “Cognition and Communication in Prairie Dogs.” The Cognitive Animal: Empirical and Theoretical Perspectives on Animal Cognition (MIT Press), pp. 257–264.
^ref-slobodchikoff2002

Smart, J. J. C. 1949. “The River of Time.” *Mind* 58(232): 483–494.
^ref-smart1949

Smart, J. J. C. 1963. *Philosophy and Scientific Realism*. London: Routledge & Kegan Paul.
^ref-smart1963

Smit, Nikolaos. 2025. “Strategies, costs and counter-strategies to sexual coercion.” *Biological Reviews*.
^ref-smit2025

Smith, Adam. 1776. *An Inquiry into the Nature and Causes of the Wealth of Nations*. London: W. Strahan and T. Cadell.
^ref-smith1776

Smith, Quentin. 1991. “Atheism, Theism and Big Bang Cosmology.” *Australasian Journal of Philosophy* 69(1):48–66.
^ref-smith1991

Smith, Michael. 1994. *The Moral Problem*. Blackwell.
^ref-smith1994

Smith, Jonathan Z. 1998. “Religion, Religions, Religious.” *in Critical Terms for Religious Studies, ed. Mark C. Taylor*.
^ref-smith1998religion

Smith, Mark S. 2002. *The Early History of God: Yahweh and the Other Deities in Ancient Israel*. Grand Rapids: Eerdmans.
^ref-smith2002

Smith, Barry. 2003. “Ontology.” In L. Floridi (ed.), The Blackwell Guide to the Philosophy of Computing and Information, Oxford: Blackwell, pp. 153–166.
^ref-smith2003

Smith, J. David, Alexandria C. Zakrzewski, and Jonathon D. Crystal. 2014. “Animal Metacognition: A Tale of Two Comparative Psychologies.” *Journal of Comparative Psychology* 128 (2): 115–131.
^ref-smithZakrzewskiCrystal2014

Smith, E., and H. J. Morowitz. 2016. *The Origin and Nature of Life on Earth: The Emergence of the Fourth Geosphere*. Cambridge: Cambridge University Press.
^ref-smithMorowitz2016

Smolin, L. 1992. “Did the Universe Evolve?” *Classical and Quantum Gravity* 9 (1): 173–191.
^ref-smolin1992

Smolin, Lee. 1997. *The Life of the Cosmos*. New York: Oxford University Press.
^ref-smolin1997

Smolin, Lee. 2013. *Time Reborn: From the Crisis in Physics to the Future of the Universe*. Houghton Mifflin Harcourt.
^ref-smolin2013

Sneddon, Lynne U., Victoria A. Braithwaite, and Michael J. Gentle. 2003. “Do Fishes Have Nociceptors? Evidence for the Evolution of a Vertebrate Sensory System.” *Proceedings of the Royal Society of London B* 270 (1520): 1115–1121.
^ref-sneddon2003

Sneddon, Lynne U., Robert W. Elwood, Shelley A. Adamo, and Matthew C. Leach. 2014. “Defining and Assessing Animal Pain.” *Animal Behaviour* 97: 201–212.
^ref-sneddon2014

Sneddon, Lynne U. 2015. “Pain in Aquatic Animals.” *Journal of Experimental Biology* 218 (7): 967–976.
^ref-sneddon2015

Soames, Scott. 1999. “The Indeterminacy of Translation and the Inscrutability of Reference.” *Canadian Journal of Philosophy* 29 (3): 321–370.
^ref-soames1999

Soames, Scott. 2002. *Beyond Rigidity: The Unfinished Semantic Agenda of Naming and Necessity*. Oxford University Press.
^ref-soames2002

Sobel, Jordan Howard. 2004. *Logic and Theism: Arguments For and Against Beliefs in God*. Cambridge University Press.
^ref-sobel2003

Sober, Elliott. 1993. *Philosophy of Biology*. Boulder, CO: Westview Press.
^ref-sober1993

Sober, Elliott. 2005. “The Design Argument.” in The Blackwell Guide to the Philosophy of Religion (ed. W. Mann), Blackwell, 2005, pp. 117–147.
^ref-sober2005

Sober, Elliott. 2008. *Evidence and Evolution: The Logic Behind the Science*. Cambridge: Cambridge University Press.
^ref-sober2008

Sober, Elliott. 2015. *Ockham's Razors: A User's Manual*. Cambridge: Cambridge University Press.
^ref-sober2015

Soh, Debra. 2020. *The End of Gender: Debunking the Myths about Sex and Identity in Our Society*. Threshold Editions.
^ref-soh2020

Sojo, V., B. Herschy, A. Whicher, E. Camprubí, and N. Lane. 2016. “The Origin of Life in Alkaline Hydrothermal Vents.” *Astrobiology* 16 (2): 181–197.
^ref-sojo2016

Solms, Mark. 2021. *The Hidden Spring: A Journey to the Source of Consciousness*. W. W. Norton (New York).
^ref-solms2021

Solomon, Robert C. 1976. *The Passions: Emotions and the Meaning of Life*. Doubleday (Garden City, NY).
^ref-solomon1976

Solomon, S., J. Greenberg, and T. Pyszczynski. 2015. *The Worm at the Core: On the Role of Death in Life*. New York: Random House.
^ref-solomon2015

Sommer, Benjamin D. 2009. *The Bodies of God and the World of Ancient Israel*. New York: Cambridge University Press.
^ref-sommer2009

Sosa, Ernest. 1980. “The Raft and the Pyramid: Coherence versus Foundations in the Theory of Knowledge.” *Midwest Studies in Philosophy* 5(1): 3–25.
^ref-sosa1980

Sosa, Ernest. 1999. “How to Defeat Opposition to Moore.” *Philosophical Perspectives* 13 (Epistemology): 141–153.
^ref-sosa1999

Sosa, Ernest. 2007. *A Virtue Epistemology: Apt Belief and Reflective Knowledge, Volume I*. Oxford University Press (Clarendon Press).
^ref-sosa2007

Sosa, Ernest. 2015. *Judgment and Agency*. Oxford: Oxford University Press.
^ref-sosa2015

Spang, A., J. H. Saw, S. L. Jørgensen, K. Zaremba-Niedzwiedzka, J. Martijn, A. E. Lind, R. van Eijk, C. Schleper, L. Guy, and T. J. G. Ettema. 2015. “Complex Archaea That Bridge the Gap between Prokaryotes and Eukaryotes.” *Nature* 521 (7551): 173–179.
^ref-spang2015

Speaks, Jeff. 2018. *The Greatest Possible Being*. Oxford: Oxford University Press.
^ref-speaks2018

Sperber, Dan, and Deirdre Wilson. 1986. *Relevance: Communication and Cognition*. Harvard University Press.
^ref-sperberWilson1986

Spinoza, B. (1677) 1996. *Ethics*. Translated by E. Curley. London: Penguin.
^ref-spinoza1677

Spreng, R. Nathan, and Cheryl L. Grady. 2010. “Patterns of Brain Activity Supporting Autobiographical Memory, Prospection, and Theory of Mind, and Their Relationship to the Default Mode Network.” Journal of Cognitive Neuroscience 22 (6): 1112-1123.
^ref-sprengGrady2010

Squire, Larry R., and Stuart M. Zola. 1996. “Structure and Function of Declarative and Nondeclarative Memory Systems.” *Proceedings of the National Academy of Sciences* 93(24): 13515–13522.
^ref-squireZola1996

Stace, W. T. 1960. *Mysticism and Philosophy*. Macmillan.
^ref-stace1960

Stalnaker, Robert. 1976. “Possible Worlds.” *Noûs* 10(1): 65–75.
^ref-stalnaker1976

Stalnaker, Robert. 1984. *Inquiry*. Cambridge, MA: MIT Press (Bradford Books).
^ref-stalnaker1984

Stalnaker, Robert. 1997. “Reference and Necessity.”
^ref-stalnaker1997

Stalnaker, Robert. 2012. *Mere Possibilities: Metaphysical Foundations of Modal Semantics*. Princeton: Princeton University Press.
^ref-stalnaker2012

Stanley, Jason, and Timothy Williamson. 2001. “Knowing How.” *The Journal of Philosophy* 98(8): 411–444.
^ref-stanleyWilliamson2001

Stanley, Jason. 2005. *Knowledge and Practical Interests*. Oxford: Oxford University Press.
^ref-stanley2005

Stanley, Jason. 2011. *Know How*. Oxford: Oxford University Press.
^ref-stanley2011

Stanovich, Keith E. 2011. *Rationality and the Reflective Mind*. Oxford University Press.
^ref-stanovich2011

Stavrakopoulou, Francesca. 2022. *God: An Anatomy*. Knopf.
^ref-stavrakopoulou2022

Stefanopoulou, Evgenia, Colette R. Hirsch, Sarra Hayes, Anna Adlam, and Sian Coker. 2014. “Are attentional control resources reduced by worry in generalized anxiety disorder?” *Journal of Abnormal Psychology* 123(2): 330–335.
^ref-stefanopoulou2014

Steffen, Will, Katherine Richardson, Johan Rockström, et al. 2015. “Planetary Boundaries: Guiding Human Development on a Changing Planet.” *Science* 347 (6223): 1259855.
^ref-steffen2015

Stein, Howard. 1968. “On Einstein–Minkowski Space–Time.” *The Journal of Philosophy* 65(1): 5–23.
^ref-stein1968

Stein, Howard. 1991. “On Relativity Theory and Openness of the Future.” *Philosophy of Science* 58(2): 147–167.
^ref-stein1991

Steinberg, Laurence. 2008. “A Social Neuroscience Perspective on Adolescent Risk-Taking.” Developmental Review 28: 78-106.
^ref-steinberg2008

Steiner, Mark. 1998. *The Applicability of Mathematics as a Philosophical Problem*. Cambridge, MA: Harvard University Press.
^ref-steiner1998

Steinhardt, Paul J., and Neil Turok. 2007. *Endless Universe: Beyond the Big Bang*. New York: Doubleday.
^ref-steinhardtTurok2007

Stenger, Victor J. 2011. *The Fallacy of Fine-Tuning: Why the Universe Is Not Designed for Us*. Amherst, NY: Prometheus Books.
^ref-stenger2011

Stephens, David W., and John R. Krebs. 1986. *Foraging Theory*. Princeton University Press.
^ref-stephensKrebs1986

Sterelny, K. 2003. *Thought in a Hostile World: The Evolution of Human Cognition*. Oxford: Blackwell.
^ref-sterelny2003

Sterling, Peter. 2012. “Allostasis: A Model of Predictive Regulation.” Physiology and Behavior 106 (1): 5-15.
^ref-sterling2012

Stern, Nicholas. 2007. *The Economics of Climate Change: The Stern Review*. Cambridge University Press.
^ref-stern2007

Stern, Josef. 2013. *The Matter and Form of Maimonides' Guide*. Cambridge, MA: Harvard University Press.
^ref-stern2013

Stern, Nicholas. 2015. *Why Are We Waiting? The Logic, Urgency, and Promise of Tackling Climate Change*. MIT Press.
^ref-stern2015

Stevenson, Bryan. 2014. *Just Mercy: A Story of Justice and Redemption*. Spiegel & Grau.
^ref-stevenson2014

Stewart-Williams, Steve, and Andrew G. Thomas. 2013. “The Ape That Thought It Was a Peacock: Does Evolutionary Psychology Exaggerate Human Sex Differences?” Psychological Inquiry 24 (3): 137-168.
^ref-stewartWilliamsThomas2013

Stiglitz, Joseph E. 2012. *The Price of Inequality: How Today's Divided Society Endangers Our Future*. W. W. Norton & Company.
^ref-stiglitz2012

Stock, Kathleen. 2021. *Material Girls: Why Reality Matters for Feminism*. Fleet.
^ref-stock2021

Stoljar, Daniel. 2001. “Two Conceptions of the Physical.” *Philosophy and Phenomenological Research* 62(2): 253–281.
^ref-stoljar2001

Stoljar, Daniel. 2006. *Ignorance and Imagination: The Epistemic Origin of the Problem of Consciousness*. New York: Oxford University Press.
^ref-stoljar2006

Stone, Jim. 1994. “Why Potentiality Still Matters.” *Canadian Journal of Philosophy* 24(2):281–293.
^ref-stone1994

Stone, Jerome A. 2008. *Religious Naturalism Today: The Rebirth of a Forgotten Alternative*. State University of New York Press.
^ref-stone2008

Strawson, P. F. 1962. “Freedom and Resentment.”
^ref-strawson1962

Strawson, P. F. 1966. *The Bounds of Sense: An Essay on Kant's Critique of Pure Reason*. London: Methuen.
^ref-strawson1966

Strawson, Galen. 1994. *Mental Reality*. Cambridge, MA: MIT Press (Bradford Books).
^ref-strawson1994

Strawson, Galen. 1997. “The Self.” Journal of Consciousness Studies 4 (5-6): 405-428.
^ref-strawson1997

Strawson, Galen. 2006. “Realistic Monism: Why Physicalism Entails Panpsychism.” *Journal of Consciousness Studies* 13(10–11): 3–31.
^ref-strawson2006

Strawson, Galen. 2017. *The Subject of Experience*. Oxford University Press.
^ref-strawson2017

Street, Sharon. 2006. “A Darwinian Dilemma for Realist Theories of Value.”
^ref-street2006

Street, Sharon. 2012. “Coming to Terms with Contingency: Humean Constructivism about Practical Reason.”
^ref-street2012

Stroud, Barry. 1968. “Transcendental Arguments.” *Journal of Philosophy*.
^ref-stroud1968

Stump, Eleonore. 1979. “Petitionary Prayer.” *American Philosophical Quarterly*.
^ref-stump1979

Stump, Eleonore, and Norman Kretzmann. 1981. “Eternity.” *The Journal of Philosophy* 78(8): 429–458.
^ref-stumpKretzmann1981

Stump, Eleonore. 1985. “The Problem of Evil.” *Faith and Philosophy* 2, no. 4: 392–423.
^ref-stump1985

Stump, Eleonore. 2003. *Aquinas*. London: Routledge.
^ref-stump2003

Stump, Eleonore. 2010. *Wandering in Darkness: Narrative and the Problem of Suffering*. Oxford University Press.
^ref-stump2010

Stump, Eleonore. 2013. “Omnipresence, Indwelling, and the Second-Personal.” *European Journal for Philosophy of Religion* 5, no. 4: 29–53.
^ref-stump2013

Stump, Eleonore. 2016. *The God of the Bible and the God of the Philosophers*. Milwaukee: Marquette University Press.
^ref-stump2016

Stump, Eleonore. 2018. *Atonement*. Oxford: Oxford University Press (Oxford Studies in Analytic Theology).
^ref-stump2018

Suchocki, Marjorie Hewitt. 1982. *God-Christ-Church: A Practical Guide to Process Theology*. New York: Crossroad.
^ref-suchocki1982

Suchocki, Marjorie Hewitt. 1988. *The End of Evil: Process Eschatology in Historical Context*. Albany: State University of New York Press.
^ref-suchocki1988

Sullivan, Dennis, and Larry Tifft. 2001. *Restorative Justice: Healing the Foundations of Our Everyday Lives*. Willow Tree Press.
^ref-sullivanTifft2001

Supran, Geoffrey, and Naomi Oreskes. 2017. “Assessing ExxonMobil's climate change communications (1977–2014).” *Environmental Research Letters* 12(8): 084019.
^ref-supranOreskes2017

Supran, Geoffrey, and Naomi Oreskes. 2021. “Rhetoric and frame analysis of ExxonMobil's climate change communications.” *One Earth* 4(5): 696–719.
^ref-supranOreskes2021

Susskind, Leonard. 1995. “The World as a Hologram.” *Journal of Mathematical Physics* 36(11):6377–6396.
^ref-susskind1995

Susskind, Leonard. 2005. *The Cosmic Landscape: String Theory and the Illusion of Intelligent Design*. New York: Little, Brown and Company.
^ref-susskind2005

Swift, Kaeli N., and John M. Marzluff. 2015. “Wild American Crows Gather Around Their Dead to Learn About Danger.” Animal Behaviour 109: 187-197.
^ref-swift2015

Swinburne, Richard. 1970. *The Concept of Miracle*. Macmillan (London).
^ref-swinburne1970

Swinburne, Richard. 1977. *The Coherence of Theism*. Oxford: Clarendon Press.
^ref-swinburne1977

Swinburne, Richard. 1979. *The Existence of God*. Oxford: Clarendon Press.
^ref-swinburne1979

Swinburne, Richard. 1989. *Responsibility and Atonement*. Clarendon Press.
^ref-swinburne1989

Swinburne, Richard. 1994. *The Christian God*. Oxford: Clarendon Press.
^ref-swinburne1994

Swinburne, Richard. 1997. *Simplicity as Evidence of Truth*. Milwaukee: Marquette University Press.
^ref-swinburne1997

Swinburne, Richard. 1998. *Providence and the Problem of Evil*. Oxford: Clarendon Press, 1998 (pp. xiv+263; ISBN 0198237987).
^ref-swinburne1998

Swinburne, Richard. 2003. *The Resurrection of God Incarnate*. Oxford: Clarendon Press.
^ref-swinburne2003

Swinburne, Richard. 2004. *The Existence of God (2nd ed.)*. Oxford: Clarendon Press.
^ref-swinburne2004

Swinburne, Richard. 2013. *Mind, Brain and Free Will*. Oxford: Oxford University Press.
^ref-swinburne2013

Swinburne, Richard. 2016. *The Coherence of Theism (Second Edition)*. Oxford: Oxford University Press.
^ref-swinburne2016

Symons, George James. 1888. *The Eruption of Krakatoa, and Subsequent Phenomena: Report of the Krakatoa Committee of the Royal Society*. Trubner and Co., London.
^ref-symons1888

Symons, Donald. 1979. *The Evolution of Human Sexuality*. Oxford University Press.
^ref-symons1979

Szabó, Zoltán Gendler. 2022. “Compositionality.” Stanford Encyclopedia of Philosophy, Fall 2022.
^ref-szabo2022

Szasz, Thomas. 1992. *Our Right to Drugs: The Case for a Free Market*. Praeger.
^ref-szasz1992

Tagliazucchi, Enzo, Leor Roseman, Mendel Kaelen, Csaba Orban, Suresh D. Muthukumaraswamy, Kevin Murphy, Helmut Laufs, Robert Leech, John McGonigle, Nicolas Crossley, Edward Bullmore, Tim Williams, Mark Bolstridge, Amanda Feilding, David J. Nutt, and Robin Carhart-Harris. 2016. “Increased Global Functional Connectivity Correlates with LSD-Induced Ego Dissolution.” *Current Biology* 26 (8): 1043–1050.
^ref-tagliazucchi2016

Tahko, Tuomas E. 2015. *An Introduction to Metametaphysics*. Cambridge University Press.
^ref-tahko2015

Tahko, Tuomas E. 2018. “The Epistemology of Essence.” in Ontology, Modality, and Mind (Oxford University Press).
^ref-tahko2018

Tainter, Joseph A. 1988. *The Collapse of Complex Societies*. Cambridge University Press (New Studies in Archaeology).
^ref-tainter1988

Tajfel, Henri, and John C. Turner. 1979. “An Integrative Theory of Intergroup Conflict.” In The Social Psychology of Intergroup Relations, 33-47.
^ref-tajfelTurner1979

Talarico, Jennifer M., and David C. Rubin. 2003. “Confidence, Not Consistency, Characterizes Flashbulb Memories.” *Psychological Science* 14 (5): 455–461.
^ref-talaricoRubin2003

Talbott, Thomas. 1999. *The Inescapable Love of God*. Universal Publishers.
^ref-talbott1999

Tallon, Philip. 2018. “The Mozart Argument and the Argument from Play and Enjoyment: The Theistic Argument from Beauty and Play.” in Jerry L. Walls and Trent Dougherty (eds.), Two Dozen (or So) Arguments for God: The Plantinga Project (Oxford University Press).
^ref-tallon2018

Tarski, Alfred. 1929. “Foundations of the Geometry of Solids.” In Logic, Semantics, Metamathematics (Oxford: Clarendon Press, 1956), trans. J. H. Woodger.
^ref-tarski1929

Tarski, Alfred. 1959. “What is Elementary Geometry?” In L. Henkin, P. Suppes, and A. Tarski (eds.), The Axiomatic Method, Amsterdam: North-Holland.
^ref-tarski1959

Taylor, Charles. 1978. “The Validity of Transcendental Arguments.” *Proceedings of the Aristotelian Society*.
^ref-taylor1978

Taylor, Charles. 1989. *Sources of the Self: The Making of Modern Identity*. Harvard University Press.
^ref-taylor1989

Taylor, Alex H., Gavin R. Hunt, Felipe S. Medina, and Russell D. Gray. 2009. “Do New Caledonian Crows Solve Physical Problems Through Causal Reasoning?” *Proceedings of the Royal Society B* 276 (1655): 247–254.
^ref-taylorHuntGray2009

Tegmark, Max. 2008. “The Mathematical Universe.” *Foundations of Physics* 38(2): 101–150.
^ref-tegmark2008

Tegmark, M. 2014. *Our Mathematical Universe: My Quest for the Ultimate Nature of Reality*. New York: Knopf.
^ref-tegmark2014

Tello-Ramos, Maria C.; Harper, Lucy; Tortora-Brayda, Isabella; Guillette, Lauren M.; Capilla-Lasheras, Pablo; Harrison, Xavier A.; Young, Andrew J.; Healy, Susan D. 2024. “Architectural Traditions in the Structures Built by Cooperative Weaver Birds.” Science 385 (6712): 1004-1009.
^ref-telloRamosEtAl2024

Tenenbaum, Joshua B., Charles Kemp, Thomas L. Griffiths, and Noah D. Goodman. 2011. “How to Grow a Mind: Statistics, Structure, and Abstraction.” Science 331 (6022): 1279-1285.
^ref-tenenbaum2011

Tennant, Frederick Robert. 1930. *Philosophical Theology, Volume II: The World, the Soul, and God*. Cambridge University Press.
^ref-tennant1930

Tetlock, Philip E., and Dan Gardner. 2015. *Superforecasting: The Art and Science of Prediction*. Crown Publishers.
^ref-tetlockGardner2015

Thomas, Frédéric, Andreas Schmidt-Rhaesa, Géraldine Martin, Charly Manu, Pierre Durand, and François Renaud. 2002. “Do Hairworms (Nematomorpha) Manipulate the Water Seeking Behaviour of Their Terrestrial Hosts?” *Journal of Evolutionary Biology* 15 (3): 356–361.
^ref-thomas2002

Thomasson, Amie L. 2015. *Ontology Made Easy*. New York: Oxford University Press.
^ref-thomasson2015

Thomasson, Amie L. 2020. *Norms and Necessity*. New York: Oxford University Press.
^ref-thomasson2020

Thompson, Evan. 2007. *Mind in Life: Biology, Phenomenology, and the Sciences of Mind*. Harvard University Press.
^ref-thompsonE2007

Thompson, Michael. 2008. *Life and Action: Elementary Structures of Practice and Practical Thought*. Harvard University Press.
^ref-thompsonM2008

Thomson, Judith Jarvis. 1971. “A Defense of Abortion.” *Philosophy & Public Affairs* 1 (1): 47–66.
^ref-thomson1971

Tolman, Richard C. 1934. *Relativity, Thermodynamics and Cosmology*. Oxford: Clarendon Press.
^ref-tolman1934

Tolstoy, Leo. (1893) 1894. *The Kingdom of God Is Within You*. William Heinemann.
^ref-tolstoy1894

Tolstoy, Leo. 1898. *What Is Art?* The Brotherhood Publishing Company.
^ref-tolstoy1898

Tomasello, Michael. 1999. *The Cultural Origins of Human Cognition*. Harvard University Press.
^ref-tomasello1999

Tomasello, Michael. 2003. *Constructing a Language: A Usage-Based Theory of Language Acquisition*. Harvard University Press.
^ref-tomasello2003

Tomaszewski, Christopher. 2019. “Collapsing the Modal Collapse Argument: On an Invalid Argument Against Divine Simplicity.” *Analysis* 79(2): 275–284.
^ref-tomaszewski2019

Tomkins, Silvan S. 1962. *Affect Imagery Consciousness: Volume I, The Positive Affects*. Springer (New York).
^ref-tomkins1962

Tooby, John, and Leda Cosmides. 1990. “The Past Explains the Present: Emotional Adaptations and the Structure of Ancestral Environments.”
^ref-toobyCosmides1990

Tooley, Michael. 1972. “Abortion and Infanticide.” *Philosophy & Public Affairs* 2 (1): 37–65.
^ref-tooley1972

Tooley, M. 1977. “The Nature of Laws.” *Canadian Journal of Philosophy* 7 (4): 667–698.
^ref-tooley1977

Tooley, Michael. 1997. *Time, Tense, and Causation*. Oxford: Clarendon Press.
^ref-tooley1997

Trewavas, Anthony. 2003. “Aspects of Plant Intelligence.” *Annals of Botany* 92(1): 1–20.
^ref-trewavas2003

Trible, Phyllis. 1978. *God and the Rhetoric of Sexuality*. Fortress Press.
^ref-trible1978

Trivers, Robert L. 1971. “The Evolution of Reciprocal Altruism.” Quarterly Review of Biology 46 (1): 35-57.
^ref-trivers1971

Trivers, Robert L. 1972. “Parental Investment and Sexual Selection.” In Sexual Selection and the Descent of Man, 1871-1971, 136-179.
^ref-trivers1972

Tronto, Joan C. 1993. *Moral Boundaries: A Political Argument for an Ethic of Care*. Routledge.
^ref-tronto1993

Tsemberis, Sam. 2010. *Housing First: The Pathways Model to End Homelessness for People with Mental Illness and Addiction*. Hazelden.
^ref-tsemberis2010

Tufekci, Zeynep. 2017. *Twitter and Tear Gas: The Power and Fragility of Networked Protest*. Yale University Press.
^ref-tufekci2017

Turner, Denys. 1995. *The Darkness of God: Negativity in Christian Mysticism*. Cambridge: Cambridge University Press.
^ref-turner1995

Turretin, Francis. (1679–1685) 1992–1997. *Institutes of Elenctic Theology*. Phillipsburg, NJ: P&R Publishing.
^ref-turretin1679

Tushnet, Mark V. 2007. *Out of Range: Why the Constitution Can't End the Battle over Guns*. Oxford: Oxford University Press.
^ref-tushnet2007

Tutu, Desmond. 1999. *No Future Without Forgiveness*. Doubleday.
^ref-tutu1999

Tversky, Amos, and Daniel Kahneman. 1974. “Judgment under Uncertainty: Heuristics and Biases.” *Science* 185(4157): 1124–1131.
^ref-tversky1974

Tversky, Amos, and Daniel Kahneman. 1992. “Advances in Prospect Theory: Cumulative Representation of Uncertainty.” *Journal of Risk and Uncertainty* 5 (4): 297–323.
^ref-tverskyKahneman1992

Tye, Michael. 1995. *Ten Problems of Consciousness: A Representational Theory of the Phenomenal Mind*. MIT Press.
^ref-tye1995

Tye, Michael. 2008. “The Experience of Emotion: An Intentionalist Theory.” *Revue Internationale de Philosophie* 62 (1): 25–50.
^ref-tye2008

Tye, Michael. 2009. *Consciousness Revisited: Materialism Without Phenomenal Concepts*. Cambridge, MA: MIT Press.
^ref-tye2009

Tyler, Tom R. 1990. *Why People Obey the Law*. Yale University Press.
^ref-tyler1990

Umoja, Akinyele Omowale. 2013. *We Will Shoot Back: Armed Resistance in the Mississippi Freedom Movement*. New York: New York University Press.
^ref-umoja2013

Unger, Roberto Mangabeira, and Lee Smolin. 2014. *The Singular Universe and the Reality of Time*. Cambridge University Press.
^ref-ungerSmolin2014

United Nations General Assembly. 1948. “Universal Declaration of Human Rights.” UN Resolution 217 A (III), December 10, 1948.
^ref-unitedNationsGeneralAssembly1948

United Nations General Assembly. 1966. “International Covenant on Economic, Social and Cultural Rights.” UN Resolution 2200A (XXI), December 16, 1966.
^ref-unitedNationsGeneralAssembly1966

Vaidya, Anand Jayprakash, and Michael Wallner. 2021. “The epistemology of modality and the problem of modal epistemic friction.” *Synthese* 198 (Suppl. 8): 1909–1935.
^ref-vaidyaWallner2021

Vallentyne, Peter, and Hillel (eds.) Steiner. 2000. *Left-Libertarianism and Its Critics: The Contemporary Debate*. Palgrave Macmillan.
^ref-vallentyneSteiner2000

Van Cleve, James. 1985. “Three Versions of the Bundle Theory.” *Philosophical Studies* 47(1):95–107.
^ref-vanCleve1985

van Hamme, Carlos. 2025a. “Why Modal Logic Cannot Ground a Necessary Personal God: Structural Limits of Modal Necessity and the Failure of Necessary Existence.” PhilArchive (preprint).
^ref-vanHamme2025a

van Hamme, Carlos. 2025b. “The Necessity Dilemma: A Modal Defeater for Classical Theism.” PhilArchive (preprint).
^ref-vanHamme2025b

van Inwagen, Peter. 1977. “Ontological Arguments.” *Noûs* 11(4): 375–395.
^ref-vanInwagen1977

Van Inwagen, Peter. 1978. “The Possibility of Resurrection.” *International Journal for Philosophy of Religion* 9 (2): 114–121.
^ref-vanInwagen1978

van Inwagen, P. 1980. “Indexicality and Actuality.” *Philosophical Review* 89(3): 403–426.
^ref-vanInwagen1980

van Inwagen, Peter. 1983. *An Essay on Free Will*. Oxford: Clarendon Press.
^ref-vanInwagen1983

van Inwagen, Peter. 1986. “Two Concepts of Possible Worlds.” *Midwest Studies in Philosophy* 11: 185–213.
^ref-vanInwagen1986

Van Inwagen, Peter. 1990a. *Material Beings*. Ithaca, NY: Cornell University Press.
^ref-vanInwagen1990

van Inwagen, Peter. 1991. “The Problem of Evil, the Problem of Air, and the Problem of Silence.” *Philosophical Perspectives* 5: Philosophy of Religion (ed. J. E. Tomberlin), Ridgeview.
^ref-vanInwagen1991

van Inwagen, Peter. 1998. “Modal Epistemology.” *Philosophical Studies* 92 (1): 67-84.
^ref-vanInwagen1998

van Leeuwen, Neil, and Michiel van Elk. 2019. “Seeking the Supernatural: The Interactive Religious Experience Model.” Religion, Brain \& Behavior.
^ref-vanLeeuwenVanElk2019

van Lommel, Pim. 2010. *Consciousness Beyond Life: The Science of the Near-Death Experience*. HarperOne.
^ref-vanLommel2010

Van Norden, Bryan W. 2007. *Virtue Ethics and Consequentialism in Early Chinese Philosophy*. Cambridge University Press.
^ref-vanNorden2007

Van Parijs, Philippe. 1995. *Real Freedom for All: What (If Anything) Can Justify Capitalism?* Oxford University Press.
^ref-vanParijs1995

Van Til, Cornelius. 1955. *The Defense of the Faith*. Philadelphia: Presbyterian and Reformed Publishing Co.
^ref-vanTil1955

Varela, Francisco J., Evan Thompson, and Eleanor Rosch. 1991. *The Embodied Mind: Cognitive Science and Human Experience*. Cambridge, MA: MIT Press.
^ref-varelaThompsonRosch1991

Varela, Francisco J. 1996. “Neurophenomenology: A Methodological Remedy for the Hard Problem.” Journal of Consciousness Studies 3 (4): 330-349.
^ref-varela1996

Veening, J.-W., W. K. Smits, and O. P. Kuipers. 2008. “Bistability, Epigenetics, and Bet-Hedging in Bacteria.” *Annual Review of Microbiology* 62: 193–210.
^ref-veening2008

Velde, Rudi A. te. 1995. *Participation and Substantiality in Thomas Aquinas*. E. J. Brill (Studien und Texte zur Geistesgeschichte des Mittelalters 46).
^ref-teVelde1995

Velleman, J. David. 1992. “Against the Right to Die.” Journal of Medicine and Philosophy 17 (6): 665-681.
^ref-velleman1992

Venema, Dennis R., and Scot McKnight. 2017. *Adam and the Genome: Reading Scripture after Genetic Science*. Grand Rapids, MI: Brazos Press.
^ref-venemaMcknight2017

Versnel, H. S. 2011. *Coping with the Gods: Wayward Readings in Greek Theology*. Brill (Religions in the Graeco-Roman World, vol. 173).
^ref-versnel2011

Vetter, Barbara. 2015. *Potentiality: From Dispositions to Modality*. Oxford University Press.
^ref-vetter2015

Vilenkin, Alexander. 1982. “Creation of Universes from Nothing.” *Physics Letters B* 117(1–2):25–28.
^ref-vilenkin1982

Vilenkin, Alex. 2006. *Many Worlds in One: The Search for Other Universes*. New York: Hill and Wang.
^ref-vilenkin2006

Vitale, Alex S. 2017. *The End of Policing*. Verso.
^ref-vitale2017

Volk, Anthony A., and Jeremy A. Atkinson. 2013. “Infant and Child Death in the Human Environment of Evolutionary Adaptation.” *Evolution and Human Behavior* 34 (3): 182–192.
^ref-volkAtkinson2013

Volkow, Nora D., George F. Koob, and A. Thomas McLellan. 2016. “Neurobiologic Advances from the Brain Disease Model of Addiction.” New England Journal of Medicine 374 (4): 363-371.
^ref-volkow2016

von Frisch, Karl. 1967. *The Dance Language and Orientation of Bees*. Belknap Press of Harvard University Press.
^ref-frisch1967

von Helmholtz, Hermann. 1847. *Über die Erhaltung der Kraft: eine physikalische Abhandlung*. Berlin: G. Reimer.
^ref-helmholtz1847

Vosoughi, S., D. Roy, and S. Aral. 2018. “The Spread of True and False News Online.” *Science* 359 (6380): 1146–1151.
^ref-vosoughi2018

Vyas, Ajai, Seon-Kyung Kim, Nicholas Giacomini, John C. Boothroyd, and Robert M. Sapolsky. 2007. “Behavioral Changes Induced by Toxoplasma Infection of Rodents Are Highly Specific to Aversion of Cat Odors.” *Proceedings of the National Academy of Sciences* 104 (15): 6442–6447.
^ref-vyas2007

Vygotsky, Lev S. 1978. *Mind in Society: The Development of Higher Psychological Processes*. Harvard University Press.
^ref-vygotsky1978

Wächtershäuser, G. 1988. “Before Enzymes and Templates: Theory of Surface Metabolism.” *Microbiological Reviews* 52 (4): 452–484.
^ref-wachtershauser1988

Wald, Robert M. 1984. *General Relativity*. University of Chicago Press.
^ref-wald1984

Walker, Pete. 2013. *Complex PTSD: From Surviving to Thriving*. Azure Coyote.
^ref-walker2013

Wallace, D. 2006. “In Defence of Naïveté: The Conceptual Status of Lagrangian Quantum Field Theory.” *Synthese* 151 (1): 33–80.
^ref-wallace2006

Wallace, D. 2012. *The Emergent Multiverse: Quantum Theory according to the Everett Interpretation*. Oxford: Oxford University Press.
^ref-wallace2012

Walls, Jerry L. 1992. *Hell: The Logic of Damnation*. University of Notre Dame Press.
^ref-walls1992

Walton, Kendall L. 1990. *Mimesis as Make-Believe: On the Foundations of the Representational Arts*. Harvard University Press.
^ref-waltonKendall1990

Walton, John H. 2009. *The Lost World of Genesis One: Ancient Cosmology and the Origins Debate*. Downers Grove, IL: InterVarsity Press.
^ref-walton2009

Walzer, Michael. 1977. *Just and Unjust Wars: A Moral Argument with Historical Illustrations*. New York: Basic Books.
^ref-walzer1977

Walzer, Michael. 1983. *Spheres of Justice: A Defense of Pluralism and Equality*. Basic Books.
^ref-walzer1983

Wang, Jennifer. 2015. “The Modal Limits of Dispositionalism.” *Nous* 49 (3): 454-469.
^ref-wang2015

Ward, Colin. 1973. *Anarchy in Action*. George Allen and Unwin.
^ref-ward1973

Warren, Mary Anne. 1973. “On the Moral and Legal Status of Abortion.” *The Monist* 57(1):43–61.
^ref-warren1973

Watson, Gary. 1975. “Free Agency.” *Journal of Philosophy* 72 (8): 205–220.
^ref-watson1975

Webb, William J. 2001. *Slaves, Women & Homosexuals: Exploring the Hermeneutics of Cultural Analysis*. InterVarsity Press.
^ref-webb2001

Webster, John. 2003. *Holiness*. SCM Press (London) / Eerdmans (Grand Rapids).
^ref-webster2003

Webster, John. 2004. *Karl Barth*. London: Continuum.
^ref-webster2004

Weinandy, Thomas G. 2000. *Does God Suffer?* University of Notre Dame Press.
^ref-weinandy2000

Weinberg, Steven. 1979. “Baryon- and Lepton-Nonconserving Processes.” *Physical Review Letters* 43: 1566–1570.
^ref-weinberg1979

Weinberg, Steven. 1987. “Anthropic Bound on the Cosmological Constant.” *Physical Review Letters* 59(22):2607–2610.
^ref-weinberg1987

Weinberg, Steven. 1989. “The Cosmological Constant Problem.” *Reviews of Modern Physics* 61(1):1–23.
^ref-weinberg1989

Weinberg, S. 1995. *The Quantum Theory of Fields*. Vol. 1. Cambridge: Cambridge University Press.
^ref-weinberg1995

Weinfeld, Moshe. 1995. *Social Justice in Ancient Israel and in the Ancient Near East*. Fortress Press / Magnes Press.
^ref-weinfeld1995

Weiss, M. C., F. L. Sousa, N. Mrnjavac, S. Neukirchen, M. Roettger, S. Nelson-Sathi, and W. F. Martin. 2016. “The Physiology and Habitat of the Last Universal Common Ancestor.” *Nature Microbiology* 1 (9): 16116.
^ref-weiss2016

Wells, Ida B. 1892. *Southern Horrors: Lynch Law in All Its Phases*. New York: New York Age Print.
^ref-wells1892

Welty, Greg. 2014. “Theistic Conceptual Realism.” In Paul M. Gould (ed.), Beyond the Control of God? Six Views on the Problem of God and Abstract Objects (New York: Bloomsbury Academic, 2014), pp. 81–96.
^ref-welty2014

Westerhoff, Jan. 2009. *Nāgārjuna's Madhyamaka: A Philosophical Introduction*. New York: Oxford University Press.
^ref-westerhoff2009

Westphal, Merold. 2001. *Overcoming Onto-Theology: Toward a Postmodern Christian Faith*. New York: Fordham University Press.
^ref-westphal2001

Wheeler, J. A. 1990. “Information, Physics, Quantum: The Search for Links.” In Complexity, Entropy, and the Physics of Information, edited by W. H. Zurek, 3–28. Redwood City, CA: Addison-Wesley.
^ref-wheeler1990

White, Thomas Joseph. 2016. “Divine Simplicity and the Holy Trinity.” *International Journal of Systematic Theology* 18, no. 1: 66–93.
^ref-white2016

White, Randall, and Gerhard et al. Bosinski. 2020. “Still No Archaeological Evidence That Neanderthals Created Iberian Cave Art.” Journal of Human Evolution 144: 102640.
^ref-white2020

Whitehead, Alfred North, and Bertrand Russell. 1910–1913. *Principia Mathematica*. Cambridge: Cambridge University Press (3 vols.).
^ref-russellWhitehead1910

Whitehead, A. N. 1929. *Process and Reality*. New York: Macmillan.
^ref-whitehead1929

Whyte, Kyle Powys. 2018. “Settler Colonialism, Ecology, and Environmental Injustice.” *Environment and Society* 9 (1): 125–144.
^ref-whyte2018

Widerker, David, and Michael (eds.) McKenna. 2003. *Moral Responsibility and Alternative Possibilities: Essays on the Importance of Alternative Possibilities*. Routledge.
^ref-widerkerMcKenna2003

Wielenberg, Erik J. 2014. *Robust Ethics: The Metaphysics and Epistemology of Godless Normative Realism*. Oxford University Press.
^ref-wielenberg2014

Wierenga, Edward R. 1989. *The Nature of God: An Inquiry into Divine Attributes*. Ithaca, NY: Cornell University Press.
^ref-wierenga1989

Wiggins, David. 1980. *Sameness and Substance*. Oxford: Blackwell.
^ref-wiggins1980

Wiggins, David. 2001. *Sameness and Substance Renewed*. Cambridge: Cambridge University Press.
^ref-wiggins2001

Wigner, E. P. 1939. “On Unitary Representations of the Inhomogeneous Lorentz Group.” *Annals of Mathematics* 40 (1): 149–204.
^ref-wigner1939

Wigner, Eugene P. 1960. “The Unreasonable Effectiveness of Mathematics in the Natural Sciences.” *Communications on Pure and Applied Mathematics*.
^ref-wigner1960

Wilkinson, Richard, and Kate Pickett. 2009. *The Spirit Level: Why More Equal Societies Almost Always Do Better*. Allen Lane.
^ref-wilkinsonPickett2009

Williams, Donald C. 1951. “The Myth of Passage.” *The Journal of Philosophy* 48(15): 457–472.
^ref-williams1951

Williams, Donald C. 1953. “On the Elements of Being: I and II.” *The Review of Metaphysics* 7(1): 3–18 and 7(2): 171–192.
^ref-williams1953

Williams, George C. 1957. “Pleiotropy, Natural Selection, and the Evolution of Senescence.” Evolution 11 (4): 398-411.
^ref-williams1957

Williams, Robert F. 1962. *Negroes with Guns*. New York: Marzani & Munsell.
^ref-williams1962a

Williams, Bernard. 1970. “The Self and the Future.” *Philosophical Review* 79 (2): 161–180.
^ref-williams1970

Williams, Bernard. 1973a. “Deciding to Believe.” In Problems of the Self: Philosophical Papers 1956–1972 (pp. 136–151). Cambridge University Press.
^ref-williams1973

Williams, Bernard. 1973b. “The Makropulos Case: Reflections on the Tedium of Immortality.” In Problems of the Self: Philosophical Papers 1956–1972 (pp. 82–100). Cambridge University Press.
^ref-williams1973b

Williams, Bernard. 1981. *Moral Luck: Philosophical Papers 1973–1980*. Cambridge: Cambridge University Press.
^ref-williams1981

Williams, Bernard. 1985. *Ethics and the Limits of Philosophy*. Cambridge, MA: Harvard University Press.
^ref-williams1985

Williams, Bernard. 2002. *Truth and Truthfulness: An Essay in Genealogy*. Princeton University Press.
^ref-williamsB2002

Williams, Thomas. 2005. “The Doctrine of Univocity is True and Salutary.” *Modern Theology* 21, no. 4: 575–585.
^ref-williams2005

Williamson, Timothy. 1994. *Vagueness*. London: Routledge.
^ref-williamson1994

Williamson, Timothy. 2000. *Knowledge and Its Limits*. Oxford University Press.
^ref-williamson2000

Williamson, Timothy. 2007. *The Philosophy of Philosophy*. Blackwell.
^ref-williamson2007

Williamson, Timothy. 2013. *Modal Logic as Metaphysics*. Oxford: Oxford University Press.
^ref-williamson2013

Williamson, Timothy. 2017. “Semantic Paradoxes and Abductive Methodology.” In B. Armour-Garb (ed.), Reflections on the Liar, Oxford: Oxford University Press, pp. 325–346.
^ref-williamson2017

Wilson, Edward O. 1975. *Sociobiology: The New Synthesis*. Harvard University Press.
^ref-wilson1975

Wilson, James Q., and George L. Kelling. 1982. “Broken Windows: The Police and Neighborhood Safety.” *The Atlantic Monthly*.
^ref-wilsonkelling1982

Wimsatt, William C. 1976. “Reductionism, Levels of Organization, and the Mind-Body Problem.” In G. Globus, G. Maxwell, and I. Savodnik (eds.), Consciousness and the Brain, New York: Plenum Press.
^ref-wimsatt1976

Winner, Langdon. 1977. *Autonomous Technology: Technics-out-of-Control as a Theme in Political Thought*. MIT Press.
^ref-winner1977

Wippel, John F. 2000. *The Metaphysical Thought of Thomas Aquinas: From Finite Being to Uncreated Being*. Catholic University of America Press.
^ref-wippel2000

Wittgenstein, Ludwig. (1921) 1961. *Tractatus Logico-Philosophicus*. Translated by D. F. Pears and B. F. McGuinness. London: Routledge.
^ref-wittgenstein1921

Wittgenstein, Ludwig. 1953. *Philosophical Investigations*. Oxford: Blackwell (trans. G. E. M. Anscombe).
^ref-wittgenstein1953

Wochner, A., J. Attwater, A. Coulson, and P. Holliger. 2011. “Ribozyme-Catalyzed Transcription of an Active Ribozyme.” *Science* 332 (6026): 209–212.
^ref-wochner2011

Woese, Carl R. 1998. “The Universal Ancestor.” *PNAS* 95(12):6854–6859.
^ref-woese1998

Wolf, Susan. 1982. “Moral Saints.” *Journal of Philosophy* 79(8): 419–439.
^ref-wolf1982

Wolf, Susan. 1990. *Freedom Within Reason*. Oxford University Press.
^ref-wolf1990

Wolf, Susan. 1997. “Happiness and Meaning: Two Aspects of the Good Life.” *Social Philosophy and Policy* 14(1): 207–225.
^ref-wolf1997

Wolf, Susan. 2010. *Meaning in Life and Why It Matters*. Princeton University Press.
^ref-wolf2010

Wolfram, S. 2002. *A New Kind of Science*. Champaign, IL: Wolfram Media.
^ref-wolfram2002

Wolterstorff, Nicholas. 1975. “God Everlasting.” In Clifton Orlebeke and Lewis Smedes (eds.), God and the Good: Essays in Honor of Henry Stob (Grand Rapids, MI: Eerdmans, 1975), pp. 181–203.
^ref-wolterstorff1975

Wolterstorff, Nicholas. 1991. “Divine Simplicity.” *Philosophical Perspectives* 5: 531–552.
^ref-wolterstorff1991

Wolterstorff, Nicholas. 2001. “Unqualified Divine Temporality.” In Gregory E. Ganssle (ed.), God & Time: Four Views (Downers Grove, IL: InterVarsity Press, 2001), pp. 187–213.
^ref-wolterstorff2001

Wolterstorff, Nicholas. 2015. *The God We Worship: An Exploration of Liturgical Theology*. Grand Rapids: Eerdmans.
^ref-wolterstorff2015

Wong, David B. 1984. *Moral Relativity*. University of California Press.
^ref-wong1984

Wong, David B. 2006. *Natural Moralities: A Defense of Pluralistic Relativism*. Oxford University Press.
^ref-wong2006

Woodward, James. 2003. *Making Things Happen: A Theory of Causal Explanation*. New York: Oxford University Press.
^ref-woodward2003

Woodward, Richard. 2011. “Is Modal Fictionalism Artificial?” *Pacific Philosophical Quarterly* 92(4): 535–550.
^ref-woodward2011

Worrall, John. 1989. “Structural Realism: The Best of Both Worlds?” *Dialectica* 43(1–2): 99–124.
^ref-worrall1989

Wright, Crispin. 1980. *Wittgenstein on the Foundations of Mathematics*. Harvard University Press.
^ref-wright1980

Wright, N. T. 2003. *The Resurrection of the Son of God*. Minneapolis: Fortress Press.
^ref-wright2003

Wright, David P. 2009. *Inventing God's Law: How the Covenant Code of the Bible Used and Revised the Laws of Hammurabi*. Oxford University Press.
^ref-wright2009

Wright, Erik Olin. 2010. *Envisioning Real Utopias*. Verso.
^ref-wright2010

Wright, Robert. 2017. *Why Buddhism Is True: The Science and Philosophy of Meditation and Enlightenment*. Simon & Schuster.
^ref-wright2017

Wykstra, Stephen J. 1984. “The Humean Obstacle to Evidential Arguments from Suffering: On Avoiding the Evils of “Appearance”.” *International Journal for Philosophy of Religion* 16, no. 2 (1984): 73–93.
^ref-wykstra1984

Yablo, Stephen. 1993. “Is Conceivability a Guide to Possibility?” *Philosophy and Phenomenological Research*.
^ref-yablo1993

Yandell, Keith E. 1993. *The Epistemology of Religious Experience*. Cambridge University Press.
^ref-yandell1993

Yarbro Collins, Adela. 1984. *Crisis and Catharsis: The Power of the Apocalypse*. Westminster Press.
^ref-yarbroCollins1984

Young, Iris Marion. 2000. *Inclusion and Democracy*. Oxford University Press.
^ref-young2000

Young, Davis A., and Ralph F. Stearley. 2008. *The Bible, Rocks and Time: Geological Evidence for the Age of the Earth*. IVP Academic.
^ref-youngStearley2008

Young, L. C., B. J. Zaun, and E. A. VanderWerf. 2008. “Successful Same-Sex Pairing in Laysan Albatross.” *Biology Letters* 4 (4): 323–325.
^ref-young2008

Young, Iris Marion. 2011. *Responsibility for Justice*. Oxford University Press.
^ref-young2011

Yurk, Harald; Barrett-Lennard, Lance; Ford, John K. B.; Matkin, Craig O. 2002. “Cultural Transmission within Maternal Lineages: Vocal Clans in Resident Killer Whales in Southern Alaska.” Animal Behaviour 63 (6): 1103-1119.
^ref-yurkEtAl2002

Zagzebski, Linda. 1994. “The Inescapability of Gettier Problems.” *The Philosophical Quarterly* 44(174): 65–73.
^ref-zagzebski1994

Zagzebski, Linda Trinkaus. 1996. *Virtues of the Mind: An Inquiry into the Nature of Virtue and the Ethical Foundations of Knowledge*. Cambridge: Cambridge University Press.
^ref-zagzebski1996

Zagzebski, Linda Trinkaus. 2017. *Exemplarist Moral Theory*. Oxford: Oxford University Press.
^ref-zagzebski2017

Zahavi, Dan. 2005. *Subjectivity and Selfhood: Investigating the First-Person Perspective*. MIT Press.
^ref-zahavi2005

Zatorre, Robert J., and Valorie N. Salimpoor. 2013. “From Perception to Pleasure: Music and Its Neural Substrates.” Proceedings of the National Academy of Sciences 110 (Suppl 2): 10430-10437.
^ref-zatorreSalimpoor2013

Zehr, Howard. 1990. *Changing Lenses: A New Focus for Crime and Justice*. Herald Press.
^ref-zehr1990

Zeman, Adam, Michaela Dewar, and Sergio Della Sala. 2015. “Lives without imagery — Congenital aphantasia.” *Cortex* 73: 378–380.
^ref-zeman2015

Zhang, Jiajie, and Donald A. Norman. 1994. “Representations in Distributed Cognitive Tasks.” Cognitive Science 18 (1): 87-122.
^ref-zhangNorman1994

Zhou, J.-N., M. A. Hofman, L. J. G. Gooren, and D. F. Swaab. 1995. “A Sex Difference in the Human Brain and Its Relation to Transsexuality.” *Nature* 378: 68–70.
^ref-zhou1995

Zimmerman, Dean W. 2005. “The A-Theory of Time, the B-Theory of Time, and 'Taking Tense Seriously'.” *Dialectica* 59(4):401–457.
^ref-zimmerman2005

Zuboff, Shoshana. 2019. *The Age of Surveillance Capitalism: The Fight for a Human Future at the New Frontier of Power*. PublicAffairs.
^ref-zuboff2019

Zuckerman, Phil. 2008. *Society without God: What the Least Religious Nations Can Tell Us about Contentment*. NYU Press.
^ref-zuckerman2008

Zunshine, Lisa. 2006. *Why We Read Fiction: Theory of Mind and the Novel*. Ohio State University Press.
^ref-zunshine2006

Zurek, W. H. 2003. “Decoherence, Einselection, and the Quantum Origins of the Classical.” *Reviews of Modern Physics* 75 (3): 715–775.
^ref-zurek2003


---

← [Notes](Notes.md) | [Index](Index.md) →
