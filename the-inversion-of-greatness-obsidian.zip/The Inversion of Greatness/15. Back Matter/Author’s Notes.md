## On the Anonymity

Why no name behind the book?

The first reason is principled: an argument should stand or fall on its own merits, not the name or credentials behind it. Blind reviews are blind for a reason.

The second is personal: the work that went into this absorbed most of my waking hours for a sustained stretch. It took time away from earnings, loved ones, and enjoyment. What I’d love—more than anything—is to regain what was lost in the process. I need a break, and privacy protects that. Whether a name is eventually released isn’t a decision I’m ready to make, and it’s a decision that can only be made once. There’s no putting the toothpaste back in the tube, so to speak.

In any event, the work here is presented in the name of contribution, not recognition.


---

← [Appendix F: Formal Results](../14.%20Appendices/Appendix%20F%20-%20Formal%20Results.md) | [ On the Use of AI](On%20the%20Use%20of%20AI.md) →
