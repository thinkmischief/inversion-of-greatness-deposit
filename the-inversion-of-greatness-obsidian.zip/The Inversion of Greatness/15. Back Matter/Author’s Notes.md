


---

← [Appendix F: Formal Results](../14.%20Appendices/Appendix%20F%20-%20Formal%20Results.md) | [ On the Name](On%20the%20Name.md) →
