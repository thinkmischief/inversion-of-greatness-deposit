The lack of names here isn’t a lack of gratitude—it’s a lack of engagement. The gratitude is waiting for those who help shape the book.

That said, one debt is worth naming up front, and one misunderstanding worth correcting with it. The name says *deficit of attention*. From the inside ADHD runs the inverse: attention that takes hold with such unnoticed force that the deficit is everything exterior. What’s interior is anything but. When a problem takes hold, it holds with a thoroughness unchosen. One connection leads to another, paths exhausted in the wake. That focus comes at a price: the sandwich never made, the forgotten occasion, the added patience any relationship asks for, and stretches where the hold was plainly unhealthy. That same hold is also why this book exists. To those who bore the weight of that hold in different ways, and supported me regardless, thank you.

The largest debt can’t be itemized. This argument wasn’t built in a vacuum. It depends on centuries of physics, logic, and philosophy. Whatever is new here lies in the connections, and connections require points of contact. Those points were made available by people asking questions for their own reasons, across generations. Without that inheritance, there would be nothing for an argument like this to connect—and none of this would be here. To everyone who has ever asked *why* and refused to settle for *because*, thank you.


---

← [Conclusion](../13.%20Conclusion/Conclusion.md) | [Appendix A: Modal Logic Primer](../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md) →
