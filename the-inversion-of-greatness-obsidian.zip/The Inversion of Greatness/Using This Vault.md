# The Inversion of Greatness

**Version:** Pre-release v0.1.3.

This is an Obsidian vault. It's the whole book — chapters, margin notes,
footnotes, references, and a Reference/ folder of every named result.

**To open it:** install Obsidian (free, obsidian.md), choose *Open folder as
vault*, and pick this folder. The included settings render the callout boxes and
margin notes the way the book uses them.

You can also just read the .md files in any text editor. They're plain markdown;
you'll lose the links and the boxes, nothing else.

Start at Home.md.

Free to share and adapt, non-commercially, with attribution (CC BY-NC 4.0). The
current version is always at inversionofgreatness.org.
