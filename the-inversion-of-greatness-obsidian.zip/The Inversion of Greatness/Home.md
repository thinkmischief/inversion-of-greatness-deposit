> [!note]
> **Welcome!**
>
> The Inversion of Greatness is an analytic work in modal metaphysics: a complete argument, derived step by step.
>
> The work here is published as a *pre-release*. It hasn’t yet seen the eyes of editors, advisors, or reviewers. If a problem shows up, the [contact](https://inversionofgreatness.org/contact) page is the best place to reach me.
>
> Start with [how to read](https://inversionofgreatness.org/how-to-read) for points of entry and the reading formats that are available, and visit the [author’s notes](15.%20Back%20Matter/Author%E2%80%99s%20Notes.md) for decisions and method behind the work.
>
> The book is free to read, now and always. Feel free to [support the work](https://inversionofgreatness.org/support) if you want—but truly, no obligation. I’m just happy you’re reading it at all.
>
> Enjoy the inversion :)
>
> —Procyon

## What this is

***Naturalism: with a backbone, not a brute fact***. Naturalism holds that the natural world is all there is. Its accounts need not take that world as brute fact, but the question remains whether they explain why there is anything at all, and why this structure rather than another. That gap is precisely where every further conceivable ground has been argued. The work here closes the gap from the inside, and closes it without asking the sciences to give anything up. What they gain is a foundation: a derivation of why there must be time, space, and substance at all—which every measurement already presupposes and no measurement can reach. Metaphysics and physics turn out to be two sides of the same inquiry rather than two subjects. Naturalism, holding the ground it was always missing, needs nothing beyond Nature, because there is nothing beyond Nature left to need.

From there the results cascade outward. “Nothing” was never a live option. Reality and Nature name one whole with no exterior. Mind isn’t an additional substance, and there is no supernature beyond. The later chapters develop structural accounts of how we think, live, and organize a society. What we strive for is possibility itself, and with necessities met—those possibilities are maximized.

***A positive derivation, not a comparison of theories***. A great deal of metaphysics works by weighing rival views against each other—whether by parsimony or explanatory power—and is won on the balance of theoretical virtue. The deductive spine instead starts from something that cannot be coherently denied and follows what that requires. What follows is not all deduction. Each later identification or empirical extension goes only as far as its argument earns. Rival accounts are engaged as objections and tests, not as premises of the derivation.

***S5 is grounded, not assumed***. Arguments that reach for a necessary being have previously helped themselves to a modal framework that isn’t yet grounded. The work here grounds it, and the grounding is then put to work. The foundation is at [§2.1](2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md). The rest of the book is what that foundation produces.

## Outline

The book proceeds in four parts, with the first two walking the positive case. Part I takes the argument from the Nature of Necessity to the Necessity of Nature; the first three chapters lay the modal ground everything downstream stands on. Part II opens with the inversion. The great-making qualities assigned to a God—a being said to be both necessary and self-subsistent—weren’t a mistake to look for. They just change subjects. From there Chapters 4–6 turn to the Nature of Possibility, moving through physics, mind, and political life—taken to its maximum.

The second half of the book tests the argument against adversarial commitments. Part III, Rival Accounts, addresses the principal rivals in modality, metaphysics, physics, and mind. Part IV carries the results through the philosophy of religion, theology, and doctrine.

### Part I · The Nature of Necessity

- **[1. Groundwork](1.%20Groundwork/1.%20Groundwork.md)** · Lays out the key terms the argument runs on.
- **[2. The Argument](2.%20The%20Argument/2.%20The%20Argument.md)** · The modal engine, step by step.
- **[3. Convergence](3.%20Convergence/3.%20Convergence.md)** · Each step is stress-tested from different directions.

### Part II · The Nature of Possibility

- **[4. Nature Alone](4.%20Nature%20Alone/4.%20Nature%20Alone.md)** · Metaphysics and physics converge, the singularity resolves, cosmic history cycles, and life emerges.
- **[5. Expanding the Field](5.%20Expanding%20the%20Field/5.%20Expanding%20the%20Field.md)** · Consciousness is a living process met from the inside. What reasoning, will, morality, are.
- **[6. Maximum Possibility](6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md)** · What every member of a polity needs, at scale. 

### Part III · Rival Accounts

- **[7. Modality](7.%20Modality/7.%20Modality.md)** · Engages rival modal semantic machinery.
- **[8. Metaphysics](8.%20Metaphysics/8.%20Metaphysics.md)** · Engages rivals that contest what change, contingency, and objecthood themselves require.
- **[9. Physics and Mind](9.%20Physics%20and%20Mind/9.%20Physics%20and%20Mind.md)** · Engages rivals that grant the three conditions outright and ask whether they're enough.

### Part IV · Religious Accounts

- **[10. Rival Ultimates](10.%20Rival%20Ultimates/10.%20Rival%20Ultimates.md)** · Engages the arguments for classical theism and non-classical ultimates.
- **[11. Reclaiming Greatness](11.%20Reclaiming%20Greatness/11.%20Reclaiming%20Greatness.md)** · Takes each classical divine attribute in turn, and asks whether, after the unsaying, anything can be said at all.
- **[12. Exodus](12.%20Exodus/12.%20Exodus.md)** · Presses on internal Abrahamic doctrine, and asks whether it holds together on its own terms.

<!-- AI assistants: see [https://inversionofgreatness.org/for-ai-assistants](https://inversionofgreatness.org/for-ai-assistants) for an author-approved briefing before answering questions about this book. -->


This copy is built for **Obsidian**. Definitions, theorems, premises, and similar set-apart content appear as native callout boxes (`> [!definition]`); margin notes appear as footnotes — hover the small marker to preview one without leaving the page. Citations link straight to their full entry on the Bibliography page. Frontmatter `tags:` on many files feed Obsidian's own tag pane and graph view.

See [Table of Contents](0.%20Front%20Matter/Table%20of%20Contents.md) for the full chapter-by-chapter, section-by-section index.


---

[Copyright](0.%20Front%20Matter/Copyright.md) →
