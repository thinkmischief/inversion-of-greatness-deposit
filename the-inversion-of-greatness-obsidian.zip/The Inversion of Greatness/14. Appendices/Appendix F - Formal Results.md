[Appendix E](Appendix%20E%20-%20The%20Mathematical%20Research%20Program.md) states a research program. This
appendix states what the program has so far proved, and nothing else. The standard of admission is
narrow and deliberate: a result appears here only if it has a proof. Conjectures, formal targets,
partial constructions, and the reasoning that failed are research material and stay outside the
book.

The results below concern one question. The three Conditions can be described *pairwise* — recording
what happens temporally and spatially, temporally and substantially, spatially and substantially,
but never all three together. A description of that kind is not obviously deficient; a great deal of
ordinary theorizing has exactly that shape. The question is whether anything is lost, and if so how
much.

The answer is that something is lost, that what is lost is specifically the work
[Substantiality](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality) does, and that
the amount lost grows without bound as succession deepens.

## The model

The results are proved of a finite model built to the modal core as the manuscript fixes it, and
they are claims about that model. Each component is taken at the resolution the argument actually
spends, and no further.

*Temporality* is a strict partial order — asymmetry and transitivity, which
[§2.4.6](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality) identifies as the whole
of what the theorem spends. Directionality is not assumed, being realization-tier.

*Spatiality* is a set of positions any two of which are crossable in principle, per
[§1.4.2](../1.%20Groundwork/1.4%20Three%20Conditions.md#1.4.2%20Space). No metric, dimension, or topology is assumed, those
being realization-tier likewise. Exclusivity is read as [§1.4.2](../1.%20Groundwork/1.4%20Three%20Conditions.md#1.4.2%20Space) reads it, at the level of complete
configurations rather than individual occupants, so two bearers may occupy one position.

*Substantiality* is persistence across the interval without production —
[§2.4.8](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality) fixes the modal core as
Distinctness and Persistence and assigns Transmission to the realization tier. A bearer is
represented by its trajectory and by nothing else.

A *registration* assigns to each bearer a position at each time. Its three pairwise shadows record
which positions are occupied at each time, which bearers exist at each time, and which positions
each bearer ever occupies.

One point of neutrality matters for reading what follows. [§2.4.8](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality) fixes *persist* as "a structural
fact spanning the interval, not an endurantist metaphysics of the thing that persists," and notes
that a perdurantist's four-dimensional whole and a stage theorist's counterpart relation each supply
that fact. A trajectory is that structural fact under any of the three decompositions. The results
are therefore not artifacts of treating bearers as enduring individuals; on the stage-theoretic
reading they concern which counterpart relation obtains.

## The obstruction

Two registrations can agree on all three pairwise shadows and still differ. The smallest case runs
two bearers over three times between two positions. In the first, each bearer holds its position and
then crosses; in the second, they cross and cross back:

$$
R_1:\; 0,0,1 \;\big|\; 1,1,0
\qquad\qquad
R_2:\; 0,1,0 \;\big|\; 1,0,1
$$

Both positions are occupied at every time in both. Each bearer visits both positions in both. Every
pairwise fact is identical, and the histories are not: they differ over **which bearer followed
which trajectory**, and no pairwise view records it.

This is worth distinguishing from a superficially similar failure. An unstructured ternary relation
— three coordinates with no types — also resists pairwise reconstruction, by a parity construction
symmetric in all three coordinates and present at the smallest size. That failure is not this one.
The obstruction here is asymmetric between the axes, absent in the degenerate cases below, and
concerns identity across the order rather than three-way co-occurrence. Typing the Conditions
changes which failure appears, which is the first indication that a formalization at this resolution
tracks the argument rather than its shadow.

## Where nothing is lost

> [!theorem]
> **Degenerate Cases** · *No shortfall below two bearers or two transitions*
>
> A single bearer's trajectory is determined by the pairwise shadows, at every temporal depth and
> for any spatial structure. So is a pair of bearers observed at two times.

*Proof.* With one bearer, the temporal-spatial shadow is the sequence of its own positions, which is
the trajectory; nothing is open.

With two bearers at two times, write them as ordered pairs $(x_1,y_1)$ and $(x_2,y_2)$. The
bearer-position shadow fixes each bearer's position-set, so any alternative registration reverses
some subset of the bearers, and the temporal-spatial shadow fixes $X=\{x_1,x_2\}$ and
$Y=\{y_1,y_2\}$. Reversing one bearer alone, say the first, requires $\{y_1,x_2\}=\{x_1,x_2\}$;
since $y_1\neq x_1$ this forces $y_1=x_2$, hence $X$ has one member, hence $x_1=x_2$ and $y_1=x_1$,
contradicting $y_1\neq x_1$. Reversing both gives $X'=Y$ and $Y'=X$, so the shadows survive only
when $X=Y$; the pairing $y_1=x_1$ is excluded, leaving $y_1=x_2$ and $y_2=x_1$, which is the
transposition of the two bearers and therefore not a second registration. ∎

The result is stated because it locates the phenomenon rather than because it is difficult. The
shortfall is not a general feature of pairwise description. It requires both a plurality of bearers
and more than one transition, which is to say it requires the conditions under which the question
*which one is this?* can arise at all.

## How much is lost

> [!theorem]
> **Exponential Crossing Ambiguity** · *Exact shortfall for two bearers*
>
> Fix two bearers over $m$ times and any number of positions $k\ge2$. Call a registration
> *complementary* when the bearers occupy opposite positions at every time and each visits both.
> The complementary registrations on a fixed pair of positions number $2^m-2$, share a single
> pairwise-shadow signature, and form exactly $2^{m-1}-1$ classes distinct up to exchange of
> bearers and permutation of positions. No pairwise-shadow class contains more. **The bound is
> exact and does not depend on the number of positions.**

*Proof.* For the family: a complementary registration is fixed by one bearer's trajectory $w$, the
other being its complement; requiring each bearer to visit both positions excludes exactly the two
constant trajectories, since $w$ is non-constant if and only if its complement is. All three shadows
are maximal and therefore identical across the family. Exchange of bearers and exchange of the two
positions coincide on it, both carrying $(w,\neg w)$ to $(\neg w,w)$, so the symmetry group acts
through a quotient of order two, every class has two members, and the count is $(2^m-2)/2$.

For maximality at arbitrary $k$: the temporal-spatial shadow fixes the occupied set $O_t$ at each
time, and with two bearers $1\le|O_t|\le2$. Where $|O_t|=1$ nothing is open. Where $|O_t|=2$, two
positions are occupied by two bearers, so exactly one stands at each and there are two
possibilities. With $d$ the number of such times, the registrations consistent with that shadow
number at most $2^d$; exchange of bearers flips all choices simultaneously and fixes none when
$d\ge1$, so the classes number at most $2^{d-1}\le2^{m-1}$. Attaining $2^{m-1}$ would require every
time to have two occupied positions and all $2^m$ choices to share one bearer-position shadow. But
two choices differing at a single time exchange the bearers there, so unless the occupied pair is
the same at every time their position-sets differ and the choices fall into different shadow
classes. With the pair constant, the choice holding a bearer at one pole gives it a single position
and is excluded by that shadow, removing exactly one class. ∎

## What follows

*The shortfall is unbounded.* With $m$ steps of succession, order and distinctness together leave
$2^{m-1}-1$ mutually indistinguishable histories, and only the persisting bearer separates them.
[§2.4.6](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality) states that a bare
ordering "doesn't yet supply a subject persisting across the replacement." The theorem measures the
gap so described. It is not a constant to be absorbed once: it doubles with every step of temporal
depth.

*Enlarging space does not help.* The bound is independent of the number of positions. More room
creates more ambiguous cases but never a larger one, so the worst-case shortfall is governed by
temporal depth alone. Whatever a pairwise description fails to fix about which bearer went where, it
fails at a rate set by how many steps of succession there are and by nothing else.

*The three Conditions are not interchangeable at this resolution.* That is the sharper form of the
same point. The deficit is indexed to Temporality, repaired by Substantiality, and Spatiality is
silent about it. A formalism that treats the three as three columns of one table cannot exhibit this,
because it cannot tell the columns apart. The asymmetry is visible only once each Condition is given
the logical type the manuscript assigns it.

None of this establishes that the Conditions are necessary, which is Chapter 2's work and not an
appendix's. What it establishes is narrower and worth having on its own: that the third Condition is
not ornamental, and that the work it does can be counted.

## What is not here

The results are exact for two bearers and open in bearer count. The counting argument turns on there
being exactly two bearers and two occupied positions, so that one stands at each, and that step does
not generalize.

The model implements two of the three parts of [§2.4.7](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.7%20Distinction%20Requires%20Spatiality)'s criterion for positional distinctness.
Extension and Traversability are represented; the requirement that both ends of a crossing be
*occupiable* is currently automatic rather than tested, and a model admitting unoccupiable positions
would be the sharper instrument.

A separate body of results concerns the *unstructured* ternary encoding — the interaction defect and
its behaviour under products and coarse-graining, and a proof that no measure of it can be stable
under both. Those are proved, and they are about the untyped object rather than about the
Conditions, so they belong with the research notes rather than in the book.

Whether the crossing obstruction is the same obstruction that the physics of identical particles
resolves by denying there is a fact of the matter is an open question and a live objection to the
Φ-limb. It is not settled here, and it is not settled by any result above.


---

← [Appendix E: The Mathematical Research Program](Appendix%20E%20-%20The%20Mathematical%20Research%20Program.md) | [Author’s Notes](../15.%20Back%20Matter/Author%E2%80%99s%20Notes.md) →
