## How to read this appendix

The argument runs in modal logic: the logic of what must be, what could be, and what could not be. This appendix assumes you have never studied it. More importantly, it teaches the vocabulary in the order this book uses it.

That order is not the standard one. Many introductions begin with possible worlds and define possibility by counting across them. This one begins with the ordinary question—is this a way things can actually be?—and follows that question to Reality’s capacity. The symbols arrive only after their meaning is in hand. Possible-world semantics comes later, as one way of representing the same modal claims. It is not something a newcomer needs to learn first and then unlearn.

Part 1 teaches the book’s modal vocabulary. Part 2 explains why modal status does not vary on that account. Part 3 sets the standard possible-worlds picture beside it. Part 4 adds the two further layers the later chapters use: scope and time-indexing. Part 5 runs the central derivation in full.

## Part 1: The book’s modal vocabulary

### Why the distinction matters

Ordinary language blurs the difference between what *is* and what *must be*. "The sky is blue" and "triangles have three sides" have the same grammatical shape, but the first could have been false and the second could not. Modal logic makes that difference exact.

That is the distinction the argument needs. Its central claim is not merely that Time, Space, and Substance are present, but that Reality could not have lacked them. Before the argument can defend that claim, the words *possible*, *impossible*, *necessary*, *contingent*, and *actual* each need one stable meaning.

### Five senses of “possible”

One word carries several questions, and the argument needs only the first. Take one case and run it through all five: *is it possible that there’s a treasure chest buried somewhere in Central Park?*

**Real.** *Is it really possible?* Is a buried chest the kind of thing Reality allows? By *Reality* I mean the whole within which anything can be real at all ([§1.1](../1.%20Groundwork/1.1%20Reality.md)). Plainly, there is room for a chest, gold, burial, and discovery. Given the desire and a shovel, burying one really *is* possible. Even still, that possibility does not make any chest actual.

To say something is really possible is to say there’s a *way* for it to be the case—which is why “there’s no way” and “impossible” mean the same thing in ordinary speech. And a way isn’t only a way to get somewhere. It’s just as much a way to become something, or to be something at all. The possibility of burying a chest being necessary doesn’t mean the actuality of a buried chest is necessary. One is a standing permission; the other is a particular fact about the world.

**Epistemic.** Is there actually a chest buried there? As long as the evidence hasn’t ruled one out, the question stays open—not because Reality is undecided, but because we are. This sense tracks the limits of our knowledge, and it shifts the moment somebody digs.

**Conceptual.** Is possibility a matter of what can be coherently specified? Start with the easy case: a chest both full and empty in the same respect at the same moment. The predicates cancel one another, and no state of the chest gets specified, the way “square circle” names no shape. That failure comes from the contradiction, not from any limit on anyone’s imagination.

Now push the other direction, which is the harder one. Suppose the chest refills itself with gold every time the lid closes. That’s easy enough to conceive of—no contradiction, no canceled words. But does conceiving of it mean it’s really possible? **Not necessarily. Inconceivability can expose a contradiction; conceivability doesn’t hand back a real capacity.** One chest fails outright; the other just stays open.

**Nomological.** Do the actual laws of nature permit a self-refilling chest? Familiar physics may rule one out. But a law-relative exclusion is narrower than an exclusion from Reality’s complete capacity, since different laws may themselves be really possible. Physical possibility sorts what can happen given a law-set. Real possibility asks whether that law-set, or any configuration under it, could be at all.

**Probabilistic.** If something can possibly happen, does that mean it probably will? A buried chest in Central Park is wildly unlikely, and being unlikely doesn’t make it any less possible. Possibility settles whether something is a candidate at all; real chance only sorts the candidates once they’re in, which is why nothing can be probable without first being possible. Credence is a different animal: we can be confident about something that turns out impossible, because we didn’t know its modal status. Probability measures either chance or uncertainty. It never manufactures possibility.

Evidence shifts as we learn, occasions come and go, imagination runs where it likes, laws distinguish physical ranges, and odds rise and fall. None of those changes answers the first question.

> [!note]
> **Possible, in this book.** Something is possible when it is a way Reality can be. *Possible* does not mean merely conceivable, not yet ruled out by what we know, permitted by the actual laws of nature, or likely to occur. Those distinctions can matter, but none defines the possibility the argument uses.

That matters more than any other distinction in this appendix, because the dispute the argument declines to enter is conducted largely in the conceptual register: the Anselm–Plantinga–Oppy exchange asks what can be *conceived* as possible ([§7.3.2](../7.%20Modality/7.3.2%20Modal%20Epistemology%20and%20the%20Remoteness%20Objection.md)). This argument starts elsewhere. It asks what Reality has room for, whether or not anyone can picture it.

### What the book means by real possibility

The first sense now has its subject. **Something is really possible when Reality has the capacity for it**—when Reality has room for it, when it is a way things can be. *Possibility* and *capacity* name the same global modal fact from two sides. Neither names a separate power hiding behind Reality and handing permissions out.

This is Reality’s complete capacity, not the local ability of one object or the options one situation presently makes available. A locked door can remove your opportunity to cross a room without making crossing rooms impossible. Circumstances determine which possibilities are available here and now. They do not supply the capacity within which those circumstances arise.

Take every real possibility together and you have the **modal maximum**: the whole field of what could really be. The word *maximum* does not say that every possibility happens, that incompatible possibilities happen together, or that every possibility is reachable from every local state. It says only that no further *real* possibility waits outside Reality to be added later.

### The operators

The symbols abbreviate distinctions already in hand.

- **R** names Reality.
- **Capacity(R,P)** says that Reality has the standing capacity for P to be the case.
- *The diamond (◇)* reads “possibly.” **◇P** means Capacity(R,P): Reality has room for P.
- *The box (□)* reads “necessarily.” **□P** means ¬Capacity(R,¬P): Reality has no room for P to fail.
- **¬◇P** reads “P is impossible”: Reality has no capacity for P.

Propositional logic supplies the rest: ¬ (not), ∧ (and), ∨ (or), → (if-then), and ↔ (if-and-only-if).

The box and diamond are interdefinable. Something is necessary exactly when its negation is impossible, and possible exactly when its negation is not necessary:

□P ≡ ¬◇¬P and ◇P ≡ ¬□¬P

Give either operator and the other follows. Most texts keep both because the notation is easier to read that way.

### The five statuses

With the operators fixed, the five modal statuses the book uses can be set out together. Possibility is primitive—basic, rather than defined from another status ([§1.2.1](../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.1%20Possibility)). Impossibility is its negation, and necessity and contingency divide the possible field by whether a proposition’s negation is foreclosed or left open. Actuality isn’t derived from the operators at all. It stands alongside them, tied in only by the rule that whatever is actual is thereby possible.

| Status     | Holds when                                       | Formal    |
| ---------- | ------------------------------------------------ | --------- |
| Necessary  | Reality has no capacity for its failure          | □P ≡ ¬◇¬P |
| Possible   | Reality has the capacity for it                  | ◇P        |
| Impossible | Reality has no capacity for it                   | ¬◇P ≡ □¬P |
| Contingent | Reality has room both for it and for its failure | ◇P ∧ ◇¬P  |
| Actual     | it is the case                                   | P         |

The five statuses aren’t mutually exclusive slots, and reading them that way is the first mistake to avoid.

Under the Modal Bivalence defended in the argument, the genuine partition is **necessary**, **impossible**, and **contingent**: every determinate proposition falls into exactly one of them. *The modal square* names their interdefinability. P is necessary if and only if ¬P is impossible, and contingent if and only if Reality has room both for P and for ¬P.

**Possible** isn’t a fourth category alongside those three. It is what the necessary and the contingent share. Whatever is necessary is thereby possible (□P → ◇P): if Reality has no room for P to fail, it has room for P. So “possible” and “necessary” overlap rather than exclude one another, and only “impossible” is genuinely exclusive with “possible.”

**Actual** is orthogonal to the partition rather than a further member of it. It records what is the case, not the breadth of Reality’s capacity, and it can accompany either a necessary or a contingent status. Whatever is actual is thereby possible (P → ◇P): if P obtains, Reality plainly has room for it. Neither converse holds.

> [!note]
> **Quick check.** A particular coin toss landed heads. That fact is actual and contingent: it happened, and Reality had room for it to go otherwise. Tails was possible without being actual. That 2 + 2 = 5 is impossible. That every triangle has three sides is necessary. If those four verdicts are clear, the vocabulary the argument needs is in hand.

**The modal fallacy.** A common misconception is the slide from *actual* to *necessary*—from “this is the case” to “this had to be the case.” Whatever is carrying these words to you—ink, pixels, a charge held in a screen—is actual and contingent; it could have been otherwise. That each of its atoms is identical to itself is necessary. Confusing the two flattens contingency into necessity, and it’s a standing hazard in modal reasoning. (It’s distinct from the *modal-collapse* worry of [§8.2.5](../8.%20Metaphysics/8.2.5%20The%20Modal%20Collapse%20Objection.md), which presses the converse: that S5 over-tightens necessity into actuality.)

One impossibility matters most for the argument: **∅**, the proposed total absence of structural and truth-evaluable standing. It counts as impossible not because it is unlikely, and not because no listed world happens to contain it, but because it cannot qualify as a real alternative or evaluation point at all ([§2.7.2](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.2%20Incoherence%20of%20%E2%88%85)). The *Reality–Nature Identity* ([§2.8](../2.%20The%20Argument/2.8%20Reality%E2%80%93Nature%20Identity.md)) separately excludes a second modal domain. The role-relative *Exclusivity of Nature* theorem ([§2.9.7](../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.7%20Exclusivity%20of%20Nature)) tests rival grounds of concrete change-realization.

### Necessity comes in kinds

The same box □ can express different claims depending on the kind of failure being excluded. Four kinds are worth separating, and only three do work here.

*Logical necessity* rules out failure by logic alone: the truths of logic and mathematics. *Metaphysical necessity* rules out failure from Reality’s complete capacity, whether or not logic alone settles it: that water is H₂O Kripke, *Naming and Necessity* [[Bibliography#^ref-kripke1980|(1980)]], for example, if water and H₂O are one thing rather than two things that happen always to travel together. *Physical (nomological) necessity* rules out failure given the actual laws of nature, and is weaker than metaphysical necessity. *Epistemic necessity* concerns what must be so given what is known. It is a fact about knowers and plays no role here.

It helps to watch one claim slide across the kinds. *Nothing travels faster than light* is physically necessary if the actual laws prohibit it. It is not thereby metaphysically necessary, since different laws may be genuinely possible. *Water is H₂O* is metaphysically necessary without being logically necessary: if the identity holds, Reality has no room for water to fail to be H₂O, yet logic alone does not establish the identity.

The kinds nest. Every logical necessity is a metaphysical one, and every metaphysical necessity a physical one—but not conversely. So *logically necessary* is the strongest verdict a claim can get, and *physically necessary* the weakest of the three.

When this book writes □, it means metaphysical necessity: the *alethic* necessity of the standard literature, what the argument calls *real* necessity, and the dual of the real possibility fixed at [§1.2](../1.%20Groundwork/1.2%20Modal%20Status.md). So □(T∧S∧Φ) means neither “logic alone proves T∧S∧Φ” nor “the actual laws happen to require it.” It means Reality has no capacity for their joint failure.

## Part 2: Why modal status does not vary

Part 1 fixed the meaning of possibility. Before setting the standard semantics beside it, one question remains: could Reality’s capacity itself vary—could something be possible from one standpoint and impossible from another?

### Two verdicts

Take any determinate proposition P. Reality has the capacity for P, or Reality lacks it: Capacity(R,P) ∨ ¬Capacity(R,P). That is **Modal Bivalence** ([§2.1.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.1%20Modal%20Bivalence)). Uncertainty about the verdict does not create a third verdict in Reality. It tells us only that we do not yet know which one holds.

The two sides matter equally. Reality’s modal structure is fixed by what it permits and what it precludes, so the result has to preserve possibility and impossibility together. The target is bilateral invariance:

(◇P → □◇P) ∧ (¬◇P → □¬◇P)

### The boundary cannot move

Begin with the negative side. Suppose P is really impossible: ¬◇P. That says no configuration in Reality’s complete admissible range contains P. Now propose an evaluation on which P is possible after all. Either that evaluation is real, in which case it already belongs to Reality’s range and shows that P was never impossible, or it is not real, in which case it is no alternative to anything. There is no exterior range from which Reality’s range can be revised.

So impossibility does not lapse: ¬◇P → □¬◇P. Possibility is the complement of that invariant exclusion. If P could pass from possible to impossible, the same boundary would have moved. So possibility does not lapse either: ◇P → □◇P. **Whatever is possible, its possibility is necessary.**

This is why S5 describes the argument’s modal logic. The argument does not select S5 because a universal accessibility relation looks intuitive. It derives the bilateral invariance of Reality’s capacity, and S5 validates the resulting operator forms.

### Local availability is not modal status

The obvious objection is that possibilities seem to come and go. About 36,000 to 11,000 years ago, the Bering land bridge made it possible to cross from Asia to America by foot. Then the ice melted, the sea rose, and that walk was gone.

Look closely at what closed. The coastlines changed, the bridge vanished, and one route became unavailable. Those changes did not make land bridges or journeys across them impossible. They changed what could be done there and then, not what Reality could admit at all.

That distinction gets us only partway. An occasion is itself one way Reality can be. Before it can make anything locally available, it must already fall within Reality’s capacity. It cannot grant the permission it needs to arise. Circumstances determine which possibilities are actual or locally reachable; they do not draw the boundary of real possibility.

### What the result establishes

The result fixes modal status. It does not make every possibility actual, make incompatible possibilities compossible, give every state a locally available successor, or prove that any particular candidate for the ground of things exists. It establishes something narrower: no candidate gets to hand out possibility as a gift, because its own eligibility to do the grounding would already have to be possible.

## Part 3: The standard picture and its debates

Only now do possible worlds enter. A *possible world* is a complete way things could have been. In the standard Kripkean presentation, modal claims are evaluated at worlds, and an accessibility relation says which worlds count as alternatives from which others. On that semantics, ◇P is true at a world when P holds at some accessible world, and □P is true when P holds at every accessible world.

That machinery is powerful, and the book uses the notation it helped standardize. But the machinery is representational here. A world depicts a configuration Reality has the capacity to admit; a relation between worlds does not create that capacity or explain why the configuration is really possible. The newcomer can therefore learn the book’s modal vocabulary without first adopting an ontology of worlds.

Three disputes run through the field. A newcomer will hear them referenced; a specialist will want to know where the argument stands. Here they are as *live questions*, with the capacity-first answer from Part 2 kept in view.

### Debate 1: Are possible worlds real?

Everyone uses possible-worlds talk. Not everyone agrees what it commits you to.

David Lewis’s *modal realism* ([§7.2.3](../7.%20Modality/7.2.3%20Modal%20Realism.md)) takes the talk at face value: other possible worlds are concrete places, as real as the actual one, just spatiotemporally disconnected from it. Most philosophers balk, and take worlds to be something less robust—maximal consistent sets of propositions, abstract representations, useful fictions. The question is whether the picture that makes modal logic so tractable describes a plurality of *places* or a way of *representing* how one reality could go.

What turns on it is ontological cost against explanatory power. Lewis’s plenitude is extravagant—an infinity of concrete worlds—and it earns its keep by analyzing modality in wholly non-modal terms: “possibly P” becomes “some world, flatly, contains P.”

The deflationary options buy modesty and face the reverse worry. If a world is just a maximal *consistent* set of propositions, consistency is itself a modal notion, so the analysis risks presupposing the very modality it meant to explain.

That dilemma is what the book’s capacity account, developed in Parts 1–2, is built to slip between.

### Debate 2: Which system is correct, and why S5?

Given the ladder K → T → S4 → S5, which system captures *metaphysical* necessity?

Each system adds a principle. In relational semantics, that principle corresponds to a constraint on accessibility. Adding constraints narrows the class of admissible frames and increases the formulas valid on every remaining frame.

| System | Characteristic schema | Frame condition | What the schema says |
| --- | --- | --- | --- |
| K | □(P → Q) → (□P → □Q) | none | Necessity distributes over implication |
| T | □P → P | reflexive | Whatever is necessary is actual |
| S4 | □P → □□P | transitive | Whatever is necessary is necessarily necessary |
| B | P → □◇P | symmetric | Whatever is actual is necessarily possible |
| S5 | ◇P → □◇P | equivalence | Whatever is possible, its possibility is necessary |

K is the base normal system. T extends K, S4 extends T, and S5 extends S4. B sits off that main chain, though S5 validates its schema too.

The case for climbing all the way to S5 rests on a single intuition: for metaphysical modality, whether something is possible or necessary isn’t itself a contingent matter. Modal status shouldn’t shift depending on which world you evaluate it from. Follow that intuition and it pushes you up each rung in turn.

Reflexivity (**T: □P → P**) is non-negotiable for a logic of how things must *be*, as opposed to what is merely known or permitted. If P is necessary, P is actually the case.

Transitivity (**S4: □P → □□P**) says a necessity isn’t a local accident. If P is necessary, that necessity is itself necessary. Deny it and you allow that something could have been necessary without having to be—strange, for a metaphysical necessity whose ground doesn’t vary.

Symmetry (**B: P → □◇P**) says whatever is actual is necessarily possible, so no world can be cut off from the ones that can reach it. Combined with transitivity it yields the *Euclidean* condition and S5’s characteristic axiom, ◇P → □◇P: if P is possible at all, it is possible from every world, so its possibility is necessary.

The word *Euclidean* is only a technical label for that relational condition. It has nothing to do with Euclidean geometry, the parallel postulate, or the shape of physical space.

Put together, these make modal status world-invariant and collapse iterated modalities (□□P ≡ □P, ◇◇P ≡ ◇P). That invariance is exactly what you want if metaphysical possibility and necessity are features of the space of possibilities as such, rather than facts that change from standpoint to standpoint. Williamson *Modal Logic as Metaphysics* [[Bibliography#^ref-williamson2013|(2013)]] presses this line, arguing S5 is the correct logic of metaphysical modality.

The honest ledger for that *standard intuition-based route*: the whole case leans on one premise, that modal status is non-contingent, and the premise is deniable. Three ways to deny it are available.

An opponent can dig in at S4, keeping necessity-of-necessity while rejecting the Euclidean axiom. Or hold outright that some possibilities are themselves contingent—that P might be reachable here yet unreachable from some other represented world. Or go further and admit *non-normal* worlds, at which the ordinary evaluation rules lapse and modal formulas are settled by stipulation. That last is the standard technical device for invalidating necessitation, and a semantic route to blocking the lift; it is engaged at [§7.3.1](../7.%20Modality/7.3.1%20Impossible%20Worlds%20and%20Relative%20Modality.md).

On a fit-based argument there is no non-question-begging way to force such an opponent up to S5.

This is precisely why the book doesn’t rest S5 on fit. Part 2 begins with the negative boundary instead: if P is really impossible, no real evaluation admits P. An alleged exception is either real, in which case it already belongs to R’s complete admissible range and P was never impossible, or unreal, in which case it can’t revise that range. Modal Bivalence fixes possibility as the complement of that invariant exclusion. The S5 forms are therefore framework results about Reality’s modal maximum, not merely a preference for a strong system.

### Debate 3: Domain constancy (the Barcan question)

When a proposition quantifies (∀x, ∃x), is the domain the same in every world, or does it vary?

*Possibilism / necessitism* holds it fixed: every individual that exists in any world exists in all of them. Williamson’s necessitism is the modern form. *Actualism / contingentism* lets the domain grow and shrink world to world.

The dispute shows up formally in the *Barcan Formula* and its converse:

Barcan Formula: ◇∃x: φ(x) → ∃x: ◇φ(x) · Converse: ∃x: ◇φ(x) → ◇∃x: φ(x)

Both are valid in S5 on constant domains and fail on variable ones, which is why they serve as the test of where a framework stands. The formulae are due to Ruth Barcan Marcus, 1946.

What turns on it is whether merely possible things must in some sense already be there. Read the Barcan formula left to right: if there could have been something that φs, then there already is something that could φ.

Constant domains keep the logic clean and validate both directions. The price is one a newcomer should feel—a fixed stock of individuals, so that a possible extra person isn’t a genuine addition to what exists but something already in the domain, merely uninstantiated. Variable domains honor the ordinary thought that different things could have existed, at the cost of messier quantifier rules and the loss of the Barcan directions.

How the book avoids paying either price is Part 4's business.

## Part 4: Two further layers

### The quantified layer: scope, and de dicto / de re

Everything so far attaches operators to whole propositions. Quantified modal logic adds ∀x (for all x) and ∃x (there exists an x), and lets them interact with □ and ◇. That raises the question of *scope*: does a necessity govern a whole proposition, or a particular thing inside it?

A de dicto necessity attaches to a proposition. *Necessarily, every finite nonempty group has an oldest member* is true: the necessity governs the whole claim. A de re necessity attaches to a thing. *Someone is such that they are necessarily the oldest member of the group* is false: no particular person has to retain that place however the membership and ages vary.

The book’s central claim is de dicto. It is necessary *that* Temporality, Spatiality, and Substantiality are instantiated, not that some particular individual necessarily bears them. Keeping the two apart is what lets the argument stay neutral on whether the same individuals exist across alternatives. That is the Barcan question, taken up only after possible-world semantics is introduced in Part 3.

### The temporal layer: propositions at times

Many of the propositions the later chapters evaluate aren’t true or false simply. They are true or false *at a time*: that a region is compressed, that a gradient is still usable, that a change occurs.

The operators themselves are unaffected. □ and ◇ still concern Reality’s capacity, never times. Their content is now a proposition already fixed to a moment or a stretch. The main text usually leaves that indexing to context rather than marking it, and two consequences are worth having in advance.

**First, the de dicto / de re distinction has a temporal analogue**—and it must not be confused with a global/local shift. *Reality necessarily retains the capacity for Change* is de dicto and true: □◇C fixes a global modal standing.

Global doesn’t mean structurally empty. The Structural Requirement identifies what that capacity consists in: before and after (T), here and there or this genuinely apart from that (S), and bearing from one state into another (Φ). Discharging the requirement against □◇C therefore yields the actual necessity of the Conditions, □(T∧S∧Φ), not merely their possible availability.

*Every state has a locally available successor* is a different claim, state-relative, and it doesn’t follow from □◇C. Still less does any particular later state necessarily obtain. No-last is reached only under the additional actual-continuation premise at [§4.6.5](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.5%20Conclusions), and even there, which future is exercised remains unsettled.

**Second, time-indexing is what lets a necessity do work without passing its own strength to the conclusion.** Take a necessary conditional whose parts are indexed to different times—□(Cmp → E), where Cmp obtains at one moment and E at a later one—and add the *actual*, contingent fact that Cmp obtains. Modus ponens yields E.

What was necessary there is the link, not either end. The conclusion inherits the contingency of the antecedent, not the necessity of the conditional. That is the schema the singularity argument runs on ([§4.6.3](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions)), and it’s why that argument isn’t an instance of the modal fallacy already noted. Nothing is inferred from *actual* to *necessary*. The inference runs from a necessary conditional together with an actual antecedent to an actual consequent.

One smaller point, easy to miss. Change isn’t something that happens at an instant; it takes a stretch. So claims about changelessness quantify over *intervals* rather than moments—*no interval of positive duration is changeless* ([§4.6.5](../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.5%20Conclusions))—and the interval form is deliberate rather than loose. An instant-by-instant version would be a different claim, and an argument that needs the one doesn’t get the other for free.

None of this bookkeeping takes a side on whether temporal passage is real or the universe is a single block laid out at once. Indexing propositions to times is available to either picture. What it records is only that some propositions differ in truth-value across a history, which both sides grant. Where the main argument does take a side in this vicinity, it does so on its own grounds rather than through the notation.

### Symbols at a glance

| Symbol | Reads |
| --- | --- |
| ¬P | not P |
| P ∧ Q | P and Q |
| P ∨ Q | P or Q |
| P → Q | if P then Q |
| P ↔ Q | P if and only if Q |
| □P | necessarily P—Reality has no capacity for ¬P |
| ◇P | possibly P—Reality has the capacity for P |
| ≡ | is equivalent to (interdefinable) |
| ∀x / ∃x | for all x / there exists an x |
| R | Reality, the one whole |
| Capacity(R,P) | Reality has the standing capacity for P |

*A note on history.* The notation and its possible-worlds reading were built up across the twentieth century. Lewis and Langford *Symbolic Logic* [[Bibliography#^ref-lewisLangford1932|(1932)]] systematized the Lewis modal systems in axiomatic form. Kripke “Semantical Analysis of Modal Logic I: Normal Modal Propositional Calculi,” [[Bibliography#^ref-kripke1963|(1963)]] supplied the relational semantics that remains standard. Hughes and Cresswell *A New Introduction to Modal Logic* [[Bibliography#^ref-hughesCresswell1996|(1996)]] is the canonical graduate text; Girle *Modal Logics and Philosophy* [[Bibliography#^ref-girle2009|(2009)]] a gentler entry.

## Part 5: Worked example of the central derivation

*Addressed to readers of the main argument. Primer-only readers can stop at Part 4.*

The argument itself is easier to say than the machinery used to defend each step. In the wording of Chapter 2, it runs:

> [!argument]
> **Necessity of Nature** · *The Cogito–S5 Pipeline*
>
> 1. **Whatever is possible, its possibility is necessary; whatever is impossible, its impossibility is necessary.** The line that separates them is fixed and invariant. (◇P → □◇P) ∧ (¬◇P → □¬◇P). (*Necessary Possibility*, [§2.1](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md))
>
> 2. **Change is possible.** Denying it performs what it denies. ◇C. ([§2.2](../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md))
>
> 3. **The possibility of Change is necessary.** Apply step 1 to Change: □◇C. ([§2.3](../2.%20The%20Argument/2.3%20Necessary%20Possibility%20of%20Change.md))
>
> 4. **The possibility of Change requires temporal, spatial, and substantial conditions.** □(◇C → (T∧S∧Φ)). (*Structural Requirement*, [§2.4](../2.%20The%20Argument/2.4%20Structural%20Requirement.md))
>
> 5. **Therefore, Reality is necessarily temporal, spatial, and substantial.** □(T∧S∧Φ). ([§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md))

The formal move from steps 3 and 4 to step 5 uses the K distribution principle introduced in Part 3 and modus ponens. That is valid bookkeeping. The argumentative weight sits in the claims the five lines state, especially step 1's account of modal invariance and step 4's Structural Requirement.

Step 2 is the only contact with actuality. Reading, doubting, and recognizing the doubt instantiate Change, so its possibility cannot be coherently denied. Step 3 applies the first principle to that fixed witness; it does not make any particular change necessary.

Step 5 establishes the joint necessity of the three Conditions. The stronger identification of those Conditions as one Nature is argued next, at [§2.6](../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md), and the identity of Reality and Nature is earned later, at [§2.8](../2.%20The%20Argument/2.8%20Reality%E2%80%93Nature%20Identity.md). The modal proof should not be made to carry those further conclusions before their own arguments arrive.

## Continue with the book

Continue with The Intuition, then read Chapters 1–3 in order. Part 5 remains here when you want to see the central derivation run in formal form.

## Further reading

For independent study, these texts form a sensible progression:

- **First independent text:** Rod Girle, *Modal Logics and Philosophy* [[Bibliography#^ref-girle2009|(2009)]], the gentlest of the works cited here.
- **Formal standard reference:** G. E. Hughes and M. J. Cresswell, *A New Introduction to Modal Logic* [[Bibliography#^ref-hughesCresswell1996|(1996)]].
- **Advanced philosophical treatment:** Timothy Williamson, *Modal Logic as Metaphysics* [[Bibliography#^ref-williamson2013|(2013)]].
- **Historical semantic turning point:** Saul Kripke, “Semantical Analysis of Modal Logic” [[Bibliography#^ref-kripke1963|(1963)]].


---

← [Acknowledgments](../15.%20Back%20Matter/Acknowledgments.md) | [Appendix B: Summary of the Formal Proof](Appendix%20B%20-%20Summary%20of%20the%20Formal%20Proof.md) →
