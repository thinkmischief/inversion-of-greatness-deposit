This appendix consolidates claims that connect the book’s structural framework with empirical inquiry. The rows differ sharply in status: some state the book’s formal framework; some are explanatory hypotheses that add substantial auxiliary assumptions; and some are ordinary empirical predictions. A scientific result can challenge an auxiliary hypothesis, an interpretation, or its application without automatically falsifying the Chapter 2 modal proof.

The classifications are therefore:

1. **Structural framework claims**: claims about the role vocabulary and the book’s modal model. They aren’t empirical predictions by themselves.

1. **Framework-guided hypotheses**: claims combining the framework with abductive, theoretical, or empirical auxiliary assumptions. Their Basis and Status columns matter decisively.

1. **Empirical predictions**: claims testable by ongoing research programs; the Status column records their standing.

The final table records positions the book treats as under pressure within its framework. It shouldn’t be read as a list of positions refuted by empirical evidence alone. This is exposed to empirical contact through its auxiliary hypotheses and identifications, but that exposure must be stated at the appropriate register.

## How evidence bears

Evidence bears differently on the three classes. A structural theorem is assessed by its derivation; observation can expose a bad application, equivocal definition, or false bridge premise without functioning as a direct laboratory test of validity. A framework-guided hypothesis earns support when it discriminates between live alternatives, not merely when it’s compatible with the data. An empirical prediction needs an operational measure, comparison, time window, relevant controls, and a stated result that would count against it.

Converging reports aren’t automatically independent evidence. Shared data, common sources, inherited models, cultural transmission, translation, sample selection, and common coding can make several apparent witnesses one evidential route. Historical and cross-cultural comparisons therefore have to separate recurrence from independence: documented borrowing can support transmissibility and uptake while weakening a claim of independent convergence. A Bayesian claim requires a stated hypothesis space, likelihoods, priors or a justified measure, and relevant selection effects; without those, the appropriate conclusion is qualitative support, tension, or underdetermination rather than a posterior probability.

Failure propagates only along the dependency actually used. Evidence against a consciousness marker bears on that marker and on conclusions that require it; it doesn’t by itself reach the Chapter 2 modal proof. Conversely, the validity of the modal proof cannot certify an empirical identification whose auxiliary bridge fails. This appendix keeps the routes visible so agreement isn’t double-counted and failure is neither quarantined nor over-propagated.

## Tier 1: Structural framework claims

*These are the formal claims the book argues at the role/modal level. They aren’t empirical predictions, and no physical observation is listed as a direct confirmation of them.*

- **The possibility of concrete change requires Temporality, Spatiality, and Substantiality.** *Source: [§2.4](../2.%20The%20Argument/2.4%20Structural%20Requirement.md) · Status: Framework theorem-premise.*
- **Temporality, Spatiality, and Substantiality are necessarily co-instantiated.** *Source: [§2.5](../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md), [§2.9.6](../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.6%20Necessity%20of%20Nature) · Status: the Necessity of Nature theorem within the book’s modal framework.*
- **At full Condition-instantiation, each Condition co-requires the other two in the same realizer through the priced succession, extension, and persistence routes.** *Source: [§2.6.2](../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.2%20Succession%E2%80%99s%20Two%20Conditions)–2.6.7 · Status: the Triconditional Cross-Entailment theorem within its stated scope.*
- **Laws divide by status: profile-constitutive invariants, effective laws, and regularities without a sufficiency proof.** *Source: [§2.11.5](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.5%20Physical%20Necessity) · Status: the Physical Invariance theorem. Nomological necessity is stated within the one modal field as □(L → Q), the antecedent marking the profile held fixed, rather than as quantification over law-varying worlds.* This is a claim about how a law’s necessity is stated and what carries it, not a prediction that any particular law is invariant. Which laws are profile-constitutive is settled by physics and proof, not by the framework.

Cosmological, physical, origin-of-life, quantum, and consciousness claims don’t belong in this tier. Each combines the framework with auxiliary assumptions and is classified below. A failure in those bridges bears on the application, not automatically on the formal spine.

## Tier 2: Framework-guided hypotheses

*These combine the framework with auxiliary legs. The Basis column marks whether that leg is abductive, interpretive, or empirical; the Status column carries evidential standing. Unless a row identifies a genuinely operational test, its final bullet is labeled “Discriminating evidence,” not “Falsifies if.” Specialist review is still required for the cosmology, origin-of-life, quantum-foundations, and consciousness rows.*

- **A stable zero-extension terminus is unavailable.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Basis: Framework-to-cosmology bridge plus interpretation of singular models · Status: Contested / specialist review required.*

  - Auxiliary assumptions: zero extension in a physical model represents absolute structural absence rather than a boundary, breakdown, or non-spatiotemporal successor regime.
  - Discriminating evidence: a mathematically controlled, empirically adequate model with a stable zero-extension state and well-defined observables would count against the application.
- **Black-hole evaporation preserves information—compatible with the framework, not predicted by it.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Basis: Physical hypothesis, not a consequence of ∅-preclusion · Status: Active theoretical support.*

  - Evidence: Page-curve and quantum-extremal-surface programs [[Bibliography#^ref-page1993|(Page 1993)]]; [[Bibliography#^ref-penington2020|(Penington 2020)]]; [[Bibliography#^ref-almheiri2020|(Almheiri et al. 2020)]].
  - Operational test: an empirically supported evaporation model yielding irrecoverable non-unitary loss, with competing recovery mechanisms excluded, would defeat this application.
- **Cosmic history has no first physical moment, given productive explanation and the contingency of any alleged first state.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md), [§2.1.3](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution), [§2.2](../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md) · Basis: Metaphysical-to-cosmological bridge · Status: Not established by the Chapter 2 theorem.*

  - Auxiliary assumptions: physical time realizes T without a boundary or emergent regime; a first moment is treated as prior changelessness rather than a boundary of the temporal manifold.
  - Discriminating evidence: a coherent, empirically adequate first-boundary or emergent-time model that doesn’t posit a prior changeless state would defeat the inference from T to past-eternity.
- **The earliest life was metabolically self-feeding rather than dependent on prior organisms.** *Domain: Origin of Life · Source: [§4.8](../4.%20Nature%20Alone/4.8%20Life.md) · Basis: Conceptual constraint on “first” plus empirical reconstruction · Status: Plausible, not structurally proven.*

  - Auxiliary assumptions: “autotrophic” is used broadly for abiotic resource capture; LUCA is an informative proxy for much earlier pre-LUCA systems.
  - Discriminating evidence: a viable origin pathway in which the first evolving system depends on a pre-existing nonliving feedstock network in a way not usefully classified as autotrophy would force revision of the label or claim.
- **The first energy-harvesting system was most likely non-photic, and chemical or redox in character.** *Domain: Origin of Life · Source: [§4.8.2](../4.%20Nature%20Alone/4.8%20Life.md#4.8.2%20The%20Requirement) · Basis: Abductive evolutionary-order claim · Status: Open.*

  - Supporting evidence: alkaline-hydrothermal-vent chemiosmosis [[Bibliography#^ref-martinRussell2007|(Martin and Russell 2007)]]; [[Bibliography#^ref-lane2015|(Lane 2015)]] and reconstructed LUCA metabolism [[Bibliography#^ref-weiss2016|(Weiss et al. 2016)]], with LUCA treated cautiously as a proxy for earlier systems.
  - Auxiliary assumptions: complex extant photosynthetic machinery is representative of all possible photic capture and no simpler prebiotic photochemistry could precede templated evolution.
  - Discriminating evidence: a demonstrated prebiotic photochemical system capable of sustaining heritable self-maintenance before complex photosystems would count against the non-photic claim; a demonstrated prebiotic energy-harvesting pathway that precedes redox-dependent self-maintenance would count against the historical-order claim.
- **Early heredity most likely coupled catalysis and template-readability, with production, energy, and information cycles co-developing.** *Domain: Origin of Life · Source: [§4.8.2](../4.%20Nature%20Alone/4.8%20Life.md#4.8.2%20The%20Requirement) · Basis: Abductive synthesis of RNA-world, metabolism-first, and chemoton programs · Status: Open.*

  - Auxiliary assumptions: extant ribozyme evidence and laboratory pathways constrain the historical route; “co-emerge” allows staged chemical precursors but denies a fully living isolated cycle.
  - Discriminating evidence: a reproducible origin pathway with long-lived evolution through separated specialized catalysts/templates or an independently living single cycle would count against the synthesis.
- **Relativistic spacetime, field mediation, conservation, and symmetry are physical realizations of the T/S/Φ roles.** *Domain: Structure of Physics · Source: [§4.5](../4.%20Nature%20Alone/4.5%20Binding%20of%20the%20Conditions.md) · Basis: Interpretive bridge from metaphysical roles to current physics · Status: Compatible with established physics, not confirmed as a unique metaphysical interpretation.*

  - Auxiliary assumptions: current relativistic/QFT structures are role-realizers rather than contingent implementations among alternatives; quantum gravity will preserve the relevant bridge.
  - Discriminating evidence: successful empirically supported physics with non-spatiotemporal fundamental structure, non-field mediation, or revised conservation would undercut one or more identifications without directly refuting the role-level theorem.
- **Cosmological history may be cyclic at the macro-scale.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Basis: Abductive family of models · Status: Speculative / contested.*

  - Supporting programs: LQG bounce at Planck density [[Bibliography#^ref-ashtekarSingh2011|(Ashtekar and Singh 2011)]]; Penrose CCC; Steinhardt–Turok ekpyrotic; Brandenberger–Peter matter bounce; Ijjas–Steinhardt new cyclic; Poplawski Einstein–Cartan torsion; Baum–Frampton phantom, retained for completeness rather than as current support, since it requires an equation-of-state parameter more negative than minus one and current supernova and baryon-acoustic-oscillation constraints run the other way.
  - Turnaround routes short of a cyclic model: a thawing scalar can carry the expansion rate through zero without phantom energy if its potential runs negative, which is unsettled [[Bibliography#^ref-scherrerSen2008|(Scherrer and Sen 2008)]]. Backreaction programs that deny a dark-energy component altogether timescape, Lane et al. [[Bibliography#^ref-laneEtAl2025|(2025)]]; Seifert et al. [[Bibliography#^ref-seifertEtAl2025|(2025)]] would remove the expansion-driven obstruction to aggregation rather than supply a bounce; their standing is contested, and the program still owes a baryon-acoustic-oscillation reduction that doesn’t assume an FLRW metric and a fit to the acoustic-peak heights in the microwave background. A turnaround is a necessary condition for a macro-cycle, not a cyclic model by itself.
  - Auxiliary assumptions: at least one bounce or cyclic model is mathematically coherent, observationally adequate, and able to address entropy accumulation and perturbation transmission.
  - Discriminating evidence: observations that exclude the viable parameter space of specified cyclic or bouncing models count against those models; eliminating one program doesn’t falsify cyclicity as a family.
- **If macro-cycles occur, some structural regularities may recur across them.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Basis: Conditional Phase Recurrence—□(K → E) where a maximal-compression phase-class K is metaphysically sufficient for entry into an expanding phase, so a later dynamically equivalent realization yields another expanding phase; the recurrence of K is itself a further physical premise · Status: Open.*

  - Auxiliary assumptions: the bounce transmits enough structure or lawlike constraint for comparable large-scale development; Modal Invariance alone doesn’t entail identical histories, stars, or observers.
  - Discriminating evidence: a successful cyclic model whose successive cycles have materially different macro-trajectories would defeat the same-trajectory application while leaving cyclicity intact.
- **No interval of positive duration is changeless, so a permanently quiescent far future is unavailable as a *stretch*.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Basis: the No Changeless Duration lemma, strict within the framework · Status: Framework-internal; not an independent empirical prediction.*

  - Auxiliary assumptions: relationalism about instants—moments are individuated by a discerning difference in the T∧S∧Φ state they index. The lemma is strict given that premise, which the book’s account of Temporality already supplies; a substantivalist individuating moments by primitive temporal haecceity declines that account upstream rather than defeating the lemma from within it.
  - What it doesn’t settle: the two horns leave the order-type question open. A dilute phase that genuinely elapses is differentiated and so not changeless; one that doesn’t elapse has zero duration and collapses to a single moment, which isn’t the infinite changeless stretch denied. Whether that single moment could stand as a bare terminus is left open—□◇C remains globally true without giving that state a locally available successor.
- **Type–token coupling is proposed as an explanatory seam rather than an artifact of incomplete physics.** *Domain: QM & Type/Token · Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md) · Basis: Interpretive / abductive · Status: Underdetermined by current physics.*

  - Relevant programs: Penrose–Diósi gravity-induced collapse Penrose [[Bibliography#^ref-penrose1989|(1989)]]; [[Bibliography#^ref-penrose1996|(1996)]]; Diósi [[Bibliography#^ref-diosi1989|(1989)]], decoherence [[Bibliography#^ref-zurek2003|(Zurek 2003)]], and consistent histories [[Bibliography#^ref-griffiths2002|(Griffiths 2002)]]; [[Bibliography#^ref-omnes1994|(Omnès 1994)]] address different parts of the measurement problem and don’t jointly confirm one metaphysical seam.
  - Discriminating evidence: a successful theory deriving determinate token outcomes from the complete physical state without an independent token-level contribution would count against this application.
- **Token outcomes aren’t pre-fixed by the preparation type on its indeterministic application.** *Domain: QM & Type/Token · Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md) · Basis: Interpretive application of the empirical distribution · Status: Open.*

  - Evidence: repeated identically specified preparations yield distributed outcomes governed by the Born rule.
  - Scope: the distribution doesn’t by itself exclude deterministic nonlocal, hidden-variable, or superdeterministic interpretations; it underdetermines whether the complete physical state fixes the token.
  - Discriminating evidence: an empirically superior theory supplying a complete token readout from the prior physical state would defeat the indeterministic application.
- **Life may be a favored attractor under sustained energy gradients and suitable chemistry.** *Domain: Origin of Life · Source: [§4.8.1](../4.%20Nature%20Alone/4.8%20Life.md#4.8.1%20The%20Dispute), [§4.8.4](../4.%20Nature%20Alone/4.8%20Life.md#4.8.4%20Confirmation) · Basis: Abductive · Status: Speculative.*

  - Supporting considerations: dissipative-structure theory [[Bibliography#^ref-schrodinger1944|(Schrödinger 1944)]]; [[Bibliography#^ref-prigogineNicolis1977|(Prigogine and Nicolis 1977)]]; [[Bibliography#^ref-england2013|(England 2013)]] and Earth’s early-emergence datum [[Bibliography#^ref-mojzsis1996|(Mojzsis et al. 1996)]]; [[Bibliography#^ref-bell2015|(Bell et al. 2015)]].
  - Scope: one inhabited planet, uncertain habitability dates, survivorship selection, and unknown transition probabilities don’t establish a general attractor law.
  - Discriminating evidence: repeated well-characterized environments with sustained gradients, suitable chemistry, and geological time but no biosignatures would lower the hypothesis’s plausibility; one null case wouldn’t by itself settle it.
- **Sustained chemical disequilibrium raises the probability of life elsewhere under the framework-guided origin hypothesis.** *Domain: Origin of Life · Source: [§4.8.4](../4.%20Nature%20Alone/4.8%20Life.md#4.8.4%20Confirmation), [§2.9.5](../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.5%20Possibility%20Precedes%20Probability) · Basis: Conditional extrapolation · Status: Open.*

  - Targets: ancient Mars, Europa, Enceladus [[Bibliography#^ref-hsu2015|(Hsu et al. 2015)]], and Titan, each with materially different uncertainties about duration, chemistry, accessibility, and preservation.
  - Scope: Modal Invariance doesn’t by itself supply the contingent chemistry or transition probability.
  - Discriminating evidence: adequate missions establishing long-lived suitable disequilibrium with strong preservation conditions but no biosignatures would count against the extrapolation in proportion to search completeness.
- **Integrated dissipative self-modeling is proposed as a marker of consciousness.** *Domain: Consciousness · Source: [§4.8](../4.%20Nature%20Alone/4.8%20Life.md), [§5.1](../5.%20Expanding%20the%20Field/5.1%20Consciousness.md) · Basis: Abductive constitutive identification · Status: Speculative research program.*

  - Auxiliary assumptions: the architecture is operationally specified independently of reports; self-modeling, integration, and dissipative maintenance jointly track phenomenal vantage rather than only cognition or control.
  - Operational tests: preregister architectural thresholds; compare report, metacognitive discrimination, flexible generalization, perturbational complexity, and lesion/anesthesia transitions across systems. Robust dissociation between the proposed architecture and this convergent marker set would count against the identification.
  - Limit: phenomenal absence isn’t directly observable, so “demonstrably lacks a vantage” isn’t an operational falsifier.
- **The same proposed marker is substrate-independent.** *Domain: Consciousness · Source: Substrate-Neutrality of the Living Constraint ([§4.8](../4.%20Nature%20Alone/4.8%20Life.md)), [§2.4](../2.%20The%20Argument/2.4%20Structural%20Requirement.md) · Basis: Conditional extrapolation · Status: Open.*

  - Operational tests: test non-biological systems that independently satisfy the preregistered architecture for the same convergent marker set, while controlling for trained verbal imitation. Persistent architecture/marker dissociation would count against substrate independence, not prove absence of experience.
- **Bacteria are proposed as minimal-marker cases; Bénard cells and hurricanes as negative controls.** *Domain: Consciousness · Source: [§4.8](../4.%20Nature%20Alone/4.8%20Life.md) · Basis: Interpretive classification · Status: Speculative.*

  - Operational tests: compare adaptive learning, memory-dependent behavioral flexibility, self/non-self regulation, integrated perturbation response, and counterfactual control. The classifications should be revised if negative controls meet the preregistered marker profile or bacteria systematically fail it.
  - Limit: the tests discriminate its markers, not vantage directly.
- **Phenomenology is proposed to track organizational structure.** *Domain: Consciousness · Source: [§5.1](../5.%20Expanding%20the%20Field/5.1%20Consciousness.md), [§5.3](../5.%20Expanding%20the%20Field/5.3%20Feeling.md) · Basis: Abductive identity claim · Status: Supported in part but underdetermined.*

  - Supporting evidence: psychoactive intervention, split-brain cases, dose-dependent anesthesia, and developmental trajectories constrain the dependence of reported experience on organization.
  - Scope: these dependencies don’t uniquely establish the book’s constitutive identity claim.
  - Discriminating evidence: robustly identical organization paired with systematically different phenomenology, or stable phenomenology across materially different relevant organization, would count against the proposed mapping, subject to the limits of report and measurement.
- **Deep self-modeling is predicted to increase hard-problem-style reports or cognate metacognitive puzzlement.** *Domain: Consciousness · Source: [§5.4](../5.%20Expanding%20the%20Field/5.4%20Knowledge.md) · Basis: Abductive meta-problem hypothesis · Status: Open.*

  - Research route: the meta-problem program [[Bibliography#^ref-chalmers2018|(Chalmers 2018)]], developmental and comparative probes, and artificial systems with independently measured self-inclusive modeling.
  - Operational test: preregister measures of reflective depth and report content while controlling for training, language exposure, and imitation. A stable dissociation in either direction would count against the proposed relation.
- **Sufficiently deep self-modeling lineages are predicted to develop structurally analogous registers, not identical cultural categories.** *Domain: Consciousness · Source: [§5.17](../5.%20Expanding%20the%20Field/5.17%20Synthesis.md) · Basis: Abductive universality conjecture · Status: Open.*

  - Research route: comparative cognition, independently developed artificial systems, and any future astrobiological evidence.
  - Discriminating evidence: a demonstrably deep self-modeling lineage whose functional and phenomenological organization lacks analogues of the proposed registers would count against universality; translation failure or different vocabulary alone wouldn’t.
- **A non-corrosion floor should recur across genealogically distant moral traditions more reliably than any one positive account of flourishing.** *Domain: Comparative morality · Source: [§5.14.3](../5.%20Expanding%20the%20Field/5.14%20Morality.md#5.14.3%20Predictions)–[5.14.4](../5.%20Expanding%20the%20Field/5.14%20Morality.md#5.14.4%20Confirmation) · Basis: Framework-guided cross-cultural hypothesis · Status: Provisionally supported.*

  - Research route: compare prohibitions, reciprocity rules, sanctions, and care practices across traditions using construct-equivalent coding, negative cases, and explicit genealogical and contact models.
  - Scope: recurrence within a transmission network tests retention and uptake, not independent convergence; translation and archive survival can also make unlike norms look alike or hide functional analogues.
  - Discriminating evidence: sufficiently independent, sustained societies of mutually exposed subjects that reliably coordinate without functional analogues of non-corrosion would count against the universality claim. Variation in the persons protected, the justification offered, or the positive ideal of flourishing wouldn’t by itself.
- **Experiences classified as spiritual should display recurrent phenomenological functions without requiring one culture-independent theology or sequence.** *Domain: Comparative religion and anthropology · Source: [§5.16.3](../5.%20Expanding%20the%20Field/5.16%20Spirituality.md#5.16.3%20Predictions)–[5.16.4](../5.%20Expanding%20the%20Field/5.16%20Spirituality.md#5.16.4%20Confirmation) · Basis: Framework-guided comparative hypothesis · Status: Open.*

  - Research route: compare boundary alteration, dependence, awe, presence, ineffability, attentional training, and self-model modulation across religious and nonreligious settings.
  - Controls: measurement invariance, translation, practice history, expectation, institutional transmission, ecology, political structure, and observer coding.
  - Discriminating evidence: if the proposed experiential functions disappear when those controls are applied, or track one inherited doctrine rather than modifiable self-modeling across settings, the general structural interpretation loses support. Recurrence alone doesn’t identify a metaphysical object.
- **Independent cumulative inquiries are predicted to converge at invariant structural nodes without repeating one another’s representations or histories.** *Domain: Epistemology · Source: [§5.4](../5.%20Expanding%20the%20Field/5.4%20Knowledge.md), [§5.17](../5.%20Expanding%20the%20Field/5.17%20Synthesis.md) · Basis: Abductive convergence prediction · Status: Open.*

  - Research route: compare independently developed scientific traditions and artificial systems on shared domains now; extend the comparison to independently evolved lineages if such evidence becomes available.
  - Discriminating evidence: stable, successful navigation of the same domain by mature inquiries that require incompatible deep modal structures would count against convergence. Different notation, ontology, discovery order, or explanatory route alone wouldn’t.

## Tier 3: Empirical

*Testable by ongoing experimental programs; the Status column carries each result’s current standing.*

- **Primordial gravitational-wave spectrum and non-Gaussianity distinguishable from slow-roll inflation.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Status: Active.*

  - Confirmation evidence: LiteBIRD, CMB-S4, Planck follow-ups; expected to discriminate within the decade
  - Falsifies if: Observation rules out bouncing-cosmology spectra in favor of slow-roll inflation only, with no surviving cyclic mechanism
- **CMB Hawking-point anomalies as previous-aeon signatures.** *Domain: Cosmology · Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md) · Status: Contested.*

  - Confirmation evidence: An et al. [[Bibliography#^ref-anEtAl2020|(2020)]]—one result, not two, since the 2018 arXiv preprint and the 2020 MNRAS paper are the same study at two stages. Meissner and Penrose [[Bibliography#^ref-meissnerPenrose2025|(2025)]] is a theoretical consolidation rather than new observational support: it remains an unrefereed preprint, and it accounts for the observed angular diameter of the spots, about twice the expected value, by positing a gravitational-wave-dominated epoch just after the crossover
  - Falsifies if: Robust statistical re-analysis eliminates the signal once ring size is marginalized over Jow and Scott [[Bibliography#^ref-jowScott2020|(2020)]] already find it weaker; Bodnia et al. [[Bibliography#^ref-bodnia2024|(2024)]] add an independent machine-learning search and flag a statistical pitfall from a few unusual bright or dark WMAP pixels
- **Bell-local factorization is incompatible with the observed correlations, given the standard auxiliary assumptions.** *Domain: Quantum Foundations · Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md) · Status: Confirmed at the Bell-test level; interpretation underdetermined.*

  - Confirmation evidence: Bell-inequality violations Bell [[Bibliography#^ref-bell1964|(1964)]]; Aspect et al. [[Bibliography#^ref-aspect1982|(1982)]]; Hensen et al. [[Bibliography#^ref-hensen2015|(2015)]] loophole-free.
  - Scope: Bell tests don’t by themselves confirm token indeterminacy. They exclude the conjunction of Bell locality, the relevant independence assumptions, and predetermined local outcomes; deterministic nonlocal and superdeterministic interpretations remain logically available at stated costs.
  - Operational reversal: a reproducible loophole-free experiment satisfying the independence and detection conditions while obeying the relevant Bell inequality would overturn the empirical verdict.
- **Penrose-Diósi gravity-induced collapse predicts a mesoscopic threshold.** *Domain: QM & Type/Token · Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md) · Status: Active.*

  - Confirmation evidence: Tabletop tests of mesoscopic superpositions currently underway
  - Falsifies if: Mesoscopic superpositions persist past the Penrose-Diósi mass threshold without reduction
- **Near-death experiences are modeled as integrative-flow destabilization rather than departure.** *Domain: Consciousness · Source: [§5.9](../5.%20Expanding%20the%20Field/5.9%20Mortality.md) · Status: Hypothesis / underdetermined.*

  - Supporting evidence: residual or resurgent cortical activity around arrest; phenomenology compatible with hypoxia, disinhibition, reconstruction, and disrupted self-modeling.
  - Operational test: prospectively time-lock hidden targets, high-density neural monitoring, perfusion/oxygenation measures, and later reports. Veridical target recovery reliably time-locked to instrument-defined absence of the neural activity needed by the model would count against it.
  - Limit: “zero brain activity” is always relative to instrument sensitivity and sampled regions; it isn’t a metaphysical observation of total absence.

## Positions Under Structural Pressure

*The book’s framework treats these positions as facing specified conceptual or explanatory burdens. This table doesn’t claim that all are empirically refuted or that every rival formulation has been exhausted.*

- **Stable singularity (permanent zero extension).** *Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

  - Pressure: If zero extension is interpreted as absolute structural absence, it conflicts with its ∅-preclusion. Boundary, breakdown, and non-spatiotemporal-successor interpretations remain live and were already separated.
- **Permanent information destruction at singularities.** *Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md).*

  - Pressure: The framework is compatible with information-preserving applications and predicts none of them, but permanent non-unitary loss doesn’t straightforwardly entail that Space is eliminated. This remains a physical hypothesis to be decided by quantum-gravity and evaporation models.
- **Block-universe fatalism (eternalism → fatalism).** *Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md).*

  - Pressure: Eternalism doesn’t entail fatalism. Its directional-flow account resists the added fatalist inference, while leaving the broader metaphysics of passage contested.
- **Strict Laplacean determinism (type fixes token exhaustively).** *Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md).*

  - Pressure: Its type–token application opposes exhaustive token fixation. Bell violations exclude Bell-local predetermined accounts under the standard assumptions, not deterministic nonlocal or superdeterministic interpretations.
- **Strict superdeterminism.** *Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md).*

  - Pressure: Superdeterminism rejects or revises measurement independence and therefore bears a substantial methodological and explanatory burden; it isn’t rendered logically unintelligible by that cost alone.
- **Strict Nietzschean eternal recurrence (token-level).** *Source: [§4.6](../4.%20Nature%20Alone/4.6%20Singularity.md), [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md).*

  - Pressure: Even if macro-cyclicity is granted, token-level recurrence doesn’t follow. Repeated tokens are treated as an additional hypothesis rather than a consequence of cyclicity.
- **Type-level fine-tuning (calls for external selector).** *Source: [§2.7.3](../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.3%20PSR%20Regress), [§10.1.9](../10.%20Rival%20Ultimates/10.1.9%20The%20Fine-Tuning%20Argument.md).*

  - Pressure: The framework rejects ∅ as a physical contrast state, but fine-tuning arguments may use other modal or theoretical contrast classes. The external-selector inference therefore faces the comparison-class and likelihood burdens developed in [§10.1.9](../10.%20Rival%20Ultimates/10.1.9%20The%20Fine-Tuning%20Argument.md) rather than simple empirical refutation.
- **Agency as readout of pre-settled computation.** *Source: [§4.7](../4.%20Nature%20Alone/4.7%20Cosmic%20History.md).*

  - Pressure: Self-modeling configurations are proposed here as loci of token-level causal contribution. Competing deterministic accounts remain live unless the independent type–token application succeeds.
- **Substance dualism for consciousness.** *Source: [§5.1](../5.%20Expanding%20the%20Field/5.1%20Consciousness.md), [§9.1](../9.%20Physics%20and%20Mind/9.1%20The%20Hard%20Problem.md).*

  - Pressure: The self-modeling account claims explanatory sufficiency and places an added-work and detection burden on a second substance. Absence of a distinctive signature is a parsimony pressure, not a deductive disproof.
- **Strong panpsychism (consciousness all the way down).** *Source: [§4.8](../4.%20Nature%20Alone/4.8%20Life.md), [§9.3](../9.%20Physics%20and%20Mind/9.3%20Russellian%20Monism.md), [§9.4](../9.%20Physics%20and%20Mind/9.4%20Cosmopsychism.md).*

  - Pressure: If dissipative self-inclusion marks consciousness, strong panpsychism loses the arbitrary-threshold motivation addressed here. Panpsychists may deny that marker or assign it a different explanatory role, so the pressure is conditional on the constitutive identification.
- **Eliminativism / strong illusionism about consciousness.** *Source: [§5.1](../5.%20Expanding%20the%20Field/5.1%20Consciousness.md), [§9.2](../9.%20Physics%20and%20Mind/9.2%20Eliminativism%20and%20Illusionism.md).*

  - Pressure: The functional transition to self-including modeling is a real activity that any account here is required to preserve. Illusionists can accept that activity while denying further phenomenal properties, so the dispute concerns what the function explains rather than whether the function exists.
- **Heterotrophic origin of life.** *Source: [§4.8](../4.%20Nature%20Alone/4.8%20Life.md).*

  - Pressure: Strict biological heterotrophy presupposes prior organisms, but origin models may posit dependence on abiotic feedstocks without using heterotrophy in that strict sense. The first-system claim therefore constrains terminology and dependency structure rather than foreclosing every externally supplied pathway.
- **Photosynthetic origin of life.** *Source: [§4.8.2](../4.%20Nature%20Alone/4.8%20Life.md#4.8.2%20The%20Requirement).*

  - Pressure: Extant chlorophyll-based photosystems are downstream evolutionary products, which weighs against their priority. Simpler prebiotic photochemical energy capture remains an empirical possibility and is the discriminating alternative already named.
- **Sequential cycle emergence (metabolism-first or replicator-first).** *Source: [§4.8.2](../4.%20Nature%20Alone/4.8%20Life.md#4.8.2%20The%20Requirement).*

  - Pressure: The chemoton application predicts functional coupling before a system counts as fully living, but allows staged chemical precursors. Metabolism-first and replicator-first programs remain live accounts of that staging unless an independently living isolated cycle is required.

A reader who finds that an empirical result defeats a stated auxiliary hypothesis, identification, or application is reading correctly. The framework isn’t protected from empirical contact, but the target of a result must be identified precisely. A cosmological, biological, or consciousness hypothesis may fail without automatically refuting the global-capacity modal framework. Conversely, repeated failure of its best applications would substantially weaken its broader explanatory ambitions.


---

← [Appendix C: Derivation Map](Appendix%20C%20-%20Derivation%20Map.md) | [Appendix E: The Mathematical Research Program](Appendix%20E%20-%20The%20Mathematical%20Research%20Program.md) →
