Chapter 2 located mathematics inside Nature’s articulation. It did not turn metaphysics into a
substitute for proof. A mathematical consequence holds wherever its profile is realized because a
realization lacking the consequence would not realize that profile. That is Invariant
Realization ([§3.5.6](../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.6%20Formal%20Realization%20Preserves%20Structure%20Without%20Supplying%20It)). The theorem transfers an invariant after mathematics has established it; it
does not establish the invariant, select the profile, or show that the profile has a concrete
realization.

The limit creates a further question. If Temporality, Spatiality, and Substantiality are not merely
features found in one world but the necessary structure within which anything real can obtain,
what does that result contribute to mathematics itself? It may explain why mathematical
consequence binds concrete realizations without changing which consequences mathematics proves.
Or the structural account may admit a formalization strong enough to exclude models, determine
invariants, and produce theorems unavailable without it. The first achievement is a metaphysical
ground for mathematics. The second would be a mathematically generative foundation. They are not
the same result.

This appendix states what would distinguish them. It records the mathematical research program
opened by the proof, not additional conclusions already contained in it. Its conjectures are
conjectures, its formal targets require formal proof, and its applications remain conditional on
bridges that have not yet been supplied.

> [!note]
> **Status of this appendix.** The Necessity of Nature, the Modal Identity, Configurational
> Necessitation, Condition-Individuation, and Invariant Realization are inherited results of the
> manuscript. The formal language, representation theorem, minimality result, exhaustiveness
> result, universal factorization, and realizability criterion for real possibility proposed here
> are open work; the reconstruction program and domain applications are developed in the working
> research notes. Nothing receives theorem-status merely by being a
> mathematical restatement of the metaphysical claim.
>
> One result from this program is an exception, and its status should be read precisely. *Exponential
> Crossing Ambiguity* is proved, unconditionally, within an explicitly stated finite model, and is stated
> with its proof in [Appendix F](Appendix%20F%20-%20Formal%20Results.md). It is not a
> restatement of the metaphysical claim: it is a lower bound on what a pairwise description omits,
> and it answers a narrower question than any of the targets above. Its weight rests on the model
> being faithful to the modal core, which is argued where it is stated and not assumed here.

## What the argument already gives mathematics

Four results set the starting conditions.

*First, mathematics is performed within the structure it describes.* A proof is an actual change:
symbols are distinguished, steps are ordered, and content is retained across an inference. The act
therefore instantiates T, S, and Φ. That performative fact does not make the conclusion true. It
identifies the conditions under which proving, calculating, recording, and checking can occur
([§3.5.6](../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.6%20Formal%20Realization%20Preserves%20Structure%20Without%20Supplying%20It)).

*Second, a mathematical profile fixes its consequences internally.* A profile specifies elements
or positions together with the quantitative, relational, or operational conditions that
individuate the structure. Where every admissible realization of a profile M satisfies Q, a real
configuration cannot realize M while lacking Q. The necessity lies in the conditional:

$$
M\models Q\quad\Longrightarrow\quad
\Box\forall x\bigl(\operatorname{Realizes}(x,M)\rightarrow Q(x)\bigr).
$$

Mathematical proof carries the left side. Invariant Realization carries the consequence into any
real realization.

*Third, the structural floor does not select a higher-resolution mathematics.* Temporality does not
select one temporal logic beyond every context; Spatiality does not select a dimension, topology,
or metric; Substantiality does not select a material bearer, conservation law, or field equation.
The three Conditions constrain any concrete realization while leaving its determinate profile to
be established. Linear orders, region calculi, manifolds, groups, algebras, and dynamical systems
may articulate parts of the structure without any one of them being identified with Nature entire
([§4.1](../4.%20Nature%20Alone/4.1%20Convergence%20of%20Method.md)).

*Fourth, logical and mathematical necessity do not pass into their subject matter without a
bridge.* A formal truth may describe a contingent configuration. A necessarily available
apparatus need not have a necessarily instantiated object. The bridge for a particular result is
therefore never resemblance alone. The profile must be specified, its consequence proved, and its
realization established at the resolution the conclusion requires.

These results give mathematics an ontological location and explain the application of proved
invariants. Whether they also give mathematics new theorems is the open question.

## The Chapter 2 inheritance map

The formal program should use the entire Chapter 2 result chain, not only the three Condition
names. Each inherited result supplies a different constraint or bridge.

| Inherited result | What it contributes here |
|---|---|
| Ordered Succession | Fixes the T-target as asymmetric, transitive ordering at modal-core resolution, not mere edge orientation. |
| Relational Distinctness | Fixes the S-target as occupiable, exclusive, crossable relational extension, not inequality or arbitrary graph separation. |
| Cross-Interval Persistence | Fixes the Φ-target as coherent bearing through a transition, not similarity between endpoint descriptions. |
| Structural Requirement | Sets the coverage conjecture: every adequate model of the fixed registered-change witness must carry all three loaded roles. |
| Sufficiency of Structure | Sets the reverse construction: the full triad must admit generic change, without pretending to recover the richer reflective witness. |
| Mutual Containment and Triconditional Cross-Entailment | Require co-instantiation in one realizer. Formal weak-role independence is a baseline below this loaded domain, not a refutation of the chapter. |
| Condition-Individuation | Requires both irreducibility and existence-axis exhaustiveness. Pairwise non-definability can address the first but not the second. |
| Conditioned-Nature | Locates mathematics as the quantifiable articulation of Nature; it interprets formal structures without selecting one formal theory. |
| Invariant Realization | Transfers every proved profile invariant into every real realization of that profile. |
| Three Logical Strata | Sets the proof-theoretic target: coordinated T-, S-, and Φ-calculi over a shared classical floor, with translation loss tested rather than assumed. |

This inventory reveals that the argument has already solved one of the hardest philosophical bridge
problems. If a mathematical profile M entails Q, Invariant Realization yields

$$
M\models Q
\quad\Longrightarrow\quad
\Box\forall x\bigl(\operatorname{Realizes}(x,M)\rightarrow Q(x)\bigr).
$$

The appendix does not need to invent a second account of why proved invariants bind real
realizations. It must do the mathematical work on the left and independently establish the
realization premise.

Apply that bridge to the rigid registered profile developed below. Let R name the finite systems
whose occurrence order, descriptors, descriptor dynamics, and comparison relations meet the
stated hypotheses; let $Q_R$ say that the system carries the canonically reconstructed temporal
order, bearer functor, and comparison metric. The mathematical theorem gives $R\models Q_R$.
Invariant Realization therefore supplies

$$
\Box\forall x\bigl(\operatorname{Realizes}(x,R)\rightarrow Q_R(x)\bigr).
$$

If an R-realization is genuinely possible, Necessary Possibility ([§2.1.10](../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.10%20Necessary%20Possibility)) and Physical
Invariance ([§3.5.6](../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.6%20Formal%20Realization%20Preserves%20Structure%20Without%20Supplying%20It)) further give necessary availability of an R-with-$Q_R$ realization. If R is
actually realized, the invariant is actual there. What remains open is exactly what should remain
open: whether the fixed reflective change-witness realizes R, and whether $Q_R$'s formal
structures meet the loaded criteria for T, S, and Φ rather than thin namesakes.

That last requirement is **role adequacy**. A reachability order must satisfy Ordered Succession at
the relevant resolution; a relational metric must support the occupancy and crossability demanded
by Relational Distinctness; a descriptor-induced functor must represent numerical bearing rather
than merely a sequence of qualitatively matching contents. The central bridge conjecture is that
registered change admits a presentation meeting all three adequacy tests naturally—independently
of arbitrary renaming or representational choice. Proving it would allow the new mathematical
reconstruction theorem and the inherited Chapter 2 modal machinery to compose.

Mutual Containment adds a separate design constraint. If it is rendered as three predicates with
the same extension, the roles collapse; if any two role-values uniquely calculate the third, the
formalization replaces co-requirement with functional reducibility. A three-sorted incidence
relation avoids both errors. Its triples record T-, S-, and Φ-instances meeting in one realizer.
Co-requirement says every admitted role-token belongs to such a triple. Irreducibility says each
pairwise projection is noninjective: forgetting one coordinate identifies full realizations that
the complete triple distinguishes.

These demands are mathematically compatible. For three copies of $\mathbb Z_3$, admit exactly the
triples satisfying $t+s+p\equiv0$ or $1\pmod3$. Every pair of coordinates permits two values of the
third, so no role is a function of the other two; all roles nevertheless occur only in complete
triples, and the admissible relation is a proper subset of the Cartesian product. The construction
does not model Nature—the modular rule is only a finite consistency witness. It proves that “one
same-realizer structure” and “three non-reducible roles” are not mutually contradictory formal
requirements. The substantive task is to derive the right incidence relation from registered
change and show that its lost coordinates correspond to the chapter’s loaded distinctions.

## Grounding and generation

A metaphysical foundation can matter without enlarging a formal theory. It may explain why logic
has real referents, why mathematical structures can describe concrete systems, or why a proof is
binding wherever its conditions are met. None of those explanations by itself removes a model
from a mathematical class. If every model admitted before the explanation remains admitted after
it, the explanation changes the interpretation of the mathematics rather than its consequences.

Generation begins with discrimination. A proposed foundation has mathematical force only where it
does at least one of three things:

1. excludes a formally admissible structure for a reason stated inside the theory;

2. requires a relation or invariant that the prior axioms left open; or

3. proves that two apparently different structures are equivalent, reducible, or incapable of
   varying independently.

This is the model-separation test. Let F be a proposed formalization of the structural account and
let Q be a mathematical sentence. If models of F realize both Q and its negation, F does not
decide Q:

$$
\mathcal M_1\models F\land Q,
\qquad
\mathcal M_2\models F\land\neg Q.
$$

The metaphysics may still explain what both models share. It has not yet supplied leverage on the
point at which they differ. If no model of F realizes the negative branch, the reason must be
recoverable from F’s independently stated axioms. Defining the unwanted branch away, or placing Q
inside the definition of the profile, purchases the result by stipulation.

The test applies with particular force here. T, S, and Φ were derived at the thinnest resolution
required for genuine change. That thinness is part of the argument’s reach: the Conditions survive
variation in geometry, law, material bearer, and physical history. The same breadth that makes the
result universal also leaves most high-resolution mathematics underdetermined. To generate a new
theorem, the formalization must preserve the universality without becoming too weak to exclude
anything.

## The formalization problem

The existing argument supplies meanings before it supplies a calculus. Temporality is ordered
succession, asymmetric and transitive at modal-core resolution, with causal structuring earned at
the realization tier; Spatiality is relational exteriority, the capacity for co-present relata to
stand apart across a crossable interval; Substantiality is determinate bearing and persistence
across transition. A mathematical theory must decide which structures represent those roles and
which maps preserve them.

One starting language would be many-sorted. It might contain bearers, states, transition indices,
and relational positions, together with relations for precedence, separation, occupancy,
persistence, and transition. A model could take the provisional form

$$
\mathcal M=
\langle B,Q,\Theta,\Sigma,
\prec,\operatorname{Sep},\operatorname{Occ},
\operatorname{Pers},\operatorname{Trans}\rangle,
$$

where B is a domain of bearers, Q a domain of states, Θ a domain carrying temporal order, and Σ a
domain carrying positional or relational differentiation. The remaining symbols would record how
a bearer occupies a differentiated state, persists across indices, and undergoes a transition.
This signature is a proposal, not the theory. Its purpose is to expose the choices prose can leave
implicit.

The first danger is circularity. If *change* is defined as an ordered difference borne by one
persister, then T, S, and Φ follow because the conclusion was placed inside the definition. The
formal program must therefore supply an independent entry characterization of change—perhaps by a
nonidentity relation between system states under an admissible transition—and then prove that any
adequate realization of that relation requires the three structures at the richer role-resolution.
The entry characterization cannot simply rename succession, exteriority, and persistence.

The second danger is encoding. Set theory can encode an order, a topology, an identity relation,
and a transition graph inside sets. The existence of such encodings does not show that the encoded
structures perform the same role, but neither does calling the roles irreducible show that no
faithful translation exists. The relevant standard must therefore be stronger than notation and
weaker than the impossibility of any coding. A translation counts against irreducibility when it
preserves the role’s objects, valid inferences, countermodels, and composition without importing
the allegedly eliminated structure through its semantics.

The third danger is triviality. Every transition system has vertices and edges; every mathematical
object can be distinguished from another under some description; every sequence has an order. A
theory that identifies those minimal facts with the full Conditions may represent everything
because it says almost nothing. The formal predicates must retain the content earned in the
manuscript: asymmetric or directed succession at the T-limb, genuine relational differentiation
at the S-limb, and bearer-relative persistence or transmission at the Φ-limb. Each addition must
be defended as part of the role rather than introduced because a desired theorem needs it.

## The triadic representation target

The book’s central mathematical target can now be stated without pretending it has been proved.

**Role-Faithful Triadic Reconstruction and Minimality** · *Formal conjecture*

Every independently adequate model of registered change admits a reconstruction in which
temporal order, relational differentiation, and bearer persistence are naturally recoverable
rather than freely adjoined. The recovered roles are non-degenerate, jointly sufficient, and
individually indispensable to the model’s valid distinctions. Any further structure required by
every such model either factors through the triad, is definable in its combined language, or
fails the independent criterion for an existence-axis.

The conjecture does not claim that every temporal, spatial, or substantial structure has one
privileged formalization; that every mathematical object is concrete; or that the triad selects
a dimension, topology, metric, dynamics, physical law, or ontology of mathematical objects. A
bare state-transition graph is not yet an adequate model of registered change: it does not
recover global time, spatial decomposition, or bearer identity from its edge relation alone.

The conjecture contains three results that may come apart. Representation says the triad is
adequate. Minimality says each part is indispensable. Exhaustiveness says nothing of the same
structural rank has been omitted. A proof of the first would not establish the second or third.

A categorical formulation may state the target most cleanly. Let **Chg** be a category whose
objects are independently defined registration-bearing change systems and whose morphisms
preserve the relevant transitions and observations. Let **TSP** be a category of compatible
triadic structures with morphisms preserving the three roles. A reconstruction theorem might
construct a functor

$$
F:\mathbf{Chg}\longrightarrow\mathbf{TSP}
$$

alongside a forgetful functor $U:\mathbf{TSP}\to\mathbf{Chg}$, with the base system recovered by
$U\circ F\simeq\operatorname{Id}_{\mathbf{Chg}}$. That equation is still insufficient if F merely
decorates every object by arbitrary choices. Role-faithfulness further requires the triadic
relations to be definable from invariants of the base semantics, the construction to be natural
under the admitted morphisms, and deletion of any limb to lose inferential content. Exhaustiveness
would then require a universal property: any other proposed necessary factor would pass through
the triadic reconstruction rather than adding an independent coordinate.

This formulation is only a target. The choice of categories, morphisms, equivalence, and recovery
conditions carries the substance. If those choices are made so that the theorem is automatic, the
result is bookkeeping. If they are independently motivated and the proof excludes live
alternatives, the result has mathematical content.

## The first formal pass

The smallest test begins with a bare transition system $\langle X,\to\rangle$ containing an edge
$x\to y$ with $x\ne y$. The edge supplies an ordered source and target. It does not determine
whether one bearer changes from x to y or one bearer at x is replaced by another at y. It likewise
does not determine whether x and y occupy one position, different positions, or internally
structured regions. A two-cycle supplies local direction while failing to select one asymmetric
global time on its state set.

Explicit two-state expansions establish the resulting projection failure. One expansion assigns
the transition’s endpoints to the same bearer; another assigns them to two bearers. They are
non-isomorphic as persistence structures and become identical when bearer structure is forgotten.
Parallel spatial expansions likewise collapse under the projection. The bare transition cannot
invert the projection and recover what was forgotten.

A general expansion lemma fixes the consequence. If every model of a base theory admits some
TSP-expansion, the expanded theory is conservative for sentences in the base language. Any base
countermodel to P can receive the expansion while remaining a countermodel to P. Freely adjoining
T, S, and Φ therefore yields no new theorem about the underlying transition systems.

> [!proposition]
> **Decoration Is Not Derivation** · *Proposition*
>
> *First formal constraint.*
>
> Bare state succession does not naturally recover global temporal order, spatial decomposition,
> or bearer persistence. If every base transition model can receive an arbitrarily chosen
> T-S-Φ expansion, that expansion is conservative over the base language. Mathematical leverage
> requires recoverable structure or principled exclusion, not universal decoration.

The proofs and countermodels are developed in the working note TSP Formalization - First
Results. The result does not refute the manuscript’s Structural Requirement, whose actual
witness is reflective and comparison-bearing rather than a bare graph edge. It determines what
the next semantics must represent: retention of earlier content, registration of a difference,
and whatever identity conditions make the retained and current contents phases of one episode.
Those additions must be independently motivated. Naming retention Φ or comparison S before the
proof would reproduce the circularity the formal pass was built to detect.

The same working note supplies a first positive construction. A directed graph generates a path
category; an observation functor carries content compositionally along its paths; and a comparison
relation inside the successor observation space relates transported prior content to current
content. Every registered edge in that structure decomposes canonically into directed succession,
functorial bearing, and co-available relational differentiation. Finite models show that the three
representational components are logically independent before the full registration condition is
imposed.

That conditional theorem is the first formal foothold, not yet the desired backbone. It extracts
the triad from independently stated registration data, but it does not show that every genuine
change admits such data, that the observation functor is behaviorally recoverable, or that the
three components are metaphysically irreducible rather than formally separable in the proposed
language. The next pass must test those three bridges.

A second construction makes the bearer condition itself mathematical. Take an acyclic path
category as a temporal base, a set-valued functor B assigning bearers to each occurrence and
transporting them along paths, a relationally structured positional functor P, and a natural
occupancy map from bearers into positions. A qualitative valuation changes when its value is
nonconstant along one B-transported bearer. Then T is the indexing base, S is relational
structure in the fibers, and Φ is functorial transport through the fibers. The Grothendieck
construction repackages B as a discrete opfibration over the temporal category, so a persisting
history is a coherent lift through a structure lying over time. This is a genuine unified model,
not three predicates stapled together.

The gain is accompanied by an exact ceiling. The functor, positional fibers, and occupancy map
are supplied data; they are not recovered from bare change. Moreover, if a forgetful map erases
them, two models that disagree about persistence can have identical—and therefore
bisimilar—transition reducts. No bisimulation-invariant language of those reducts can distinguish
the models. Φ can become behaviorally visible only by independently justifying richer
observations, transition labels, admissible equivalences, or logical vocabulary.

This narrows the research fork. If every adequate persistence semantics is equivalent to indexed
transport or lifting, then the mathematical apparatus may already exist and the contribution is
its metaphysical interpretation and unifying deployment. If some warranted Φ-validities cannot
be expressed that way, those failures identify the first plausible axioms of a genuinely new
calculus. The immediate target is therefore a representation-and-completeness result for an
independently characterized class of registered-change models, not a declaration that the
category-theoretic packaging is itself new mathematics.

The naturality requirement can now be pushed to a no-go result. Take two finite endpoint sets of
possible bearers and allow all independent renamings of each set. A recovered persistence map
would have to be a bijection commuting with those renamings. With two or more occupants this is
impossible: permuting only the target endpoint changes every proposed matching while leaving the
bare presentation unchanged. Thus bare endpoint data admit no natural Φ-reconstruction, not
merely no unique one.

More generally, a natural reconstruction exists on an isomorphism class exactly when the
automorphism group of a representative fixes at least one candidate expansion. This converts
recoverability into an invariant-choice problem. It also yields a positive criterion. If an
independently motivated cross-stage compatibility relation has a unique perfect matching, that
matching is fixed by every automorphism and canonically supplies bearer transport. Unique edge
matchings then extend by composition to a functor on the history’s path category. The next
substantive problem is whether registered comparison itself supplies compatibility evidence rigid
enough to meet this criterion without already assuming trans-temporal identity.

There is now a sharper positive theorem too. Suppose each stage’s occupants receive injective
observable descriptors, and independently specified descriptor-evolution maps preserve identities
and composition. If every predicted later descriptor is realized, each earlier occupant has one
and only one compatible later occupant. Those forced edge maps compose into a unique bearer
functor and commute with descriptor-preserving isomorphisms. Φ is then recovered rather than
inserted.

When descriptors repeat, the same construction recovers only equivalence classes of
observationally indiscernible occupants. Permutations within a repeated-descriptor class preserve
all the base data, so individual persistence remains underdetermined unless further structure
fixes an invariant matching. The distinction is crucial: registered comparison may establish the
continuation of retained content-types without yet establishing the numerical identity of their
bearers. Any proposed derivation of Φ must say which level it reaches.

The other two limbs admit bounded positive recovery as well. A finite acyclic occurrence graph
canonically determines its reachability partial order; it determines a unique linear order exactly
when every pair of occurrences is already comparable. A finite connected symmetric comparison
relation canonically determines its shortest-path metric, and the original relation is recovered
as distance one. These are elementary constructions, but they prevent “time” and “space” from
functioning as unanalyzed labels.

Together they give an integrated result for finite rigid registered systems: an acyclic occurrence
graph supplies T as partial order; injective descriptors with compositional evolution and realized
predictions supply Φ as a unique bearer functor; and connected symmetric comparison fibers supply
S-like metric structure. All three reconstructions commute with structure-preserving
isomorphisms. This is the strongest positive theorem presently earned. Its hypotheses remain the
load-bearing issue: the metaphysical argument must independently justify occurrence acyclicity,
descriptor-level individuation, and adjacency-grade comparison before the theorem can count as a
formal consequence of registered change rather than a characterization of one favorable class.

## What the pairwise view omits, exactly

The results above are conditional: each purchases its conclusion with hypotheses the metaphysical
argument must independently justify. A weaker kind of result is available unconditionally, and it
answers a different question. Rather than asking what the triad can reconstruct, it asks what is
lost when the triad is read pairwise — when a description records the temporal, spatial, and
bearer facts two at a time and never all three together.

Fix a finite model at the resolution the modal core actually spends. Temporality is a strict
partial order, with Directionality left to the realization tier ([§2.4.6](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality)). Spatiality is separation with
crossability in principle and no metric, dimension, or topology ([§1.4.2](../1.%20Groundwork/1.4%20Three%20Conditions.md#1.4.2%20Space)). Substantiality is persistence across the interval without production, since
Transmission is likewise realization-tier ([§2.4.8](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality)). A registration assigns each bearer a position at each time it exists.
Its three pairwise shadows record which positions are occupied when, which bearers exist when, and
which positions each bearer ever occupies.

Two registrations can agree on all three shadows and still differ over which bearer followed which
trajectory. The smallest instance runs two bearers over three times between two positions: in one
registration each bearer stays put and then crosses, in the other they cross and cross back. Every
pairwise fact is identical; the histories are not. The shadows record that both positions were
occupied throughout and that each bearer visited both, and that is all they can record.

The shortfall admits an exact count.

That count is established in [Appendix F](Appendix%20F%20-%20Formal%20Results.md), which carries the proof.
Its shape is worth stating here because it is what the program has so far returned. Call a
registration *complementary* when the two bearers occupy opposite positions at every time and each
visits both. For $m$ times the complementary registrations on a fixed pair of positions number
$2^m-2$, they share a single pairwise-shadow signature, and they fall into exactly $2^{m-1}-1$
classes distinct up to exchange of bearers and permutation of positions. No pairwise-shadow class
contains more, at any number of positions, so the bound is exact and independent of how much room
the model is given.

Three things follow, and the third is the one worth carrying.

*The obstruction is not the standard one.* An unstructured ternary relation fails pairwise
recovery through parity: symmetric in all three coordinates, present at minimum size, and worth
one bit at every arity. The obstruction here is asymmetric, absent in the smallest cases, and
concerns identity across the order rather than three-way co-occurrence. Typing the Conditions
changes which failure appears, which is the first sign that a formalization at this resolution is
tracking the argument rather than its shadow.

*The bound is unconditional within the model.* It assumes no adequacy bridge, no acyclicity beyond
the order already fixed, and no descriptor-level individuation. What it does assume is the model
itself, and that assumption is where its weight sits.

*The third Condition does a growing amount of work.* [§2.4.6](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality) states that a bare ordering "doesn’t yet supply a subject persisting
across the replacement." The theorem measures the gap so described: with $m$ steps of succession,
order and distinctness together leave $2^{m-1}-1$ mutually indistinguishable histories, and only
the persisting bearer separates them. The shortfall is not a constant to be absorbed once. It
doubles with every step of temporal depth.

*And enlarging space does not help.* The bound is independent of the number of positions. More room
creates more ambiguous classes but never a larger one, so the worst-case shortfall is set by
temporal depth alone. Whatever a pairwise description fails to fix about which bearer went where,
it fails at a rate governed by how many steps of succession there are and by nothing else. This is
the sense in which the three Conditions are not interchangeable at this resolution: the deficit is
indexed to T and repaired by Φ, and S is silent about it.

The claim is correspondingly narrow. It is exact for two bearers and open in bearer count, and
nothing here establishes it for the general registration. The reading of the
theorem also depends on Substantiality being read as [§2.4.8](../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality) reads it — a structural fact spanning the interval rather than an
endurantist metaphysics, so that a perdurantist whole and a stage-theoretic counterpart relation
each supply it. A trajectory is that structural fact under any of the three decompositions, and on
the stage-theoretic reading the ambiguity is over which counterpart relation obtains. It is
therefore not an artifact of treating bearers as enduring individuals.

## Beyond representation: universality and definability

A representation theorem would show that T, S, and Φ are adequate to describe genuine change. It
would not yet show that the description is privileged. A rival formalism might represent the same
systems with different primitives, preserve every relevant inference, and omit the triadic
vocabulary entirely. If so, the triad may be one coordinate system on a structure whose invariant
content is more general than any of its three names.

The next target is therefore invariance under reformulation. Let a translation between theories
count as adequate when it preserves models, countermodels, valid consequence, and composition at
the resolution at issue. The triadic account is universal only if every adequate formalization of
genuine change either recovers the three roles or preserves an equivalent structure under
different notation. The claim concerns role-equivalence, not word-equivalence: a theory need not
contain predicates called *temporal*, *spatial*, or *substantial* if its semantics performs the
same offices.

This suggests a factorization target. Suppose G maps an independently specified change theory
into some formal category **A**. A triadic theory would have the relevant universal standing if,
for every adequate G, there were a role-preserving route through **TSP**:

$$
\mathbf{Chg}\xrightarrow{F}\mathbf{TSP}\xrightarrow{H}\mathbf A,
\qquad
G\simeq H\circ F.
$$

The equivalence sign matters. A strict equality of presentations would demand identical notation
and construction choices. The structural claim requires preservation of the relevant content,
not one canonical alphabet. The hard work is to specify the equivalence under which a temporal
order cannot be hidden in an index, relational differentiation cannot be hidden in the domain,
and persistence cannot be hidden in the identity conditions on morphisms.

Universal factorization would still leave the No Fourth Condition problem. An additional
predicate may obtain in every TSP-model without being definable from T, S, and Φ. Universal
co-extension is not definition, just as necessary accompaniment is not identity. The stronger
target is definability completeness:

**Triadic Definability Completeness** · *Formal conjecture*

Let X be invariant under the admissible isomorphisms of genuine-change models and necessary in
every such model. If X satisfies the independent existence-axis criterion, then X is explicitly
definable in the combined T-S-Φ language, or every adequate representation of X factors through
a structure already definable there.

Mere truth in every intended model is insufficient. The target requires a definability or
factorization result, not another statement of co-extension.

The conjecture is stronger than the book’s present Condition-Individuation result. That result
screens candidates and places an irreducibility burden on a proposed fourth. Definability
Completeness would discharge the burden from the other side by proving that every qualifying
universal invariant is already expressible in the triad. It may fail. Failure would be
informative: an undefinable invariant necessary in every intended model would identify either a
fourth structural role or an expressive weakness in the chosen formal language.

Three different forms of uniqueness must remain separate.

- *Uniqueness of presentation* would say there is one privileged syntax. Nothing in the book

  requires this, and it is unlikely to be the right target.
- *Uniqueness of decomposition* would say that a change-model’s T-, S-, and Φ-components are

  recoverable up to the relevant isomorphism or equivalence.
- *Uniqueness of structural role* would say that every adequate presentation preserves the same

  three offices even where it packages them differently.

The third is the metaphysical claim’s natural mathematical form. The second would strengthen it.
The first would mistake a notation for the structure.

## From formal consistency to real possibility

Mathematics supplies structures that are consistent relative to their axioms. The book’s modal
vocabulary asks a different question: whether a structure is really possible. The two cannot be
identified without argument. A consistent description may fail to specify a concrete realizer,
combine conditions that cannot jointly obtain, or leave its intended interpretation
underdetermined. Conversely, failure in one formal presentation may reveal a defective
formalization rather than a real impossibility.

The widest mathematical ambition of the project is a criterion connecting those domains. Let
$\operatorname{Mod}(M)$ mean that the profile M has a model in the background mathematics, and let
$\operatorname{RealPoss}(M)$ mean that M has a really possible realization. Invariant Realization
currently runs only after the second predicate is secured. A realizability theorem would
seek conditions K such that

$$
\operatorname{RealPoss}(M)
\quad\Longleftrightarrow\quad
\operatorname{Mod}(M)\land
\operatorname{TSPCompatible}(M)\land K(M).
$$

The right-to-left direction is the difficult one. TSP-compatibility may be necessary while
remaining far from sufficient. A profile can contain order, differentiation, and bearing yet
conflict with another modal constraint, fail compossibility, or specify no route from mathematical
structure to concrete realization. The placeholder K cannot be filled with “and M is really
possible.” It must contain independently stated conditions whose sufficiency can be proved.

The research program should therefore proceed through three increasingly strong targets.

*Structural admissibility.* Characterize when a mathematical profile can represent ordered,
differentiated, borne change without contradiction in the triadic semantics. This concerns the
profile’s form, not whether Nature physically instantiates it.

*Real possibility.* Determine whether structural admissibility, together with further earned
modal constraints, is sufficient for a real realization. This is where the gap between formal
model and possible realizer must be faced rather than renamed.

*Physical availability.* Given real possibility, determine what further laws, parameters, and
boundary conditions are required for physical realization in a particular regime. The Necessity
of Nature does not make every structurally admissible profile physically available from every
configuration or actual in any history.

**The Realizability Problem** · *Open problem*

Find necessary and sufficient conditions for a mathematical profile to have a really possible
concrete realization, or prove that no recursively specifiable criterion can decide that class
at the proposed level of generality. Distinguish structural admissibility from physical
availability and both from actuality.

Either result would matter. A positive characterization would formalize the boundary between
mathematical consistency and real possibility. An impossibility or undecidability result would
show that the boundary cannot be captured by the proposed kind of calculus. What would not count
as a result is assuming that every consistent structure exists, or assuming that only structures
already observed are possible. Each collapses one side of the problem into the other.

This is the point at which the articulation thesis faces its most demanding test. If mathematics
is Nature’s quantifiable articulation, uninstantiated mathematics may describe unrealized
structural possibilities, abstractions from realized structure, or formal constructions with no
real possible counterpart. The book leaves robust Platonism and the status of uninstantiated
structure open ([§8.1.5](../8.%20Metaphysics/8.1.5%20Platonism.md)). A complete realizability theorem would therefore
require either settling that dispute or stating its scope so that it does not pretend to classify
every abstract object.

## A stratified calculus of necessity

The word *necessary* presently carries several offices that the manuscript distinguishes in
prose. A formal extension could give those offices separate operators. Let $\Box_L$ mark logical
consequence, $\Box_M$ invariance within a specified mathematical profile, $\Box_S$ the structural
necessity fixed by T-S-Φ, and $\Box_P$ necessity relative to an independently specified physical
law-profile. Actuality remains unboxed.

The target is not to multiply primitive necessities. It is to expose their domains and derive the
licensed interaction principles. A proved invariant within M does not establish that M is really
possible:

$$
\Box_M Q\nRightarrow\operatorname{RealPoss}(M).
$$

Where M is really realized, its invariant transfers:

$$
\Box_M Q\land\operatorname{Realizes}(x,M)
\Longrightarrow Q(x).
$$

A law-relative necessity likewise remains conditional on its profile:

$$
\Box_P Q\nRightarrow\Box_S Q.
$$

The strongest formal result here would be a sound and complete interaction logic specifying every
valid transfer among the operators and supplying countermodels to the invalid ones. That calculus
would make the book’s repeated register discipline mathematical: it would show exactly why a
proof inside a profile, a condition of any concrete realization, a law of one physical regime,
and an actual fact cannot trade modal force without an explicit bridge.

A further target is a representation theorem for the modalities themselves. If each operator can
be interpreted by an accessibility, inclusion, fibration, or restriction relation among model
classes, their interaction may be derived from the geometry of those classes rather than imposed
as a list of axioms. The hoped-for hierarchy would run from the broad structural class through
specified mathematical and physical profiles to actual configurations, while allowing
mathematics to range across more than one stratum.

The result could also be negative. If two proposed operators validate exactly the same formulas
under every independently motivated semantics, the distinction between them is not formal at that
resolution. If no complete calculus exists for the intended class, the failure must be located
rather than concealed by one undifferentiated box.

## Adversarial tests

A foundational proposal should specify how it can fail before using its breadth as evidence of
success. The following tests guard the program against turning universal applicability into
universal accommodation.

*The deletion test.* Remove T, S, and Φ one at a time. For each deletion, construct the strongest
remaining model and ask whether it still realizes the independently specified change relation. A
verbal insistence that the missing role must be present is not an independence proof.

*The permutation test.* Recode the primitives and ask whether the alleged axes can exchange roles
without loss. If T, S, and Φ are recoverable only from their names, the semantics has not
individuated them.

*The hidden-import test.* Examine definitions, background identity, morphisms, and model
equivalence for a role that was allegedly eliminated. A persistence relation imported through
cross-time object identity has not been derived from a system without Φ.

*The rival-formalization test.* Apply the theory to formalisms not designed around objects moving
through a space: field theories, algebraic and categorical descriptions, point-free topology,
process ontologies, and purely relational models. The triad must recover its roles without forcing
every rival into one object-language.

*The granularity test.* Vary the resolution. A relation necessary at the thin structural level
must not be mistaken for a particular metric, conservation law, carrier, time parameter, or
topology at a higher level.

*The countermodel test.* Search deliberately for models satisfying the proposed TSP axioms while
failing the desired conclusion. One countermodel fixes the theorem’s scope more decisively than a
catalog of confirming examples.

*The novelty test.* Remove the metaphysical axiom from a completed proof. If the proof still goes
through, or if the axiom merely renames a standard assumption, the result may be valuable but is
not mathematical leverage supplied by this framework.

*The bridge audit.* For every application, identify the exact step at which a structural theorem
enters the domain proof. If that step moves from “a bearer persists” to “this norm is bounded,” or
from “a field realizes Φ” to “its spectrum has a positive gap,” an unproved bridge has been marked,
not crossed.

These tests are not a defensive perimeter around the project. They are how the project discovers
whether its foundation has mathematical content. A theory that survives them has earned more than
one that explains every result after the result is known.

## What the outcomes would mean

Four outcomes are possible, and each answers a different version of the foundational question.

| Outcome | Consequence |
|---|---|
| The formal theory has no intended model | The proposed formal meanings cannot jointly realize the philosophical account; the formalization or the account must be revised. |
| The theory is definitionally or categorically equivalent to an existing formalism | The book may supply a new metaphysical grounding or unification of known mathematics, but the formal consequences belong to the existing theory. |
| The theory is a conservative extension | The backbone explains why the mathematics applies without enlarging what the background theory proves in its own language. |
| The theory is consistent and nonconservative | The structural axioms yield genuinely new formal consequences; their independent justification becomes the central burden. |

The second and third outcomes are not failures. Mathematics has often gained understanding from
representation, equivalence, and unification without gaining a new numerical prediction. A proof
that apparently separate temporal, spatial, and persistence formalisms are coordinated by one
universal construction would be a mathematical result even if every component theorem were
recoverable elsewhere. What would not be licensed is describing interpretive unification as a new
proof of the old consequences.

The fourth outcome is the strongest and the most dangerous. A new axiom can prove new results
because it is false, overly restrictive, or a disguised form of the desired conclusion. Its
metaphysical motivation does not protect it. The new consequences matter only if the axiom is
clear, its consistency strength is understood, its model class is independently motivated, and
the theorem uses rather than restates it.

## The first mathematical home: a substantial logic

Temporal and spatial logics already have developed operators, semantics, and model theories.
Substantial logic is the manuscript’s name for a less unified office: inference about identity,
persistence, part and whole, bearer and property, and transmission across change. The name does
not yet identify one established calculus ([§2.11.1](../2.%20The%20Argument/2.11%20Three%20Logical%20Strata.md#2.11.1%20Three%20Distinct%20Logics)).

That asymmetry makes the Φ-limb the first constructive opportunity. A substantial logic would need
to distinguish at least:

- numerical identity from qualitative similarity;
- persistence from the reappearance of an equivalent state;
- a bearer from the state or property it bears;
- transmission from mere correlation between endpoints;
- constitution from causation and grounding;
- part-whole continuity from identity of the whole.

Its semantics could be tested first on finite transition structures. The initial results would be
ordinary but indispensable: satisfiability, soundness, completeness for a bounded fragment, the
finite-model property if available, and the complexity of decision procedures. Combination with a
temporal logic would test whether persistence can be formalized without simply reducing it to
cross-temporal identity. Combination with a spatial or region logic would test whether occupancy
and exteriority contribute independent constraints.

The strongest early result would not be the creation of a new symbol for persistence. It would be
a representation or non-reducibility theorem showing that a class of transition structures loses
information essential to its valid inferences when the Φ-relations are forgotten. That would give
formal content to the claim that Substantiality is an axis rather than an optional description.

A first co-presence calculus can now be stated. Take three normal modal operators and let
$E_i=\langle i\rangle\top$ say that an i-related witness exists at the current point. Add the
cyclic axioms

$$
E_T\leftrightarrow(E_S\land E_\Phi),\qquad
E_S\leftrightarrow(E_T\land E_\Phi),\qquad
E_\Phi\leftrightarrow(E_T\land E_S).
$$

The resulting logic is sound and strongly complete for frames on which the three successor sets
are, at every point, either all nonempty or all empty. The canonical-model proof follows from the
standard modal existence lemma. This is only co-presence resolution—the modalities do not yet
carry the loaded internal criteria—but it is a genuine proof-theoretic starting point.

Its conservativity profile measures the present leverage exactly. The system is nonconservative
over the unconstrained three-modal fusion because it proves cross-axis co-presence formulas that
fail on finite frames with only one kind of successor. Yet it is conservative over every
single-modal fragment. Any T-only countermodel can be expanded by setting the S- and Φ-relations
equal to its T-relation, preserving the T-formula while satisfying co-presence; the same argument
runs cyclically. The backbone therefore produces new coordination theorems without yet adding a
new theorem internal to time, space, or persistence alone. Any result stated in the native
language of an established domain would require an enriched and independently justified bridge that
breaks this marginal conservativity inside that language.

## The leverage gate

An extension of the framework can earn a mathematical result only by being nonconservative over the
theory it extends, and the condition is exact. Let D be the accepted background theory in a
problem’s native language, Q the target sentence, and F a TSP extension. If $D+F$ is conservative
over D for native sentences, F cannot prove Q or its negation unless D already could. Leverage
therefore requires a nonconservative but independently justified bridge, or else a native witness or
counterexample. The bridge may be an estimate, invariant, reduction, duality, compactness argument,
or construction; metaphysical interpretation alone cannot discharge it.

The gate is worth stating on its own because the failure it describes is the tempting one. An
application that moves directly from the necessity of T, S, and Φ to a conclusion in some domain has
skipped both the mathematical profile and the bridge proof Invariant Realization requires. What
would count instead is a new invariant, a new definability result, or a new restriction on an
independently specified profile.

There is an exact test for whether such a bridge has succeeded. Let U forget a rich mathematical
model while retaining only its T-S-Φ profile, and let Q be the desired theorem, quantity, or
invariant. Q is determined at the triadic resolution exactly when it is constant across every
family of rich models having the same triadic reduct. Equivalently, Q must factor through U. If two
admissible models cast the same T-S-Φ shadow but disagree on Q, the derivation cannot be completed
from that shadow alone. The theory must refine the profile, independently exclude one model, or
add a bridge strong enough to make Q constant on the surviving family. This **Fiberwise
Determinacy Criterion** turns “keep pushing” into a proof protocol: construct the fiber, search for
a same-shadow counterexample, and, if none survives, prove constancy over the whole fiber.

The criterion also locates the present boundary. Bare relational adjacency admits different edge
lengths and different triangle angles; the real-number field supports functions with different
regularity and blowup behavior; the same state-transition graph admits different resource costs.
So trigonometric, analytic, and complexity-theoretic targets are not fixed at the thinnest triadic
resolution. Reconstruction, developed in the working research notes, has nevertheless earned a path into those subjects. With
explicit metric and Euclidean hypotheses it recovers triangles and their angles; from finite-set
isomorphism classes it recovers $\mathbb N$, then propagates by standard universal constructions
to $\mathbb Z$, $\mathbb Q$, and $\mathbb R$. What remains is not a vague lack of leverage but an
identified mathematical task: find the weakest independently defensible enrichment on which the
target becomes fiberwise constant.

The forward-and-reverse representation problem can now be solved at one formal resolution. Fix a
category of protocol contexts and admissible passages. An indexed registration assigns each
context a relational set of addressable loci, a set of record-bearers, continuation maps along
passages, and a natural occupancy map locating bearers. The Grothendieck construction turns those
assignments into two discrete opfibrations over the protocol category—one of loci and one of
bearers—with an occupancy functor between them. Taking fibers reverses the construction. For every
fixed protocol base, the indexed and fibred presentations are therefore equivalent categories,
and the equivalences commute with change of base. This **Registered-Change Representation
Equivalence** supplies an exact forward-and-back translation, with round-trip recovery up to the
appropriate natural equivalence.

The deletion tests are equally exact. There are pairs of nonisomorphic registration systems that
become isomorphic after passage structure is forgotten, pairs that collapse after the locus
relation is forgotten, and pairs that collapse after bearer transport is forgotten. Moreover, the
total bearer-history category alone does not determine the protocol base: the projection is
indispensable typing data. The resulting **Formal Three-Axis Information Theorem** establishes
that each formal component carries information the other two do not recover across the
unrestricted model class. It does not contradict Chapter 2's same-realizer cross-entailment,
because thin formal order, relation, and transport are not yet the loaded Conditions. It instead
states the remaining bridge precisely: prove that independently described concrete registration
satisfies the loaded operational assays, and that every adequate representation factors through
the triadic one.

One further universal construction identifies how much can be recovered at a chosen observational
resolution. Quotient protocol arrows, loci, and bearer continuations by indistinguishability under
all admitted registrations, provided those equivalences are congruences for composition,
relation, transport, and occupancy. The quotient is the coarsest presentation preserving every
admitted observation, and every structural map whose value depends only on those observations
factors uniquely through it. This **Maximal Observable Triadic Quotient** prevents a false uniqueness
claim: the inverse representation can recover exactly what the observational language separates,
not surplus distinctions no possible registration detects.

The inverse problem also has a standard categorical solution criterion. A system determines a
presheaf of all the ways admissible probes map into it. By Yoneda, the profile formed from all
structured probes recovers the system and its processes up to isomorphism. A restricted family of
actual probes does the same exactly when its restricted nerve is fully faithful—when the family is
**dense**. The resulting **Dense-Probe Recovery Criterion** separates three possibilities. Dense
probes give full recovery; merely faithful probes distinguish processes while possibly admitting
spurious transformations between response profiles; nonfaithful probes collapse genuinely
different processes. The open work is therefore sharper than “show that mathematics represents
reality.” It is to identify a smaller, independently motivated family of registrations—finite
paths, local interventions, occupancy tests, or record comparisons—and prove that it is dense in
the selected category of fibred change systems. Using every possible structured object as a probe
would make the Yoneda result automatic and metaphysically uninformative.

Dense-Probe Recovery and Fiberwise Determinacy answer opposite halves of the program. Density asks
whether observations recover the mathematical profile. Fiberwise constancy asks whether the
desired higher-resolution result follows from that profile. Together they give the full route:

$$
\text{registrations}
\xrightarrow{\text{dense recovery}}
\text{triadic mathematical profile}
\xrightarrow{\text{fiberwise determinacy}}
\text{target invariant}.
$$

Failure at the first arrow means the observations underdetermine the profile. Failure at the
second means the recovered profile underdetermines the result. A successful mathematical
application must close both gaps. When the probe family is dense and the target is constant on the
realization-fibers, **Observation-to-Invariant Transfer** composes the two results: the target is
determined by the registrations themselves.

The dense family can be made finite in shape. Fix a finite protocol category. An indexed triadic
presentation is then a model of a finite many-sorted finitary signature: locus and bearer sorts at
each stage, unary transport operations for each passage, a binary locus relation, occupancy maps,
and the equations for identity, composition, naturality, and relation preservation. Every such
model is assembled as the directed colimit of its finite generated diagrams. Equivalently, its
finitely presented objects form a dense subcategory. The **Finite-Probe Density Theorem** therefore
shows that a presentation—even an infinite one—and every map between presentations are determined
up to isomorphism by their responses to finite formal registered-change probes.

The required probe jobs are concrete. The categorical nerve through dimensions 0, 1, and 2
recovers stages, arrows, identities, and composition. A vertex and directed-edge probe recover a
binary relational structure. Singleton bearer probes propagated along arrows recover the bearer
sets and their transport. An occupancy atom and transition square recover incidence and its
naturality. Omission countermodels show that each job matters: two one-object categories can share
their objects, arrows, and identity while differing on $a^2=0$ versus $a^2=a$; point probes cannot
distinguish an empty relation from one containing an edge; stagewise bearer probes cannot recover
identity versus constant continuation; and the same rigid locus and bearer data can support two
different occupancy maps. This **Probe-Schema Minimality** is relative to the jobs, not to one
privileged list of probe objects—alternative dense families may perform them differently.

Forward and backward testing are not interchangeable. Incoming preparation probes use response
sets of the form $\mathcal K(a,k)$; outgoing measurements use $\mathcal K(k,b)$. Restricted
incoming probes recover systems when they are dense, while restricted outgoing tests recover them
when they are codense. One condition need not imply the other: the singleton is dense in
$\mathbf{Set}$ because maps from it select every element, but it is not codense because every set
has exactly one map to the singleton. The **Two-Sided Operational Recovery Criterion** therefore
requires preparation density and measurement codensity separately. When both hold, input-facing
and output-facing profiles independently reconstruct the same formal object, providing a genuine
forward/backward consistency test.

Finite versions are mechanically testable. In a finite candidate category, density is decidable
by checking whether each canonical map from a hom-set to the corresponding set of natural
transformations between restricted response profiles is bijective. On a finite list of rich
models, fiberwise determinacy is decidable by grouping isomorphic reducts and comparing target
values within each group. With fixed finite signatures, axioms, and cardinality bounds, all models
can be enumerated and tested for density, deletion loss, and same-shadow obstructions. This
**Bounded Adequacy Search** cannot prove an unrestricted theorem without an additional finite- or
small-model result, but every counterexample it finds conclusively defeats the proposed universal
claim.

The base signature nevertheless supports one unbounded promotion. Let T be a universal theory in
the transport–relation–occupancy signature over a fixed finite protocol category, and let Q be a
universal target sentence. If Q fails in any model of T, its failure has finitely many witnesses.
The substructure generated by those witnesses is finite: every string of transports reduces to a
single arrow of the finite base, and occupancy followed by transport reduces by naturality. Since
universal theories survive passage to substructures, the finite generated structure is still a
model of T and still refutes Q. The **Universal Triadic Finite-Countermodel Theorem** follows: every
failed universal consequence in this fragment has a finite countermodel within a computable
witness-generated bound. Consequently, entailment of universal Q from finite universal T is
decidable by bounded finite enumeration. Existential totality, unrestricted modal, higher-order,
analytic, and infinite-base enrichments remain outside this result and require separate
finite-model arguments.

The decision result exposes a principled limit that mirrors the Bilateral Frame. Universal axioms
are preserved under substructures, so they naturally express the preclusion or safety arm:
transport never violates occupancy, relations are preserved, and forbidden reversals or collapses
do not occur. Positive adequacy is different. Requiring a nontrivial passage, distinct related
loci, an existing continuation, or a global amalgamation has existential or liveness force, and
the witness can disappear in a substructure. The **Existential Adequacy Barrier** follows: no
universal theory can characterize an intended class that is not closed under substructures. The
resulting **Bilateral Logical Split** explains why the decidable universal fragment can settle
unbounded prohibition claims while leaving the permission arm to a stronger logic. A universal
safety theory alone may admit the empty or frozen structures Chapter 2 explicitly excludes.

Part of the positive arm is nevertheless decidable. Add finitely many quantifier-free
existential requirements to the universal safety theory: a bearer exists, two loci differ, a
relation is realized, a descriptor changes, or a specified finite registration diagram occurs.
If the combined theory has any model, retain one tuple witnessing each permission and close those
witnesses under the finitely many typed base transports and occupancy maps. The closure is finite,
still satisfies every universal preclusion, and retains every selected witness. The **Witnessed
Bilateral Small-Model Theorem** follows, with the same explicit orbit bound as the universal case.
Satisfiability and both universal and existential consequence are therefore decidable for this
universal-plus-finite-witness fragment.

Some open-ended liveness can also be admitted. Skolemize a finite family of
$\forall\bar x\exists y$ requirements. If the typed witness functions always move to a strictly
higher component of a finite rank, while the original structural operations do not decrease rank
and have finitely many within-rank normal forms, nested witness production has bounded depth. The
generated closure is finite. This **Ranked Liveness Small-Model Theorem** and its decision procedure
cover finite-horizon continuation, finite refinement hierarchies, and fixed-cover gluing whose
witnesses move upward without feeding a new demand back into their own rank.

The boundary is exact. An irreflexive transitive relation with
$\forall x\exists y\,(x<y)$ has infinite models such as $\mathbb N$ under $<$ but no nonempty
finite model. Repeatedly choosing a greater element in a finite set produces a strict cycle and,
by transitivity, $x<x$. The **Strict-Liveness Infinity Obstruction** explains why typed
continuation along available arrows is consistent while global strict continuation at every stage
is not. Chapter 2 requires a bearer through the registered transition; it does not require every
bearer to persist through every unavailable future passage. The resulting **Bilateral Finite
Satisfiability** theorem combines universal safety with finite witnesses or acyclic ranked
liveness without leaving decidability.

Existence alone still does not earn a canonical persistence map. If a definable continuation
relation satisfies $\forall x\exists!y\,W(x,y)$, the unique witness function commutes with every
automorphism: applying an automorphism to $W(x,s(x))$ produces a witness for the transformed input,
and uniqueness identifies it with $s(\alpha x)$. **Unique-Witness Naturalization** therefore turns
relational liveness into invariant Φ-like transport without an arbitrary choice. Conversely, if
the stabilizer of an input permutes its admissible witnesses without a fixed point, no
automorphism-invariant selector exists. The **Symmetric-Witness Obstruction** leaves branching or
relational transport intact while blocking a canonical persistence function. Additional structure
must break the symmetry or supply an invariant fixed point.

Geometry supplies a concrete instance. In a uniquely geodesic metric space, every pair of points
has one constant-speed geodesic, and every isometry must carry that path to the unique path between
the transformed endpoints. **Unique-Geodesic Naturalization** therefore produces canonical
isometry-natural transport: metric relation supplies the endpoints and length, the unit interval
orders the path, and the curve carries the represented point. Antipodal points on a circle provide
the backstop. Reflection fixes the endpoints while swapping the two minimizing semicircles, so no
isometry-invariant rule selects one without orientation or other symmetry-breaking data. Distance
and the unordered path-pair are earned; a preferred traversal is not.

Recurrent liveness admits a different extension. In a relational transition model, least fixed
points recover finite reachability and greatest fixed points recover invariant safety or
indefinite continuation. On a finite graph,
$\nu X.\langle a\rangle X$ holds exactly at states that can reach a directed cycle. A nested
least/greatest fixed point similarly characterizes paths on which a marked condition recurs. The
result does not identify a cycle with infinitely many distinct moments. A one-state self-loop and
an infinite one-way chain carrying the same labels are bisimilar, so no modal mu-calculus formula
distinguishes them. This **Cycle–Infinity Indistinguishability** is the backstop: fixed points can
say that transition remains indefinitely available, not that every stage is new.

On an n-state model, the non-nested reachability, safety, and liveness calculations stabilize
after at most n strict approximation changes: an ascending least-fixed-point sequence can add each
state once, and a descending greatest-fixed-point sequence can remove it once. This **Finite
Approximation Bound** makes the basic registered regions directly computable, while leaving the
complexity of nested alternation to the general mu-calculus algorithms.

The interaction claim must also be stated jointly. A root can lead to a T-cycle, a separate
S-cycle, and a separate Φ-cycle while possessing no registered edge at all. Each axis is then live
and registered change is not. The **Joint-Liveness Obstruction** proves that three independent
seriality claims cannot replace a same-transition bridge. Introduce a primitive registered
relation only for edges already certified to carry passage, locus/occupancy structure, and bearer
lift together. Its least and greatest fixed points then compute registered reachability, safety,
liveness, and recurrence without pretending that relation intersection is available in the basic
modal language.

Cycles also yield exact bearer results. Transport around a base loop gives monodromy
$h:B(c)\to B(c)$. On a finite fiber every h-orbit is eventually periodic; if h is injective, it is
a permutation and every bearer is periodic from the start. With locus monodromy g and natural
occupancy $o h=g o$, bearer return always entails locus return. Locus return entails bearer return
when occupancy is injective on the bearer orbit; without injectivity, two bearers may occupy the
same locus while swapping or merging. **Occupancy Period Preservation** and **Occupancy Period
Reflection** thus identify exactly when spatial recurrence carries substantial recurrence.

These relational fixed-point formulas remain inside the established multimodal mu-calculus, whose
satisfiability problem has finite/small-model results and is EXPTIME-complete
([Kozen](https://research.ibm.com/publications/results-on-the-propositional-m-calculus);
[Emerson and Jutla](https://epubs.siam.org/doi/10.1137/S0097539793304741);
[Bradfield and Stirling](https://www.research.ed.ac.uk/en/publications/modal-mu-calculi/)). The
inheritance is exact only while T, S, Φ, and registered transition are a fixed finite relational
signature. Equality-sensitive bearer variables, intersected modalities, hybrid names, counting,
metric constraints, fiber quantification, and descent require new finite-model and decision
proofs.

There is a sharper identity boundary inside that modal fragment. Compare a root whose single
terminal successor is reached by T, S, and Φ with a root having three separately reached terminal
successors. Relating the common successor to each split successor gives a multimodal bisimulation.
The first root has a shared witness and the second does not, so **Same-Successor
Inexpressibility** follows: not even modal fixed points define the existence of one endpoint shared
by all three relations. Categorically, the distinction is between nonemptiness of the ordinary
product $T_x\times S_x\times\Phi_x$ and nonemptiness of the pullback
$T_x\times_W S_x\times_W\Phi_x$. The latter is the diagonal-witness condition.

That diagonal still identifies only an endpoint. In an edge-sorted model, one edge bearing all
three role predicates and three role-specific parallel edges with the same source and target have
identical thin relational reducts. Only the first has one transition-token carrying all three
roles. **Edge-Token Nonrecoverability** therefore marks a second strict boundary: separate
successors, a common endpoint, and a common transition-token are progressively stronger. The
last requires retained arrows, an edge sort, or an independently certified registered-transition
object; it cannot be recovered from endpoint relations alone.

At the thin relational resolution, introducing
$R_{\mathrm{reg}}(x,y)\leftrightarrow(R_T(x,y)\land R_S(x,y)\land R_\Phi(x,y))$ is a conservative
definitional extension: every base structure has one expansion and every enriched formula can be
translated back by substitution. **Naming–Existence Separation** then identifies the substantive
step. The definition adds no old-language theorem; the assertion
$\exists x\exists y\,R_{\mathrm{reg}}(x,y)$ adds exactly the common-successor existence claim. A
finite collection of such witnesses remains in the previously established decidable witnessed
fragment, while occupancy injectivity remains universal and preserves bearer-period reflection.
None of this proves that thin intersection exhausts the book’s loaded notion of one realizer. In
particular, same-endpoint intersection does not entail same-transition-token identity without a
thinness premise. That bridge still has to be justified in the enriched semantics.

Hybrid state names can express what ordinary modal fixed points miss: a successor may be named,
evaluation returned to the root, and the other modalities required to reach that very name. They
can likewise compare an iterated successor with a named starting state and state exact finite
period. Counting T-, S-, and Φ-successors separately cannot perform this recovery: the common and
split models have the same count on each axis. These are expressivity results only. No
finite-model or complexity theorem for an arbitrary hybrid, graded, fixed-point combination is
claimed.

The same-realizer direction becomes sharper when registered occurrence is modeled globally rather
than reconstructed from three projections. Let
$R\subseteq\mathcal T\times\mathcal S\times\mathcal F$ record temporal, spatial, and bearer
values occurring together. Form the natural join $J(R)$ of its three pairwise projections. The
**Pairwise-Join Closure Theorem** says that J is an extensive, monotone, idempotent operation;
$J(R)$ has exactly R’s pairwise projections and is the largest ternary relation compatible with
them. The defect $\Delta_2(R)=J(R)\setminus R$ is empty exactly when the pairwise decomposition is
lossless.

Pairwise data do not force that condition. On three binary coordinates, the even- and odd-parity
relations are disjoint, have equal cardinality, and have identical full pairwise projections. In
each relation any two values uniquely determine the third. Thus **Pairwise-Shadow
Nonrecoverability** survives cardinality information and pair-to-third functional dependence. The
construction extends to n coordinates: opposite parity classes have identical projections onto
every proper coordinate subset. Higher-order co-instantiation can therefore be invisible in every
lower-arity shadow.

There is nevertheless an exact finite existence test. Given proposed T–S, T–Φ, and S–Φ relations,
take their common join K. A ternary relation having exactly those projections exists if and only if
each projection of K returns the corresponding supplied relation—equivalently, every supplied
pair extends to at least one compatible triple. This **Pairwise-Realizability Criterion** decides
global compatibility, but it does not select which compatible triples are actual occurrences.

Occurrence identity requires one further level. Introduce a key set E and role maps
$\tau:E\to\mathcal T$, $\sigma:E\to\mathcal S$, and $\varphi:E\to\mathcal F$. Joining the three
graph relations on the common key reconstructs the complete E-indexed record exactly. Forgetting E
retains only the image ternary relation and preserves token identity precisely when
$(\tau,\sigma,\varphi)$ is injective. **Keyed Registration Reconstruction** consequently separates
pairwise loss of three-way interaction from tuple-level loss of occurrence multiplicity.
Quotienting E by equality of all three role-values canonically recovers that image and is universal
among maps that identify coordinate-equivalent occurrences. **Canonical Extensionalization**
therefore specifies exactly what the three roles can reconstruct while leaving open whether two
coordinate-indistinguishable occurrences are numerically one.

The join machinery is established database theory, where join dependencies characterize lossless
decomposition
([database reference](https://doi.org/10.1016/0306-4379(94)90016-7)). The neighboring
local-to-global literature is the sheaf-theoretic analysis of contextuality, where obstruction to
a global section is central
([Abramsky and Brandenburger](https://arxiv.org/abs/1102.0264)). No novelty is claimed for those
theories. The proposed TSP contribution is to make the metaphysical same-realizer requirement
select a keyed global occurrence as primary and to demand a representation theorem showing that
independently characterized registrations admit such presentations invariantly.

Projection and recombination support a sharper representation result. Order ternary relations by
inclusion and order triples of pairwise relations componentwise. If $\Pi$ sends a global relation
to its three pairwise projections and K sends three pairwise relations to their natural join, then

$$
\Pi(R)\le A
\quad\Longleftrightarrow\quad
R\subseteq K(A).
$$

Thus **Projection–Globalization Adjunction** holds: $\Pi\dashv K$. The composite $K\Pi$ is the
pairwise-join closure on global relations, while $\Pi K$ is an interior operator returning the
largest part of the supplied pairwise data in which every pair extends to a compatible triple.

The fixed points give an exact **Pairwise–Global Fixed-Point Equivalence**. Losslessly
pairwise-decomposable global relations and fully extendable pairwise presentations are
order-isomorphic under projection and join. This is the precise domain on which the two
representations are interchangeable. Parity relations fall outside it; their three-way
interaction is exactly the obstruction to the equivalence’s unrestricted extension. A tuple in
$K\Pi(R)\setminus R$ is a finite certificate that unconstrained pairwise rejoining fails to
recover R.

Token-sensitive presentations have a parallel exact form. An occurrence set E with three role
maps is, by the product universal property, exactly a map
$E\to\mathcal T\times\mathcal S\times\mathcal F$. Hence keyed TSP presentations form the slice
category $\mathbf{Set}/(\mathcal T\times\mathcal S\times\mathcal F)$. Image factorization records
the loss incurred by passing from keyed occurrences to the unkeyed ternary relation. This is an
elementary **Keyed Presentation Equivalence**, but it identifies the category in which a future
adequacy theorem must land.

The equivalence is stable under faithful changes of coordinates and unstable under arbitrary
aggregation. Coordinatewise injections commute with pairwise closure. For arbitrary
coarse-graining q, only

$$
q\[K\Pi(R)]\subseteq K\Pi(q[R])
$$

is guaranteed, and the inclusion can be strict. Three fine tuples mapping to $(0,0,1)$,
$(0,1,0)$, and $(1,0,0)$ generate the spurious coarse tuple $(0,0,0)$ on rejoining, even when the
fine relation was lossless. Conversely, collapsing a parity relation to singleton coordinates
erases its defect. **Coarse-Graining Artifact** therefore requires every empirical application to
distinguish faithful representation from resolution-losing observation.

The candidate originality-bearing theorem is now specific: independently characterize a category
of concrete registrations and construct a faithful functor from it into the keyed slice category
which reflects occurrence equivalence and is invariant, up to natural isomorphism, across every
admissible formal presentation. The join adjunction and keyed equivalence are established
mathematical leverage, not the proposed novelty. The hard new content would be deriving the source
category and admissible maps from Chapter 2 without defining them by the desired conclusion.

Local registration supplies a further exact test. On a category of observational contexts with
admitted covers, let a presheaf assign records to contexts and restriction maps to refinements.
Compatible local records determine one global record precisely when the familiar sheaf diagram is
an equalizer. The **Registered Descent Criterion** separates two failures: if restriction is not
injective, distinct global histories look identical in every local context; if a compatible local
family is not in its image, all overlap checks pass but no global bearer realizes the records.
This is a mathematically substantive interaction of locality, comparison, and persistence, but
the sheaf condition is an additional bridge principle, not something obtained from the label
*Substantiality*. Cohomological obstructions become available only after a suitable group-,
torsor-, or abelian-valued registration theory has been independently justified.

## What success would be

The first success is a precise formal failure. A proposed semantics may reveal that Spatiality has
been defined too weakly, that persistence was imported through the identity relation, or that the
three roles translate into one another under every natural morphism. Such a result would identify
where the philosophical distinctions need more work.

The next success is a formal theory with nontrivial models, independent axioms, and a sound
calculus. It would place the backbone inside mathematics even before completeness or a universal
representation theorem had been reached.

A stronger success is a theorem showing that independently specified change-bearing structures
admit a faithful triadic representation and that forgetting any limb loses essential inferential
content. That would be the mathematical counterpart of the Structural Requirement and Sufficiency
of Structure.

The strongest structural result is universal factorization plus definability completeness: every
adequate formalization of genuine change preserves the three roles, and every further universally
necessary existence-axis is definable from or factors through them. That would turn No Fourth
Condition from a burden placed on alternatives into a theorem inside a formal system.

The widest foundational result is a realizability theorem: necessary and sufficient
conditions separating a merely modeled mathematical profile from one admitting a really possible
concrete realization. A proof that no criterion of the proposed kind can decide that boundary
would be a different foundational result rather than an empty return.

The strongest reconstructive result would show that substantial regions of mathematics arise as
invariant articulations of the triad, with their defining structures recovered rather than merely
encoded. It need not derive every branch of mathematics to establish a common foundation for
order, relation, identity, transformation, proof, and computation.

Whether the resulting theory is conservative then decides the generative question. If it is
conservative, the book has given mathematics a metaphysical ground and perhaps a new unification:
an account of why consequence is real and why proved invariants bind their realizations. If it is
nonconservative for independently defensible reasons, it has also given mathematics a new source
of theorem. A domain application reaches the final grade only when one of those new consequences
crosses an explicit bridge into an existing mathematical problem.

The hierarchy therefore ends in four different maxima: exhaustiveness of the structural floor,
characterization of real possibility, reconstruction of mathematical form, and genuinely new
theorems. None can be borrowed from another. Together they state the full reach of the question
opened here: not only why mathematics works, but how much of mathematics follows from the
structure that makes any working, proving, or realization possible at all.


---

← [Appendix D: Empirical Predictions](Appendix%20D%20-%20Empirical%20Predictions.md) | [Appendix F: Formal Results](Appendix%20F%20-%20Formal%20Results.md) →
