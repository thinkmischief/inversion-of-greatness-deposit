> [!diagnostic]
> **Analogy Enlists the Structure It Was Built to Avoid** · *Diagnostic*
>
> Analogical predication needs a constitutive relation between attribute and bearer on the divine side, or the proportion isn’t a proportion *of* anything—and strong simplicity has factored exactly that relation out at the divine pole. The causal grounding analogy rests on is itself structurally constituted: asymmetric production, distinct cause and effect, a productive act carried across the distinction. Those are role-level demands, not yet clock-time, metric space, or physical transmission. So the device preserves the predicates by recruiting, at the level of its own grounding, the structure it was introduced to let the subject do without. It doesn’t fail by saying too little. It succeeds only by quietly requiring what it denies.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [§11.8.3 — 11.8.3 Describability](../../11.%20Reclaiming%20Greatness/11.8.3%20Describability.md).
