> [!principle]
> **Bilateral Frame** · *Principle*
>
> The modal constraint is identified by its bilateral work: a constraint that only permits is a permission, not yet a constraint on change. Any account that underwrites possibility without equally underwriting impossibility has not described the modal constraint. This is not merely a requirement later premises must satisfy. It is the method by which the invariant constraint is identified with T∧S∧Φ. There is no shortcut through possibility alone.

Stated at [§2.1.2 — Bilateral Frame](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.2%20Bilateral%20Frame).
