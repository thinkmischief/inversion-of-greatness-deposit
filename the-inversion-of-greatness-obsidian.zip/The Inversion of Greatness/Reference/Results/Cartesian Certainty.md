> [!premise]
> **Cartesian Certainty** · *Premise*
>
> Change is really possible. No denial can escape it: the act of doubting that anything changes is itself a change, from not-doubting to doubting. ◇C.

Stated at [§2.2 — 2.2 Cartesian Certainty](../../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md).

## Glossary

*Concept.* The indubitable certainty that change is possible (◇C): to doubt it is already to change one’s epistemic state, so the denial is self-refuting. The Cartesian fixed point of the argument, its premise Cartesian Certainty ([[2.2 Cartesian Certainty|§2.2]]), reformulated as *cogito ergo muto*. Lifted to its necessitated form—the [[Necessary Possibility of Change]] (□◇C)—by the Necessary Possibility theorem. *See* Performative Self-Refutation; Necessary Possibility of Change. Established in [[2.2 Cartesian Certainty|§2.2]].
