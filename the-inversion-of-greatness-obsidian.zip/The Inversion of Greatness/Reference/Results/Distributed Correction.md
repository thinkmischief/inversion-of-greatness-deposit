> [!theorem]
> **Distributed Correction** · *Theorem*
>
> Democracy’s first function is not the periodic aggregation of preferences but the continuing correction of a shared public model by those living under its consequences. Representation supplies direction, information makes conditions visible, plural institutions test competing descriptions, and public review allows an arrangement to revise itself when its first account fails. Exclusion, censorship, opacity, and capture are therefore not merely procedural defects. They damage the polity’s capacity to learn what it is doing to its own members.
>
> **Depends on:** [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]]) and [[Modal Convergence]] ([[5.4 Knowledge|§5.4]])

Stated at [§6.14 — 6.14 Convergence](../../6.%20Maximum%20Possibility/6.14%20Convergence.md).

## Glossary

**R27** · *Theorem.* Democracy’s first function is not periodic preference aggregation but continuing public correction: representation supplies direction, public information makes conditions visible, plural institutions test competing descriptions, and review enables revision when an arrangement’s first account fails. Exclusion, censorship, opacity, and capture therefore damage a polity’s capacity to learn what it is doing to those it governs. Established in [[6.14 Convergence|§6.14]].
