> [!theorem]
> **Exclusivity of Nature** · *Theorem*
>
> The necessary structural ground of any concrete change-realizer is uniquely T, S, and Φ together. Any proposed alternative *for that role* is either (i) functionally equivalent to T, S, and Φ, in which case it is structure under another description, or (ii) genuinely unable to supply the full Conditions, in which case it cannot ground concrete change-realization. A zero-content candidate is ∅; a thinly or analogically structured candidate is not thereby ∅, but inherits the independent burden of showing how its claimed grounding role reaches concrete change without reinstantiating the Conditions. Nature is not one change-ground among structural competitors. Nor does declining that role secure an outside: any real coexistent belongs to Reality and therefore, by the *Reality–Nature Identity*, to Nature. Chapters 10 and 11 test whether particular necessary-being descriptions remain coherent within that exhaustive identity.

Stated at [§2.9.7 — Exclusivity of Nature](../../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.7%20Exclusivity%20of%20Nature).

## Glossary

*Theorem.* Candidate grounds already specified within the modal domain cannot ground that domain externally: if they instantiate the relevant structural roles, they do not stand outside them. A proposal withdrawing all determinate relation faces an ∅-like specification problem. This theorem alone does not decide Finean explanatory priority; the downstream [[No Unconditioned Essence]] result combines it with Reality–Nature Identity, Essence-Description, and Way–Possibility Convertibility to close essence as a structurally prior or additional source. Established in [[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]; completed for essence-priority at [[7.2.1 The Source of Possibility|§7.2.1]].
