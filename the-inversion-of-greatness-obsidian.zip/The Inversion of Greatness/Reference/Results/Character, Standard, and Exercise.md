> [!diagnostic]
> **Character, Standard, and Exercise** · *Diagnostic*
>
> Moral predicates don’t all have one grammar. They may describe character, disposition, standard, agent, institution, state of affairs, or manner of acting. Concrete claims that God commands, judges, forgives, protects, permits, or responds are actional and relational; they incur the conditions of those exercises. Claims about perfect character or an unchanging disposition need not describe a transition, but they owe a value standard, counterfactual profile, and relation to actual conduct. The section must keep bearer, standard, disposition, and exercise apart rather than deriving them all from an adverb.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [§11.9.1 — 11.9.1 Benevolence](../../11.%20Reclaiming%20Greatness/11.9.1%20Benevolence.md).
