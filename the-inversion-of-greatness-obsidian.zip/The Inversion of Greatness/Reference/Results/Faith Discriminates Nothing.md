> [!dissolution]
> **Faith Discriminates Nothing** · *Dissolution*
>
> Where faith is invoked as an independent warrant for what the evidence doesn’t warrant on its own, it must discriminate among candidates. Adherents of mutually exclusive traditions reach their own conclusions by a method described in the same terms and with the same sincerity, so the method alone doesn’t select among them. Either faith independently warrants a particular conclusion, in which case a discriminating account is still owed; or it is commitment downstream of grounds already had, in which case the grounds do the discriminating and faith cannot carry a belief the grounds are admitted not to support.
>
> **Dissolves:** faith as an independent warrant for belief
>
> **Depends on:** [[The Explanatory Burden]] ([[12. Exodus|§12]])

Stated at [§12.3.7 — 12.3.7 Faith and Belief](../../12.%20Exodus/12.3.7%20Faith%20and%20Belief.md).
