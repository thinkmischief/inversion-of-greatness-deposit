> [!right]
> **Fair Trial** · *Right*
>
> A fair trial requires meaningful notice, an opportunity to understand and answer the case, adequate assistance, an impartial decision-maker, and review appropriate to the stakes. Pretrial detention, police encounters, crisis response, and use of force are governed by related but stage-specific protections: lawful grounds, necessity, proportionality, communication where feasible, and remedy. They share the standing of the person subjected to authority; they are not all instances of the trial right.
>
> **Depends on:** [[Morality]] ([[5.14 Morality|§5.14]]), [[Will]] ([[5.11 Will|§5.11]]), and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.12 — 6.12 Enforcement](../../6.%20Maximum%20Possibility/6.12%20Enforcement.md).
