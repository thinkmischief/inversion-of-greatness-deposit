> [!proposition]
> **Bearer-Neutrality of Substantiality** · *Proposition*
>
> Substantiality is a role, not a kind of stuff. The dissolution of the matter/energy dichotomy—conservation of energy, the field as a first-class entity alongside matter, mass–energy equivalence—bears on what *realizes* the role, not on whether the role is required. Whatever the carrier turns out to be made of, something must carry: what obtains in one state has to be borne into the next. Rest mass, fields, particles, and dynamical energy may realize that function in different physical theories, and the argument identifies Φ with none of them.
>
> *Scope.* An interpretive proposal at realization tier, not a result extracted from mass–energy equivalence. That equivalence doesn’t settle whether matter and energy are identical, two ontological categories, or two aspects of a deeper ontology, and nothing here needs it to.
>
> **Depends on:** [[Cross-Interval Persistence]] ([[2.4 Structural Requirement#2.4.8 Exchange Requires Substantiality|§2.4.8]])

Stated at [[4.4 Substance|§4.4 Substance]].
