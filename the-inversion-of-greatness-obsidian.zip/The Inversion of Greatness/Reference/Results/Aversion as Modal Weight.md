> [!corollary]
> **Aversion as Modal Weight** · *Corollary*
>
> Aversion may answer a present state of affairs, but it can also persist as a standing weight against that state’s continuation, worsening, or recurrence. In its anticipatory and dispositional forms, it weights represented branches even when the object is absent. Modal weight is therefore one genuine form of aversion, not the exhaustive form of every drive-state.
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]) and [[Parasitic Negation]] ([[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]])

Stated at [§5.2 — 5.2 Drive](../../5.%20Expanding%20the%20Field/5.2%20Drive.md).

## Glossary

*Corollary of [[Drive]].* Drive at either pole is directed at a branch rather than at a state of affairs: a being is averse not to the injury already sustained but to its continuing, worsening, or recurring, and the aversion persists through stretches in which nothing occurs. A drive-state is therefore a standing weight on a line the being holds as available, not an occurrent response to what is present. Three consequences: the modal field is required at the chapter’s floor rather than introduced at [[5.4 Knowledge|§5.4]]; aversion to a really impossible outcome is empty rather than small, since impossibility does not vary ([[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]]), making it a mapping failure wearing the phenomenology of a stake; and a weight can be borne without being felt, which is what lets a wrong go unnoticed ([[5.14 Morality|§5.14]]). The result fixes the *form* of a drive-state only—not the accuracy of a being’s weights, nor whether what it is averse to is actually available to it. Established in [[5.2 Drive|§5.2]].
