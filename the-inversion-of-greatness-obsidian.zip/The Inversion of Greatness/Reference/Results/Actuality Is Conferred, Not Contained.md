> [!proposition]
> **Actuality Is Conferred, Not Contained** · *Proposition*
>
> Each abstract form privileges the actual world by a relation of its own: for a world-story, that every proposition in the maximal consistent set is true; for a maximal property, that Reality has it; for a maximal state of affairs, that it obtains. In none of the three does the privilege come from a feature of the surrogate. What makes the set true, the property had, or the state of affairs obtain is how Reality stands. Actuality is therefore conferred on the apparatus from outside rather than found within it. The ersatzist supplies a semantics for modal talk and inherits, rather than displaces, whatever Reality must be for one set to come out true.
>
> **Depends on:** [[Reality–Nature Identity]] ([[2.8 Reality–Nature Identity|§2.8]])

Stated at [[7.2.4 Linguistic Ersatzism|§7.2.4 Linguistic Ersatzism]].
