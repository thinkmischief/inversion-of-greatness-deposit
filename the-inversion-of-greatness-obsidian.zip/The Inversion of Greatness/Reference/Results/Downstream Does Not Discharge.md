> [!theorem]
> **Downstream Does Not Discharge** · *Theorem*
>
> Every domain that maintains a condition of participation runs the same three layers: prevention of the conditions upstream of breakdown, repair when prevention fails, and reintegration of the affected party. The layering is not borrowed between domains but falls out of the recognition obligation in each, which is why it recurs without being copied. Two consequences follow, and they are what the rest of the chapter leans on. First, an intervention that suppresses, manages, or conceals the visible expression of an unmet condition does not thereby discharge the obligation that condition created: the obligation is owed to the person whose condition it is, and it remains owed whether or not the expression is still visible. Second, resources committed downstream are not committed upstream, so arrangements must be compared across the whole layered structure rather than at the point where breakdown becomes visible. The priority is presumptive rather than absolute. Which layer a given case belongs to is settled by comparative evidence, feasibility, proportionality, and burden distribution, on the terms the §6 root’s prevention presumption states, and a prevention that is ineffective, disproportionate, or more burdensome than the repair it displaces does not earn the presumption.
>
> **Depends on:** [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.14 — 6.14 Convergence](../../6.%20Maximum%20Possibility/6.14%20Convergence.md).

## Glossary

*Theorem.* Every domain maintaining a condition of participation runs the same three layers—prevention of the conditions upstream of breakdown, repair when prevention fails, and reintegration of the affected party. The layering is not borrowed between domains but falls out of the recognition obligation in each, which is why it recurs without being copied. Earned at [[6.14 Convergence|§6.14]].
