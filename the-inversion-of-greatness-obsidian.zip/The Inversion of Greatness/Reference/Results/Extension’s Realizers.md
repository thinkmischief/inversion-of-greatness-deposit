> [!lemma]
> **Extension’s Realizers** · *Lemma*
>
> Real relational extension is biconditional with directed succession and persistent bearing: S ↔ (T ∧ Φ). The S entering the pivot is the S-role the theorem spends: concrete, occupiable, exclusive extension, the extension of media, rather than any static or merely representational surrogate.
>
> **Depends on:** [[Relational Distinctness]] ([[2.4 Structural Requirement#2.4.7 Distinction Requires Spatiality|§2.4.7]])
> **Feeds into:** [[Mutual Containment]] ([[2.6 Triconditionality of Nature#2.6.5 Mutual Containment|§2.6.5 Mutual Containment]])

Stated at [§2.6.3 — Extension’s Two Conditions](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.3%20Extension%E2%80%99s%20Two%20Conditions).

## Glossary

*Lemma.* Real relational extension is biconditional with directed succession and persistent bearing: S ↔ (T ∧ Φ). The S entering the pivot is the S-role the theorem spends—concrete, occupiable, exclusive extension, the extension of media—rather than any static or merely representational surrogate. Earned at [[2.6 Triconditionality of Nature|§2.6]].
