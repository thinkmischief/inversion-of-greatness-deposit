> [!proposition]
> **A Mirrorable Defense Discriminates Nothing** · *Proposition*
>
> The evil-god challenge begins from a hypothesis almost everyone rejects—that the world is the work of a wholly malevolent creator—and observes that such a creator faces a *problem of good* mirroring the believer’s problem of evil, answerable by mirror images of the same defenses. What the mirroring establishes is a constraint on what a defense can accomplish. A defense that runs equally well for an evil creator cannot by itself establish a good creator’s moral character, however successful it is at its own stated task of blocking an incompatibility charge. Defeating the charge that God and evil are logically incompatible is one achievement; discriminating a good creator from a malevolent or indifferent one is another, and the familiar theodicy forms are not shown to deliver the second by delivering the first.
>
> *Scope.* The result is about what theodicies can settle, not a demonstration that the world is indifferent, and the symmetry argument is not offered as conclusive. A defender may identify genuine asymmetries in value, agency, revelation, or the evidence; the standing demand is that such asymmetries be independently defended rather than assumed, since assuming them is what the challenge exists to expose.
>
> **Depends on:** [[The Explanatory Burden]] ([[12. Exodus|§12]])

Stated at [[12.5.6 Evil God Redux|§12.5.6 Evil God Redux]].
