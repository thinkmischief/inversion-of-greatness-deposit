> [!premise]
> **Bounded Productive Range** · *Premise*
>
> Along any order-unbounded history-segment whose productive gradients are neither internally maintained nor renewed, usable gradients don’t traverse an unbounded effective range, and a bounded asymptotic range doesn’t contain infinitely many physically distinguishable productive macrostates. The premise applies in either temporal direction. Together with [[Endless Productive Continuation]], it closes the first two limbs of the Gradient Exhaustion Fork toward the future, leaving recurrence or continuous occupancy of a bounded productive macrocondition. Applied to an actually occupied productive phase with no earliest state and no internal maintenance or renewal, it excludes that phase’s running through the whole predecessor order.

Stated at [§4.6.5 — Conclusions](../../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.5%20Conclusions).

## Glossary

*Premise.* Nature’s usable gradients don’t increase through an unbounded effective range, and a bounded asymptotic tail doesn’t contain infinitely many physically distinguishable productive macrostates. With [[Endless Productive Continuation]], it closes the ever-novel limbs of [[The Gradient Exhaustion Fork]], leaving recurrence or continuous occupancy of a bounded productive macrocondition. Stated at [[4.6 Singularity#4.6.5 Conclusions|§4.6.5]].
