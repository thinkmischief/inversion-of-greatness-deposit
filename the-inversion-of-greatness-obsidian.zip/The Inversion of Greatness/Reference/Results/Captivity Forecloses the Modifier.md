> [!proposition]
> **Captivity Forecloses the Modifier** · *Proposition*
>
> A permitted relation requires consent that is informed, voluntary, competent, specific, and revocable; absent those conditions, a form of authorization is another party’s rule imposed through the grammar of permission, not the subject’s own. The captive-marriage provisions regulate the soldier’s procedure and the timing of his access without consulting the woman’s state at any point, so the textual conditions for a permitted relation are absent on the text’s own account—independent of whether the ban that produced the captivity was itself justified.
>
> **Depends on:** [[Consent’s Conditions]] ([[5.14 Morality|§5.14]]); [[Consent as Right Modifier]] ([[6.1 Rights|§6.1]])

Stated at [[12.4.3 Divinely Commanded Evil|§12.4.3 Divinely Commanded Evil]].
