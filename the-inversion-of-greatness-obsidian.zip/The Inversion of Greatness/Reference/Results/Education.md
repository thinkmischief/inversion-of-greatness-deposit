> [!right]
> **Education** · *Right*
>
> Participation is unavailable to subject $s$ without cultivated capacity to model the polity: $\neg Reach_s(participation \land no\ cultivated\ capacity)$. That capacity includes what is possible, what is necessary for what, and how to navigate. Reasoning’s catch and thin will are already running; education densifies the field. Curriculum and provider stay open.
>
> **Depends on:** [[Morality]] ([[5.14 Morality|§5.14]]), [[Knowledge]] ([[5.4 Knowledge|§5.4]]), and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.9 — 6.9 Education](../../6.%20Maximum%20Possibility/6.9%20Education.md).
