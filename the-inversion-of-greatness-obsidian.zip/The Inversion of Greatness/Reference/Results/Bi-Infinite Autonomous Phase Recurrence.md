> [!corollary]
> **Bi-Infinite Autonomous Phase Recurrence** · *Corollary*
>
> Let $\langle p_n\rangle_{n\in\mathbb Z}$ be a two-sided phase-history over a finite set $P$, with $p_{n+1}=F(p_n)$ for one time-independent successor function $F:P\to P$. Then there is an integer $m>0$ such that $p_{n+m}=p_n$ for every integer $n$. No occupied transient is possible. If the history contains the three distinct phase-types in the actual ordered half-cycle $C\rightarrow K\rightarrow E$, then $m\geq3$ and that half-cycle returns without end in both directions; its next phases necessarily include a later return from $E$ to $C$.
>
> **Depends on:** two-sided serial closure; [[Finite-Past-Depth Recurrence]] and [[Finite Autonomous Phase Dynamics]]; the actual half-cycle secured conditionally by [[Dominance-Scale Bidirectional Capacity]] ([[4.6 Singularity#4.6.5 Conclusions|§4.6.5]])

[[Invariant Realization]] and [[Strict Actualization]] transfer the finite-map result to any actual physical realization of the complete profile; they don’t establish that the universe realizes it. Stated at [[4.6 Singularity#4.6.5 Conclusions|§4.6.5]].

[[Relational Phase Closure]] supplies the required two-sided phase-history from relationally complete Total Phase Quotient once the three-cycle map is fixed. No-first-state alone does not: a single first phase could otherwise contain a firstless infinity of states.
