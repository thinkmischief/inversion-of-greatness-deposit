> [!corollary]
> **Bi-Infinite Autonomous Phase Recurrence** · *Corollary*
>
> Let $\langle p_n\rangle_{n\in\mathbb Z}$ be a two-sided phase-history over a finite set $P$, with $p_{n+1}=F(p_n)$ for one time-independent successor function $F:P\to P$. Then there is an integer $m>0$ such that $p_{n+m}=p_n$ for every integer $n$. No occupied transient is possible. If the history contains the three distinct phase-types in the actual ordered half-cycle $C\rightarrow K\rightarrow E$, then $m\geq3$ and that half-cycle returns without end in both directions; its next phases necessarily include a later return from $E$ to $C$.
>
> **Depends on:** two-sided serial closure; [[Finite-Past-Depth Recurrence]] ([[4.6 Singularity#4.6.5 Conclusions|§4.6.5]]) and [[Finite Autonomous Phase Dynamics]] ([[4.6 Singularity#4.6.5 Conclusions|§4.6.5]]); the actual half-cycle secured conditionally by [[Dominance-Scale Bidirectional Capacity]] ([[4.6 Singularity#4.6.5 Conclusions|§4.6.5]])

Stated at [§4.6.5 — Conclusions](../../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.5%20Conclusions).

## Glossary

*Corollary.* Every two-sided phase-history over a finite phase set under one time-independent successor function is periodic everywhere: no occupied phase can be transient. It is the strongest past-depth case of [[Finite-Past-Depth Recurrence]]. If such a history contains the actual $C\rightarrow K\rightarrow E$ half-cycle, that half-cycle returns without end in both directions and therefore includes a later return from $E$ to $C$. [[Invariant Realization]] and [[Strict Actualization]] transfer the finite-map result to an actual physical realization; they don’t establish two-sided history or the finite autonomous profile. Earned at [[4.6 Singularity#4.6.5 Conclusions|§4.6.5]].
