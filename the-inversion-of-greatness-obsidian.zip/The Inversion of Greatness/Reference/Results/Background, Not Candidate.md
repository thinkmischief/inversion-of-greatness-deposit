> [!proposition]
> **Background, Not Candidate** · *Proposition*
>
> Occam’s Razor compares candidate explanations against a stable background of structural possibilities, which is why it can weigh electrons against fields. It cannot weigh structure itself against its absence, because there is no coherent contrast class in which the roles fail to obtain. With no alternative to compare against, the roles are not one posit among rivals but the condition any posit, mind included, already occupies.
>
> **Depends on:** [[Incoherence of ∅]] ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]])

Stated at [[10.1.8 The Simplicity Argument|§10.1.8 The Simplicity Argument]].
