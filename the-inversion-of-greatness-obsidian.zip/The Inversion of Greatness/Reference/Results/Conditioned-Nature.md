> [!theorem]
> **Conditioned-Nature** · *Theorem*
>
> For any X that spells out a structural feature of N, the nature of X = the X-describable feature of N.
>
> **Depends on:** [[Triconditional Identity]] ([[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])

Stated at [§2.6.12 — Conditioned-Nature](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.12%20Conditioned-Nature).

## Glossary

*Theorem.* For any X that spells out a structural feature of N, the nature of X = the X-describable feature of N. Earned at [[2.6 Triconditionality of Nature#2.6.12 Conditioned-Nature|§2.6.12]].
