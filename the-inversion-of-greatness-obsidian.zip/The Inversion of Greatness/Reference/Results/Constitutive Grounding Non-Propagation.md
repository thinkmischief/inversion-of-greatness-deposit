> [!lemma]
> **Constitutive Grounding Non-Propagation** · *Lemma*
>
> Two relations must be kept apart. □(T∧S∧Φ) and □◇C are not ground and grounded but one fact under two readings: by the Modal Identity, the necessity of the structural conditions just is the necessary possibility of change read modally, so □◇C carries its necessity by identity, not by transmission across a grounding relation. The structural conditions also ground particular changes, but only in part: to be a change at all is to instantiate T, S, and Φ, while what makes a given change occur rather than another—its initial conditions or outcome—lies outside the three roles. Configurational Necessitation fixes the full-ground conditional, □(P → Q); Strict Actualization yields actual Q from that conditional and actual P. Physical Invariance applies that boundary to complete physical profiles: $\Box\forall x(\operatorname{Realizes}(x,M)\rightarrow Q(x))$ fixes what follows of an *M*-realization without establishing $\Box\exists x\,\operatorname{Realizes}(x,M)$. Only an independently established □P permits K to yield □Q. The necessary Conditions therefore constrain every change without making the complete antecedent of every change necessary. □(T∧S∧Φ) ⊢ □◇C, not □C.
>
> **Depends on:** [[Modal Identity]] ([[2.6 Triconditionality of Nature#2.6.6 Modal Identity|§2.6.6]]), [[Configurational Necessitation]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]]), [[Strict Actualization]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]]), and [[Physical Invariance]] ([[3.5 What the Convergence Shows#3.5.6 Formal Realization Preserves Structure Without Supplying It|§3.5.6]])
>
> **Feeds into:** Modal Collapse Resistance

Stated at [§8.2.5 — 8.2.5 The Modal Collapse Objection](../../8.%20Metaphysics/8.2.5%20The%20Modal%20Collapse%20Objection.md).

## Glossary

*Lemma.* □(T∧S∧Φ) and □◇C are not ground and grounded but one fact under two readings: by [[Modal Identity]] the necessity of the structural Conditions just *is* the necessary possibility of change read modally, so □◇C carries its necessity by identity rather than by transmission across a grounding relation. Earned at [[8.2.5 The Modal Collapse Objection|§8.2.5]].
