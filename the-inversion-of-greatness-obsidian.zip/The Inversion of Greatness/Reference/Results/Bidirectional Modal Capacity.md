> [!theorem]
> **Bidirectional Modal Capacity** · *Theorem*
>
> Reality necessarily retains both directional capacities: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. Neither capacity can be first supplied or subsequently lost by any cosmological configuration; both are internal to the one totality Reality is. The result is about global modal standing, not local reachability or cosmic scale. It does not entail that every configuration can access both directions, that expansion reverses, that every trajectory meets, or that the whole universe reconverges.
>
> **Depends on:** Actuality ([[1.2 Modal Status#1.2.5 Actuality|§1.2.5]]) and [[Necessary Possibility]] ([[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])

Stated at [§4.6 — 4.6 Singularity](../../4.%20Nature%20Alone/4.6%20Singularity.md).

## Glossary

*Theorem.* Let $\mathrm{Con}$ state that some separated physical trajectories reduce their separation and enter a common region or phase, and $\mathrm{Div}$ state that some separated physical trajectories increase their separation. Both are actual; actuality implies possibility, and [[Necessary Possibility]] lifts each to a necessary global capacity: $\Box\Diamond\mathrm{Con} \land \Box\Diamond\mathrm{Div}$. Reality can neither acquire nor lose either directional capacity. The theorem supplies a boundary-closed, two-directional modal architecture when combined with [[No Stable Zero-Extension]], but it does not entail that both directions are locally reachable from every configuration or that minimal convergence scales into total cosmic reconvergence. Established in [[4.6 Singularity|§4.6]].
