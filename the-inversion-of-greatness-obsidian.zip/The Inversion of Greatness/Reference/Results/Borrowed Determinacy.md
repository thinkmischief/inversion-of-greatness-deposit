> [!proposition]
> **Borrowed Determinacy** · *Proposition*
>
> A Form is a Form only by being a determinate this rather than that: Triangle and not Circle, Justice and not Beauty. Ask what fixes the determinacy. If it is the configurations the Form describes, then determinacy runs from structure to Form, and the Form does not supply a concrete change-realizer that lacks the conditions; it need not thereby be reduced to a description. If it is native to the Form instead, the position owes an account of differentiation within an order carrying no distinction, ordering, or bearing to supply it.
>
> **Depends on:** [[Ontological Identity]] ([[2.6 Triconditionality of Nature#2.6.8 Ontological Identity|§2.6.8]])

Stated at [[8.1.5 Platonism|§8.1.5 Platonism]].
