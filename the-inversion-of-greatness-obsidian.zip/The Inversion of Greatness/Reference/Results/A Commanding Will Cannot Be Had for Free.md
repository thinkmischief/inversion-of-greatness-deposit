> [!proposition]
> **A Commanding Will Cannot Be Had for Free** · *Proposition*
>
> Even granting that moral authority requires a personal ground, the ground the argument names cannot supply it. Ordinary commands are temporal acts; grounding obligation in an eternal nature instead avoids the issuing event but still owes an account of the directed relation between commander, content, and the persons obligated. Each is a condition of succession, relation, or persistence, and a ground precluded from time, space, and substance has not been shown able to supply any of them.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [[10.1.12 The Moral Argument|§10.1.12 The Moral Argument]].
