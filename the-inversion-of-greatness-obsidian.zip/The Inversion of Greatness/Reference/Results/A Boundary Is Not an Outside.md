> [!proposition]
> **A Boundary Is Not an Outside** · *Proposition*
>
> Grant the Kalām its finite past outright. A past boundary is the first chronometric coordinate of the successional order—the earliest position passage has reached, viewed from within—not a moment prior to that order from which it departed. The beginning the cosmology delivers is therefore a feature *inside* T, and the beginning the argument needs is categorial: an origination of the order as such. A boundary of an order does not transport that order’s explanation outside it. So the empirical finding can be conceded in full while the theological inference it is meant to underwrite is declined, and conceding it costs nothing, because what a first coordinate marks is where the dimension starts being measured rather than where it came from.
>
> **Depends on:** [[Parasitic Negation]] ([[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]])

Stated at [[10.1.5 The Cosmological Argument|§10.1.5 The Cosmological Argument]].
