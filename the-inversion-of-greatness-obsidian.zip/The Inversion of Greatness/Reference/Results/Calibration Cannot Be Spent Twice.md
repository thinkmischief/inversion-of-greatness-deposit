> [!dissolution]
> **Calibration Cannot Be Spent Twice** · *Dissolution*
>
> An appeal to deliberately calibrated evidence may block an inference from apparent disconfirmation, and it may correlate difficulties so that they no longer compound. It cannot also count the resulting evidential situation as confirmation. The latitude that makes ambiguity expected makes clarity unexpected in the same measure, so a defender who cites the model to absorb the difficulties has spent the width that a favorable reading would need. Held evenly, the model predicts an evidential situation in which neither side’s reading is surprising, and it therefore discriminates between them less than either party wants.
>
> **Dissolves:** the use of a calibrated-disclosure model both to neutralize disconfirming evidence and to treat the resulting ambiguity as evidence for the position it protects
>
> *Scope.* The dissolution grants that a calibration model may be true, that a tradition may hold it for independent reasons, and that correlated difficulties genuinely don’t compound. It doesn’t make the model meaningless or settle whether any particular text is inspired. It fixes only that the two uses cannot be made together.
>
> **Depends on:** [[The Explanatory Burden]] ([[12. Exodus|§12]])

Stated at [§12.3.6 — 12.3.6 Divine Hiddenness](../../12.%20Exodus/12.3.6%20Divine%20Hiddenness.md).
