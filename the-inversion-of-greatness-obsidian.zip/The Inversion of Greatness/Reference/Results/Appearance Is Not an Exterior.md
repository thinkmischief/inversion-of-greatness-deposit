> [!proposition]
> **Appearance Is Not an Exterior** · *Proposition*
>
> An error theory may distinguish the structure of a representation from the structure of what it represents; it may not place a real representing act outside Reality. If an appearance of temporal order or plurality is real, then the appearance itself belongs to Reality and carries the actual transition or differentiation the strict totality-denial excludes. If the appearance is unreal, it supplies no actual appearance for the proposed ground to explain. A non-temporal or undifferentiated ground may therefore survive only as a proposed ground within Reality of real structured appearance, not as a wholly non-temporal or wholly undifferentiated replacement for Reality.
>
> *Scope.* This does not infer that the represented object has the structure of the representing act, settle the nature of the proposed ground, or show that every appearance is veridical. It closes strict temporal unreality and strict monism only as claims about Reality as a whole.
>
> **Depends on:** Reality’s no-exterior scope ([[1.1 Reality|§1.1]]), [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]]), and [[Articulation Closure]] ([[3.3 Triconditional Necessity - From Above#3.3.6 Uneven Overdetermination|§3.3.6]])

Stated at [§8.4 — What the Rivals Carried](../../8.%20Metaphysics/8.4%20What%20the%20Rivals%20Carried.md).
