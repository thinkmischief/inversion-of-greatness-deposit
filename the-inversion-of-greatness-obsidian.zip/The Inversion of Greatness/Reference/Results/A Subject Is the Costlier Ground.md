> [!proposition]
> **A Subject Is the Costlier Ground** · *Proposition*
>
> Cosmopsychism advertises parsimony: leaner than dualism, and carrying no strong-emergence debt. Both advantages are won against those rivals and neither transfers here, since the structural account posits one fundamental category and no emergence either. On the account of subjecthood defended in Chapters 4–5, a subject is a structured configuration of self-modeling operating under structural constraints. Given that account, seating a subject at the ground posits more than the structure it already presupposes. The priority reversal is therefore also the parsimony verdict.
>
> **Depends on:** [[Necessity of Nature]] ([[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]), [[Life]] ([[4.8 Life|§4.8]]), and [[Consciousness]] ([[5.1 Consciousness|§5.1]])

Stated at [[9.4 Cosmopsychism|§9.4 Cosmopsychism]].
