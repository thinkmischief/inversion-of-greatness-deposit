> [!principle]
> **Condition-Individuation** · *Principle*
>
> X is a Condition of Reality only if X comes with a natural quantifier-pair ⟨*X-positive, X-negative*⟩ such that the Law of Excluded Middle applies exhaustively to empirical existence-claims along the X-axis (every empirical existence-claim at X-instantiation is determinately either X-positive or X-negative, with no third option) and X is irreducible to any other LEM-applicable axis.

Stated at [§2.6.11 — No Fourth Condition](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.11%20No%20Fourth%20Condition).
