> [!proposition]
> **A Problem One Level Down** · *Proposition*
>
> Presentism, four-dimensionalism, and relationalism each supply an ordered continuity structure, at a level the derivation operates above: presentism at each present moment with cross-time relations carried by tensed-fact primitivism, four-dimensionalism in the manifold existing timelessly, relationalism in properties indexed to times. The temporary-intrinsics problem is therefore a dispute about how cross-time continuity is realized rather than about whether it is required. What each supplies is a candidate occupant of the continuity role; whether the occupant meets the loaded Φ type is settled by the independent role-to-type argument, and none of the three analyses is refuted by that question being asked.
>
> **Depends on:** [[Triconditional Identity]] ([[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])

Stated at [[8.3.1 The Problem of Temporary Intrinsics|§8.3.1 The Problem of Temporary Intrinsics]].
