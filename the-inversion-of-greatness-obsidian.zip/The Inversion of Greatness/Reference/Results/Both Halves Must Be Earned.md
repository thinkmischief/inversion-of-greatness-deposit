> [!proposition]
> **Both Halves Must Be Earned** · *Proposition*
>
> An argument from asymmetric prediction of misleading evidence requires two claims, not one: that the favored position predicts the contrary evidence its critics report, and that no rival position predicts the favorable evidence its adherents report. The second is a claim about ascertainment, selection, retention, and shared evidential causes, and the conditional-independence and denominator requirements bear on it directly. An asymmetry established only by arguing the first half assumes the second.
>
> *Scope.* The proposition does not deny that an asymmetry may hold, or that a tradition may have principled grounds for predicting resistance to its teachings. It fixes what the second half costs.
>
> **Depends on:** the conditional-independence and denominator requirements established in this section; [[The Plurality–Dominance Gap]] (§10.1.16)

Stated at [[10.1.16 Religious Experience and Miracles|§10.1.16 Religious Experience and Miracles]].
