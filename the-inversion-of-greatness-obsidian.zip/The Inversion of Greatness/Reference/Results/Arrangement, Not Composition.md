> [!proposition]
> **Arrangement, Not Composition** · *Proposition*
>
> The nihilist denies that arrangements compose further objects while granting the arrangement-facts. The structural roles attach to the arrangements. *Arranged* is itself a structural predicate: simples arranged chair-wise must be individuated from one another, and where the arrangement lasts across an interval and is maintained by its own causal activity, it obtains in order and something holds across it. Whether arrangements additionally compose objects is a question the argument leaves open, because it operates one level below it.
>
> **Depends on:** [[Ontological Identity]] ([[2.6 Triconditionality of Nature#2.6.8 Ontological Identity|§2.6.8]])

Stated at [[8.3.4 Mereological Nihilism|§8.3.4 Mereological Nihilism]].
