> [!diagnostic]
> **Awareness Needs a By and an Of** · *Diagnostic*
>
> One burden is earned universally and survives every refinement: awareness has to be awareness *by* something and *of* something, with determinate subject–content articulation and a bearer, and this holds even where knower and known are numerically one and every content is simultaneous. That much doesn’t yet establish a temporal interval or a spatial manifold, and the section doesn’t take it to. The heavier roles enter conditionally instead, each with its own trigger: attention that modulates as its object varies incurs temporal ordering; second-personal awareness incurs distinct relational poles and a standpoint; awareness realized as an ongoing cognitive process incurs persistence in its bearer. The classical account can decline the loaded readings of T and S, but only by holding divine awareness at the thin, non-modulating level of self-cognition, and it then owes an account of how absolute simplicity supports determinate content rather than bare identity. The analogical defense doesn’t relieve that debt, since analogy obtains only where structural scaffolding is shared with the creaturely paradigm, and the shared scaffolding is what the paradigm consists in.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [§11.4.1 — 11.4.1 Awareness](../../11.%20Reclaiming%20Greatness/11.4.1%20Awareness.md).
