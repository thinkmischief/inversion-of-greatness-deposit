> [!proposition]
> **Being, Not Concreteness** · *Proposition*
>
> Necessitism separates being from concreteness: whatever exists exists necessarily, while what is concrete varies by world. At the higher order the analogue of concreteness is instantiation: a plurality or configuration may exist necessarily and still not be instantiated at every world. Higher-order necessitism rigidifies being at whichever order it is run, leaving instantiation free, and the proof’s first premise records an instantiation rather than a being. The residue therefore survives the ascent unless every necessarily-existing configuration is also instantiated everywhere, which is modal collapse rather than necessitism.
>
> **Depends on:** [[Configurational Necessitation]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]])

Stated at [[7.2.7 Necessitism|§7.2.7 Necessitism]].
