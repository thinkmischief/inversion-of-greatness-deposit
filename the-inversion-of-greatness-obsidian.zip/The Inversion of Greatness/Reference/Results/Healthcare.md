> [!right]
> **Healthcare** · *Right*
>
> Participation is unavailable to subject $s$ without effective care: $\neg Reach_s(participation \land no\ effective\ care)$. That care includes mental-health care that can put livable lines back in the field, and rest: time off and parental leave. Rest is not a further right. Consciousness as vantage is the standing-gate, not the autobiographical I. Payer form stays open.
>
> **Depends on:** [[Consciousness]] ([[5.1 Consciousness|§5.1]]), [[Feeling]] ([[5.3 Feeling|§5.3]]), [[Mortality]] ([[5.9 Mortality|§5.9]]), and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.10 — 6.10 Healthcare](../../6.%20Maximum%20Possibility/6.10%20Healthcare.md).
