> [!theorem]
> **Epistemic Foundation** · *Theorem*
>
> The conditions of participation do more than prevent suffering. They create the interval in which a person can attend, compare reasons, refuse coercive terms, learn from correction, and form a direction that is genuinely their own. A person pressed against hunger, untreated illness, insecure shelter, threat, or unanswerable power may retain formal rights while losing the practical distance those rights require. Maintaining the foundation therefore protects not only welfare but the conditions of informed consent, democratic judgment, and moral agency themselves. The political foundation functions as the infrastructure that makes freedom cognitively and practically real, not as a benefit tacked on after freedom is secured.
>
> **Depends on:** [[Will]] ([[5.11 Will|§5.11]]), [[Morality]] ([[5.14 Morality|§5.14]]), and the Chapter 6 effective-exercise premise

Stated at [§6 — 6. Maximum Possibility](../../6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md).

## Glossary

*Theorem.* The participation foundation is epistemic infrastructure: the material and social conditions that give a subject enough practical distance from necessity to attend, compare reasons, refuse coercive terms, learn from correction, and form a direction of their own. It therefore protects the practical conditions of informed consent, democratic judgment, and moral agency, not welfare alone. Established in §6.
