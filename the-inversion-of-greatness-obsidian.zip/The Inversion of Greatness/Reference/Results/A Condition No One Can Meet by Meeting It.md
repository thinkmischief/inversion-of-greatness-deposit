> [!proposition]
> **A Condition No One Can Meet by Meeting It** · *Proposition*
>
> Where conscious belief is stated as a condition the subject must directly satisfy, the condition must be reachable by what the subject does. On the tradition’s own admission, which Pascal supplies from inside it, belief is not an act the will performs, so the terminal state is not directly reachable by compliance. Indirect responsibility for inquiry and attention survives, and a grace-produced or evidential account of faith exits the direct-command objection. What does not survive is the set that addresses belief as a performed instruction while retaining the tradition’s own account of how belief occurs.

Stated at [[12.3.7 Faith and Belief|§12.3.7 Faith and Belief]].
