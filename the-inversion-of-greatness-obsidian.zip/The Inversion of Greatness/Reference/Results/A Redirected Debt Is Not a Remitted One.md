> [!proposition]
> **A Redirected Debt Is Not a Remitted One** · *Proposition*
>
> Penal substitution’s distinctive claim is that the cross lets mercy operate without justice being waived. Mercy, on the account the tradition itself uses, is a gift beyond what is deserved—the remission of what is owed. A debt that isn’t remitted but redirected, and then collected in full from a substitute, hasn’t been forgiven; the structure of a gift has been replaced by the structure of transactional substitution, and what the model preserves under the name of mercy is a rearrangement of who pays. The doctrine cannot hold both halves of its own claim at once: a justice fully satisfied with every debt collected, and a mercy that is genuine with the debt forgiven. Satisfying either this way removes the other.
>
> *Scope.* This is the second of the two points and is independent of the first. It grants the transfer mechanism outright—whether guilt can move to a substitute at all is argued separately—and shows that even a transfer that worked wouldn’t deliver mercy in the sense the doctrine needs. Older moral objections to the cross aren’t being restated here; the pressure is on the model’s own definitions of justice and mercy.

Stated at [[12.1.7 Atonement|§12.1.7 Atonement]].
