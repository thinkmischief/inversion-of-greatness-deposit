> [!dissolution]
> **Constitutive, Not Confused** · *Dissolution*
>
> A claim drawing no contrast among cases is confused only where some case could have gone otherwise. The sole countercase here is ∅, which isn’t a case that fails to obtain but the absence of any case. The boundary falls between there being cases and there being none, so the register is constitutive, not confused: the diagnostic meant to dissolve the claim locates it. Act-side, fixing register rather than cross-world scope.
>
> **Dissolves:** the confusion-charge

Stated at [§7.1.7 — 7.1.7 Wittgensteinian Quietism](../../7.%20Modality/7.1.7%20Wittgensteinian%20Quietism.md).
