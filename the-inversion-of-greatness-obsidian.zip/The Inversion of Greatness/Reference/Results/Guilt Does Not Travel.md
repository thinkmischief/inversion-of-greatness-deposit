> [!theorem]
> **Guilt Does Not Travel** · *Theorem*
>
> Culpability is blameworthiness indexed to the bearer whose act it evaluates. Consequence, inherited condition, remedial responsibility, corporate answerability, and harm may cross relations between persons; culpability does not cross merely because one of those does. Imputation calls the verdict transferred without supplying the agent’s performance; participation either makes the substitute genuinely culpable and abandons innocence or leaves the transfer figurative; consent permits bearing a cost but does not create deserving; satisfaction converts punishment of the guilty into payment by another. Two Abrahamic scriptures state the same agent-indexing principle in their own canonical voice: no soul bears the burden of another (Qur’an 17:15), and the person who sins is the one who shall die (Ezek 18:20). Any account that treats guilt as portable therefore owes an additional identity-of-act relation strong enough to make the recipient the acting bearer, not merely a mechanism for moving consequences.
>
> **Depends on:** [[Five Relocations, One Missing Act]] ([[11.9.2 Righteousness|§11.9.2]]) and [[Identity]] ([[5.7 Identity|§5.7]])

Stated at [§12.1.6 — 12.1.6 Inherited Guilt](../../12.%20Exodus/12.1.6%20Inherited%20Guilt.md).

## Glossary

*Theorem.* Culpability is blameworthiness indexed to the bearer whose act it evaluates. Consequence, inherited condition, remedial responsibility, corporate answerability and harm may all cross relations between persons; culpability does not cross merely because one of those does. Earned at [[12.1.6 Inherited Guilt|§12.1.6]].
