> [!corollary]
> **Concrete-Entity Test** · *Corollary*
>
> An abstract object is not a counterexample to the Conditions on concrete change: abstract existence by itself attributes no concrete operation. Any candidate said to change, act, experience, create, sustain, intervene, or efficiently produce a concrete effect incurs the full Structural Requirement at the operation or contact where that work occurs: a when in the order of the act, a where distinguishing its terms, and a what that bears the difference across it. A candidate assigned determinate abstract content but no concrete operation remains an abstractum. A candidate assigned concrete work must supply T, S, and Φ at that work. A candidate assigned neither determinate content nor a determinate relation supplies no entity or ground at all.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [[2.4 Structural Requirement|§2.4 Structural Requirement]].
