> [!dissolution]
> **Essence-Description** · *Dissolution*
>
> For any X that spells out a structural region of N, the essence of X is exhausted by the X-essential conditions on T, S, and Φ, provided the structural-region criterion survives the hyperintensional tests identified below. Within that scope, the Lockean gap between *real essence* (the hidden inner constitution) and *nominal essence* (the description that picks out a thing by its properties) collapses: descriptions that pick out the conditional profile are descriptions of essence, not approximations to an inaccessible essence behind them. The result doesn’t decide the essence of a candidate wholly outside N by definition.
>
> **Dissolves:** the Lockean real/nominal gap

Stated at [§2.6.12 — Conditioned-Nature](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.12%20Conditioned-Nature).
