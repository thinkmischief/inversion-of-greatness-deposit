> [!proposition]
> **Cheap Substitution, Expensive Word** · *Proposition*
>
> *Deus sive Natura* offered as a term-substitution costs nothing at the level of the necessity claim: if “God” just names the necessary ground, the relabeling is harmless. What it does not carry over is everything the term historically did—an object of worship, a source of moral obligation, a being who hears prayer, a guarantor of cosmic justice. The substitution is cheap where it changes nothing and expensive exactly where the tradition needed it to change something.
>
> **Depends on:** [[Necessity of Nature]] ([[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]])

Stated at [[10.3.1 Spinozist Pantheism|§10.3.1 Spinozist Pantheism]].
