> [!diagnostic]
> **Cardinality Presupposes Distinguishability** · *Diagnostic*
>
> *One* is a cardinality claim, and a cardinality claim presupposes distinguishability: to fix a being as exactly one is to hold the resource by which a second would have differed. Location, temporal trajectory, and material constitution are ordinary resources, and primitive thisness is a proposed nonqualitative one; whichever does the work is differentiating structure. Simplicity secures *exactly one* by removing what *exactly two* would have needed, which buys uniqueness by converting the count into a transcendental consistent with no determinate count of the kind. The frame meets no such difficulty. Whatever makes a second concrete structure second belongs to the complete structure of Reality; if nothing does, there is no second. That inference is deductive given Structural Individuation, and a primitivist may decline the premise, but declining it withholds assent rather than furnishing a countermodel.
>
> **Depends on:** [[Structural Individuation]] ([[2.4 Structural Requirement#2.4.9 Forward Conditional Necessity|§2.4.9]])

Stated at [§11.2.2 — 11.2.2 Unity](../../11.%20Reclaiming%20Greatness/11.2.2%20Unity.md).
