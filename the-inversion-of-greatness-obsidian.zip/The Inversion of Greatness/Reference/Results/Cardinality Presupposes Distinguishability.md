> [!diagnostic]
> **Cardinality Presupposes Distinguishability** · *Diagnostic*
>
> *One* is a cardinality claim, and a cardinality claim presupposes distinguishability: if there were a second, it would be determinately nonidentical to the first. [[Differentiation Minimum]] secures that much without settling what grounds the nonidentity. Location, temporal trajectory, and material constitution are ordinary positive grounds, and primitive thisness is a proposed nonqualitative one; by Structural Individuation, whichever positively individuates belongs to the complete differentiating structure. Simplicity secures *exactly one* by removing what *exactly two* would ordinarily have needed, which buys uniqueness by converting the count into a transcendental consistent with no determinate count of the kind. Numerical unicity of the frame follows deductively only given Structural Individuation. A primitivist may decline that premise while retaining the weaker minimum theorem.
>
> **Depends on:** [[Differentiation Minimum]] and [[Structural Individuation]] ([[2.4 Structural Requirement#2.4.9 Forward Conditional Necessity|§2.4.9]])

Stated at [§11.2.2 — 11.2.2 Unity](../../11.%20Reclaiming%20Greatness/11.2.2%20Unity.md).
