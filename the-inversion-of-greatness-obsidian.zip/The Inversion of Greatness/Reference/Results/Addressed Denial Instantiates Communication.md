> [!theorem]
> **Addressed Denial Instantiates Communication** · *Theorem*
>
> A denial addressed through signs to another subject presents content for uptake across their separation. Whatever its success, truth, conventional form, or eventual interpretation, the act is an attempted coordination of signs and response. An addressed denial that communication occurs therefore instantiates communication at that minimal level.
>
> The theorem establishes attempted communication, not shared conventions, successful reference, accurate transfer, mutual understanding, or language’s complete functional identity. A private mark, involuntary signal, or uninterpreted event falls outside the conclusion unless it is addressed for uptake.
>
> **Depends on:** [[Representational Minimum]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.12 — 5.12 Language](../../5.%20Expanding%20the%20Field/5.12%20Language.md).
