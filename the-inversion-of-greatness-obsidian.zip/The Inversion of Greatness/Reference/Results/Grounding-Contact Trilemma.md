> [!disjunction]
> **Grounding-Contact Trilemma** · *Disjunction*
>
> What does an ultimate ground supply that Nature doesn’t already?
>
> - **If it supplies only abstract or atemporal grounding content,** then it is an abstract structure within Nature, not an exterior ground. If it is invoked to explain concrete actuality, the relation between those resolutions is still owed.
> - **If it is concrete, or does concrete work,** then it is T, S, and Φ in determinate operation; neither route adds an independently constituted item to Nature. *Priced by* [[Necessary Occupancy]] ([[2.9 The Whole Line#2.9.7 Exclusivity of Nature|§2.9.7]]) for a concrete ground; [[Concrete-Entity Test]] ([[2.4 Structural Requirement|§2.4]]) for a concrete operation.
> - **If it supplies neither determinate content nor a determinate grounding relation,** then it supplies no ground at all.
>
> So the direct Thomist identification of classical *ipsum esse subsistens* with □(T∧S∧Φ) cannot be sustained while the classical type-level denials remain intact. Retaining determinate analogical content yields an internal abstract-grounding proposal, not a second source behind Nature. Dropping the denials yields a revised aspect of Nature.
>
> **Dependency routes:** abstract or atemporal grounding—[[The Grounding Conditional]] ([[2.2 Cartesian Certainty#2.2.2 Actuality’s Reach|§2.2.2]]) and [[No Unconditioned Essence]] ([[7.2.1 The Source of Possibility|§7.2.1]]); concrete ground—[[Necessary Occupancy]] ([[2.9 The Whole Line#2.9.7 Exclusivity of Nature|§2.9.7]]) and [[Reality–Nature Identity]] ([[2.8 Reality–Nature Identity|§2.8]]); concrete operation—the [[Concrete-Entity Test]] ([[2.4 Structural Requirement|§2.4]]); no determinate ground—[[Incoherence of ∅]] ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]])

Stated at [§10.4 — 10.4 What the Rivals Carried](../../10.%20Rival%20Ultimates/10.4%20What%20the%20Rivals%20Carried.md).
