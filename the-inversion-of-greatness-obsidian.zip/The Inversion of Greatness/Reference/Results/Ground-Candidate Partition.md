> [!lemma]
> **Ground-Candidate Partition** · *Lemma*
>
> With respect to the grounding role, any candidate g either (i) formally instantiates T ∧ S ∧ Φ; (ii) claims to realize the same grounding functions without formal instantiation; or (iii) claims to ground temporal, spatial, and substantial facts while realizing none of the corresponding structure. The classification keeps one criterion throughout: how g is alleged to realize the grounding role. It is diagnostic rather than an independent proof of the Exclusivity of Nature theorem. Horn (ii) is the substantive role-to-type dispute; it closes only if the prior realizer and no-surplus premises succeed.
> **Feeds into:** the S5 Bottleneck Reductio ([[3.5 What the Convergence Shows#3.5.5 The S5 Bottleneck Reductio|§3.5.5 The S5 Bottleneck Reductio]])

Stated at [§3.5.5 — The S5 Bottleneck Reductio](../../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.5%20The%20S5%20Bottleneck%20Reductio).

## Glossary

*Lemma.* With respect to the grounding role, any candidate *g* either formally instantiates T ∧ S ∧ Φ; or claims to realize the same grounding functions without formal instantiation; or claims to ground temporal, spatial and substantial facts while realizing none of the corresponding structure. One criterion runs throughout—how *g* is alleged to realize the role—and the partition is diagnostic rather than probative. Earned at [[3.5 What the Convergence Shows|§3.5]].
