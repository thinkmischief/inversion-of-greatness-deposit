> [!right]
> **Belonging** · *Right*
>
> Effective agency requires secure membership somewhere and basic standing everywhere. Borders allocate jurisdiction and special duties; they do not manufacture or erase standing. Admission, pace, assistance, and institutional form stay open under capacity, fair shares, and comparable rights.
>
> **Depends on:** [[Morality]] ([[5.14 Morality|§5.14]]) and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.2 — 6.2 Belonging](../../6.%20Maximum%20Possibility/6.2%20Belonging.md).
