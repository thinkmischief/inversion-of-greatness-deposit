> [!right]
> **Belonging** · *Right*
>
> Participation is unavailable to subject $s$ without membership in some community that can hold the foundation: $\neg Reach_s(participation \land no\ belonging)$. What crosses a border is the substrate, not a culture. Visa, pace, and form of government stay open.
>
> **Depends on:** [[Morality]] ([[5.14 Morality|§5.14]]) and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.2 — 6.2 Belonging](../../6.%20Maximum%20Possibility/6.2%20Belonging.md).
