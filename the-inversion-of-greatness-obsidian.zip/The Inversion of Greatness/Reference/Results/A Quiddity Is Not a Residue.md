> [!proposition]
> **A Quiddity Is Not a Residue** · *Proposition*
>
> A quiddity offered as a positive ground of concrete role-occupancy faces a fork. If it positively individuates one realizer from another, that individuator belongs to their complete differentiating structure, and the profile that omitted it was incomplete. If no positive individuator is supplied, the proposal is brute numerical nonidentity rather than a further categorical ground. [[Differentiation Minimum]] preserves that nonidentity as determinate difference; [[Structural Individuation]] is the stronger premise that excludes it as a complete account of concrete individuation. The proposition therefore does not refute categorical character or primitive identity. It establishes conditionally that a *positive* categorical individuator cannot both do individuating work and remain absent from the complete structure.
>
> **Depends on:** [[Differentiation Minimum]] and [[Structural Individuation]] ([[2.4 Structural Requirement#2.4.9 Forward Conditional Necessity|§2.4.9]])

Stated at [§2.8 — 2.8 Reality–Nature Identity](../../2.%20The%20Argument/2.8%20Reality%E2%80%93Nature%20Identity.md).
