> [!proposition]
> **A Quiddity Is Not a Residue** · *Proposition*
>
> A quiddity offered as the concrete ground of role-occupancy faces a fork. If it individuates one realizer from another, that individuation is a real differentiating structure, and the profile that omitted it was incomplete. If it supplies no differentiating structure, it does not individuate the realizers at all. Bare non-identity names no third way between making a difference and making none. The proposition does not refute categorical character; it establishes that categorical character cannot be both concretely individuating and nonstructural.
>
> **Depends on:** [[Structural Individuation]] ([[2.4 Structural Requirement#2.4.9 Forward Conditional Necessity|§2.4.9]])

Stated at [[2.8 Reality–Nature Identity|§2.8 Reality–Nature Identity]].
