> [!proposition]
> **Concrete Relata, Non-Concrete Seam** · *Proposition*
>
> Each Lewisian world is internally rich, with intervals throughout. What carries no interval is the relation between worlds, and every seam we have uncontested access to is interval-free exactly where it is non-concrete: there is no distance from Holmes to Hamlet, not an unknown distance but no such fact. Lewis is therefore a concretist about each world and, unowned, an ersatzer about the many. The plurality is a set of concrete relata related as if they were not concrete. Lewis predicts the missing interval rather than conceding it, since standing in no spatiotemporal relation is what he takes distinctness of worlds to be, so what the comparison prices is a relation without precedent outside representation rather than an inconsistency.
>
> And the intuition that makes the picture feel forced—that the worlds are *obviously* many—leans on distinguishability, which is downstream of the structure and confers no actuality of its own: that two worlds can be told apart no more makes them two concrete existents than telling Holmes from Hamlet makes either one a man. The arrow runs from the Conditions to distinguishability, never back.
>
> **Depends on:** [[Structural Individuation]]; the seam comparison is diagnostic support

Stated at [[7.2.3 Modal Realism|§7.2.3 Modal Realism]].
