> [!diagnostic]
> **Being Heard Is a Structural Feature, Not a Register** · *Diagnostic*
>
> Love without intrinsic affective change is the classical proposal, and whether willing another’s good suffices for perfect love or whether receptivity is essential is genuinely disputed. What the relocations cost can be stated. Petitionary prayer needs a recipient whose receiving is part of the prayer’s structure; moving the receiving into an eternal-figuring register must supply *being heard* in that register or lose it. The Cross needs a suffering of the person. Classical impassibilism locates the suffering according to the human nature while denying that the divine nature is affected; that is a live proposal, not a second sufferer beside the Word. The remaining burden is how the one person is the subject of the suffering without intrinsic alteration of the divine nature, and what *the person suffered* still names if the divine nature is unaffected.
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [§11.3.4 — 11.3.4 Impassibility](../../11.%20Reclaiming%20Greatness/11.3.4%20Impassibility.md).
