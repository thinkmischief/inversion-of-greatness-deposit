> [!premise]
> **Cross-Interval Persistence** · *Constitutive Premise · Φ-limb*
>
> For one state to give way to the next *as a change rather than a bare replacement* is for something to persist across the interval and bear the transition, not merely for two states to be correlated. Whatever occupies that role satisfies Φ at modal-core resolution. This spends Chapter 1’s fixing of Substantiality as occupied carriage across an interval ([[1.4 Three Conditions#1.4.3 Substance|§1.4.3]]) rather than re-arguing it. The premise deliberately does not say *causally produce*.

Stated at [§2.4.8 — Exchange Requires Substantiality](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality).
