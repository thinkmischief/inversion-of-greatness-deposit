> [!theorem]
> **Configurational Necessitation** · *Theorem*
>
> Where P is metaphysically sufficient for Q—where no possible realization of P lacks Q—the relation is a structural constraint rather than a local regularity: □(P → Q).

Stated at [§2.9.4 — Necessity Precedes Contingency](../../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.4%20Necessity%20Precedes%20Contingency).

## Glossary

*Theorem.* Where *P* is metaphysically sufficient for *Q*—where no possible realization of *P* lacks *Q*—the relation is a structural constraint rather than a local regularity: □(P → Q). Earned at [[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]]. *See* [[Strict Actualization]] for the move from the conditional to an actual consequent.
