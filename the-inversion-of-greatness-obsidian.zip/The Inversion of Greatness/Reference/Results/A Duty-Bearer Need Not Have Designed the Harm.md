> [!proposition]
> **A Duty-Bearer Need Not Have Designed the Harm** · *Proposition*
>
> Duty follows capacity, and the tradition says so in its own voice rather than borrowing the principle. The servant given much is required much (Luke 12:48). The one who knows the right thing to do and fails to do it has sinned (Jas 4:17). The talents are judged by what each servant could do with what he was holding, not by what he had authored. None of these grounds obligation in authorship; each grounds it in what the agent was able to do. An omnipotent sustaining agent is that principle at its limit—total capacity, no feasibility constraint, no competing claim on scarce resources—so denying design-level intent doesn’t discharge the duty. Permission by a capable duty-bearer is still non-provision.
>
> *Scope.* A defender who holds that these texts bind only creaturely servants, and that capacity in the divine case carries no answerability, can resist the charge. They then owe an account of why the principle their own scriptures state without qualification stops precisely where capacity is greatest.

Stated at [[12.4.1 Teleological Evil|§12.4.1 Teleological Evil]].
