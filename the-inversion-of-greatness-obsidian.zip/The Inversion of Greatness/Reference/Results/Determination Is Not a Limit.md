> [!disjunction]
> **Determination Is Not a Limit** · *Disjunction*
>
> The Argument from Limits treats every determination as a defect a maximal foundation must shed. But the limit at issue isn’t privation, a perfection lacked, it is determination: to be anything at all, even infinite fullness, is to be this and not that. Either the foundation keeps its determinacy, and it is a structured ground, the floor already conceded, or it renounces determinacy, and the plenitude is ∅ under a superlative name.
>
> **Depends on:** [[Incoherence of ∅]] ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]])

Stated at [§10.1.4 — 10.1.4 The Necessary Foundation Argument](../../10.%20Rival%20Ultimates/10.1.4%20The%20Necessary%20Foundation%20Argument.md).
