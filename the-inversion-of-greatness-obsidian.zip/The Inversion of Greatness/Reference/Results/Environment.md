> [!right]
> **Environment** · *Right*
>
> Successor participation is unavailable to subject $s$ if the substrate is spent down: $\neg Reach_s(later\ participation \land exhausted\ conditions)$. This is the right to life at *bios* carried across time, not a right of nature itself. Climate instrument stays open.
>
> **Depends on:** [[Technology]] ([[5.13 Technology|§5.13]]), [[Mortality]] ([[5.9 Mortality|§5.9]]), and [[The Chapter 6 Premises]] ([[6.1 Rights|§6.1]])

Stated at [§6.5 — 6.5 Environment](../../6.%20Maximum%20Possibility/6.5%20Environment.md).
