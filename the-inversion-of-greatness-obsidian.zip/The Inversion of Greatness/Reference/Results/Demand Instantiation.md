> [!corollary]
> **Demand Instantiation** · *Corollary*
>
> Any demand for a ground of Temporality, Spatiality, and Substantiality must itself be structured. Grounding, explanation, and condition each already name asymmetric ordering, distinct terms, and a stable standing of dependence. These are the generic roles of ordering, distinction, and bearing, not yet the loaded Conditions. A grounding relation stripped of all three is not a grounding relation. The demand therefore cannot terminate in an absolutely structureless ground.
>
> *Scope.* The result does not upgrade ontological priority to Temporality, distinct relata to Spatiality, or stable dependence to Substantiality. A thinly or analogically structured ground remains a live candidate with a contact burden, engaged where that dispute is joined ([[7.2.1 The Source of Possibility|§7.2.1]]).
>
> **Depends on:** [[Structural Requirement]] ([[2.4 Structural Requirement|§2.4]])

Stated at [[2.4 Structural Requirement|§2.4 Structural Requirement]].
