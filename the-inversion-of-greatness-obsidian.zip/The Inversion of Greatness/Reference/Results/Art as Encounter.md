> [!corollary]
> **Art as Encounter** · *Corollary*
>
> Description alone does not reproduce acquaintance, though linguistic and nonlinguistic communication can both guide and partly constitute encounters. Artworks characteristically supply organized things or events for a receiver to undergo, not merely reports about them.
>
> Art is therefore not a clean second channel running beside language. The two overlap in poetry, narrative, performance, song, film, ritual, and ordinary expressive speech. What distinguishes the artistic function in these mixed cases is the organized encounter and attention the work solicits, not the absence of propositions or the necessity of a deliberately encoded feeling.
>
> **Depends on:** [[Art]] ([[5.15 Art|§5.15]]) and [[One Channel]] ([[5.12 Language|§5.12]])

Stated at [§5.15 — 5.15 Art](../../5.%20Expanding%20the%20Field/5.15%20Art.md).

## Glossary

*Corollary of [[Art]] and [[One Channel]].* Description alone does not reproduce acquaintance, though linguistic and nonlinguistic communication can both guide and partly constitute encounters. Artworks characteristically supply organized things or events for a receiver to undergo, not merely reports about them. Art is therefore not a clean second channel running beside language: the two overlap in poetry, narrative, performance, song, film, ritual, and ordinary expressive speech, and what distinguishes the artistic function in those mixed cases is the organized encounter and attention the work solicits, not the absence of propositions or a deliberately encoded feeling. Its liability follows: a manufactured encounter can install a reading that misrepresents what it is a reading of, with no paraphrase for the receiver to check it against—the against-mapping mode ([[5.14 Morality|§5.14]]) running through a channel with no propositional surface. Established in [[5.15 Art|§5.15]].
