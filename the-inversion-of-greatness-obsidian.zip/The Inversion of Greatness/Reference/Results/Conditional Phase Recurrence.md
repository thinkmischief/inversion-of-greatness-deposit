> [!theorem]
> **Conditional Phase Recurrence** · *Theorem*
>
> Let K be a dynamically complete maximal-compression phase-class and E entry into an expanding phase. If K is metaphysically sufficient for E, then □(K → E). Every actual realization K_n therefore yields an expanding phase E_n. If cosmic evolution later returns to a dynamically equivalent realization K_{n+1}, the same sufficient relation yields E_{n+1}. The recurrence of K is a further physical premise; the recurrence of E given K is not. The theorem fixes recurrence of the phase-transition type, not identity of the token histories formed within the outgoing phases.
>
> **Depends on:** [[Physical Invariance]] ([[3.5 What the Convergence Shows#3.5.6 Formal Realization Preserves Structure Without Supplying It|§3.5.6]]), through [[Configurational Necessitation]] and [[Strict Actualization]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]])

Stated at [§4.6.3 — Predictions](../../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.3%20Predictions).

## Glossary

*Theorem.* Let *K* be a dynamically complete maximal-compression phase-class and *E* entry into an expanding phase. If *K* is metaphysically sufficient for *E*, then □(K → E), so every actual realization of *K* yields an expanding phase, and a later dynamically equivalent realization yields another. **The recurrence of *K* is a further physical premise**; the theorem supplies the conditional, not the cycle. Earned at [[4.6 Singularity|§4.6]].
