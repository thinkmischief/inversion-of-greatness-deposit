> [!proposition]
> **A Label Is Not a Distance** · *Proposition*
>
> A primitive thisness may be a nonqualitative individuator, but if it makes one concrete item not another, it is real differentiating structure; if it makes no difference, it does not individuate. That conclusion is not yet spatial. The distinctness a displacement crosses must additionally be relational-extensional. A thisness may mark *that* two items differ without supplying the distance between positions that movement requires.
>
> **Depends on:** [[Structural Individuation]] and [[Relational Distinctness]]

Stated at [[8.3.5 Haecceitism|§8.3.5 Haecceitism]].
