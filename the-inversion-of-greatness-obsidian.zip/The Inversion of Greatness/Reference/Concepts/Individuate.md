**Individuate** · To mark one thing off from another as a distinct item—to say what makes this one this one rather than that one. An *individuation* condition is whatever does that marking off.
