**via negativa** · “The negative way” (Latin); apophatic theology, defining God by what God is not.
