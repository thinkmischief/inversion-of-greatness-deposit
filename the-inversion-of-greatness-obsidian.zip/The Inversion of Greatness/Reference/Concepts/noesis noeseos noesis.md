***noesis noeseos noesis*** · “Thought thinking itself” (Greek); Aristotle’s description of the *Prime Mover* in *Metaphysics* XII.
