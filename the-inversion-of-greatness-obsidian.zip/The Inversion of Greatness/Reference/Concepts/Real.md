**Real** · *Concept.* What is the case. The real and Reality are co-extensive: there is nothing real outside Reality, and Reality is exhausted by what is real.
