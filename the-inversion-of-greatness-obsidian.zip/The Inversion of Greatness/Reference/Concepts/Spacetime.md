**Spacetime** · *Concept.* The physical realization of T↔S—Time and Space compose into a single manifold. Established in [[4.5 Binding of the Conditions|§4.5]].
