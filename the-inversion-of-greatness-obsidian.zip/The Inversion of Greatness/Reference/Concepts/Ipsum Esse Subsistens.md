***Ipsum Esse Subsistens*** · “Subsisting being itself,” Aquinas’s name for God as pure act of being.
