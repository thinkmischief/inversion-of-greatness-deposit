***actus purus*** · “Pure act” (Latin); Aquinas’s name for God as having no potency.
