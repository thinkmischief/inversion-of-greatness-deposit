***Soziale Marktwirtschaft*** · The German social market economy, invoked in the political application of the framework.
