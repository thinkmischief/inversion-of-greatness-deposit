**Distinction** · *Concept.* One of the three structural requirements of Change (alongside Succession and Exchange). Identified with S in the role-definitions.
