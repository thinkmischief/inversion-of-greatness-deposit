**Benevolence, Divine** · *See* Moral Predicates, Divine; [[11.9.1 Benevolence|§11.9.1]].
