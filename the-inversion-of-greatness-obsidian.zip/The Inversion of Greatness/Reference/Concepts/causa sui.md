***causa sui*** · “Cause of itself” (Latin); said of a being that accounts for its own existence rather than depending on another for it.
