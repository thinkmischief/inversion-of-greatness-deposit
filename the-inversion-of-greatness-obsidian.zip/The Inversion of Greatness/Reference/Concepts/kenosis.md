***kenosis*** · “Emptying” (Greek); the self-emptying of God, especially the divine self-limitation ascribed to the incarnation. *Kenotic* is the adjective.
