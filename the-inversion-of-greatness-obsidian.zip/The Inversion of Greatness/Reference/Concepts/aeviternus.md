***aeviternus*** · “Of the aeon” (Latin); the medieval intermediate category between time and eternity.
