***Dasein*** · Heidegger’s “being-there,” the human mode of existence.
