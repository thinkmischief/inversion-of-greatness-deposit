***Sein-zum-Tode*** · Heidegger’s “being-toward-death.”
