**Primitive** · Taken as basic and not defined in terms of anything more fundamental. A claim about where an account starts, not about how crude it is.
