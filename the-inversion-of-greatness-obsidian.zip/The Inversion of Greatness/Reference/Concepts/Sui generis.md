***Sui generis*** · “Of its own kind” (Latin); belonging to no wider category, so not explicable as an instance of something more general.
