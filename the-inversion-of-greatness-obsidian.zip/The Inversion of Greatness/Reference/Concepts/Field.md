**Field** · *Concept.* The physical realization of S↔Φ—substance does not occur without spatial extent. Established in [[4.5 Binding of the Conditions|§4.5]].
