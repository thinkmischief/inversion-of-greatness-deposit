***tota simul*** · “All at once” (Latin); Boethius’s name for the eternal present in which God comprehends all time.
