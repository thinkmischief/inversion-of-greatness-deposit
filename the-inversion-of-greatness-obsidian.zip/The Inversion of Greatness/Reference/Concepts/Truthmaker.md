**Truthmaker** · Whatever it is in the world in virtue of which a true claim is true. A truthmaker question asks what a truth answers to, not how the truth is known.
