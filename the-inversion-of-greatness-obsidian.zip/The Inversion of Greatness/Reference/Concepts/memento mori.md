***memento mori*** · “Remember that you must die” (Latin).
