***Spiritus*** · Latin for breath, spirit; the structural concept that the framework reads as a phenomenological description of Φ-persistence in self-modeling configurations.
