**Obtain** · Said of a state of affairs: to be the case. “If that condition obtains” means *if that is how things are*. It does not mean *acquire*.
