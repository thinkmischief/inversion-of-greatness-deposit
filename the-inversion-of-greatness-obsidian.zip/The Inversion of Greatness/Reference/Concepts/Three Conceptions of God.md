**Three Conceptions of God** · *See* Classical God; Revised God; Scriptural God. For the method that generates a maximally-great candidate, *see also* Perfect-Being Theology; Maximally Great Being.
