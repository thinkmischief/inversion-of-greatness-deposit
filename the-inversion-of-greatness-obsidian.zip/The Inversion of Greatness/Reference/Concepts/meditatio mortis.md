***meditatio mortis*** · The meditative practice of contemplating death (Latin).
