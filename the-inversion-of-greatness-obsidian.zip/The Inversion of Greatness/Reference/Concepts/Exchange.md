**Exchange** · *Concept.* One of the three structural requirements of Change. Identified with Φ.
