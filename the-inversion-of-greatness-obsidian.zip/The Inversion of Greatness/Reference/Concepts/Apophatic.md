**Apophatic** · “By denial” (from Greek *apophasis*); characterizing God by what God is not. *Apophaticism* is the corresponding position. *See* via negativa; [[10.2.2 Via Negativa|§10.2.2]].
