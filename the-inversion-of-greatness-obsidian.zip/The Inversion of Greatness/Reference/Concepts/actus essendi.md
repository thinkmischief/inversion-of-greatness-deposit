***actus essendi*** · “Act of being” (Latin); the metaphysical actuality of a being’s existence.
