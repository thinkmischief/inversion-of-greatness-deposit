**Qualia** · *Concept.* (singular *quale*) What an experience is like from the inside: the look of red, the hurt of a pain. Named as the target of the hard problem at [[9.1 The Hard Problem|§9.1]].
