***maranasati*** · The Theravada Buddhist meditation on death (Pali).
