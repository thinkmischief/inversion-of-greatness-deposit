**Prima facie** · “At first appearance” (Latin); how something looks before the case for or against it has been heard. A prima facie reason can be outweighed by another.
