> [!definition]
> **Capacity** · *Definition*
>
> Reality’s standing capacity for P, written Capacity(R,P): the same modal fact as P’s real possibility, said the other way round. ◇P is Capacity(R,P); □P is ¬Capacity(R,¬P). It is Reality’s global modal standing, not the local ability of any state or thing, and it names no power behind Reality.

Stated at [§1.2.1 — Possibility](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.1%20Possibility).
