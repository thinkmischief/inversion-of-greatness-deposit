> [!identification]
> **Imagination** · *Identification*
>
> Imagination is the operation by which a mind loads into its modal field a branch it has not traversed: registration without access. Where modal memory holds what the body has met, imagination holds what it has not, assembled out of what it has. It is not a faculty added to the field but the field’s own capacity to be extended past the body’s history.
> *Status: the structural half is a conditional corollary of Cartesian Certainty via the modal field: to hold that one can imagine this and that, or to deny that one can imagine at all, is already to load unvisited branches. The trying is the loading. That this operation just is registration-without-access, rather than imagery or some other description of the entertaining, remains a functional proposal defended by fit. The catch does not certify that R can admit a loaded branch.*
>
> **Depends on:** [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]]) and [[Knowledge]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.5 — 5.5 Imagination](../../5.%20Expanding%20the%20Field/5.5%20Imagination.md).
