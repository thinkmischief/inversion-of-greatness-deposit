> [!identification]
> **Imagination** · *Identification*
>
> Imagination is the operation by which a mind internally constructs and loads a candidate branch not presently supplied by modal access and not merely retrieved from modal memory. It works offline on registered materials by recombining, transforming, abstracting, interpolating, or simulating them. A branch may also enter a field through testimony or another mediated access; what distinguishes imagination is the branch’s generation within the field, not merely its being new to the body’s direct experience.
>
> *Status: the structural half is a conditional corollary of Cartesian Certainty via the modal field: to hold that one can imagine this and that, or to deny that one can imagine at all, is already to generate and load candidate branches. The trying is the loading. That this operation is internally generative branch-construction, rather than imagery or some other description of the entertaining, remains a functional proposal defended by fit. The catch does not certify that R can admit a loaded branch.*
>
> **Depends on:** [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]]) and [[Knowledge]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.5 — 5.5 Imagination](../../5.%20Expanding%20the%20Field/5.5%20Imagination.md).
