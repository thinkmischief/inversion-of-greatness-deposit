> [!definition]
> **Supervenience** · *Definition*
>
> One range of facts is fixed by another: A *supervenes on* B when there can be no difference in A without some difference in B.

Stated at [§1.5.4 — Supervenience](../../1.%20Groundwork/1.5%20Existence.md#1.5.4%20Supervenience).

## Glossary

*Concept.* One range of facts is fixed by another: A *supervenes on* B when there can be no difference in A without some difference in B. The supervenient (A) varies only as the subvenient (B) varies; the canonical case is the mental supervening on the physical. Established in [[1.5 Existence#1.5.4 Supervenience|§1.5.4]].
