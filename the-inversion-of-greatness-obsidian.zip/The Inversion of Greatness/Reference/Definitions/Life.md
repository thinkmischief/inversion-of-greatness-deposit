> [!definition]
> **Life** · *Definition*
>
> Life is a temporally extended process. In its active phases, a living configuration maintains and rebuilds organizational closure through sustained energy throughput. During dormancy or cryptobiosis, it remains living where the organization produced by that activity persists in a condition with an internally grounded disposition to resume the same self-producing process when enabling conditions return. Mere future revival by external reconstruction is not sufficient.

Stated at [§4.8 — 4.8 Life](../../4.%20Nature%20Alone/4.8%20Life.md).

## Glossary

*Definition.* A temporally extended process whose active phases couple a closed self-producing recursion to sustained energy throughput. During dormancy or cryptobiosis, the organization produced by that activity persists with an internally grounded disposition to resume the same process when enabling conditions return; external reconstructability alone does not suffice. Multiply realizable across substrates, with Darwinian evolution downstream of closure. Established in [[4.8 Life|§4.8]].
