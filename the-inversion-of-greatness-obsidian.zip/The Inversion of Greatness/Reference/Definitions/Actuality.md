> [!definition]
> **Actuality** · *Definition*
>
> A proposition is actual when it is true of the realized configuration.

Stated at [§1.2.5 — Actuality](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.5%20Actuality).

## Glossary

*Definition.* A proposition is actual when it is true of the configuration that has actually been taken. Every actual fact is possible (actuality implies possibility), but not every possibility is actual. Conflating actuality with necessity—treating what happens to be true as if it could not have failed to be—is the *modal-collapse error*. Established in [[1.2 Modal Status|§1.2]].
