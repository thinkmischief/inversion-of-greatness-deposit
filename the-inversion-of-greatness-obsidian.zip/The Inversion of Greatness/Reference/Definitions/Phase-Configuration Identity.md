> [!definition]
> **Phase-Configuration Identity** · *Definition*
>
> Two occurrences are the same phase-type exactly when they agree in every feature that can alter the successor macro-phase under the invariant laws. Token differences are permitted only where no admissible value of those differences changes that successor. Thus phase identity here means identity of the transition-sufficient configuration, not resemblance in expansion rate, density, or any other single variable.

Stated at [§4.6.5 — Conclusions](../../4.%20Nature%20Alone/4.6%20Singularity.md#4.6.5%20Conclusions).

## Glossary

*Definition.* Two occurrences are the same phase-type exactly when they agree in every feature capable of altering the successor macro-phase under the invariant laws. Token differences are allowed only where none changes that successor. This is identity of a transition-sufficient configuration, not resemblance in one selected variable. Fixed at [[4.6 Singularity#4.6.5 Conclusions|§4.6.5]].
