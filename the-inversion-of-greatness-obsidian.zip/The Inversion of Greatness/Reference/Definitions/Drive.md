> [!identification]
> **Drive** · *Identification*
>
> In their active phases, living closures exhibit directed regulation: they maintain some conditions, approach or preserve some exchanges, and counter others. A dormant phase can bear that direction dispositionally in the retained organization without presently exercising it. Conscious subjects can register corresponding alternatives as attraction, aversion, or urgency. *Drive* is the chapter’s proposal that these felt orientations are the first-person aspect of the organism’s integrated regulation before they differentiate into specific object-directed feelings.
> *Status: strict for the existence of biological directedness and for the first-person actuality of felt orientation in the witness case. The continuity between them, its distribution across living systems, and the claim that later motives share one underlying organization are defended by fit. Life and Modal Pressure do not by themselves entail felt drive. The felt half inherits the conditionality of the life–consciousness identification at [[5.1 Consciousness|§5.1]]: cite this result unconditionally for biological directedness, conditionally wherever the interior is at issue.*
>
> **Depends on:** [[Modal Pressure]] ([[5. Expanding the Field|§5]]) and [[Life]] ([[4.8 Life|§4.8]])

Stated at [§5.2 — 5.2 Drive](../../5.%20Expanding%20the%20Field/5.2%20Drive.md).
