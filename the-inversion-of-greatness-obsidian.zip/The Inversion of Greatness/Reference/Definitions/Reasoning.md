> [!identification]
> **Reasoning** · *Identification*
>
> Reasoning transforms a subject’s representations toward a conclusion, forecast, decision, or action, governed by rule, evidence, or reason. It works within a modal field by comparing alternatives and their relations—but a field update driven by perception or trained reflex alone isn’t thereby an inference.
>
> *Status: actual in the present argumentative act, since denying reasoning by offering considerations against it performs the operation. The performative witness establishes an instance, not a complete psychological theory. Inferential answerability distinguishes the register more precisely than fallibility alone; whether non-discursive performances count as reasoning depends on whether they are genuinely reasons-responsive rather than merely successful control. Concrete operators: [[1.5 Existence|§1.5]].*
>
> **Depends on:** [[Knowledge]] ([[5.4 Knowledge|§5.4]]) and [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]])

Stated at [§5.6 — 5.6 Reasoning](../../5.%20Expanding%20the%20Field/5.6%20Reasoning.md).
