> [!identification]
> **Reasoning** · *Identification*
>
> Reasoning is the rule-, evidence-, or reason-sensitive transformation of a subject’s representations toward a conclusion, forecast, decision, or action. It operates within a modal field when it compares alternatives and their relations, but not every field update, perceptual discrimination, or skilled response is thereby an inference.
> *Status: actual in the present argumentative act, since denying reasoning by offering considerations against it performs the operation. The performative witness establishes an instance, not a complete psychological theory. Inferential answerability distinguishes the register more precisely than fallibility alone; whether non-discursive performances count as reasoning depends on whether they are genuinely reasons-responsive rather than merely successful control. Concrete operators: [[1.5 Existence|§1.5]].*
>
> **Depends on:** [[Knowledge]] ([[5.4 Knowledge|§5.4]]) and [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]])

Stated at [§5.6 — 5.6 Reasoning](../../5.%20Expanding%20the%20Field/5.6%20Reasoning.md).
