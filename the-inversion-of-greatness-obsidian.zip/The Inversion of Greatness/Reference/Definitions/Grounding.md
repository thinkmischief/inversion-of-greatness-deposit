> [!definition]
> **Grounding** · *Definition*
>
> Non-causal dependence: X *grounds* Y when Y holds *because of* X, where the *because* is metaphysical, not causal or temporal.

Stated at [§1.5.5 — Ground and Dependence](../../1.%20Groundwork/1.5%20Existence.md#1.5.5%20Ground%20and%20Dependence).

## Glossary

*Concept.* Non-causal dependence: X *grounds* Y when Y holds *because of* X, where the *because* is metaphysical, not causal or temporal. The dependence runs one way only; the canonical case is Fine’s singleton, grounded in its member and not the reverse. Adjacent operators (*fixes*, *makes the case*) name determination. Established in [[1.5 Existence#1.5.5 Ground and Dependence|§1.5.5]].
