> [!definition]
> **Persistence** · *Definition*
>
> Existing across more than one time or through a change, whether by enduring, perduring, or another continuity relation.

Stated at [§1.5.8 — Persistence](../../1.%20Groundwork/1.5%20Existence.md#1.5.8%20Persistence).

## Glossary

*Concept.* Staying the same through change: a thing *persists*, *endures*, or *remains* across a transition, as a river persists while its water turns over. *Endures* and *persists* carry technical readings in the philosophy of time (perdurantism and endurantism). Established in [[1.5 Existence#1.5.8 Persistence|§1.5.8]].
