> [!definition]
> **Institutional Bearer** · *Definition*
>
> An institutional bearer is a persisting arrangement of offices, rules, records, procedures, and material capacities through which changing persons can make and carry publicly attributable commitments. The persons remain the subjects; the arrangement is not a collective consciousness. Offices specify who may act for it, procedures specify how an act becomes its act, and records allow its obligations to survive turnover among officeholders.

Stated at [§6 — 6. Maximum Possibility](../../6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md).

## Glossary

*Political-structural definition.* A persisting arrangement of offices, rules, records, procedures, and material capacities through which changing persons can make and carry publicly attributable commitments. The arrangement is not a collective consciousness: persons remain the subjects, while offices and procedures specify how an act becomes attributable to the institution and records carry its obligations across turnover. Established at the Chapter 6 political bridge.
