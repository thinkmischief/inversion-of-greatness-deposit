> [!identification]
> **Spirituality** · *Identification*
>
> On the naturalist interpretation proposed here, spirituality is a family of practices and experiences in which subjects orient toward dependence, finitude, ultimacy, sacredness, belonging, transformation, or what exceeds ordinary control and representation. One important form is a field registering the limits of its own model. Such registration can be accurate about the limit while remaining underdetermining about whether its source is impersonal structure, another agent, a deity, a practice-shaped construction, or some combination.
> *Status: finitude and model-incompleteness are secure; their identification with spirituality and the genealogy offered for religious interpretation are abductive. Imagination can render the unknown as gods, powers, or favoring wills without certifying those objects, but the existence of cognitive and social mechanisms does not by itself disprove a theological referent. This is a structural-naturalist account among rivals, not a corollary that closes philosophy of religion. The no-outside argument is developed later at [[11.10 What Remains of God|§11.10]].*
>
> **Dependency routes:** subject-side orientation—[[Drive]] ([[5.2 Drive|§5.2]]), [[Knowledge]] ([[5.4 Knowledge|§5.4]]), [[Will]] ([[5.11 Will|§5.11]]), and [[Imagination]] ([[5.5 Imagination|§5.5]]); realization constraint—[[Configurational Necessitation]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]]) and [[Strict Actualization]] ([[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]])

Stated at [§5.16 — 5.16 Spirituality](../../5.%20Expanding%20the%20Field/5.16%20Spirituality.md).
