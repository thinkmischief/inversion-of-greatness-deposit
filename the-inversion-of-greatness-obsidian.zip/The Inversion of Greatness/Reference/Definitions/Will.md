> [!identification]
> **Will** · *Identification*
>
> Will is a living being’s capacity to select and act through represented alternatives. It draws on what the other registers supply—direction from drive, valence from feeling, a corrigible map from knowledge, comparison from reasoning, weighting from meaning—and is the selection itself, insofar as it issues through the agent’s organized capacities. Freedom (*modal freedom*) is not standing outside causation. On the proposed account it varies along four distinguishable dimensions. **Depth and coverage**: how much of the alternatives and consequences are represented. **Fidelity**: how well that representation matches the situation. **Endorsement or identification**: whether the governing valuation is the agent’s own, rather than merely the strongest passing impulse. **Latitude**: the practical room to enact or refuse the selection.
>
> *Status: Drive plus a represented field makes selection possible but does not strictly derive thick will, freedom, responsibility, or this four-part analysis. The analysis is a compatibilist proposal defended by its treatment of ignorance, deception, compulsion, weakness of will, and coercion. Each dimension is gradable, and gains in one can coexist with losses in another. Chapter 11 application: [[11.7.2 Causality|§11.7.2]].*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]) and [[Knowledge]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.11 — 5.11 Will](../../5.%20Expanding%20the%20Field/5.11%20Will.md).
