> [!definition]
> **Possibility** · *Definition*
>
> A proposition is possible when it really could be the case (◇P).

Stated at [§1.2.1 — Possibility](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.1%20Possibility).

## Glossary

*Definition.* A proposition is possible (◇P) when it really could be the case. Distinguished in [[1.2 Modal Status#1.2.1 Possibility|§1.2.1]] from *logically possible* (broader: every real possibility is logically possible, not the reverse), *conceivable* (a reach of imagination), *epistemically possible* (a fact about a knower’s evidence), *nomologically possible* (narrower on the standard reading, though our characterisations of the laws may misfire in either direction), and *probable* (sorts what is in the running). Necessary truths count as possible. Established in [[1.2 Modal Status|§1.2]].
