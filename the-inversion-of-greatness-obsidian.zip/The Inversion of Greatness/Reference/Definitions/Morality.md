> [!identification]
> **Morality** · *Identification*
>
> Morality is the domain of reasons and claims governing how agents may treat subjects with welfare, agency, relationships, and stakes of their own. The account’s positive orientation is fostering: accurately attending to those dimensions and sustaining or enlarging them where one has reason and standing to act. Its limiting orientation is non-corrosion: not damaging, commandeering, or disregarding another’s protected interests without adequate justification.
> *Status: Drive and Meaning supply first-person stakes and instrumental “oughts” relative to ends. They do not entail obligations to anyone else. The two-place moral result requires the explicit reciprocity/equal-standing premise: relevantly similar stakes count alike regardless of whose they are, unless a relevant difference justifies different treatment. The chapter defends that bridge through consistency, mutual exposure, and the instability of claimed self-exemption. Readers who reject the bridge can accept the upstream metaphysics without contradiction. The account rests on two premises it does not derive, and they are independent: this bridge, and the life–consciousness identification at [[5.1 Consciousness|§5.1]], whose conditionality the felt side of the moral relation inherits.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]), [[Meaning]] ([[5.10 Meaning|§5.10]]), and [[Life]] ([[4.8 Life|§4.8]])

Stated at [§5.14 — 5.14 Morality](../../5.%20Expanding%20the%20Field/5.14%20Morality.md).
