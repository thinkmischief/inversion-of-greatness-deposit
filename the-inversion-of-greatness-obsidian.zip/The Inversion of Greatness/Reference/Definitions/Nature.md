> [!definition]
> **Nature** · *Definition*
>
> The joint structure of Time, Space, and Substance: what any genuine change requires.

Stated at [§1.4.4 — Triconditional Structure](../../1.%20Groundwork/1.4%20Three%20Conditions.md#1.4.4%20Triconditional%20Structure).

## Glossary

*Definition.* The joint structure of Time, Space, and Substance: what any genuine change requires. Box-free at the definition; that the three hold of necessity, □(T ∧ S ∧ Φ), is a separately earned result. Not a totality of natural objects, nor an abstract framework Reality happens to possess, but the necessary structural constitution in virtue of which any Reality is possible. The completed line states this constitution as necessary at [[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]; the *Reality–Nature Identity* theorem establishes the identity of Reality and Nature at [[2.8 Reality–Nature Identity|§2.8]]. *See also* Identity of Reality and Nature.
