> [!definition]
> **Modal Notation** · *Definition*
>
> Let R be Reality, the one whole. For any proposition P:
>
> - Capacity(R,P) means that P belongs to the complete range R has the capacity to admit.
> - ◇P means Capacity(R,P).
> - □P means ¬Capacity(R,¬P): R has no capacity for P’s failure.

Stated at [§2.1.4 — Modal Stability](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.4%20Modal%20Stability).
