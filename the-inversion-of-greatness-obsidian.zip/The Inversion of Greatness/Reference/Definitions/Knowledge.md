> [!identification]
> **Knowledge** · *Identification*
>
> Knowledge is a subject’s sufficiently accurate and appropriately connected held orientation within some domain: propositional, procedural, or acquaintance-based. A modal field contains the alternatives and relations a subject represents; only the parts that meet the relevant standards of truth, competence, acquaintance, reliability, or non-accidentality count as knowledge. The field can therefore be deeper than the subject’s knowledge and can contain error alongside it.
> *Status: the first-person act establishes minimal differentiation and holding, not knowledge of every represented content. Global denial cannot coherently erase the conditions of inquiry instantiated in the denial, while depth, fidelity, warrant, and the boundaries among the three forms remain substantive epistemological questions. Upstream: Synthesis of Nature Alone ([[4.9 Synthesis|§4.9]]); Chapter 11 inversions [[11.3.4 Impassibility|§11.3.4]], [[11.4.2 Omniscience|§11.4.2]].*
>
> **Depends on:** [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]]) and [[Modal Pressure]] ([[5. Expanding the Field|§5]])

Stated at [§5.4 — 5.4 Knowledge](../../5.%20Expanding%20the%20Field/5.4%20Knowledge.md).
