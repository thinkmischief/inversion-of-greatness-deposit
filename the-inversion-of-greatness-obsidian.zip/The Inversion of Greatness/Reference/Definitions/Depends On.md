> [!definition]
> **Depends On** · *Definition*
>
> [[Consent’s Conditions]] ([[5.14 Morality|§5.14]])
>
> **Defined within:** [[Consent as Right Modifier]]
