> [!definition]
> **Necessity** · *Definition*
>
> A proposition is necessary when it really could not fail to be the case (□P).

Stated at [§1.2.3 — Necessity](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.3%20Necessity).

## Glossary

*Definition.* A proposition is necessary (□P) when it really could not fail to be the case. What is necessary does not lapse: there is no configuration with a square circle, no configuration with 2 + 2 = 5. Necessity can attach to possibility itself—□◇P is true just when the permission does not lapse in any configuration. Established in [[1.2 Modal Status|§1.2]].
