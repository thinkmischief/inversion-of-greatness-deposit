> [!definition]
> **Consent as Right Modifier** · *Definition*
>
> Consent is the subject’s authority to modify the default rule governing a protected domain: the rights-bearer’s act of specifying what may happen within that domain, by whom, under what conditions, and for how long. It does not erase the right; it exercises the right. Refusal leaves the default protection in force, and consent changes the permitted relation only to the extent the competent subject has authorized it. Consent must therefore be informed, voluntary, competent, and specific; where it licenses an ongoing use of the subject’s body, presence, or intimate participation, it must also remain prospectively revocable. Absent those conditions, the purported modification is not the subject’s rule for what may happen to them, but another party’s rule imposed through the grammar of permission. Withdrawal does not undo completed acts or erase external responsibilities already incurred.
>
> **Depends on:** [[Consent’s Conditions]] ([[5.14 Morality|§5.14]])

Stated at [§6.1.2 — The Requirement](../../6.%20Maximum%20Possibility/6.1%20Rights.md#6.1.2%20The%20Requirement).
