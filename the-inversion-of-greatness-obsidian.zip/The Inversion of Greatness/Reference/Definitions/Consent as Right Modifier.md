> [!definition]
> **Consent as Right Modifier** · *Definition*
>
> Consent is the subject’s authority to modify the default rule governing a protected domain: the rights-bearer’s act of specifying what may happen within that domain, by whom, under what conditions, and for how long. It does not erase the right; it exercises the right. Refusal leaves the default protection in force, and consent changes the permitted relation only to the extent the competent subject has authorized it. Consent must therefore be informed, voluntary, competent, specific, and revocable: absent those conditions, the purported modification is not the subject’s rule for what may happen to them, but another party’s rule imposed through the grammar of permission.
>
> **Depends on:** [[Consent’s Conditions]] ([[5.14 Morality|§5.14]])

Stated at [§6.1 — 6.1 Rights](../../6.%20Maximum%20Possibility/6.1%20Rights.md).
