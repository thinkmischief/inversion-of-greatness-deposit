> [!definition]
> **Impossibility** · *Definition*
>
> A proposition is impossible when it really could not be the case (¬◇P).

Stated at [§1.2.2 — Impossibility](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.2%20Impossibility).

## Glossary

*Definition.* A proposition is impossible (¬◇P) when it really could not be the case. Structurally so: there is no configuration that includes it. Distinguished from “very improbable” and “situationally unobtainable.” Established in [[1.2 Modal Status|§1.2]].
