> [!definition]
> **Convergent Individualism** · *Definition*
>
> A political proposal in which distinct subjects retain separate ends and wide latitude above a common participation foundation, while converging on maintenance of that foundation through shared institutions they can hold accountable.

Stated at [§6 — 6. Maximum Possibility](../../6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md).
