> [!identification]
> **Feeling** · *Identification*
>
> Feeling is the conscious registration of a body’s condition and situation with valence, salience, or urgency. It can concern what is actual, remembered, anticipated, imagined, or merely believed possible. The chapter proposes that affect is the lived readout of integrated stake-sensitive regulation rather than a second signal added after valuation has occurred.
> *Status: the first-person actuality of feeling and its temporal, differentiated, embodied character are strict in the witness case. Affect’s relation to valuation, attention, interoception (the sensing of the body’s internal condition), appraisal, and action is empirically supported but theoretically contested. Attending to a denial demonstrates selective attention, not affect; that feeling is the proposed integrated readout remains a functional proposal defended by fit.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]])

Stated at [§5.3 — 5.3 Feeling](../../5.%20Expanding%20the%20Field/5.3%20Feeling.md).
