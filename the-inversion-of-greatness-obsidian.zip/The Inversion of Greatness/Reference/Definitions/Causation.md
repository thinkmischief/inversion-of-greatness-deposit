> [!definition]
> **Causation** · *Definition*
>
> One event brings about another: *X causes Y*. What the *bringing about* amounts to, mere regularity or real production, is the standing dispute.

Stated at [§1.5.6 — Causation](../../1.%20Groundwork/1.5%20Existence.md#1.5.6%20Causation).

## Glossary

*Concept.* In the productive or efficient sense, a source causes a concrete effect when the effect obtains because the source makes a difference to it. Causation isn’t identified with Φ here: at the resolution of the Chapter 2 theorem, Φ supplies cross-interval bearing, while productive causal transmission belongs to the richer realization tier. Whether efficient causation is mere regularity or real production remains the Humean/anti-Humean dispute fixed at [[1.5 Existence#1.5.6 Causation|§1.5.6]]. Material, formal, and final causes answer different explanatory questions, and metaphysical grounding is non-causal dependence. The Concrete-Entity Test applies to concrete productive work, not to every use of *because* or *cause* ([[2.4 Structural Requirement|§2.4]]); the offices where divine causality is tested are distinguished at [[11.7.2 Causality|§11.7.2]].
