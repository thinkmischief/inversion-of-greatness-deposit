> [!identification]
> **Language** · *Identification*
>
> Language is a structured social practice for coordinating signs and acts across subjects. Its vehicles can be propositional, indexical, expressive, interrogative, imperative, performative, iconic, or ostensive; often one utterance does several jobs. Understanding is not reproduction of an interior but sufficient practical alignment in use, reference, inference, response, and correction. The interval between subjects is not a barrier to that coordination but its condition.
> *Status: an addressed denial already performs a communicative act across an interval, establishing only the local fact of attempted coordination. Cartesian Certainty does not derive linguistic conventions, semantic content, propositional form, or successful understanding. The broader account is a functional proposal defended by fit with public criteria and linguistic practice. Chapter 11 application: [[11.8.3 Describability|§11.8.3]].*
>
> **Depends on:** [[Knowledge]] ([[5.4 Knowledge|§5.4]]) and [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]])

Stated at [§5.12 — 5.12 Language](../../5.%20Expanding%20the%20Field/5.12%20Language.md).
