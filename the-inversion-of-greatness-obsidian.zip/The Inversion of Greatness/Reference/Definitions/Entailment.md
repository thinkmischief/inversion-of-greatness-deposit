> [!definition]
> **Entailment** · *Definition*
>
> One claim guarantees another: *P entails Q* means there is no way for P to be true while Q is false.

Stated at [§1.5.3 — Inference](../../1.%20Groundwork/1.5%20Existence.md#1.5.3%20Inference).

## Glossary

*Concept.* One claim guarantees another: *P entails Q* means there is no way for P to be true while Q is false. Throughout the book *entails* carries the modal-metaphysical reading—no possible world in which P obtains and Q fails—unless the context is explicitly formal-logical. *See also* Necessity. Established in [[1.5 Existence#1.5.3 Inference|§1.5.3]].
