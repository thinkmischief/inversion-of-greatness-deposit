> [!definition]
> **Contingency** · *Definition*
>
> A proposition is contingent when it really could be the case and really could fail to be (◇P ∧ ◇¬P).

Stated at [§1.2.4 — Contingency](../../1.%20Groundwork/1.2%20Modal%20Status.md#1.2.4%20Contingency).

## Glossary

*Definition.* A proposition is contingent (◇P ∧ ◇¬P) when it really could be the case and really could fail to be. The modal status that tracks arrangement-dependence: truth varies with which configuration obtains. Established in [[1.2 Modal Status|§1.2]].
