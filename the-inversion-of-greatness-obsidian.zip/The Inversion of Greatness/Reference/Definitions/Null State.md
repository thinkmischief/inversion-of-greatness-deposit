> [!definition]
> **Null State** · *Definition*

Stated at [§2.7.1 — Null State (∅)](../../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.1%20Null%20State%20(%E2%88%85)).

## Glossary

*Definition.* Absolute nothingness. Not a state of Reality; the absence of any state. Distinguished from vacuum (which is structured emptiness within Reality) and from absence-of-X (which is a determinate fact within Reality). Cannot be a contrast class for Reality because it cannot be specified ([[2.7 Nothing to Consider#2.7.1 Null State (∅)|§2.7.1]]).
