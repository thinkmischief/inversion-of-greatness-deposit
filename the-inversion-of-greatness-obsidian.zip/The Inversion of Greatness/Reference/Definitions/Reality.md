> [!definition]
> **Reality** · *Definition*
>
> The whole within which any thing is a thing: what anything real belongs to, and what gives the word *real* its content. The belonging is structural, not set-theoretic. Reality is not a member of some larger collection, and it is not a member of itself either—it is the whole within which membership is possible at all.

Stated at [§1.1 — 1.1 Reality](../../1.%20Groundwork/1.1%20Reality.md).

## Glossary

*Definition.* The totality of what is real. Fixed by the role rather than by any claim about what fills it: whether Reality is matter or mind or number, one or many, created or not, is left open here. Has no contrast class—nothing is outside Reality, because anything that could be specified would be part of it ([[1.1 Reality|§1.1]]). *See also* Identity of Reality and Nature.
