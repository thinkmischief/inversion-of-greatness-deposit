> [!identification]
> **Identity** · *Identification*
>
> Identity, in the autobiographical and practical sense developed here, is the organism’s maintained self-model: itself represented as an embodied agent with a history, relations, commitments, and projected continuations. That model is real as an organized activity and can change or fragment without implying that every form of consciousness or organismic continuity changes with it.
> *Status: Cartesian Certainty establishes a present subject-position without settling its persistence criterion or internal architecture. Evidence supports dissociable narrative, embodied, agentive, and perspectival components of self-representation. The claim that the maintained self-model exhausts personal identity, and the choice among organismic, psychological, narrative, and further-fact continuity accounts, remains defended by argument and fit. Upstream: [[5.6 Reasoning|§5.6]]; Synthesis of Nature Alone ([[4.9 Synthesis|§4.9]]).*
>
> **Depends on:** [[Consciousness]] ([[5.1 Consciousness|§5.1]]) and [[Knowledge]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.7 — 5.7 Identity](../../5.%20Expanding%20the%20Field/5.7%20Identity.md).
