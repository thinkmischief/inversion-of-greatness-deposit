> [!identification]
> **Art** · *Identification*
>
> Art is a socially situated practice of making, selecting, framing, performing, or sustaining forms for aesthetic, expressive, imaginative, commemorative, critical, or ritual uptake. A work can occasion perspectival and affective understanding that no paraphrase reproduces, while also carrying propositions and actions. Its reception is constrained without being copied: different warranted readings can emerge from the same work, and some readings can still be poorly supported by its form, history, or context. Resonance (beauty) is one possible event, not the definition of the register.
> *Status: Drive, imagination, feeling, language, and technology supply capacities art recruits; none strictly derives art or an exhaustive definition of it. Deliberate transmission is one important case, not a necessary condition: improvisation, collective practice, found objects, ritual inheritance, and works whose effects outrun their makers remain possible. The account is a functional proposal defended by range and fit.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]), [[Imagination]] ([[5.5 Imagination|§5.5]]), [[Feeling]] ([[5.3 Feeling|§5.3]]), and [[Language]] ([[5.12 Language|§5.12]])

Stated at [§5.15 — 5.15 Art](../../5.%20Expanding%20the%20Field/5.15%20Art.md).
