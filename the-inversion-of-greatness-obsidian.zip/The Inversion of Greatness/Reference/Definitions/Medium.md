> [!definition]
> **Medium** · *Definition*
>
> What carries or sustains something across: a beam *bears* a load, a wire *carries* a current. A medium can bear without producing.

Stated at [§1.5.7 — Medium of Transmission](../../1.%20Groundwork/1.5%20Existence.md#1.5.7%20Medium%20of%20Transmission).

## Glossary

*Concept.* What carries or sustains something across: a beam *bears* a load, a wire *carries* a current. Adjacent to causation but distinguishable—a medium can bear without producing. Names the general transmission operator, not a role-term for Nature or a synonym for Substance ([[1.4 Three Conditions#1.4.3 Substance|§1.4.3]]). Established in [[1.5 Existence#1.5.7 Medium of Transmission|§1.5.7]].
