> [!identification]
> **Sexuality** · *Identification*
>
> Sexuality is one differentiation of drive’s attraction-pole: the embodied and self-modeled register shaped, in lineages whose variation architecture includes sexual reproduction, by the possibility of coupling across distinct organisms. At sufficient depth it is registered from inside as attraction, desire, orientation, embodied coupling, and sexual identity, including configurations in which sexual attraction is minimal, absent, or conditional. It is the structural pair to mortality at the lineage level wherever variation-generating coupling is the lineage’s solution; no corresponding reproductive aim is imposed on any individual subject or expression.
> *Status: the structural half is Drive’s attraction-pole differentiated; desire is the word Drive already uses once the pull has an object. Thin certainty: some ways of connecting are more intimate than others. There is a depth gradient of how intimate a field feels with different agents—some people you connect with, some you do not. That gradient is this register plus Meaning and Identity, not a Cogito for “sexuality exists.” Sexual identity, a shared encounter, reproduction for those who weight it, can each mean something—that weighting is [[5.10 Meaning|§5.10]]. Occurrence of sexual reproduction remains contingent on lineage biology. That this differentiated field just is sexuality remains a functional proposal defended by fit.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]])

Stated at [§5.8 — 5.8 Sexuality](../../5.%20Expanding%20the%20Field/5.8%20Sexuality.md).
