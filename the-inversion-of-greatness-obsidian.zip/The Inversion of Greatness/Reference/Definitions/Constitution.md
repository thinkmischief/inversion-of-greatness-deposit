> [!definition]
> **Constitution** · *Definition*
>
> The relation between a thing and what it is made up of, read from either side: the clay *constitutes* the statue, and the statue *consists in* the clay.

Stated at [§1.5.2 — Constitution](../../1.%20Groundwork/1.5%20Existence.md#1.5.2%20Constitution).

## Glossary

*Concept.* The relation between a thing and what it is made up of, read from either side: the clay *constitutes* the statue, and the statue *consists in* the clay. Runs at both the material-token level (statue and clay) and the role-analytic level (*change consists in succession, distinction, and exchange*). Established in [[1.5 Existence#1.5.2 Constitution|§1.5.2]].
