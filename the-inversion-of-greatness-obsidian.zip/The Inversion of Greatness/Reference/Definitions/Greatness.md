> [!definition]
> **Greatness** · *Definition*
>
> The gradable dimension along which anything that exists in its own right—a *subsistence*—may stand. Great-making properties such as knowledge, power, goodness, presence, and life admit of more and less, so one subsistence may stand higher on a given property than another. A *maximum possible* degree is the most of a property that could actually be held, whether by one individual or by a subsistent collective; it is not an absolute stipulated in advance. The ceiling at which every property reaches the greatest degree compatible with the others is what the tradition calls *maximal greatness*.

Stated at [§11.1 — 11.1 Greatness](../../11.%20Reclaiming%20Greatness/11.1%20Greatness.md).
