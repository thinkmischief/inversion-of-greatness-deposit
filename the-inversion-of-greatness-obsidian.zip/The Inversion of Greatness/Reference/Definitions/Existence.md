> [!definition]
> **Existence** · *Definition*
>
> To exist concretely is to occupy a when, a where, and a what: to stand in Time, Space, and Substance rather than outside them. A concrete thing’s existing just *is* that standing, not something extra added on top of what the thing already is.

Stated at [§1.5.1 — Existence and Instantiation](../../1.%20Groundwork/1.5%20Existence.md#1.5.1%20Existence%20and%20Instantiation).

## Glossary

*Definition.* Concrete existence is the three Conditions in determinate operation; it need not mean point-location in metric space. Abstract existence is an abstraction of structural articulation and therefore realizes the Conditions at abstract resolution without thereby becoming a concrete location or activity. A candidate said to change, act, experience, create, sustain, or cause incurs the concrete definition at the operation. Established in [[1.5 Existence|§1.5]]; formalized by the Concrete-Entity Test at [[2.4 Structural Requirement|§2.4]] and the constitutive non-addition of [[2.8 Reality–Nature Identity|§2.8]].
