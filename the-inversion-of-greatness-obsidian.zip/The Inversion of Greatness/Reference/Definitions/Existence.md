> [!definition]
> **Existence** · *Definition*
>
> To exist is to occupy a when, a where, and a what: to stand in Time, Space, and Substance rather than outside them. A thing’s existing just *is* that standing, not something extra added on top of what the thing already is.

Stated at [§1.5.1 — Existence and Instantiation](../../1.%20Groundwork/1.5%20Existence.md#1.5.1%20Existence%20and%20Instantiation).

## Glossary

*Definition.* To exist is to stand in Time, Space, and Substance: the three Conditions in determinate operation. Existence is univocal. It need not mean point-location in metric space, and there is no second, abstract kind of existence. Numbers, propositions, sets, and relations are real as structure that existing things have or could have; *abstract existence* is shorthand for that standing, not a second way of existing. A candidate said to change, act, experience, create, sustain, or cause incurs the concrete definition at the operation. Established in [[1.5 Existence|§1.5]]; spent by the Concrete-Entity Test at [[2.4 Structural Requirement|§2.4]], and derived at [[2.8 Reality–Nature Identity|§2.8]] as Univocal Existence (the Concreteness Fork) and, applied to abstracta, as the No Independent Abstract Realm (the Abstracta Fork).
