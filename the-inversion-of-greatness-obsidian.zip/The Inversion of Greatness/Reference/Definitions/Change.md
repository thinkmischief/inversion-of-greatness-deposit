> [!definition]
> **Change** · **C** · *Definition*
>
> The concrete transition witnessed here, at minimum resolution: one state, then another.

Stated at [§1.3 — 1.3 Change](../../1.%20Groundwork/1.3%20Change.md).

## Glossary

**C** · *Reference-fixing definition.* The concrete reflective transition witnessed in reading, doubting, and recognizing the doubt, introduced at minimum resolution as *one state, then another*. The phrase fixes the phenomenon rather than exhaustively analyzing a maximally thin generic succession. Its ordered phases, concrete co-present differentiation, and retained content are progressively resolved as Succession, Distinction, and Exchange without changing C’s reference. Lowercase *change* may retain its ordinary generic use; formal C always names the witnessed kind fixed at [[1.3 Change|§1.3]] and displayed at full resolution in [[2.2 Cartesian Certainty|§2.2]].
