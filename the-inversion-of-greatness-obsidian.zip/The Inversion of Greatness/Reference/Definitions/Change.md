> [!definition]
> **Change** · **C** · *Definition*
>
> The concrete transition witnessed here, at minimum resolution: one state, then another. C is the kind of transition of which the witnessed transition is a token, fixed at that minimum resolution; ◇C says that Reality has the capacity for a transition of that kind.

Stated at [§1.3 — 1.3 Change](../../1.%20Groundwork/1.3%20Change.md).

## Glossary

**C** · *Reference-fixing definition.* The kind of transition of which the concrete transition witnessed in reading, doubting, and recognizing the doubt is a token, fixed at minimum resolution as *one state, then another*; ◇C says that Reality has the capacity for a transition of that kind. Reflection is evidential, not part of C’s intension: a displacement is another token of the same kind. The phrase fixes the phenomenon rather than exhaustively analyzing a maximally thin generic succession. Its ordered phases, concrete co-present differentiation, and retained content are progressively resolved as Succession, Distinction, and Exchange without changing C’s reference. Lowercase *change* may retain its ordinary generic use; formal C always names the witnessed kind fixed at [[1.3 Change|§1.3]] and displayed at full resolution in [[2.2 Cartesian Certainty|§2.2]].
