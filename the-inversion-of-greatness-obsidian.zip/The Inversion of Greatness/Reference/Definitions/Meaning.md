> [!identification]
> **Meaning** · *Identification*
>
> At its minimal first-person level, meaning is a subject’s field *weighted* as worth pursuing, protecting, or avoiding: which branches matter and what their loss would cost. Intersubjective meaning adds a different relation—the ways projects, practices, signs, and lives acquire significance among subjects across time. Where knowledge concerns accuracy, meaning concerns significance and direction.
> *Status: Drive supplies weighting, and a held field supplies something that can be weighted. That combination makes significance-to-a-subject available; it does not strictly derive every richer sense of “meaning,” prove that every inquiry is existentially meaningful, or determine which ends deserve pursuit. The proposed identification of lived meaning with weighted orientation is defended by fit. Its intersubjective forms require the relations developed later rather than being smuggled into the first-person result.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]) and [[Knowledge]] ([[5.4 Knowledge|§5.4]])

Stated at [§5.10 — 5.10 Meaning](../../5.%20Expanding%20the%20Field/5.10%20Meaning.md).
