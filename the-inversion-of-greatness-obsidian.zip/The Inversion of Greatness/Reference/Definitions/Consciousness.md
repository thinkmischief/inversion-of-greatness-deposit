> [!identification]
> **Consciousness** · *Identification*
>
> Consciousness is actual in at least the present first-person episode, and every such episode is temporally ordered, differentiates content, and is concretely borne. Consciousness is what sufficiently integrated self-producing life is like from within: at minimum, a bounded organism’s integrated registration of its own condition in relation to its environment, where differences bear positively or negatively on it and can alter its conduct. Depth varies along discrimination, temporal reach, flexible integration, and reflective self-awareness, as a branching profile rather than a ladder.
>
> *Status: the first-person witness and the structural constraint are strict; the identity is abductive, warranted by biological continuity, multiple realization, and explanatory economy.*
>
> **Depends on:** [[Cartesian Certainty]] ([[2.2 Cartesian Certainty|§2.2]]) and [[Life]] ([[4.8 Life|§4.8]])

Stated at [§5.1 — 5.1 Consciousness](../../5.%20Expanding%20the%20Field/5.1%20Consciousness.md).

## Glossary

*Identification.* Consciousness is actual in at least the present first-person episode, and is what sufficiently integrated self-producing life is like from within: at minimum, a bounded organism’s integrated registration of its own condition in relation to its environment, where differences bear positively or negatively on it and can alter its conduct. Depth varies along discrimination, temporal reach, flexible integration, and reflective self-awareness, as a branching profile rather than a ladder. The first-person witness and T/S/Φ constraint are strict. Biological continuity, multiple realization, and explanatory economy warrant the identity between phenomenal awareness and the proposed living organization abductively as the best-supported explanation developed at [[5.1 Consciousness|§5.1]]; they do not deductively demonstrate it. Configurational Necessitation and Strict Actualization apply strictly only if that sufficiency premise is true. Life at [[4.8 Life|§4.8]].
