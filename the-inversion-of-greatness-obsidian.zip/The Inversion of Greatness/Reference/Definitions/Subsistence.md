> [!definition]
> **Subsistence** · *Definition*
>
> *Subsistence* ordinarily names continued existence or the means by which it is maintained. Here the noun is used in a stipulated political sense for a relation in which members and institutions maintain the shared conditions of agency-bearing life and effective participation. The stipulation is explanatory shorthand, not an inference from etymology and not a claim that a polity is literally an organism or a single subject.

Stated at [§6 — 6. Maximum Possibility](../../6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md).

## Glossary

*Political-structural definition.* Ordinarily, continued existence or the means by which it is maintained. Stipulated here in a political sense for a relation in which members and institutions maintain the shared conditions of agency-bearing life and effective participation—explanatory shorthand, not an inference from etymology and not a claim that a polity is literally an organism or a single subject. Distinct from **Subsistent Grounding**, the metaphysical result the political term rhymes with rather than restates. Established at the §6 chapter root; paired with Mutual Sustenance.
