> [!definition]
> **Subsistence** · *Definition*
>
> *Subsistence* ordinarily names continued existence or the means by which it is maintained. This chapter uses the noun in a stipulated political sense for a relation in which members and institutions maintain the shared conditions of continued participation. The stipulation is explanatory shorthand, not an inference from etymology and not a claim that a polity is literally an organism or a single subject.

Stated at [§6 — 6. Maximum Possibility](../../6.%20Maximum%20Possibility/6.%20Maximum%20Possibility.md).

## Glossary

*Political-structural definition.* Run intransitively, to subsist names what a subject does individually: continue to exist. Run transitively, it names what subjects do to each other: act on one another to keep one another in being. The noun names what the activity makes: a subsistence, the collective entity a community or commonwealth constitutes at that scale. Distinct from **Subsistent Grounding**, the metaphysical result the political term rhymes with rather than restates. Established at the §6 chapter root; paired with Mutual Sustenance.
