> [!identification]
> **Technology** · *Identification*
>
> Technology is the organized use of materials, processes, skills, or representations to extend or redirect practical capacity. Its developed forms can externalize models and procedures into shared substrates—notation, instruments, machines, computers—making them persistent, queryable, transmissible, and recombinable beyond one body. The artifact stores a configuration that users can exploit; it does not contain objective modal structure itself or guarantee that the representation embodied in it is accurate.
> *Status: Drive, learning, and practical reach make tool use intelligible but do not strictly entail technology. Successful technique may precede explicit understanding, and specific tools remain contingent on materials, transmission, history, and opportunity. The identification of technology with organized outward reach is a functional proposal defended by fit.*
>
> **Depends on:** [[Drive]] ([[5.2 Drive|§5.2]]), [[Knowledge]] ([[5.4 Knowledge|§5.4]]), and [[Language]] ([[5.12 Language|§5.12]])

Stated at [§5.13 — 5.13 Technology](../../5.%20Expanding%20the%20Field/5.13%20Technology.md).
