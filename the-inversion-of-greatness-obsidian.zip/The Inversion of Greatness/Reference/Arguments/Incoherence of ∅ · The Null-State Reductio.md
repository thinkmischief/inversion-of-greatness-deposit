> [!argument]
> **Incoherence of ∅** · *The Null-State Reductio*
>
> 1. Suppose absolute structural absence: no directed order, no determinate difference, no bearing, no fact-profile, and no evaluation structure. That is the null state, ∅. It is stronger than an objectless world, which may retain a determinate structure.
> 1. Suppose ◇∅. Then ∅ must qualify as a possible-world evaluation point: a candidate at which contents can be settled one way rather than another.
> 1. Qualifying as an evaluation point requires at least determinate content that could be true or false. By definition, ∅ supplies neither that content nor the standing it requires. It isn’t an unusually empty evaluation point but the removal of what lets anything count as one.
> 1. ∴ ∅ isn’t a possible world: ¬◇∅
>
> *Scope.* This conclusion does **not** arise because the meta-level sentence “∅ obtains at w” becomes a fact *inside* w. That inference would confuse a truth about a representation with content represented as internal to the world. Nor does ¬◇∅ by itself yield □(T ∧ S ∧ Φ). The full modal-core conjunction remains the Chapter 2 theorem; the Triconditional Cross-Entailment ([[2.6 Triconditionality of Nature#2.6.7 Triconditional Cross-Entailment|§2.6.7]]) is an upstream dependency if one tries to move from the absence of total collapse to the inseparability of the loaded Conditions.

Stated at [§3.2.6 — The Null-State Reductio](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.6%20The%20Null-State%20Reductio).
