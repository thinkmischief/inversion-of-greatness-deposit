> [!argument]
> **The No-Way Argument** · *Argument*
>
> 1. God has no alternative way to be: by the tradition’s own commitment to simplicity, *actus purus*, and immutability, God couldn’t have been otherwise.
> 1. The absence of alternatives isn’t by itself the defect, and the argument must not be run as though it were. A necessary being has exactly *one* way to be, and *Necessity entails Possibility* ([[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]]) gives □P → ◇P: what couldn’t fail to be the case could, in particular, be the case. Uniqueness of way is therefore compatible with possibility, and an inference straight from *no alternative* to *not possible* would contradict the book’s own modal grammar ([[1.2 Modal Status#1.2.1 Possibility|§1.2.1]]).
> 1. What does the work is the *strict formulation’s* further denial of every thin or analogical content by which the divine predicates could have determinate content. Simplicity and pure actuality alone don’t yield that denial. Where it is added, what remains isn’t one determinate way with alternatives foreclosed but a description with no stated conditions of satisfaction.
> 1. To be possible is to have a determinate way to be: ◇P ↔ ∃way(P) (Way–Possibility Convertibility, [[3.2 Triconditional Necessity - From Below#3.2.5 Shape of Possibility|§3.2.5]]). An analogically structured account satisfies this step only if it supplies a determinate divine correlate. That correlate is then an aspect of Nature and inherits the predication and realization questions at [[10.2.1 Divine Simplicity|§10.2.1]] rather than being declared impossible here.
> 1. ∴ The classical theist’s God, on the strict content-stripped formulation, isn’t possible. *(3, 4)*
> 1. What isn’t possible is impossible.
> 1. ∴ The classical theist’s God, on that formulation, is impossible.
>
> *Scope.* What is shown impossible by this fast line is the strict, fully content-stripped set, not every doctrine that calls God necessary. Essence-prior, apophatic, or analogically structured proposals remain assessable only where they supply enough content to distinguish their alleged referent. Once they do, the [[No Divine Addition]] result below locates that content as Nature or an aspect of Nature rather than an independent divine remainder.

Stated at [§11.10 — 11.10 What Remains of God](../../11.%20Reclaiming%20Greatness/11.10%20What%20Remains%20of%20God.md).
