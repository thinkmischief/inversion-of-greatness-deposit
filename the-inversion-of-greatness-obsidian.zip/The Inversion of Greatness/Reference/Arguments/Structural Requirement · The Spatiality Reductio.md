> [!argument]
> **Structural Requirement** · *The Spatiality Reductio*
>
> Let Place(x) mean *x is placed*.
>
> 1. Any placing requires Spatiality, since *placed* presupposes a relational interval between positions (∀x(Place(x) → S)).
> 1. Something is placed: there is at least one placing, demonstrably the plural *heres* of the present standpoint (∃xPlace(x)).
> 1. So Spatiality is instantiated (∴ S; from 1, 2).
> 1. If Spatiality had ever been absent, it would have to be placed or introduced, since a transition from its absence to its presence is itself a placing (Place(S)).
> 1. **Space cannot have been introduced, because introducing needs somewhere to put it.** Any placing or introduction of Spatiality would require Spatiality already in place at its own onset, since line 1’s warrant—*placed* presupposes a relational interval between positions—applies to the placing of S itself (Place(S) → S-at-or-before-Place(S)).
> 1. ∴ So Spatiality was never absent: the supposed onset entails S at or before the first placing of S—S-prior-to-S, a contradiction (from 4, 5 by reductio).

Stated at [§2.4.7 — Distinction Requires Spatiality](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.7%20Distinction%20Requires%20Spatiality).
