> [!argument]
> **Structural Requirement** · *The Spatiality Reductio*
>
> Let Place(x) mean *x is placed*.
>
> 1. Any placing requires Spatiality, since *placed* presupposes a relational interval between positions (∀x(Place(x) → S)).
> 1. Something is placed: there is at least one placing, demonstrably the plural *heres* of the present standpoint (∃xPlace(x)).
> 1. So Spatiality is instantiated (∴ S; from 1, 2).
> 1. Suppose Spatiality emerged from its total absence. That emergence would be a real transition from no Spatiality to Spatiality.
> 1. **Any real transition requires Spatiality.** Its terms must be determinately distinct, and the transition must cross the relation between them; otherwise there are not two states joined in one change but only two unrelated descriptions. That crossable relational exteriority is S at modal-core resolution (*Relational Distinctness*).
> 1. ∴ Spatiality cannot emerge from no Spatiality. The alleged onset would instantiate S in the very transition by which S was supposed first to appear.

Stated at [§2.4 — 2.4 Structural Requirement](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md).
