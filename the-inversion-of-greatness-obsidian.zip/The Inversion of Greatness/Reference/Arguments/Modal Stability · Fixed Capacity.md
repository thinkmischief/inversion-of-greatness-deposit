> [!argument]
> **Modal Stability** · *Fixed Capacity*
>
> 1. If ¬Capacity(R,P), no real evaluation admits P. An evaluation that admitted P would itself witness Capacity(R,P), contradicting the exclusion. Therefore ¬◇P → □¬◇P (*Negative boundary*)
> 1. By Modal Bivalence, Capacity(R,P) and ¬Capacity(R,P) exhaust P’s modal status. A change from Capacity(R,P) to ¬Capacity(R,P) would change the fixed exclusion boundary. Therefore ◇P → □◇P (*Complement*)
> 1. If □P, then R has no capacity for ¬P. If ¬P were actual, actuality would demonstrate that very capacity. Therefore P: □P → P (*T*)
> 1. Since the incapacity constituting □P is fixed by the negative boundary, □P → □□P (*S4*)
> 1. If P is actual, actuality demonstrates Capacity(R,P). By the complement result, P → □◇P (*B*)
> 1. ∴ T, S4, and B over the normal modal base yield the familiar S5 representation of the bilateral result.

Stated at [§2.1.4 — Modal Stability](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.4%20Modal%20Stability).
