> [!argument]
> **Incoherence of ∅** · *The Modal Form*
>
> 1. If ∅ is a possible world, ∅ is an evaluation point: a world at which claims, modal claims included, can be true or false (◇∅ → ∅ is an evaluation point).
> 1. Being an evaluation point requires sustaining a structured state of affairs—holding contents one way rather than another ([[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]]).
> 1. ∅, the joint absence of T, S, and Φ, sustains no structured state of affairs and so isn’t an evaluation point, by definition ([[2.7 Nothing to Consider#2.7.1 Null State (∅)|§2.7.1]]).
> 1. ∴ ∅ isn’t a possible world, by modus tollens on steps 1 and 3 (¬◇∅).

Stated at [§2.7.2 — Incoherence of ∅](../../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.2%20Incoherence%20of%20%E2%88%85).
