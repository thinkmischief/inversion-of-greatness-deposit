> [!argument]
> **Triconditional Necessity** · *The Self-Refutation*
>
> 1. Any denial of □(T ∧ S ∧ Φ) is a propositional act.
> 1. Any propositional act requires ordered enactment (O), distinction (D), and bearing (B) as its conditions of possibility.
> 1. So any denial of □(T ∧ S ∧ Φ) instantiates the generic role-floor in the act of denying: ordered enactment (O), distinction (D), and bearing (B).
> 1. This holds in every world where a denial is so much as formulated (no principle of sufficient reason assumed).
> 1. A world with no denier is untouched by the performative argument. Its silence doesn’t imply that it lacks any Condition, and a denier-free world cannot be identified with ∅ merely from the absence of a tokened denial.
> 1. ∴ The line establishes O, D, and B wherever a denial or inference is performed—not the modal-core Conditions, which Chapter 2 supplies ([[2.4 Structural Requirement|§2.4]]) and whose uneven recovery here is audited at [[3.3 Triconditional Necessity - From Above#3.3.6 Uneven Overdetermination|§3.3.6]]. Cross-world necessity requires the separate silent-world bridge identified at [[3. Convergence/3.1 Necessary Possibility of Change - Stress-Tested#3.1.3 The Performative Witness|§3.1.3]] and 3.5.4.

Stated at [§3.3.1 — Denial Runs on Nature](../../3.%20Convergence/3.3%20Triconditional%20Necessity%20-%20From%20Above.md#3.3.1%20Denial%20Runs%20on%20Nature).
