> [!argument]
> **A Beginning Needs What It Would Begin** · *The Cosmological Inversion*
>
> 1. **A categorial beginning of Nature would be a transition from Nature’s absence to Nature’s presence.** This is stronger than a first chronometric coordinate within Nature: it is the onset of the structural field itself.
> 1. **Any real transition requires ordered terms, a determinate difference between them, and something in which the transition obtains.** In the book’s modal-core vocabulary, a transition requires Temporality, Spatiality, and Substantiality—the when, where, and what of Change (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]]).
> 1. **Those Conditions jointly are Nature.** Nature names T∧S∧Φ in operation (*Triconditional Identity*, [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]]).
> 1. **So a transition by which Nature began would already instantiate Nature.** The proposed onset presupposes on the transition what it denies on the absence side.
> 1. **∴ Nature has no categorial beginning.** A transition from no Nature to Nature would already instantiate what it claims to originate.
>
> *Scope.* This line establishes that Nature has no categorial beginning. It should not be read as conceding a first moment: the separate [[The First-State Dilemma]] rules that out on further premises in [[4.6 Singularity|§4.6]]. The present line doesn’t by itself establish that Nature is necessary, which the modal proof argues separately ([[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]), and it doesn’t touch the simultaneous-dependence burden, which asks for moment-by-moment sustaining rather than for an origin ([[10.1.6 The Divine Conservation Argument|§10.1.6]]). A defender who grants the conclusion may still press that Nature is held in being without having begun.

Stated at [§10.1.5 — 10.1.5 The Cosmological Argument](../../10.%20Rival%20Ultimates/10.1.5%20The%20Cosmological%20Argument.md).
