> [!argument]
> **A Beginning Needs What It Would Begin** · *The Cosmological Inversion*
>
> 1. **Whatever begins to exist begins at a time, in a place, and from something that persists through the beginning.** This is what the Kalām’s own ordinary cases display before any causal reading is imposed on them ([[10.1.5 The Cosmological Argument|§10.1.5]]).
> 1. **There is no time, place, or persisting substance outside Nature.** Nature is Reality’s necessary constitution, and no real content occupies a modal domain outside it (*Reality–Nature Identity*, [[2.8 Reality–Nature Identity|§2.8]]).
> 1. **So if Nature began, its beginning would have a when, a where, and a what—all of them internal to Nature.** Nature would have to obtain already at its own beginning.
> 1. **∴ Nature did not begin.** The categorial beginning the argument requires—a moment prior to T from which T departed—is foreclosed, and what remains available is a chronometric boundary within T ([[2.4 Structural Requirement#2.4.6 Succession Requires Temporality|§2.4.6]]).
>
> *Scope.* This establishes that Nature has no categorial beginning. It doesn’t establish that Nature is necessary, which the modal line argues separately ([[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]), and it doesn’t touch the dependence-seeking wing, which asks for moment-by-moment sustaining rather than for an origin ([[10.1.6 The Divine Conservation Argument|§10.1.6]]). A defender who grants the conclusion may still press that Nature is held in being without having begun.

Stated at [§10.1.5 — 10.1.5 The Cosmological Argument](../../10.%20Rival%20Ultimates/10.1.5%20The%20Cosmological%20Argument.md).
