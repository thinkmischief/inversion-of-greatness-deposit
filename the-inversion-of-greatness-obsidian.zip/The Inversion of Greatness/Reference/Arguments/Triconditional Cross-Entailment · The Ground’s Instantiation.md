> [!argument]
> **Triconditional Cross-Entailment** · *The Ground’s Instantiation*
>
> Let e be an actual experience and g its proposed ground.
> 1. **Keep representation, represented content, and instantiation apart.** To instantiate a structural feature F is for F to be actually present in e; to encode F is for a representation to have F as content while F itself is absent (*The representation distinction*).
> 1. **If any one Condition is operatively instantiated in e, all three are instantiated in e.** The Operative-Role Bridge and Triconditional Cross-Entailment yield T(e)∧S(e)∧Φ(e), not merely a representation of that conjunction.
> 1. **If e is a state g is in, e’s operative structure is instantiated by g.** State–Realizer Instantiation yields T(g)∧S(g)∧Φ(g); the structure is the ground’s own rather than content it merely hosts.
> 1. ∴ If e is actually structured and is a state of g, then g instantiates T, S, and Φ. A ground that merely encodes the Conditions could underwrite a representation of such experience, but not the actually structured experience required by [[3. Convergence/3.1 Necessary Possibility of Change - Stress-Tested#3.1.5 The Witness and Its Ground|The Witness and Its Ground (§3.1.5)]].
>
> *Scope.* Whether weak or strong, emergence may relocate where a feature is first instantiated; it cannot convert actual instantiation into mere encoding. Once the feature is actually present, step 2 fires.

Stated at [§2.6 — 2.6 Triconditionality of Nature](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md).
