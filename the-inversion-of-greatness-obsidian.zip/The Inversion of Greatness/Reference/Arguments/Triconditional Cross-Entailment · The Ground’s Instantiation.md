> [!argument]
> **Triconditional Cross-Entailment** · *The Ground’s Instantiation*
>
> 1. Three things must be kept apart: the representation itself, its represented content, and the instantiation of what is represented. To instantiate a structural feature F is for F to be actually present; to encode F is to bear a representation whose content is F while F itself is absent. A two-dimensional engine encodes three-dimensional space without occupying it: the distinction is what the result turns on, and it is this three-way form that the book uses wherever representing is contrasted with instantiating (*The representation distinction*)
> 1. The actual instantiation of any one Condition-feature carries the conjunction of the other two with it in that experiencing (*Triconditional Cross-Entailment*)
> 1. An experience in which the Conditions are actually present is a state its ground is in, not a content it merely hosts and not a free-floating fact; State–Realizer Instantiation therefore makes the instantiation the ground’s own rather than a structure the ground merely represents.
> 1. ∴ A ground of actually-structured experience instantiates T, S, and Φ. One that merely encoded them could underwrite a representation of such experience, but not an experience in which the structure is actually present, and it is the latter that [[2.2 Cartesian Certainty#2.2.2 Actuality’s Reach|Actuality’s Reach (§2.2.2)]] requires.
>
> *Scope.* Whether weak or strong, emergence may relocate where a feature is first instantiated; it cannot convert actual instantiation into mere encoding. Once the feature is actually present, step 2 fires.

Stated at [§2.6.7 — Triconditional Cross-Entailment](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md#2.6.7%20Triconditional%20Cross-Entailment).
