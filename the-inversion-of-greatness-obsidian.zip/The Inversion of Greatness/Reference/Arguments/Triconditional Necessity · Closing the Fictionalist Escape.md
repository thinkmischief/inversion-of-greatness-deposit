> [!argument]
> **Triconditional Necessity** · *Closing the Fictionalist Escape*
>
> 1. Modal fictionalism treats “□(T ∧ S ∧ Φ)” as internal to the possible-worlds fiction.
> 1. Constructing that fiction requires O (succession in the telling), D (a fiction/reality distinction), and B (a persisting framework).
> 1. So wherever fictionalism is formulated, the formulating instantiates O, D, and B.
> 1. The fact that telling the fiction instantiates O, D, and B doesn’t by itself settle what the fiction can represent. A fiction may describe impossible or inconsistent contents.
> 1. Excluding an object-side ∅ therefore requires the independent Null-State argument ([[3.2 Triconditional Necessity - From Below#3.2.1 Something Is the Case|§3.2.1]], 3.2.6), not the performance of storytelling alone.
> 1. ∴ Fictionalism supplies no act-side escape from the Conditions; whether its represented content supplies an object-side countermodel stands or falls with that independent ∅-floor.

Stated at [§3.3.3 — Against Fictionalism](../../3.%20Convergence/3.3%20Triconditional%20Necessity%20-%20From%20Above.md#3.3.3%20Against%20Fictionalism).
