> [!argument]
> **Modal Verdicts Are Structurally Borne** · *The Modal-Adjudication Line*
>
> 1. **Reality’s modal field has two genuinely occupied poles.** Under every evaluation, at least one proposition is possible and at least one is impossible ([[Modal Self-Sustenance]], [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]]).
> 1. **Every fixed contentful proposition receives one of those two verdicts.** Modal Bivalence makes possibility and impossibility exhaustive, while the fixed-content rule keeps the proposition adjudicated the same throughout the comparison ([[2.1 The S5 Pipeline#2.1.1 Modal Bivalence|§2.1.1]]; [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]]).
> 1. **One complete boundary determines the verdict.** Membership in Reality’s admissible range yields possibility; exclusion yields impossibility. The verdict answers to that boundary rather than to a local arrangement, and the Bilateral Frame requires the same constraint to do both jobs ([[2.1 The S5 Pipeline#2.1.2 Bilateral Frame|§2.1.2]]).
> 1. **That adjudication instantiates determinate difference and directed order.** The opposed verdicts supply D; the determination from Reality’s permitting or precluding boundary to the verdict supplies O. This is explanatory direction, not temporal succession.
> 1. **The determination is borne as one real modal fact about Reality’s capacity.** It is not a free-standing inscription or a verdict without a subject. By the Facthood Line, a determinate fact must be borne as what obtains; here, Reality’s complete capacity carries the membership or exclusion that fixes the verdict, supplying B ([[3.2 Triconditional Necessity - From Below#3.2.1 Something Is the Case|§3.2.1]]).
> 1. **∴ Reality’s modal-adjudicative structure instantiates O∧D∧B at field resolution.** This is an object-side result: it requires no thinker, token denial, grounding relation, or locally realized change.
>
> *Scope.* The line establishes the generic roles in the architecture by which Reality fixes modal verdicts. It does not identify O/D/B with T/S/Φ, place three local occupants in every world, or independently establish □◇C or □(T∧S∧Φ). Its O-limb depends on taking the book’s “answers to” relation as real explanatory determination; rejecting that direction cuts this line without emptying the two modal poles.
>
> **Depends on:** [[Modal Bivalence]]; [[Bilateral Frame]]; [[Modal Self-Sustenance]]; the global-capacity and fixed-content account of [[2.1 The S5 Pipeline#2.1.4 Modal Stability|Modal Stability (§2.1.4)]]; [[Facthood Requires Difference and Bearing]]

Stated at [§3.5.3 — The Closed Seam](../../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.3%20The%20Closed%20Seam).
