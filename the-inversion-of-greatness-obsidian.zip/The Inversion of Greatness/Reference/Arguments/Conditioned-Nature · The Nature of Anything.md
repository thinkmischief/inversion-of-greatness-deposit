> [!argument]
> **Conditioned-Nature** · *The Nature of Anything*
>
> 1. **Nature names the joint operative structure T∧S∧Φ.** This is the definitional clause of the Triconditional Identity; the biconditional ◇C↔T∧S∧Φ fixes the same structure from the side of Change ([[2.4 Structural Requirement#2.4.10 Sufficiency of Structure|§2.4.10]]; [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]]).
> 1. **Restrict X to a structural feature, instance, or abstraction of N.** Within that domain, what X is is fixed by its constitutive relation to T, S, and Φ—not merely by being described or known by structurally situated speakers.
> 1. **So “the nature of X” terminates in the feature of N that X spells out.** In the limit case, *Nature is necessary* is predication, while *the nature of necessity* identifies the invariant structure in which that necessity consists ([[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]]).
> 1. **A candidate claimed wholly outside N is not absorbed by this schema.** It instead owes a determinate constitutive relation by which its nature-talk refers; an epistemic relation alone does not meet that burden ([[2.7 Nothing to Consider|§2.7]]; [[8.1.5 Platonism|§8.1.5]]).
> 1. ∴ For any X within the stated structural domain, the nature of X is the X-describable feature of N. For an alleged external X, the argument yields only a burden of specification, not the same identity theorem.

Stated at [§2.6 — 2.6 Triconditionality of Nature](../../2.%20The%20Argument/2.6%20Triconditionality%20of%20Nature.md).
