> [!argument]
> **Reality–Nature Identity** · *The No-Outside Reductio*
>
> 1. Reality has no exterior: nothing real lies outside it ([[1.1 Reality|§1.1]]).
> 1. **Every real possibility is settled inside one modal field, and that field is Nature.** *(Chapter 2 field identity, [[2.8 Reality–Nature Identity|§2.8]].)* Every determinate real possibility is evaluated within the one modal field constituted by T, S, and Φ; this doesn’t say every world locally contains three corresponding occupants ([[2.8 Reality–Nature Identity|§2.8]]).
> 1. **Suppose Reality had something left over.** Suppose Reality exceeded Nature at this resolution: some real content would have to occupy a second modal domain outside that field.
> 1. **Then that leftover would still need a determinate way to be, which puts it back in the field.** But any alleged real content must have a determinate possible way to be, and that way is already evaluated within Reality’s one modal field. If it has no such way, it supplies no real remainder.
> 1. **∴ Nothing is left over.** No second modal domain remains. By maximality, Reality is identical to Nature at field-and-totality resolution (R = N).

Stated at [§3.4.1 — No Outside](../../3.%20Convergence/3.4%20Reality%E2%80%93Nature%20Identity.md#3.4.1%20No%20Outside).
