> [!argument]
> **Reality–Nature Identity** · *Closing the Residue*
>
> 1. Any residue by which Reality might exceed Nature must be a real something not decomposable into, and not presupposing, T, S, Φ.
> 1. Either the residue makes a difference to what is the case, or it doesn’t.
> 1. If it does, the difference made is determinate, the dependence or determination is directed, and the difference is borne or realized. The residue therefore instantiates thin distinction, order, and bearing ([[1.1 Reality#1.1.3 Reality Holds Together|§1.1.3]], [[1.5 Existence#1.5.9 What the Operators Require|§1.5.9]]). Its upgrade to loaded T/S/Φ requires the independent bridges and candidate-specific engagements.
> 1. If it doesn’t—no difference in truth, modal profile, relation, grounding, causation, explanation, or constitution—it supplies no individuating surplus. “Reality plus X” and “Reality without X” are then one profile under two descriptions, not two realities; X isn’t a further real item.
> 1. ∴ The no-difference horn closes the completely surplus posit. The difference-making horn classifies the rival as articulated but doesn’t, by itself, place every thinly articulated or transcendent candidate inside loaded Nature.
>
> *Scope.* This dilemma therefore supplies the no-residue component, not the unconditional R = N verdict alone. The canonical field identity carries that verdict; candidate-specific engagements determine whether a purported remainder relocates, remains a structured burden, or fails specification.

Stated at [§3.4.3 — No Residue](../../3.%20Convergence/3.4%20Reality%E2%80%93Nature%20Identity.md#3.4.3%20No%20Residue).
