> [!argument]
> **Necessary Possibility** · *The S5 Pipeline*
>
> 1. R has no real exterior: nothing real stands beyond the one whole, and there is no vantage on Reality from outside it (*No Exteriority*, [[1.1 Reality|§1.1]])
> 1. Every contentful proposition receives one of the two classical verdicts: ◇P or ¬◇P; P retains that same content throughout the iteration (*Modal Exhaustiveness*, [[2.1 The S5 Pipeline#2.1.1 Modal Bivalence|§2.1.1]])
> 1. Under the notation fixed above, ◇P means Capacity(R,P), membership in R’s complete admissible range, and ¬◇P means exclusion from it ([[1.2 Modal Status#1.2.1 Possibility|§1.2.1]])
> 1. Modal status answers to that complete permitting and precluding boundary, not to how any particular configuration is arranged. This fixes what the verdict is *about*; it doesn’t yet make the verdict invariant (*Modal Constitution*, [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]])
> 1. If an alleged evaluation admits an excluded P, it is either a real alternative already within R’s range—so P wasn’t excluded—or not a real alternative. Therefore genuine impossibility cannot vary: ¬◇P → □¬◇P (*Invariant Exclusion*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 1. Modal Bivalence makes possibility the complement of that fixed exclusion. If P is within R’s complete range, no local evaluation can exclude it from that same range. Therefore ◇P → □◇P (*Invariant Complement*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 1. Thus the modal status of every fixed P—qualitative or singular—is invariant across every real evaluation. Local reachability may vary, but every pair of real alternative horizons is already compared within R’s complete range; no variation supplies a second real modal maximum. (◇P → □◇P) ∧ (¬◇P → □¬◇P) (*Necessary Possibility*, defended by *The Bottleneck*, [[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]])

Stated at [§2.1.10 — Necessary Possibility](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.10%20Necessary%20Possibility).
