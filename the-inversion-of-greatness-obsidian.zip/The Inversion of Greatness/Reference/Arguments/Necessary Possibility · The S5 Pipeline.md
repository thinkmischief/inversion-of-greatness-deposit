> [!argument]
> **Necessary Possibility** · *The S5 Pipeline*
>
> 1. Every contentful proposition receives one of the two classical verdicts: ◇P or ¬◇P (*Modal Exhaustiveness*, [[2.1 The S5 Pipeline#2.1.1 Modal Bivalence|§2.1.1]])
> 1. R has no real exterior: nothing real stands beyond the one whole, and there is no vantage on Reality from outside it (*No Exteriority*, [[1.1 Reality|§1.1]]). Under the notation fixed above, ◇P means Capacity(R,P), membership in R’s complete admissible range, and ¬◇P means exclusion from it ([[1.2 Modal Status#1.2.1 Possibility|§1.2.1]])
> 1. Modal status answers to that complete permitting and precluding boundary, not to how any particular configuration is arranged. This fixes what the verdict is *about*; it doesn’t yet make the verdict invariant (*Modal Constitution*, [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]])
> 1. If an alleged evaluation admits P, it is either a real alternative already within R’s range—so P wasn’t excluded—or not a real alternative. Therefore genuine impossibility cannot vary: ¬◇P → □¬◇P (*Invariant exclusion*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 1. Possibility is the complement of that fixed exclusion. If P passed from possible to impossible, the exclusion boundary would have changed. Therefore ◇P → □◇P (*Invariant complement*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 1. Local reachability may vary, but every pair of real alternative horizons is already compared within R’s complete range. No variation in reachability supplies a second real modal maximum (*The Bottleneck*, [[2.1 The S5 Pipeline#2.1.5 The S5 Bottleneck|§2.1.5]])
> 1. Logical truth supplies a necessary possibility-witness and contradiction a necessary impossibility-witness, so the fixed frame is non-vacuously occupied on both sides. (□∃P: ◇P) ∧ (□∃P: ¬◇P) (*Modal Self-Sustenance*, [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]])

Stated at [§2.1.10 — Necessary Possibility](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.10%20Necessary%20Possibility).
