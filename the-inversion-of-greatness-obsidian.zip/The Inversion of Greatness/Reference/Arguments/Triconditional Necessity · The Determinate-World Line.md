> [!argument]
> **Triconditional Necessity** · *The Determinate-World Line*
>
> 1. A possible world just is a total way things could be; being total, it is fully determinate: it leaves no relevant matter open.
> 1. *The representation distinction* ([[2.6 Triconditionality of Nature#2.6.7 Triconditional Cross-Entailment|§2.6.7]]): keep apart the representation, its represented content, and the instantiation of what is represented. Structure in the representation alone proves nothing about what the represented way instantiates.
> 1. A determinate represented way must nonetheless specify genuine contrasts (the thin S-role) and subject matter of which its truths hold (thin bearing/Φ-role). Logical obtaining rather than not is alethic exclusion, not by itself temporal direction (T).
> 1. ∴ A world’s determinate content supplies a partial floor at the level of generic roles. Where the represented way contains change or ordered variation, the independent role analysis supplies loaded T and the associated S/Φ realizers; the necessity of the full conjunction isn’t re-derived from determinacy alone.

Stated at [§3.2.2 — No Bare Possibilities](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.2%20No%20Bare%20Possibilities).
