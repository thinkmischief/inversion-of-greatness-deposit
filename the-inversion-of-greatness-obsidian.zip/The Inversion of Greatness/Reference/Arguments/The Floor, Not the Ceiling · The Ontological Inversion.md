> [!argument]
> **The Floor, Not the Ceiling** · *The Ontological Inversion*
>
> 1. **Anselm’s criterion ranks candidates by greatness, so a candidate must first be determinate enough to enter the comparison.** *That than which no greater can be conceived* is comparative, and a comparison requires terms with content.
> 1. **The strict withdrawal description removes time, place, bearing, and every determinate analogue that could perform their roles.** The subtraction is on the object side, not merely a failure of the conceiving act ([[10.1.1 The Modal Ontological Argument|§10.1.1]] above; [[3.3 Triconditional Necessity - From Above#3.3.4 The Conceivability Trap|§3.3.4]]).
> 1. **So the description supplies no determinate candidate for Anselm’s criterion to rank.** It is not the lowest member of the scale; it fails the prior condition for membership at all ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]]).
> 1. **∴ Withdrawing the Conditions cannot make a candidate greater.** The Conditions are the floor of admissibility—what any candidate must already instantiate to be rankable—not the ceiling of greatness or proof that anything is unsurpassable. The criterion still needs a determinate subject and an independent account of greatness.
>
> *Scope.* The inversion bears on the strictly withdrawn description, in the same range as [[11.10 What Remains of God|§11.10]]’s scope note: an account that supplies determinate content—analogically, or by holding that modal truths follow from what the candidate is—isn’t touched here and carries its burdens forward rather than being refuted at this step. Nor does the argument show that Nature is great in any evaluative sense; the inversion set out at [[4. Nature Alone|§4]] concerns metaphysical ultimacy only.

Stated at [§10.1.1 — 10.1.1 The Modal Ontological Argument](../../10.%20Rival%20Ultimates/10.1.1%20The%20Modal%20Ontological%20Argument.md).
