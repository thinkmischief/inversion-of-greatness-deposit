> [!argument]
> **The Floor, Not the Ceiling** · *The Ontological Inversion*
>
> 1. **Anselm’s criterion ranks conceptions, so it presupposes that there is something determinate to rank.** *That than which no greater can be conceived* is comparative, and a comparison requires candidates with content.
> 1. **A description that withdraws time, place, and bearing leaves its object with no determinate content.** The subtraction is on the object side, not merely a failure of the conceiving act ([[10.1.1 The Modal Ontological Argument|§10.1.1]] above; [[3.3 Triconditional Necessity - From Above#3.3.4 The Conceivability Trap|§3.3.4]]).
> 1. **So the strictly withdrawn subject isn’t the top of Anselm’s scale but its floor**—not that than which no greater can be conceived, but that than which no *lesser* can be, since nothing determinate remains to be conceived at all ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]]).
> 1. **∴ Anselm’s own criterion, applied consistently, selects the Conditions rather than a subject described by their withdrawal.** What cannot be surpassed is what any candidate must already instantiate to be a candidate.
>
> *Scope.* The inversion bears on the strictly withdrawn description, in the same range as [[11.10 What Remains of God|§11.10]]’s scope note: an account that supplies determinate content—analogically, or by holding that modal truths follow from what the candidate is—isn’t touched here and carries its burdens forward rather than being refuted at this step. Nor does the argument show that Nature is great in any evaluative sense; the inversion set out at [[4. Nature Alone|§4]] concerns metaphysical ultimacy only.

Stated at [§10.1.1 — 10.1.1 The Modal Ontological Argument](../../10.%20Rival%20Ultimates/10.1.1%20The%20Modal%20Ontological%20Argument.md).
