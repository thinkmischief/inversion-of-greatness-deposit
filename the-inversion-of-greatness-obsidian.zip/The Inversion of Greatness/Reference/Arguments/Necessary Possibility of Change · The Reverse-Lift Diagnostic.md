> [!argument]
> **Necessary Possibility of Change** · *The Reverse-Lift Diagnostic*
>
> 1. **Chapter 3’s own routes support order, difference, and bearing, but not all to the same reach.** Stage 2 supplies overlapping support for O, D, and B, with different quantificational reach. Grant for the diagnostic that a complete generic O∧D∧B floor has been secured.
> 1. **Fully typed Conditions do entail that change is possible.** The Sufficiency of Structure establishes that the fully typed Conditions entail the possibility of Change: (T∧S∧Φ) → ◇C ([[2.4 Structural Requirement#2.4.10 Sufficiency of Structure|§2.4.10]]), with the frozen-world case tested at [[2.4 Structural Requirement#2.4.11 The Frozen-World Test|§2.4.11]].
> 1. **So if Chapter 3 delivered the Conditions at full strength everywhere, □◇C would follow.** If Chapter 3 independently delivered T, S, and Φ at full modal-core resolution under every evaluation, universal modus ponens would yield □◇C. That would be the Reverse Lift.
> 1. **It doesn’t. O, D, and B aren’t the Conditions under different letters.** O/D/B aren’t T/S/Φ under different letters, and Stage 2 doesn’t independently box even the generic conjunction.
> 1. **And borrowing Chapter 2’s identification to close the gap would borrow the very result being re-derived.** Importing Chapter 2’s bilateral identification to convert O/D/B into the modal-core Conditions would already import the □◇C-dependent Structural Requirement the Reverse Lift was meant to replace. The derivation would be circular.
> 1. **∴ The Reverse Lift corroborates □◇C; it doesn’t independently establish it.** The Reverse Lift is valid only conditionally: it corroborates □◇C for a reader who independently grants the full type-resolution or the Modal Identity, but it isn’t a new S5-free proof of □◇C.

Stated at [§3.5.4 — No Reverse Lift](../../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.4%20No%20Reverse%20Lift).
