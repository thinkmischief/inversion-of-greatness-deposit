> [!argument]
> **Structural Requirement** · *The Substantiality Reductio*
>
> Let Borne(x) mean *x is borne across an interval*.
>
> 1. Any bearing requires Substantiality, since *borne* presupposes something that persists across the interval it is carried over (∀x(Borne(x) → Φ)).
> 1. Something is borne: there is at least one bearing, demonstrably the thinker holding the present thought across its occurring (∃xBorne(x)).
> 1. So Substantiality is instantiated (∴ Φ; from 1, 2).
> 1. If Substantiality had ever been absent, it would have to be borne into presence, since a transition from its absence to its presence is itself something carried across an interval (Borne(Φ)).
> 1. **Substance cannot have been borne into being, because bearing needs something that persists through it.** Any bearing of Substantiality would require Substantiality already instantiated across its own bearing interval, since line 1’s warrant—*borne* presupposes something that persists across the interval—applies to the bearing of Φ itself (Borne(Φ) → Φ-at-or-before-Borne(Φ)).
> 1. ∴ So Substantiality was never absent: the supposed onset entails Φ at or before the first bearing of Φ—Φ-prior-to-Φ, a contradiction (from 4, 5 by reductio).

Stated at [§2.4.8 — Exchange Requires Substantiality](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.8%20Exchange%20Requires%20Substantiality).
