> [!argument]
> **Structural Requirement** · *The Substantiality Reductio*
>
> Let Borne(x) mean *x is borne across an interval*.
>
> 1. Any bearing requires Substantiality, since *borne* presupposes something that persists across the interval it is carried over (∀x(Borne(x) → Φ)).
> 1. Something is borne: there is at least one bearing, demonstrably the thinker holding the present thought across its occurring (∃xBorne(x)).
> 1. So Substantiality is instantiated (∴ Φ; from 1, 2).
> 1. Suppose Substantiality emerged from its total absence. That emergence would be a real transition from no Substantiality to Substantiality.
> 1. **Any real transition requires Substantiality.** Something must make the later state a continuation of the earlier state rather than an unrelated replacement; whatever occupies that cross-interval bearer-role satisfies Φ at modal-core resolution (*Cross-Interval Persistence*).
> 1. ∴ Substantiality cannot emerge from no Substantiality. The alleged onset would instantiate Φ in the very transition by which Φ was supposed first to appear.

Stated at [§2.4 — 2.4 Structural Requirement](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md).
