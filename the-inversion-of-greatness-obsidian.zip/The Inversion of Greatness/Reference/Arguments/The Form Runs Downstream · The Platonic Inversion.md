> [!argument]
> **The Form Runs Downstream** · *The Platonic Inversion*
>
> 1. **The Platonist treats Forms as prescriptive.** The Form of Tree explains why trees take the shape they do; the Form of the Triangle why triangles have the angle-sum they have.
> 1. **To be a Form at all is to be a determinate *this* rather than *that*.** The Form of the Triangle isn’t the Form of the Circle, and a Form with nothing it is rather than isn’t fixes nothing.
> 1. **That determinacy is borrowed, not native.** The Form of the Triangle is determinate because triangles, actual or possible, are determinate; its distinctness from the Form of the Circle is the distinctness of the configurations it describes.
> 1. **∴ The prescriptive direction reverses.** What the Platonist calls a Form runs downstream of actuality plus the structural conditions, never upstream: what looks like a prior pattern prescribing actuality is a description of what actuality, under those conditions, produces.
>
> *Scope.* The reply isn’t that Platonism is incoherent. A robust Platonist may keep the abstracta, and what the four forms test is only whether those abstracta supply a concrete change-realizer lacking the conditions. The inversion bears on the prescriptive reading, not on mathematical existence.

Stated at [§8.1.5 — 8.1.5 Platonism](../../8.%20Metaphysics/8.1.5%20Platonism.md).
