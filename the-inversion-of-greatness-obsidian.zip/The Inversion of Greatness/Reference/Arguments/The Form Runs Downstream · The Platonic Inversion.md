> [!argument]
> **The Form Runs Downstream** · *The Platonic Inversion*
>
> 1. **The Platonist treats Forms as prescriptive.** The Form of Tree explains why trees take the shape they do; the Form of the Triangle why triangles have the angle-sum they have.
> 1. **To be a Form at all is to be a determinate *this* rather than *that*.** The Form of the Triangle isn’t the Form of the Circle, and a Form with nothing it is rather than isn’t fixes nothing.
> 1. **What fixes that determinacy lies on the concrete side, the abstract side, or both.** The content comes from the configurations described, from distinctions and relations among Forms or a higher abstract ground, or from some combination of them.
> 1. **If the concrete side contributes, the Form is not wholly prior to what it explains.** Its content is at least partly descriptive and downstream from the structured configurations it is invoked to prescribe.
> 1. **If the abstract side fixes the content, that side is already structured rather than structureless.** Distinct Forms, a higher ground, and any ordering among them require determinate difference and bearing; a mixed account inherits this result together with the preceding one.
> 1. **Explaining a concrete instance additionally requires a determinate instantiation relation.** That relation distinguishes Form from instance and runs from alleged ground to grounded, and every such Form and relation belongs to Reality’s one modal field ([[2.8 Reality–Nature Identity|§2.8]]).
> 1. **∴ No Form is a structureless or exterior source of concrete configuration.** It is downstream wherever concrete configuration fixes its content, already structured wherever the abstract side fixes it, and internal to Nature wherever it bears a real explanatory relation to an instance.
>
> *Scope.* The reply isn’t that Platonism is incoherent or that native abstract determinacy is impossible. A robust Platonist may keep the abstracta, but not as a second modal domain outside Nature. The argument closes the claims that a Form explains concrete configuration from outside every structural relation or supplies a concrete change-realizer lacking the Conditions. It bears on exterior prescriptive priority, not on mathematical existence.

Stated at [§8.1.5 — 8.1.5 Platonism](../../8.%20Metaphysics/8.1.5%20Platonism.md).
