> [!argument]
> **Triconditional Necessity** · *Way Possible*
>
> 1. To be possible is to be a way things could be.
> 1. A determinate way has content rather than being an undifferentiated blank.
> 1. ∴ Possibility analytically requires the role of difference (S-role). Direction and bearer require further premises; they don’t follow from the word *possible* alone.

Stated at [§3.2.5 — Shape of Possibility](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.5%20Shape%20of%20Possibility).
