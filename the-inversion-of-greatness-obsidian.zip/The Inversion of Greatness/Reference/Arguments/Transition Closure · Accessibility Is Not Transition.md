> [!argument]
> **Transition Closure** · *The Unswitchable Capacity*
>
> 1. Suppose an initial state s₀ with no local transition-capacity: no transition available from s₀ realizes C.
> 1. For the capacity to be acquired within the same history, s₀ must be followed by some state s₁ that has it: local transition-capacity passing from absent at s₀ to present at s₁.
> 1. That passage is itself a change, one state and then another ([[1.3 Change|§1.3]]).
> 1. But s₀ is stipulated to host no transition realizing change. It therefore cannot host the very passage by which local transition-capacity would be acquired.
> 1. ∴ Local transition-capacity cannot originate, within a single history, from a state that lacks it. Brute onset doesn’t help: an uncaused passage is still a passage, and s₀ still cannot host it.
>
> *Scope.* This closes only the local claim. If some later state in the same history exhibits change, a transition realizing C was available in that history all along, so the world’s global status was already ◇C—the history doesn’t move from ¬◇C to ◇C, but exercises, later, a ◇C that held from the start.

Stated at [§3.1.2 — The Unswitchable Capacity](../../3.%20Convergence/3.1%20Necessary%20Possibility%20of%20Change%20-%20Stress-Tested.md#3.1.2%20The%20Unswitchable%20Capacity).
