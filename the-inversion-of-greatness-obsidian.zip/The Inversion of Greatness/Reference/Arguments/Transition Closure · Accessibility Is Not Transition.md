> [!argument]
> **Transition Closure** · *Accessibility Is Not Transition*
>
> 1. Suppose a state lacks local transition-capacity: no transition available from it realizes C.
> 1. Any passage from that state into a state with local transition-capacity would itself realize C.
> 1. Any such passage is itself an instance of C. At the later Condition-resolution, the Structural Requirement ([[2.4 Structural Requirement|§2.4]]) will show that it also requires T, S, and Φ; the onset closure itself needs only the C-instance.
> 1. From (1)–(3): the source state cannot host the passage by which the local capacity would be acquired. At the later resolution, the joint structure likewise cannot first arrive through an onset that already realizes the Change requiring it.
> 1. That a ◇C world is accessible from a ¬◇C world doesn’t mean the latter produces, transitions into, or can historically reach the former. Accessibility relates modal alternatives; transition occurs within a history (*No accessibility slide*)
> 1. A stronger diachronic-reachability relation could require a source-history that realizes the route. Under that added definition, (4) blocks the onset of local transition-capacity—but this is closure under diachronic reachability, not under bare or merely renamed modal accessibility.
> 1. ∴ Local transition-capacity cannot switch on within a history from a state that lacks it. The result is unconditional and temporal.
>
> *Scope.* The modal formula ¬◇C → □¬◇C isn’t derived here; proposition-wise modal invariance comes from the global-capacity argument ([[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]]–2.1.5, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]]), not from onset closure (*Scope*)

Stated at [§2.1.6 — The Transition Closure](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.6%20The%20Transition%20Closure).
