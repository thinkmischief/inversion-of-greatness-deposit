> [!argument]
> **Fictionalism Retains the Conditions** · *The Fictionalist Test*
>
> 1. Modal fictionalism treats “□(T ∧ S ∧ Φ)” as internal to the possible-worlds fiction.
> 1. Formulating that position is an actual change: the thinker or text passes from not having formulated it to having formulated it while retaining and distinguishing its content.
> 1. Every actual change requires Temporality, Spatiality, and Substantiality (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]]).
> 1. So wherever modal fictionalism is formulated, the formulation instantiates T, S, and Φ. Fictionalism supplies no act-side escape from the Conditions.
> 1. The Conditions of the formulation do not by themselves become Conditions of the represented object. A fiction may represent impossible or inconsistent contents.
> 1. ∴ The act-side escape is closed by the Structural Requirement; an alleged object-side countermodel must independently supply a possible way Reality could be. A representation of ∅ cannot do so, because the structured representation is not the represented no-world (*No-World Reductio*, [[3.2 Triconditional Necessity - From Below#3.2.6 The Null-State Reductio|§3.2.6]]).
>
> *Scope.* T, S, and Φ follow here only because formulating the position is actual Change and the Structural Requirement governs every actual Change—not because O, D, and B have been silently retyped. The conclusion governs the formulation, not everything a fiction can represent.

Stated at [§3.3 — 3.3 Triconditional Necessity - From Above](../../3.%20Convergence/3.3%20Triconditional%20Necessity%20-%20From%20Above.md).
