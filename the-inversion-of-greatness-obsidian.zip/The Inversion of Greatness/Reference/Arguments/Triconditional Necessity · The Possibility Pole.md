> [!argument]
> **Triconditional Necessity** · *The Possibility Pole*
>
> 1. Every possibility-candidate must have determinate content, so every adequate world-description employs the difference-role. This is a constraint on candidate content within the modal field, not yet a claim that each world’s local inventory contains Spatiality.
> 1. If a world is additionally understood as a directed arrangement, the T-role is engaged.
> 1. If its determinate content must be borne or realized rather than merely listed, the Φ-role is engaged.
> 1. ∴ The full role-level T ∧ S ∧ Φ conclusion follows only with the directed-arrangement and bearer premises made explicit. Modal vocabulary alone establishes the S-role, not the whole conjunction.

Stated at [§3.2.5 — Shape of Possibility](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.5%20Shape%20of%20Possibility).
