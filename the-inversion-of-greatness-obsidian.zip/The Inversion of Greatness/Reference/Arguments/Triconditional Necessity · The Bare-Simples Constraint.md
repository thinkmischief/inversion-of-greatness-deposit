> [!argument]
> **Triconditional Necessity** · *The Bare-Simples Constraint*
>
> 1. Suppose mereological nihilism: only simples, no composites.
> 1. If simples are arranged or contrasted, they are individuated from one another (the thin S-role).
> 1. The arrangement’s obtaining rather than not supplies an alethic contrast, not by itself temporal direction (T).
> 1. If the arrangement is genuinely instantiated rather than merely encoded, its features are borne by the simples or mosaic (thin Φ-role). Loaded causal persistence remains the independent burden developed at [[2.4 Structural Requirement#2.4.8 Exchange Requires Substantiality|§2.4.8]] and tested against Humean contingency at [[8.2.2 Humean Contingency|§8.2.2]].
> 1. ∴ Nihilism doesn’t eliminate distinction or bearing. A static arrangement supplies no independent T-limb.
>
> *Scope.* Mereological nihilism isn’t a counterexample to the partial structural floor; the full Triconditional Necessity continues to depend on the separate change, direction, and co-instantiation bridges.

Stated at [§3.2.4 — All the Way Down](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.4%20All%20the%20Way%20Down).
