> [!argument]
> **Necessity of Nature** · *The Cogito–S5 Pipeline*
>
> 1. **Whatever is possible, its possibility is necessary; whatever is impossible, its impossibility is necessary.**
> 1. **Change is possible.**
> 1. **The possibility of change is itself necessary.**
> 1. **A Reality in which change is possible is already temporal, spatial, and substantial.**
> 1. **Reality is necessarily constituted by the three Conditions.**
> 1. **The three Conditions aren’t three requirements that happen to coincide but one structure, and *Nature* is its name.**
> 1. **No empty alternative lies beneath Nature.**
> 1. **Nothing real is left outside Nature’s modal field, so at the level of the whole, Reality and Nature are one.**
> 1. **Therefore: Reality is necessarily Nature.**

Stated at [§2 — 2. The Argument](../../2.%20The%20Argument/2.%20The%20Argument.md).

## Also stated

> [!argument]
> **Necessity of Nature** · *The Cogito–S5 Pipeline*
>
> 1. Whatever is possible is necessarily possible. ◇P → □◇P (*Necessary Possibility*, Necessary Possibility, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 1. By universal instantiation, taking the witnessed Change C for P; C retains the reference fixed in [[1.3 Change|§1.3]] rather than abbreviating arbitrary generic succession. ◇C → □◇C.
> 1. The concrete reflective Change C is really possible. ◇C (*Possibility of Change*, Cartesian Certainty, [[2.2 Cartesian Certainty#2.2.1 Change Is Actual|§2.2.1]])
> 1. By modus ponens on 2 and 3, the possibility of C is itself necessary. □◇C. (Necessary Possibility of Change lemma, [[2.3 Necessary Possibility of Change|§2.3]])
> 1. Necessarily, if C is really possible, then Reality’s modal field is constituted by T, S, and Φ. □(◇C → (T∧S∧Φ)) (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]])
> 1. By the K-axiom, distributing the box over the conditional. □◇C → □(T∧S∧Φ).
> 1. ∴ By modus ponens on 4 and 6. □(T∧S∧Φ). (Triconditional Necessity, [[2.5 Triconditional Necessity|§2.5]]; Necessity of Nature theorem, [[2.9 The Whole Line#2.9.6 Necessity of Nature|§2.9.6]])

Stated at [Appendix A - Modal Logic Primer — Appendix A - Modal Logic Primer](../../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).
