> [!argument]
> **The Ground Fails Its Own Preconditions** · *The Transcendental Inversion*
>
> 1. **A ground of intelligibility must be determinate enough to be that ground rather than another—or rather than nothing.** The ground need not be understood by us, but it must have content of its own if the claim is about a subject at all.
> 1. **The strict withdrawal description denies Temporality, Spatiality, Substantiality, and every thin, analogical, or other articulation that could distinguish its alleged subject.**
> 1. **So nothing determinate remains to perform the grounding role.** The description fixes neither one subject rather than another nor a subject rather than ∅, the withdrawal of every structured state ([[2.7 Nothing to Consider#2.7.1 Null State (∅)|§2.7.1]]).
> 1. **∴ The strict withdrawal description fixes no possible ground of intelligibility.** ∅ is not a possible state, so removing every condition of determinacy cannot identify a subject that grounds anything ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]]).
>
> *Scope.* The line bears on a description withdrawing all three Conditions while refusing every replacement articulation, and on nothing weaker. A determinate atemporal ground, an analogical account that states what its proportion preserves, or a proposal on which modal truths follow from what the ground is isn’t declared empty by this argument; the later [[No Unconditioned Essence]] and [[No Divine Addition]] results locate any possible referent as Nature or an aspect of Nature ([[10.2.1 Divine Simplicity|§10.2.1]], [[10.4 What the Rivals Carried|§10.4]], [[11.10 What Remains of God|§11.10]]). The conclusion converges with *The Contentless God Has No Referent* without depending on it: the strict-withdrawal premise and the conclusion run on [[2.7 Nothing to Consider|§2.7]] directly, so nothing here is borrowed from Chapter 11.

Stated at [§10.1.3 — 10.1.3 The Transcendental Argument for God](../../10.%20Rival%20Ultimates/10.1.3%20The%20Transcendental%20Argument%20for%20God.md).
