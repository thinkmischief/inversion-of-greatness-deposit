> [!argument]
> **The Ground Fails Its Own Preconditions** · *The Transcendental Inversion*
>
> 1. **There are preconditions of intelligibility.** Features that must obtain for anything to be thought, said, or reasoned about at all.
> 1. **They cannot be coherently denied.** Any denial is itself an act of thinking and saying, and so supplies an instance of what it denies (*The Self-Refutation*, [[3.3 Triconditional Necessity - From Above#3.3.1 Denial Runs on Nature|§3.3.1]]).
> 1. **Among them is determinacy on the side of the object.** For a subject to be thought or said *about* is for it to have content distinguishing it from other subjects and from nothing at all.
> 1. **Temporality, Spatiality, and Substantiality are what supply that determinacy.** Their joint absence is ∅, the state in which no content is held one way rather than another ([[2.7 Nothing to Consider#2.7.1 Null State (∅)|§2.7.1]]).
> 1. **A description may withdraw all three at once.** Atemporality, aspatiality, and insubstantiality together, while denying every thin or analogical content that might supply determinacy in their place.
> 1. **∴ Such a description fixes no possible subject.** It leaves nothing to distinguish its subject from ∅, and ∅ isn’t a possible state ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]]). The preconditions of intelligibility exclude a ground described by their withdrawal.
>
> *Scope.* The line bears on a description withdrawing all three Conditions while refusing every replacement articulation, and on nothing weaker. A determinate atemporal ground, an analogical account that states what its proportion preserves, or an essence-prior proposal supplying content by another route isn’t declared empty by this argument; the later [[No Unconditioned Essence]] and [[No Divine Addition]] results locate any possible referent as Nature or an aspect of Nature ([[10.2.1 Divine Simplicity|§10.2.1]], [[10.4 What the Rivals Carried|§10.4]], [[11.10 What Remains of God|§11.10]]). The premises are the transcendental argument’s own, and the conclusion converges with *The Contentless God Has No Referent* without depending on it: steps 4 and 6 run on [[2.7 Nothing to Consider|§2.7]] directly, so nothing here is borrowed from Chapter 11.

Stated at [§10.1.3 — 10.1.3 The Transcendental Argument for God](../../10.%20Rival%20Ultimates/10.1.3%20The%20Transcendental%20Argument%20for%20God.md).
