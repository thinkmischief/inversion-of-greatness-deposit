> [!argument]
> **Subsistent Grounding** · *Substantiality Is Not the Basement*
>
> 1. **Nature just is the three Conditions taken together.** Nature is the joint structural complex: N ↔ T∧S∧Φ (*Triconditional Identity*, [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])
> 1. **No one Condition stands under the other two; each requires the others.** Within full change-realizing structure, Φ requires T and S, and each Condition likewise requires the other two (*Triconditional Cross-Entailment*, [[2.6 Triconditionality of Nature#2.6.7 Triconditional Cross-Entailment|§2.6.7]])
> 1. **That mutual requirement is symmetric, so it isn’t a grounding relation.** The dependence asserted here is symmetric and co-constitutive, not a one-way grounding relation from Φ to T and S.
> 1. **A physics-in-the-basement view needs exactly the asymmetry the Conditions don’t have.** Fundamentality physicalism, in the basement form targeted here, requires an asymmetric priority claim: Φ grounds T and S while not being co-grounded or co-constituted by them.
> 1. **∴ Substantiality isn’t the basement.** That priority claim is incompatible with the Triconditional Cross-Entailment’s co-constitutive structure. Therefore the present view isn’t fundamentality physicalism and cannot privilege Φ as the sole basement.
>
> *Scope.* This doesn’t by itself refute every thesis called *physicalism*; it rejects the specific one-way fundamentality thesis once the Triconditional Cross-Entailment is granted—and that theorem is granted here at its earned scope and price ([[2.6 Triconditionality of Nature#2.6.7 Triconditional Cross-Entailment|§2.6.7]], on the same-realizer routes of [[2.6 Triconditionality of Nature#2.6.2 Succession’s Two Conditions|§2.6.2]]–2.6.4), not assumed. A Φ-basement that reads T and S as derivative or representational must either deny Φ’s own role-criterion—bearing across intervals of real succession ([[2.4 Structural Requirement#2.4.8 Exchange Requires Substantiality|§2.4.8]]), which already carries T constitutively—or accept the entailments and lose the asymmetry; the escape routes are priced at §§2.6.2–2.6.4, not left open.

Stated at [§2.9.3 — No Privileged Floor](../../2.%20The%20Argument/2.9%20The%20Whole%20Line.md#2.9.3%20No%20Privileged%20Floor).
