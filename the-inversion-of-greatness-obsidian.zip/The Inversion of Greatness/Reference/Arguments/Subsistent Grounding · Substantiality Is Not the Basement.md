> [!argument]
> **Subsistent Grounding** · *Substantiality Is Not the Basement*
>
> 1. **Nature just is the three Conditions taken together.** Nature names the joint structural complex T∧S∧Φ (*Triconditional Identity*, [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])
> 1. **No one operative Condition stands under the other two inside a concrete change-realizer.** Under the Operative-Role Bridge, Φ doing bearing-work requires T and S, and each operative Condition likewise co-instantiates the other two (*Triconditional Cross-Entailment*, [[2.6 Triconditionality of Nature#2.6.7 Triconditional Cross-Entailment|§2.6.7]])
> 1. **That mutual requirement is symmetric, so it isn’t a grounding relation.** The dependence asserted here is symmetric and co-constitutive, not a one-way grounding relation from Φ to T and S.
> 1. **A physics-in-the-basement view needs exactly the asymmetry the Conditions don’t have.** Fundamentality physicalism, in the basement form targeted here, requires an asymmetric priority claim: Φ grounds T and S while not being co-grounded or co-constituted by them.
> 1. **∴ Substantiality isn’t the basement.** That priority claim is incompatible with the Triconditional Cross-Entailment’s co-constitutive structure. Therefore the present view isn’t fundamentality physicalism and cannot privilege Φ as the sole basement.
>
> *Scope.* This doesn’t by itself refute every thesis called *physicalism*; it rejects the specific one-way fundamentality thesis for concrete change-realizers once the Operative-Role Bridge and Triconditional Cross-Entailment are granted. A Φ-basement may refuse the bridge, but it must then explain how bearing does concrete work across differentiated stages without the ordered interval and operative positions that the bridge makes explicit. The result is conditional on that premise rather than analytic from the thin Φ-predicate.

Stated at [§2.9 — 2.9 The Whole Line](../../2.%20The%20Argument/2.9%20The%20Whole%20Line.md).
