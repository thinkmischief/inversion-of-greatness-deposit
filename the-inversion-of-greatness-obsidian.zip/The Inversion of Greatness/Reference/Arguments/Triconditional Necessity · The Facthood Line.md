> [!argument]
> **Triconditional Necessity** · *The Facthood Line*
>
> 1. Something is the case. Its denial, “nothing is the case,” is itself something being the case, so it self-refutes ([[3.2 Triconditional Necessity - From Below#3.2.6 The Null-State Reductio|§3.2.6]]).
> 1. Any state of affairs is *this rather than that*: a real distinction—the Space-side requirement introduced in [[1.4 Three Conditions|§1.4]].
> 1. Any state *obtains rather than not*: this supplies exclusion and polarity, but not yet temporal or influence-carrying direction. The contrast between P and ¬P isn’t a before/after order.
> 1. Any state is *borne, not merely described*: there is a fact or realizer in which its obtaining consists—the thin bearing-role, not yet causal persistence across an interval.
> 1. ∴ Bare facthood secures D and B at the level of generic roles. O requires a separate directed-dependence or succession premise; the modal-core Conditions require Chapter 2’s bilateral identification.
>
> *Scope.* The thinker-free ∅ result is narrower: a candidate possible world must sustain determinate content capable of being true or false, while ∅ is defined by withdrawing that standing. This yields ¬◇∅ ([[3.2 Triconditional Necessity - From Below#3.2.6 The Null-State Reductio|§3.2.6]]), not □(T ∧ S ∧ Φ) from facthood alone.

Stated at [§3.2.1 — Something Is the Case](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.1%20Something%20Is%20the%20Case).
