> [!argument]
> **Triconditional Necessity** · *The Necessity Pole*
>
> 1. “□” collapses to actuality-without-alternative unless there is a non-trivial possibility-space.
> 1. “□” is used ineliminably and with content.
> 1. So a non-trivial possibility-space is corroborated, the contentful use of “□” being evidence that the space is genuine, not by itself a proof.
> 1. By Way–Possibility Convertibility, a non-trivial possibility-space is a space of determinate ways. Determinacy supplies D (determinate difference). O (directed order) enters only under the separately defended directed-arrangement reading of *way*; B (bearing or realization) enters only under the separate bearer/realizer premise (*Convertibility Lemma applied at its earned strength*)
> 1. ∴ The necessity pole corroborates only the existence of a non-trivial contrast-space and, through Way–Possibility Convertibility, its difference-role. With the additional direction and bearer premises it tracks the same role-level triad as the possibility pole, but it doesn’t establish □(T ∧ S ∧ Φ) or independently necessitate those roles.

Stated at [§3.2.5 — Shape of Possibility](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.5%20Shape%20of%20Possibility).
