> [!argument]
> **The Necessity of Nature** · *The Cogito-to-S5 Pipeline*
>
> 1. **Reality has no real exterior.** Every real alternative therefore belongs to Reality’s complete range. R is the whole (*No Exteriority*, [[1.1 Reality|§1.1]])
> 2. **Every contentful proposition is either really possible or really impossible.** ◇P ∨ ¬◇P (*Modal Exhaustiveness*, [[2.1 The S5 Pipeline#2.1.1 Modal Bivalence|§2.1.1]])
> 3. **Real possibility reports membership in that complete range.** It is not merely what is reachable from one local configuration. ◇P ↔ Capacity(R,P) ([[1.2 Modal Status#1.2.1 Possibility|§1.2.1]])
> 4. **Modal status answers to Reality’s complete permitting-and-precluding boundary.** Local arrangements can vary without replacing that boundary (*Modal Constitution*, [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]])
> 5. **Impossibility is invariant.** An evaluation admitting an excluded P would either be real and already within R—so P was not excluded—or unreal and irrelevant to real possibility. ¬◇P → □¬◇P (*Invariant Exclusion*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 6. **Possibility is invariant.** Modal Bivalence makes possibility the complement of that fixed exclusion: if P is within R’s complete range, no local evaluation can exclude it from that same range. ◇P → □◇P (*Invariant Complement*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 7. **Thus the modal status of every fixed P—qualitative or singular—is invariant across every real evaluation.** Local reachability may vary, but no variation supplies a second real modal maximum. (◇P → □◇P) ∧ (¬◇P → □¬◇P) (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 8. **Change is actual, and therefore possible.** Doubting change itself enacts a transition from not entertaining that doubt to entertaining it. C; therefore ◇C (*Cartesian Certainty*, [[2.2 Cartesian Certainty|§2.2]]). A second witness reaches the same line: movement is really possible, and movement is one species of Change, so ◇M entails ◇C ([[2.4 Structural Requirement#2.4.9 Forward Conditional Necessity|§2.4.9]]).
> 9. **Therefore, the possibility of Change is necessary.** □◇C (*Necessary Possibility of Change*, from 7 and 8, [[2.3 Necessary Possibility of Change|§2.3]])
> 10. **Change can be possible only where Temporality, Spatiality, and Substantiality obtain.** □(◇C → (T∧S∧Φ)) (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]])
> 11. **Therefore, those three Conditions necessarily obtain.** □(T∧S∧Φ) (*Triconditional Necessity*, from 9 and 10 by necessity distribution and modus ponens, [[2.5 Triconditional Necessity|§2.5]])
> 12. **The Conditions are not three coincident requirements but three mutually implicating aspects of one operative structure.** *Nature* names that structure (*Triconditional Identity*, [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])
> 13. **Nothing real remains outside Nature’s field; given Structural Individuation, nothing remains alongside it as a nonstructural surplus.** Any alleged surplus must have a determinate way to be within Nature’s field. A positive individuator belongs to the complete structure; a primitivist who denies that concrete individuation needs such a ground blocks this identity step while retaining field inclusion. Given [[Structural Individuation]], N = R (*Reality–Nature Identity*, [[2.8 Reality–Nature Identity|§2.8]])
> 14. **∴ Reality is Nature, and its temporal, spatial, and substantial structure is necessary.** The theorem does not determine which configurations occupy that structure. (N = R) ∧ □(T∧S∧Φ).

Stated at [§2.9 — 2.9 The Whole Line](../../2.%20The%20Argument/2.9%20The%20Whole%20Line.md).

## Also stated

> [!argument]
> **The Necessity of Nature** · *The Cogito-to-S5 Pipeline*
>
> 1. **Reality has no real exterior.** Every real alternative therefore belongs to Reality’s complete range. R is the whole (*No Exteriority*, [[1.1 Reality|§1.1]])
> 2. **Every contentful proposition is either really possible or really impossible.** ◇P ∨ ¬◇P (*Modal Exhaustiveness*, [[2.1 The S5 Pipeline#2.1.1 Modal Bivalence|§2.1.1]])
> 3. **Real possibility reports membership in that complete range.** It is not merely what is reachable from one local configuration. ◇P ↔ Capacity(R,P) ([[1.2 Modal Status#1.2.1 Possibility|§1.2.1]])
> 4. **Modal status answers to Reality’s complete permitting-and-precluding boundary.** Local arrangements can vary without replacing that boundary (*Modal Constitution*, [[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]])
> 5. **Impossibility is invariant.** An evaluation admitting an excluded P would either be real and already within R—so P was not excluded—or unreal and irrelevant to real possibility. ¬◇P → □¬◇P (*Invariant Exclusion*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 6. **Possibility is invariant.** Modal Bivalence makes possibility the complement of that fixed exclusion: if P is within R’s complete range, no local evaluation can exclude it from that same range. ◇P → □◇P (*Invariant Complement*, [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]])
> 7. **Thus the modal status of every fixed P—qualitative or singular—is invariant across every real evaluation.** Local reachability may vary, but no variation supplies a second real modal maximum. (◇P → □◇P) ∧ (¬◇P → □¬◇P) (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 8. **Change is actual, and therefore possible.** Doubting change itself enacts a transition from not entertaining that doubt to entertaining it. C; therefore ◇C (*Cartesian Certainty*, [[2.2 Cartesian Certainty|§2.2]])
> 9. **Therefore, the possibility of Change is necessary.** □◇C (*Necessary Possibility of Change*, from 7 and 8, [[2.3 Necessary Possibility of Change|§2.3]])
> 10. **Change can be possible only where Temporality, Spatiality, and Substantiality obtain.** □(◇C → (T∧S∧Φ)) (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]])
> 11. **Therefore, those three Conditions necessarily obtain.** □(T∧S∧Φ) (*Triconditional Necessity*, from 9 and 10 by necessity distribution and modus ponens, [[2.5 Triconditional Necessity|§2.5]])
> 12. **The Conditions are not three coincident requirements but three mutually implicating aspects of one operative structure.** *Nature* names that structure (*Triconditional Identity*, [[2.6 Triconditionality of Nature#2.6.10 Triconditional Identity|§2.6.10]])
> 13. **Nothing real remains outside Nature’s field; given Structural Individuation, nothing remains alongside it as a nonstructural surplus.** Any alleged surplus must have a determinate way to be within Nature’s field. A positive individuator belongs to the complete structure; a primitivist who denies that concrete individuation needs such a ground blocks this identity step while retaining field inclusion. Given [[Structural Individuation]], N = R (*Reality–Nature Identity*, [[2.8 Reality–Nature Identity|§2.8]])
> 14. **∴ Reality is Nature, and its temporal, spatial, and substantial structure is necessary.** The theorem does not determine which configurations occupy that structure. (N = R) ∧ □(T∧S∧Φ).

Stated at [Appendix A - Modal Logic Primer — Appendix A - Modal Logic Primer](../../14.%20Appendices/Appendix%20A%20-%20Modal%20Logic%20Primer.md).

## Also stated

> [!argument]
> **The Necessity of Nature** · *The Cogito-to-S5 Pipeline*
>
> 1. **Reality has no real exterior.** Every real alternative therefore belongs to Reality’s complete range. R is the whole.
> 2. **Every contentful proposition is either really possible or really impossible.** ◇P ∨ ¬◇P.
> 3. **Real possibility reports membership in that complete range.** ◇P ↔ Capacity(R,P).
> 4. **Modal status answers to Reality’s complete permitting-and-precluding boundary, not to a local arrangement.**
> 5. **Impossibility is invariant.** ¬◇P → □¬◇P.
> 6. **Possibility is invariant.** ◇P → □◇P.
> 7. **Thus the modal status of every fixed P—qualitative or singular—is invariant across every real evaluation.** (◇P → □◇P) ∧ (¬◇P → □¬◇P).
> 8. **Change is actual, and therefore possible.** C; therefore ◇C.
> 9. **Therefore, the possibility of Change is necessary.** □◇C.
> 10. **Change can be possible only where Temporality, Spatiality, and Substantiality obtain.** □(◇C → (T∧S∧Φ)).
> 11. **Therefore, those three Conditions necessarily obtain.** □(T∧S∧Φ).
> 12. **The Conditions are three mutually implicating aspects of one operative structure.** *Nature* names that structure.
> 13. **Nothing real remains outside Nature’s field; given Structural Individuation, no nonstructural surplus remains alongside it.** N = R.
> 14. **∴ Reality is Nature, and its temporal, spatial, and substantial structure is necessary.** (N = R) ∧ □(T∧S∧Φ).

Stated at [Appendix B - Summary of the Formal Proof — Appendix B - Summary of the Formal Proof](../../14.%20Appendices/Appendix%20B%20-%20Summary%20of%20the%20Formal%20Proof.md).
