> [!argument]
> **Conditions on There Being a Mind** · *The Idealist Inversion*
>
> 1. **Any mind invoked to ground or constitute a world must be capable of hosting structured content.** Otherwise it cannot perform the explanatory role for which idealism invokes it.
> 1. **Hosting structured content requires distinguishable terms, order among them, and something that bears them.** These are Spatiality, Temporality, and Substantiality at role-resolution.
> 1. **So any mind capable of grounding or constituting a world already instantiates the Conditions.** Remove distinction, order, and bearing, and no candidate remains for the stipulated role.
> 1. **∴ Idealism can relocate the Conditions into a fundamental mind, but it cannot remove them from Reality.** Fundamentality fixes explanatory order; it does not exempt the proposed fundamental from the structure required to play its role.
>
> *Scope.* This is a relocation verdict rather than an incoherence one: the conditions are granted and re-housed, not removed, and the position stays live wherever it disputes the type-level claims rather than the roles. Whether a contentless or objectless awareness hosts no world at all is a separate question, engaged at [[5.16 Spirituality#5.16.5 Conclusions|§5.16.5]].

Stated at [§9.5 — 9.5 Idealism](../../9.%20Physics%20and%20Mind/9.5%20Idealism.md).
