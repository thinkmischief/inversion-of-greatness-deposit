> [!argument]
> **Conditions on There Being a Mind** · *The Idealist Inversion*
>
> 1. **The idealist inference runs from a premise about priority to a conclusion about reality.** Because mind is where the conditions are met—in perception, in intuition, in constitution—the conditions are held to be features of mind rather than of what there is.
> 1. **To be a mind of the relevant kind is already to host content.** And to host content is to sustain distinguishable items (S) in an ordered succession (T) borne by something that persists through it (Φ).
> 1. **Remove all distinction, succession, and persistence and what remains isn’t a minimal consciousness but no candidate for hosting a world at all.**
> 1. **∴ The conditions the idealist locates in mind are conditions on there being a mind to locate them in.** Fundamentality is a claim about explanatory order; structure is a claim about what the fundamental thing must be like to play its role. Idealism needs the first to deliver the second, and the first leaves the second exactly where it stood.
>
> *Scope.* This is a relocation verdict rather than an incoherence one: the conditions are granted and re-housed, not removed, and the position stays live wherever it disputes the type-level claims rather than the roles. Whether a contentless or objectless awareness hosts no world at all is a separate question, engaged at [[5.16 Spirituality#5.16.5 Conclusions|§5.16.5]].

Stated at [§9.5 — 9.5 Idealism](../../9.%20Physics%20and%20Mind/9.5%20Idealism.md).
