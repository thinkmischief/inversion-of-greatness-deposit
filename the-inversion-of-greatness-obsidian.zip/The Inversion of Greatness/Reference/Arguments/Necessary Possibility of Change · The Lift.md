> [!argument]
> **Necessary Possibility of Change** · *The Lift*
>
> 1. Whatever is possible, its possibility is necessary. ◇P → □◇P (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 1. Change is possible, and certain at the very level of its own denial (to deny it would itself be a change). ◇C (*Possibility of Change*, Cartesian Certainty, [[2.2 Cartesian Certainty|§2.2]])
> 1. ∴ The possibility of change is necessary. □◇C

Stated at [§2.3 — 2.3 Necessary Possibility of Change](../../2.%20The%20Argument/2.3%20Necessary%20Possibility%20of%20Change.md).
