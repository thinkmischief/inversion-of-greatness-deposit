> [!argument]
> **Necessary Possibility of Change** · *The Performative Witness*
>
> 1. To deny ◇C is to perform an act: an act of denial, affirmation, or even of entertaining the question.
> 1. By [[1.3 Change|§1.3]], that act is a passage from not-denying to denying (one state, then another) and so is *itself a change*. At any world where the question is so much as raised, change is therefore *actual*.
> 1. From actuality, possibility follows: ◇C holds at any such world, exhibited in the very act that would refuse it.
> 1. This bare witness is the definitional core of what Chapter 2 sets as Cartesian Certainty ([[2.2 Cartesian Certainty|§2.2]]), stripped of the epistemic apparatus and used here only as a ◇C-witness, never as a premise toward S5.
> 1. ∴ ◇C holds at every *thinking* world. The witness reaches no further on its own: the *silent* worlds (those with no thinker to token the act) are deferred to [[3.5 What the Convergence Shows#3.5.4 No Reverse Lift|§3.5.4]].

Stated at [§3.1.3 — The Performative Witness](../../3.%20Convergence/3.1%20Necessary%20Possibility%20of%20Change%20-%20Stress-Tested.md#3.1.3%20The%20Performative%20Witness).
