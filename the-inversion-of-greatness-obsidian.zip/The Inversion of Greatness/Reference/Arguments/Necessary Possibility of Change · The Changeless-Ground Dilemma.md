> [!argument]
> **Necessary Possibility of Change** · *The Changeless-Ground Dilemma*
>
> 1. Suppose a *changeless* ground, a being or principle on which changes depend but which doesn’t itself undergo transition.
> 1. Its changelessness doesn’t imply ¬◇C: if grounded changes occur or are possible, they themselves witness ◇C.
> 1. The live question is whether the ground can perform a grounding role while lacking every structural role involved in that role.
> 1. If the candidate has no determinate character and stands in no directed, differentiating, or obtaining relation to what it grounds, it supplies no grounding fact. If it has such determinate relational character, it instantiates the thin roles of order, difference, and bearing, though that doesn’t yet establish full temporal succession, spatial extension, or causal persistence in the ground itself.
> 1. ∴ A wholly unstructured changeless ground cannot ground change. A structured but non-changing ground remains a live type-level proposal for later engagement. The dilemma therefore reinforces role-level structure; it doesn’t independently establish □◇C.

Stated at [§3.1.1 — The Changeless-Ground Dilemma](../../3.%20Convergence/3.1%20Necessary%20Possibility%20of%20Change%20-%20Stress-Tested.md#3.1.1%20The%20Changeless-Ground%20Dilemma).
