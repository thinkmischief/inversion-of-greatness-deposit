> [!argument]
> **What the Variables Range Over** · *The Quinean Inversion*
>
> 1. **Ontological commitment is fixed by what our best science must quantify over.** This is Quine’s own criterion, not one imported to embarrass him ([[2.9 The Whole Line#2.9.3 No Privileged Floor|§2.9.3]]).
> 1. **Any nomological practice quantifies ineliminably over a structured succession of distinguishable, causally interacting items.** The structural conditions aren’t an optional modal overlay laid on the science; they are what its bound variables range over.
> 1. **No nomological practice can decline them.** Rival sciences, future regimentations, and Quine’s own meta-theory alike must range over them. Which predicates can be extended to new cases varies from science to science; the structural conditions don’t, because they are the conditions under which any predicate can be extended that way at all.
> 1. **∴ Quinean indispensability commits the practice to whatever temporal, relational, and physical ontology its best regimentation genuinely quantifies over.** The skepticism is about modal vocabulary; the commitment is read off the variables, and the variables were never modal vocabulary.
>
> *Scope.* Identifying that ontology exactly with T, S, and Φ requires the independent role and realizer arguments; the criterion alone doesn’t supply the identification. The framework-independence earned here is the thin kind of [[7.1.6 Metaontological Deflationism|§7.1.6]]—conditions no framework can refuse, not a privileged carving lying behind every framework.

Stated at [§7.1.3 — 7.1.3 Quinean Modal Skepticism](../../7.%20Modality/7.1.3%20Quinean%20Modal%20Skepticism.md).
