> [!argument]
> **What the Variables Range Over** · *The Quinean Inversion*
>
> 1. **A theory’s ontological commitments are fixed by what the bound variables of its best regimentation must range over.** This is Quine’s own criterion, not one imported to embarrass him ([[2.9 The Whole Line#2.9.3 No Privileged Floor|§2.9.3]]).
> 1. **Nomological practice requires repeatable assignments to distinguishable items or states, comparisons across an order, and a domain that bears those assignments.** These roles are used in stating, testing, and extending laws whether the regularities are productive or Humean.
> 1. **Removing modal vocabulary does not remove those commitments.** Rival sciences may regiment the roles differently, but a practice that states and projects laws must still quantify over whatever realizes them.
> 1. **∴ Quinean austerity commits nomological practice to the bearers, relations, and ordered differences its best regimentation genuinely quantifies over.** The skepticism can remove modal words; it cannot remove the ontology read from the variables.
>
> *Scope.* Identifying that ontology exactly with T, S, and Φ requires the independent role and realizer arguments; the criterion alone doesn’t supply the identification. The framework-independence earned here is the thin kind of [[7.1.6 Metaontological Deflationism|§7.1.6]]—conditions no framework can refuse, not a privileged carving lying behind every framework.

Stated at [§7.1.3 — 7.1.3 Quinean Modal Skepticism](../../7.%20Modality/7.1.3%20Quinean%20Modal%20Skepticism.md).
