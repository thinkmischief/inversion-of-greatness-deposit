> [!argument]
> **Incoherence of ∅** · *The No-World Reductio*
>
> 1. Define ∅ as absolute absence: no time, no place, no thing, no domain, no bearer, no fact-profile, no evaluation structure, and no Reality there to be one way rather than another. It is not an objectless world; it is the withdrawal of worldhood.
> 1. By [[Way–Possibility Convertibility]], ◇P iff there is a determinate way Reality could be such that P. A modal witness is the represented way itself, not the representation used to describe it.
> 1. Suppose ◇∅. Then there is a determinate way Reality could be in which there is no Reality, no way, and nothing with which worldhood could consist.
> 1. That supposition cancels its own witness. If anything remains that can be the way, bear a truth-profile, or distinguish that candidate from another, the candidate is an objectless or otherwise sparse *world*, not ∅. If nothing remains, there is no member of the modal range.
> 1. An ersatz description or empty formal model doesn’t restore the witness. It is a structured item in Reality whose syntax may *say* “nothing”; its existence and structure belong to the representation, while the represented no-world supplies no way for it to represent. Treating the model’s structure as the content instead changes the target back into a structured empty world.
> 1. ∴ ∅ ∉ Range(R), and therefore ¬◇∅.
>
> *Scope.* This conclusion does **not** arise because the meta-level sentence “∅ obtains at w” becomes a fact *inside* w. That inference would confuse a truth about a representation with content represented as internal to the world. Nor does it exclude objectless, abstracta-only, empty-domain, or changeless worlds merely by name; any such candidate that retains worldhood is not ∅. Finally, ¬◇∅ by itself doesn’t yield □(T ∧ S ∧ Φ). The full modal-core conjunction remains the Chapter 2 theorem. Triconditional Cross-Entailment supplies only the further, Operative-Role-Bridge-indexed claim about one concrete change-realizer; it cannot be used to lift the Null-State result into field-level necessity.

Stated at [§3.2.6 — The Null-State Reductio](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.6%20The%20Null-State%20Reductio).
