> [!argument]
> **Modal Self-Sustenance** · *The Negative Direction*
>
> 1. Under no evaluation of R does ⊥ obtain.
> 1. So ⊥ is impossible under every evaluation of R: □¬◇⊥.
> 1. ∴ Necessarily something is impossible: □∃P: ¬◇P.

Stated at [§2.1.3 — Modal Constitution](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).
