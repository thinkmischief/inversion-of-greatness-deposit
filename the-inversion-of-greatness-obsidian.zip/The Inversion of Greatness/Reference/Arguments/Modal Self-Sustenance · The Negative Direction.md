> [!argument]
> **Modal Self-Sustenance** · *The Negative Direction*
>
> Let P range over propositions.
> 1. Under no evaluation of R does the contradiction ⊥ obtain.
> 1. So ⊥ is impossible under every evaluation of R: □¬◇⊥.
> 1. ∴ Every evaluation has at least one impossible proposition—namely ⊥: □∃P(¬◇P).

Stated at [§2.1.3 — Modal Constitution](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).
