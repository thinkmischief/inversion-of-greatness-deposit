> [!argument]
> **The Modal Ontological Reductio** · *The Three-Conditions Line*
>
> 1. **Possibly, a maximally great being necessarily exists.** ◇□MGB.
> 1. **A maximally great being necessarily knows, wills, and has the power to act.** Maximal greatness includes maximal excellence in every possible world.
> 1. **Knowing, willing, and possessing a determinate power to act require Temporality, Spatiality, and Substantiality.** A concrete personal operation or power requires an order in which it is articulated, a determinate contrast and relation distinguishing its terms, and a subject that bears it ([[Concrete-Entity Test]], [[Necessary Occupancy]], [[Power Is a This-Rather-Than-That]]).
> 1. **The classical maximally great being is claimed to exist without Temporality, Spatiality, or Substantiality.** No temporal, spatial-relational, substantial, or determinately analogous structure belongs to the candidate.
> 1. **Therefore, the candidate cannot know, will, or possess a determinate power to act.** It lacks the conditions required for the personal excellences that make it maximally great.
> 1. **A being that cannot know, will, or possess a determinate power to act is not maximally great.** So nothing possible answers to the conjunction in the opening premise: ¬◇CG₀. By modal duality, □¬CG₀.
>
> **∴ The classical maximally great being so described necessarily does not exist.**
>
> *Scope.* CG₀ names the conjunction displayed here: necessary maximal excellence, concrete personal powers, and denial of T, S, and Φ together with every determinate analogue that could perform their roles. Plantinga’s thinner maximal-greatness predicate is not made impossible by this reductio alone. An analogical, essence-prior, temporal, embedded, or otherwise revisionary candidate exits premise 4 and carries its own specification, contact, and aseity burdens forward.

Stated at [[10.1.1 The Modal Ontological Argument|§10.1.1]].
