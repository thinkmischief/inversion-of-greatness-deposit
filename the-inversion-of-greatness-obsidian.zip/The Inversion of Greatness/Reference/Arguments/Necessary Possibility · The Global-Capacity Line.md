> [!argument]
> **Necessary Possibility** · *The Global-Capacity Line*
>
> 1. R has no real exterior: there is no vantage on Reality from outside it, and nothing real stands beyond the one whole (*No Exteriority*, [[1.1 Reality|§1.1]])
> 1. By Modal Bivalence, either Capacity(R,P) or ¬Capacity(R,P): P is admitted or excluded.
> 1. ¬Capacity(R,P) means that no genuinely admissible configuration of R contains P. An alleged evaluation containing P is therefore either admitted by R—in which case P wasn’t excluded—or not a real alternative.
> 1. Genuine impossibility is consequently invariant: ¬◇P → □¬◇P.
> 1. Possibility is the complement of that fixed exclusion boundary. If P could pass from possible to impossible, the boundary would have changed.
> 1. ∴ Genuine possibility is consequently invariant: ◇P → □◇P.

Stated at [§2.1 — 2.1 The S5 Pipeline](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md).
