> [!argument]
> **Incoherence of ∅** · *The Temporal Form*
>
> 1. For t to be a past time at all is for t to stand in succession-relations—Temporality-facts at t. So Past(∅) entails T at t.
> 1. By definition, ∅ is the joint absence of T, S, and Φ; for ∅ to obtain at t is for Temporality to be absent at t. So Past(∅) entails ¬T at t.
> 1. ∴ Past(∅) entails both T and ¬T at the same evaluation point t. So ∅ obtained at no past time: ¬Past(∅).

Stated at [§2.7.2 — Incoherence of ∅](../../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.2%20Incoherence%20of%20%E2%88%85).
