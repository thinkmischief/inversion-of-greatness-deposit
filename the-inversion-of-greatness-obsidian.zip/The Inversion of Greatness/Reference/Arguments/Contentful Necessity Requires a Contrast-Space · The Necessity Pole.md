> [!argument]
> **Contentful Necessity Requires a Contrast-Space** · *The Necessity Pole*
>
> 1. **The symbol □ can be interpreted on a one-point modal frame.** In that frame, however, □P and P have the same extension: necessity marks no contrast with actuality.
> 1. **For “necessarily P” to say something substantively modal beyond “P,” it must hold P fixed across admissible alternatives.** The contrast need not include a ¬P-world; P may hold throughout. What must be non-trivial is the range across which its invariance is assessed.
> 1. **So substantively contentful necessity commits its user to a contrast-space of admissible ways.** This conceptual commitment corroborates a non-trivial modal range; operator-usage alone does not prove that the range is metaphysically populated.
> 1. **By Way–Possibility Convertibility, each admissible possibility is a determinate way.** Determinacy supplies D (determinate difference). O (directed order) requires the separately defended directed-arrangement premise; B (bearing or realization) requires the separate bearer/realizer premise.
> 1. **∴ The necessity pole independently reaches the difference-role and conditionally reaches O∧D∧B when the direction and bearer premises are added.** It does not establish □(T ∧ S ∧ Φ), identify the generic roles with the Conditions, or prove the populated contrast-space that Modal Self-Sustenance establishes separately ([[2.1 The S5 Pipeline#2.1.3 Modal Constitution|§2.1.3]]).

Stated at [§3.2.5 — Shape of Possibility](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.5%20Shape%20of%20Possibility).
