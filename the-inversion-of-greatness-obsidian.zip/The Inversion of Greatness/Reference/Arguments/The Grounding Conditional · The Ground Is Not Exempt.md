> [!argument]
> **The Grounding Conditional** · *The Ground Is Not Exempt*
>
> 1. **Grounding anything already costs order, difference, and a bearer.** Any grounding relation Grounds(x,y) requires asymmetric priority (the T-role), real differentiation of x from y (the S-role), and a real fact or realizer in which the relation obtains (the Φ-role).
> 1. **That cost is paid at every level of the stack, including the bottom one.** Whenever Grounds(x,y) holds, at any level of an ontological stack, those three roles are instantiated at the level of the ground.
> 1. **∴ A ground of change cannot be exempt from what grounding requires.** Any coherent ground of actual change instantiates directed order, differentiation, and bearing—the generic role-floor Chapter 3 writes O∧D∧B ([[3.2 Triconditional Necessity - From Below|§3.2]]), not the modal-core Conditions.
>
> *Scope.* The line doesn’t by itself identify their concrete types. Temporal succession, spatial extension, and causal persistence require the separate realizer arguments developed later.

Stated at [§2.2.2 — Actuality’s Reach](../../2.%20The%20Argument/2.2%20Cartesian%20Certainty.md#2.2.2%20Actuality%E2%80%99s%20Reach).
