> [!argument]
> **Reality–Nature Identity** · *The Role-Semantics Constraint*
>
> 1. “Reality” functions as a definite structural description: the unique totality to which every real content belongs ([[1.1 Reality|§1.1]]).
> 1. **“Nature” here names that same totality under its positive structural description.** At this stage, “Nature” names that totality insofar as it is constituted by the positive T/S/Φ structure; it must not be confused with the abstract role-list alone ([[1.4 Three Conditions|§1.4]]).
> 1. **Reality keeps that structure under every modal evaluation.** *(Canonical field result.)* Under every modal evaluation, Reality retains its T/S/Φ constitution; Chapter 3’s generic role-floor corroborates but doesn’t independently establish that modal-core claim.
> 1. **Satisfying a role necessarily doesn’t by itself make the role-term and the bearer the same thing.** Necessary satisfaction of a role doesn’t by itself entail that the role-term, the role-list, and the bearer co-refer.
> 1. If maximality establishes one all-inclusive bearer and the No-Individuating-Surplus criterion excludes a further real item beyond its structural constitution ([[3. Convergence/3.4 Reality–Nature Identity#3.4.1 No Outside|§3.4.1]], 3.4.3), then “Reality” and “Nature” pick out that same totality.
> 1. **∴ The identity is carried by the field theorem, not by role semantics alone.** □(R = N) is carried by the canonical field theorem plus maximality and no-surplus—not by role semantics or Chapter 3’s generic floor alone.

Stated at [§3.4.2 — One Role, One Occupant](../../3.%20Convergence/3.4%20Reality%E2%80%93Nature%20Identity.md#3.4.2%20One%20Role,%20One%20Occupant).
