> [!argument]
> **Facthood Requires Difference and Bearing** · *The Facthood Line*
>
> 1. Something is the case. Its denial, “nothing is the case,” is performatively self-refuting: the claim is itself something being the case ([[2.4 Structural Requirement#2.4.4 Something Must Be|§2.4.4]]).
> 1. Any state of affairs is *this rather than that*: a real distinction—the determinate-difference role, not yet the loaded Spatiality it is identified with at [[1.4 Three Conditions|§1.4]].
> 1. Any state *obtains rather than not*: this supplies exclusion and polarity, but not yet temporal or influence-carrying direction. The contrast between P and ¬P isn’t a before/after order.
> 1. Any state is *borne, not merely described*: there is a fact or realizer in which its obtaining consists—the thin bearing-role, not yet causal persistence across an interval.
> 1. ∴ Bare facthood secures D and B at the level of generic roles. O requires a separate directed-dependence or succession premise; the modal-core Conditions require Chapter 2’s bilateral identification.
>
> *Scope.* The thinker-free ∅ result is narrower: possibility ranges over ways Reality could be, while ∅ withdraws not merely occupants but the way and worldhood themselves. This yields ¬◇∅ ([[3.2 Triconditional Necessity - From Below#3.2.6 The Null-State Reductio|§3.2.6]]), not □(T ∧ S ∧ Φ) from facthood alone.

Stated at [§3.2.1 — Something Is the Case](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.1%20Something%20Is%20the%20Case).
