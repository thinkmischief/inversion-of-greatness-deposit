> [!argument]
> **Modal Self-Sustenance** · *The Positive Direction*
>
> 1. Under every evaluation of R, ⊤ obtains.
> 1. Whatever actually obtains demonstrates a corresponding capacity in R.
> 1. ∴ ⊤ is possible under every evaluation of R: □◇⊤. Therefore necessarily something is possible: □∃P: ◇P.

Stated at [§2.1.3 — Modal Constitution](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).
