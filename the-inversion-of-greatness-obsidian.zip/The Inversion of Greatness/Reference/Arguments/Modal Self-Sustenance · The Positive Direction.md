> [!argument]
> **Modal Self-Sustenance** · *The Positive Direction*
>
> Let P range over propositions.
> 1. Under every evaluation of R, the tautology ⊤ obtains.
> 1. Whatever obtains at an evaluation is within R’s admissible range and is therefore possible.
> 1. ∴ Every evaluation has at least one possible proposition—namely ⊤: □∃P(◇P). Equivalently, □◇⊤.

Stated at [§2.1.3 — Modal Constitution](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.3%20Modal%20Constitution).
