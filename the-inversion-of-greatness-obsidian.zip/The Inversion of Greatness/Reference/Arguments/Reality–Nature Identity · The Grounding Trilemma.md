> [!argument]
> **Reality–Nature Identity** · *The Grounding Trilemma*
>
> 1. Let g be a proposed ground additional to Nature. Relative to Nature, g must either (i) ground Nature, (ii) be grounded by Nature, or (iii) stand in no grounding relation to Nature. A grounding relation between g and Nature either runs in one direction, the other, or fails to obtain, so the three positions exhaust the field; asymmetry ([[1.5 Existence#1.5.5 Ground and Dependence|§1.5.5]]) keeps the first two from collapsing into one.
> 1. If g grounds Nature, the grounding relation must be directed from ground to grounded, distinguish g from what it grounds, and obtain as a real dependence rather than a verbal pairing. At the level of generic roles, those are O, D, and B. The proposed external ground therefore incurs generic content; whether it instantiates T, S, and Φ is the separate question of moving from those roles to the specific Conditions ([[3. Convergence/3.1 Necessary Possibility of Change - Stress-Tested#3.1.5 The Witness and Its Ground|§3.1.5]]).
> 1. If g is grounded by Nature, g is derivative within the dependence order Nature constitutes. It may be a real configuration, but it isn’t an additional ground of Reality over and above Nature.
> 1. If g stands in no grounding relation to Nature, it doesn’t ground Nature. It may remain an idle posit, but it cannot fill the role under dispute.
> 1. Therefore no additional candidate occupies the ground-of-Nature position from a contentless outside. Every candidate either incurs directed order, difference, and bearing in the grounding relation, is derivative within the field, or performs no grounding work. Whether the first horn instantiates the loaded Conditions remains the role-to-type dispute.
> 1. ∴ No candidate supplements Nature in the specific role of grounding Nature from a contentless outside.
>
> *Scope.* The first horn leaves the role-to-type dispute open; the third leaves open idle surplus. The full R = N theorem is inherited from Chapter 2, with the residue argument summarized at [[3. Convergence/3.4 Reality–Nature Identity#3.4.3 No Residue|No Residue (§3.4.3)]].

Stated at [§3.4.4 — Nothing Additional](../../3.%20Convergence/3.4%20Reality%E2%80%93Nature%20Identity.md#3.4.4%20Nothing%20Additional).
