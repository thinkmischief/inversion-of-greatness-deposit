> [!argument]
> **Triconditional Necessity** · *The Full Line*
>
> 1. Real possibility is Capacity(R,P), the standing capacity of R, not local reachability. Therefore whatever is really possible is necessarily possible. ◇P → □◇P (*Necessary Possibility*)
> 1. Change is possible, certain at the very level of its own denial (Cartesian Certainty, §2.2). ◇C (*Possibility of Change*)
> 1. From (1): apply the theorem to change itself. ◇C → □◇C
> 1. From (2) and (3), modus ponens necessitates the possibility of change. □◇C (*Necessary Possibility of Change*)
> 1. Necessarily, the possibility of change cannot obtain without the three Conditions. □(◇C → (T∧S∧Φ)) (*Structural Requirement*)
> 1. From (5): the K axiom carries necessity across the conditional. □◇C → □(T∧S∧Φ)
> 1. ∴ From (4) and (6), by modus ponens: the three Conditions hold of necessity. □(T∧S∧Φ)

Stated at [§2.5 — 2.5 Triconditional Necessity](../../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md).
