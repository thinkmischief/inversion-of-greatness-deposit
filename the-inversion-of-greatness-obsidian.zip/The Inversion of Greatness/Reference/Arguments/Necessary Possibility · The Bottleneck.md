> [!argument]
> **Necessary Possibility** · *The Bottleneck*
>
> 1. R has no real exterior (*No Exteriority*, [[1.1 Reality|§1.1]])
> 1. If a supposedly different total horizon is a real alternative, it already belongs to R’s range. If it shares no Reality within which it can be an alternative, it doesn’t vary one Reality’s capacity.
> 1. Therefore no real evaluation crosses the exclusion boundary: ¬◇P → □¬◇P.
> 1. ∴ By Modal Bivalence, possibility is the complement of that fixed exclusion: ◇P → □◇P.
>
> *Scope.* Local reachability may vary within the range; the real modal verdict doesn’t. The notation is the one fixed at [[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]].

Stated at [§2.1.5 — The S5 Bottleneck](../../2.%20The%20Argument/2.1%20The%20S5%20Pipeline.md#2.1.5%20The%20S5%20Bottleneck).
