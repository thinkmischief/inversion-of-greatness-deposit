> [!argument]
> **Triconditional Necessity** · *Closing the Impossibility Escape*
>
> 1. Some substantial impossibilities are paradigm cases: the stone too heavy to be lifted, the immovable meeting the irresistible, two bodies co-located.
> 1. Each requires determinate relata and relational profiles: a bearer related to a lifting power, opposed directed powers borne by distinct relata, or distinct bodies assigned one location.
> 1. Where a case includes an attempted act, collision, or transition, it also requires ordered change; co-location by itself doesn’t.
> 1. The cases therefore supply no unstructured outside. Each remains articulated through some of the roles whose modal-core realization Chapter 2 identifies.
> 1. The lift from “operative in this case” to “necessary” isn’t made here. The canonical □(T ∧ S ∧ Φ) remains the Chapter 2 result; §3.2’s ∅-criterion and §3.3.4’s conceivability diagnosis don’t independently derive it.
> 1. ∴ *given* the upstream theorem, these substantial impossibility examples illustrate how impossibility remains articulated even in what it forecloses. They don’t provide a case-independent route to T ∧ S ∧ Φ or extend the theorem’s proof.

Stated at [§3.3.5 — The Impossibility Escape](../../3.%20Convergence/3.3%20Triconditional%20Necessity%20-%20From%20Above.md#3.3.5%20The%20Impossibility%20Escape).
