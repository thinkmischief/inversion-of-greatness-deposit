> [!argument]
> **Triconditional Necessity** · *Lines 7–11 of the Cogito-to-S5 Pipeline*
>
> 7. **Modal status is invariant across every real evaluation.** In particular, whatever is really possible remains possible. ◇P → □◇P (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 8. **Change is actual, and therefore possible.** Doubting change itself enacts a transition from not entertaining that doubt to entertaining it. C; therefore ◇C (*Cartesian Certainty*, [[2.2 Cartesian Certainty|§2.2]])
> 9. **Therefore, the possibility of Change is necessary.** □◇C (*Necessary Possibility of Change*, from 7 and 8, [[2.3 Necessary Possibility of Change|§2.3]])
> 10. **Change can be possible only where Temporality, Spatiality, and Substantiality obtain.** □(◇C → (T∧S∧Φ)) (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]])
> 11. **∴ Those three Conditions necessarily obtain.** □(T∧S∧Φ) (*Triconditional Necessity*, from 9 and 10 by necessity distribution and modus ponens)

Stated at [§2.5 — 2.5 Triconditional Necessity](../../2.%20The%20Argument/2.5%20Triconditional%20Necessity.md).
