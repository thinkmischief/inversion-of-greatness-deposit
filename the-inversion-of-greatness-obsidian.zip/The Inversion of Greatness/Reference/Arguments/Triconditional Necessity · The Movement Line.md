> [!argument]
> **Triconditional Necessity** · *The Movement Line*
>
> 1. Movement is really possible. ◇M (*Movement*, [[2.4 Structural Requirement#2.4.7 Distinction Requires Spatiality|§2.4.7]])
> 1. Whatever is really possible is necessarily possible. ◇P → □◇P (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 1. From (1) and (2): the possibility of movement is necessary. □◇M
> 1. A displacement occupies a before and an after (T), crosses an interval between positions (S), and is undergone by what persists across it (Φ). So necessarily, if movement is really possible, the three Conditions hold. □(◇M → T∧S∧Φ) (*Containment*)
> 1. ∴ From (3) and (4), by the K axiom and modus ponens: the three Conditions hold of necessity. □(T∧S∧Φ)

Stated at [§2.4.9 — Forward Conditional Necessity](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.9%20Forward%20Conditional%20Necessity).
