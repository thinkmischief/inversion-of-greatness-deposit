> [!argument]
> **Necessary Possibility of Change** · *The ∅ Reductio*
>
> 1. Suppose ¬□◇C. Then there is a possible world w₀ in which ◇C fails: change isn’t even possible at w₀.
> 1. By the Modal Identity ([[2.6 Triconditionality of Nature#2.6.6 Modal Identity|§2.6.6]]), □(◇C ↔ (T∧S∧Φ)), read at the **modal-core resolution** fixed in [[2.4 Structural Requirement|§2.4]]. So at w₀, ¬◇C entails ¬(T∧S∧Φ): at least one modal-core Condition fails. This isn’t yet the absence of generic directed order, difference, and bearing, and therefore not yet ∅.
> 1. By the Mutual Containment Result ([[2.6 Triconditionality of Nature#2.6.5 Mutual Containment|§2.6.5]]), T, S, and Φ are instantiated together or not at all in any possible world. So if any one of the three fails at w₀, all three fail at w₀.
> 1. From (2) and (3): T, S, and Φ are jointly uninstantiated at w₀.
> 1. The move from joint modal-core failure to ∅ is a separate substantive bridge, not a definition. By the grade-(iv) disposition ([[2.7 Nothing to Consider#2.7.1 Null State (∅)|§2.7.1]]) and the Conditioned-Nature corollary ([[2.6 Triconditionality of Nature#2.6.12 Conditioned-Nature|§2.6.12]]), any alleged abstract or thinly structured residue is either dependent on Nature’s structural features or a named holdout requiring its own account. Grant that no-free-standing-residue thesis and the joint failure leaves absolute structural absence, ∅. By the Incoherence of ∅ theorem ([[2.7 Nothing to Consider#2.7.2 Incoherence of ∅|§2.7.2]]), ∅ isn’t a possible world. A Platonist or essence-prior objector who rejects the bridge isn’t refuted by the reductio alone; the dispute is routed to [[8.1.5 Platonism|§8.1.5]] and Chapters 8–9.
> 1. ∴ Step 1 posited w₀ as a possible world, so the supposition contradicts itself. □◇C

Stated at [§2.7.4 — Preclusion Boundary](../../2.%20The%20Argument/2.7%20Nothing%20to%20Consider.md#2.7.4%20Preclusion%20Boundary).
