> [!argument]
> **The Necessity of Nature** · *The Cogito-to-S5 Pipeline — Five-Stage Preview*
>
> 1. **The modal status of every fixed contentful P is invariant.** Whatever is possible, its possibility is necessary; whatever is impossible, its impossibility is necessary. Qualitative and singular propositions are both included under the global-capacity operator. (◇P → □◇P) ∧ (¬◇P → □¬◇P) (*Necessary Possibility*, derived in full at [[2.1 The S5 Pipeline|§2.1]])
> 2. **Change is actual, and therefore possible.** Doubting change itself enacts a transition from not entertaining that doubt to entertaining it. ◇C (*Cartesian Certainty*, [[2.2 Cartesian Certainty|§2.2]])
> 3. **Therefore, the possibility of Change is necessary.** □◇C (*Necessary Possibility of Change*, from 1 and 2, [[2.3 Necessary Possibility of Change|§2.3]])
> 4. **Change can be possible only where Temporality, Spatiality, and Substantiality obtain.** □(◇C → (T∧S∧Φ)) (*Structural Requirement*, [[2.4 Structural Requirement|§2.4]])
> 5. **Therefore, those three Conditions necessarily obtain.** □(T∧S∧Φ) (*Triconditional Necessity*, from 3 and 4 by necessity distribution and modus ponens, [[2.5 Triconditional Necessity|§2.5]])

Stated at [§2 — 2. The Argument](../../2.%20The%20Argument/2.%20The%20Argument.md).
