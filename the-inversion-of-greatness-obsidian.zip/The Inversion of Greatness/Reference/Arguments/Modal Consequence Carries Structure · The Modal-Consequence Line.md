> [!argument]
> **Modal Consequence Carries Structure** · *The Modal-Consequence Line*
>
> 1. **Let P and Q be distinct contents joined by a genuine non-trivial one-way relation of metaphysical sufficiency.** P is sufficient for Q, while the converse is not included in the relation.
> 1. **Metaphysical sufficiency is a necessary consequence, not a local regularity.** If no possible realization of P lacks Q, then □(P → Q) ([[Configurational Necessitation]], [[2.9 The Whole Line#2.9.4 Necessity Precedes Contingency|§2.9.4]]).
> 1. **The relation instantiates determinate difference and directed order.** P and Q remain distinct termini, supplying D; sufficiency runs from P to Q, supplying O. Neither claim turns consequence into temporal succession.
> 1. **A genuine modal consequence must obtain as a real constraint.** If the relation is more than a pairing of inscriptions, its obtaining is a modal fact. By the Facthood Line, that fact must be borne as what obtains; necessity preserves the same constraint across admissible evaluations, supplying B ([[3.2 Triconditional Necessity - From Below#3.2.1 Something Is the Case|§3.2.1]]).
> 1. **The schema has an established instance.** Necessity entails possibility, □P → ◇P, while possibility does not in general entail necessity ([[2.1 The S5 Pipeline#2.1.4 Modal Stability|§2.1.4]]). The relation is therefore a non-trivial directed modal consequence rather than an empty form.
> 1. **∴ Every genuine non-trivial one-way modal consequence instantiates O∧D∧B at relation resolution.** The established necessity-to-possibility consequence supplies at least one object-side witness.
>
> *Scope.* The line does not make logical consequence temporal, distinct propositions spatially separated, or an abstract relation causally persistent. It reaches only the generic roles. It neither proves that a proposed P is sufficient for Q nor identifies O/D/B with T/S/Φ; those remain the burdens Configurational Necessitation and the Closed Seam preserve.
>
> **Depends on:** [[Configurational Necessitation]]; [[Necessity entails Possibility]]; [[Facthood Requires Difference and Bearing]]; the distinction between a real modal constraint and its token inscription

Stated at [§3.5.3 — The Closed Seam](../../3.%20Convergence/3.5%20What%20the%20Convergence%20Shows.md#3.5.3%20The%20Closed%20Seam).
