> [!argument]
> **Triconditional Necessity** · *The Structured-Content Line*
>
> 1. Take anything that is the case at all. For it to be the case, it must be *this* rather than *that*: the content is settled one way instead of another.
> 1. ∴ That settled contrast establishes a distinction requirement: content that is this rather than that cannot be an undifferentiated blank. It therefore supports the role of distinctness that the broader derivation identifies with Spatiality.
>
> *Scope.* The line doesn’t independently derive Temporality or Substantiality from determination alone. The neighboring lines supply further partial role-level support and the null-state backstop; Chapter 2 supplies the bilateral identification with T, S, and Φ and the full modal-core theorem.

Stated at [§3.2.3 — Structured Content](../../3.%20Convergence/3.2%20Triconditional%20Necessity%20-%20From%20Below.md#3.2.3%20Structured%20Content).
