> [!argument]
> **Structural Requirement** · *The Movement Limb*
>
> 1. Movement is really possible. ◇M (*Movement*)
> 1. Whatever is really possible is necessarily possible. ◇P → □◇P (*Necessary Possibility*, [[2.1 The S5 Pipeline#2.1.10 Necessary Possibility|§2.1.10]])
> 1. From (1) and (2): □◇M.
> 1. Necessarily, if displacement is really possible, Reality’s constitution includes the relational exteriority a displacement crosses. □(◇M → S) (*Displacement*)
> 1. ∴ From (3) and (4), by the K axiom and modus ponens: □S.

Stated at [§2.4.7 — Distinction Requires Spatiality](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.7%20Distinction%20Requires%20Spatiality).
