> [!argument]
> **Structural Requirement** · *The Temporality Reductio*
>
> Let Beg(x) mean *x begins*.
> 1. Any beginning requires Temporality, since *begins* presupposes a before/after distinction (∀x(Beg(x) → T)).
> 1. Something has begun: there is at least one beginning, demonstrably the present argument’s own utterance (∃xBeg(x)).
> 1. So Temporality is instantiated (∴ T; from 1, 2).
> 1. If Temporality had ever been absent, it would have to begin, since a transition from its absence to its presence is itself a beginning (Beg(T)).
> 1. **Time cannot have begun, because a beginning needs a before.** Any beginning of Temporality would require Temporality already instantiated on the before side of its own onset, since line 1’s warrant—*begins* presupposes a before/after distinction spanning the onset—applies to T itself (Beg(T) → T-at-or-before-Beg(T)).
> 1. ∴ So Temporality was never absent: the supposed onset entails T at or before the first instantiation of T—T-prior-to-T, a contradiction (from 4, 5 by reductio).

Stated at [§2.4.6 — Succession Requires Temporality](../../2.%20The%20Argument/2.4%20Structural%20Requirement.md#2.4.6%20Succession%20Requires%20Temporality).
