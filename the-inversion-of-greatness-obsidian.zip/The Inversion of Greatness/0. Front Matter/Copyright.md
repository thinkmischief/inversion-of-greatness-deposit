*The Inversion of Greatness: From the Nature of Necessity to Maximum Possibility*

Copyright © 2026 Procyon.

**Pre-release of the book.** This is an open pre-release, made available for engagement and review. It hasn’t yet been edited or reviewed by another reader, and it isn’t a numbered edition. A concept DOI identifies the book as a work, and each versioned pre-release snapshot or numbered edition receives its own version DOI. For citation guidance, see How to Cite.

This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License (CC BY-NC 4.0). You are free to share and adapt the material for noncommercial purposes, provided you give appropriate credit, link to the license, and indicate whether changes were made. Commercial use is reserved to the author. To view a copy of this license, visit [https://creativecommons.org/licenses/by-nc/4.0/](https://creativecommons.org/licenses/by-nc/4.0/).

Source files and build tooling are licensed under the MIT License; the full license text is distributed with the project’s source files, available from [https://inversionofgreatness.org](https://inversionofgreatness.org/).

Scripture quotations are from the New Revised Standard Version Updated Edition (NRSVUE) unless otherwise noted, and are cited by the standard abbreviations for the biblical books.

Quotations from third-party works are reproduced under fair use / fair dealing for purposes of criticism, comment, and scholarship, and are attributed to their sources in the References.

Published online and free to read at [https://inversionofgreatness.org](https://inversionofgreatness.org/). Pre-release versions are archived on Zenodo under version DOIs; the concept DOI [10.5281/zenodo.22242970](https://doi.org/10.5281/zenodo.22242970) identifies the book across pre-release deposits, numbered editions, and any future print edition. The deposited files are also mirrored on GitHub at [inversion-of-greatness-deposit](https://github.com/thinkmischief/inversion-of-greatness-deposit).

Produced from a single source with Quarto, an open-source publishing system.


---

← [Home](../Home.md) | [Preface](Preface.md) →
