Something about reality makes reading this possible.

Your eyes are able to move across the page, picking up the meaning of each word along the way. The understanding follows the same order. Each word has a moment, a place, and a form.

Reality also makes certain readings impossible. You can never return to the moment before the reading began, and you can't hold in your mind what hasn’t arrived yet.

*Reality permits. Reality prohibits.*

But what makes reading this possible? And is any of it necessary?

Consider a different case. Flip a coin and it could land heads or tails. But for that flip to happen at all, a coin is necessary. That doesn’t mean the coin itself had to exist, though. It depends on the material, the mint, and the people behind the process—and the chain doesn’t stop there. Follow it back far enough, past the mint, past the people, past anything you’d recognize as stuff at all, and the question presses: does the chain of events ever bottom out, and if so, in what?

The coin is necessary for the *flip*, but what—if anything—is necessary for the history that culminated in the toss?

There aren’t many options: the chain could bottom out in something that just happened to cause it, with no reason or explanation. It could trace back to a necessary being of some sort, one that grounds or sustains everything on top. Or it could run backward forever, each thing depending on something before it, with no bottom or beginning anywhere in sight.

Science makes the question easier to answer in one way, and harder in another. Cosmologists trace the history of the universe back nearly 13.8 billion years. Direct observation reaches the cosmic microwave background, and other models carry us further toward a hot, dense early state. That visible horizon gives the appearance of a bottom—and that’s precisely where theism finds its bite.

Aquinas argued that whatever isn’t necessary on its own must depend on something else. That can’t go on forever, he argued, so something must exist in its own right. Not necessarily earlier—but underneath. Anselm approached the question from the inside. We can *think* of a being so great, no thought can surpass it. But a being lodged in thought isn’t all that great. So the greatest possible being must exist in reality. Leibniz widened the question to the chain itself. Even if every event were explained by an earlier event, why the chain rather than nothing at all? His answer: a being that carries the reason for its existence within itself.

Three different arguments pointing in the same direction: a God, standing beyond the world as its creator and ground—and the source of all that is possible.

Each was met with a response. Hume denied what Aquinas depends on: no first cause can be inferred from the limits of experience alone. Kant denied Anselm from the outside: nothing can be thought into being simply by enriching its definition. Russell denied that the chain needed a reason at all: causes within the world say nothing about whether the world itself is caused.

The arguments never went away, and the objections never closed anything. What narrowed was the ground a successful argument either way would have to stand on. For a while, that ground lay dormant.

Then Kripke opened the door on progress with a new tool: a relational possible-worlds semantics that gave modal logic a precise form [[Bibliography#^ref-kripke1963|(1963)]]—possible, impossible, necessary, each with a settled function—yet unsettled about what those functions described.

Plantinga saw the opportunity to try to overlay those functions with the divine—a being of Maximal Greatness, defined by the necessity of its own existence [[Bibliography#^ref-plantinga1974b|(1974)]]. He argued that if it’s even possible that a necessary being exists, then it must exist—*necessarily*. Then Mackie ran the argument backward: grant that it’s equally possible that a being defined as necessary *does not* exist, and the logic cuts against the definition of God with equal force [[Bibliography#^ref-mackie1982|(1982)]]. If it is even possible for such a being not to exist, then it can't be necessary, and a God who isn’t necessary isn’t a God at all.

That's the whole dispute, and to this day, the symmetry holds—each side still trying to out-conceive the other. And without an anchor, modal logic remains a force without application.

The argument here doesn't enter that dispute. It inverts the direction both sides were looking. It was never about conceivable possibility. It's about what makes conceiving possible at all.

Reading, coin-flipping, and conceiving; each a different activity, each a different cause. But is anything necessary for all three? That's the work to come. But before getting into it, take a look at the opening line one more time:

**Something about reality makes reading this possible.**

Where is the word God?


---

← [Preface](Preface.md) | [1. Groundwork](../1.%20Groundwork/1.%20Groundwork.md) →
